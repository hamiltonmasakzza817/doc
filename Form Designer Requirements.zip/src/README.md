# 表单设计器

一个基于 React 的可视化表单构建工具，支持拖拽式操作、实时预览和属性配置。

## 功能特性

### ✨ 核心功能

- **可视化画布** - 拖放式设计界面，所见即所得
- **组件库** - 丰富的布局和表单组件
- **属性配置** - 实时配置组件样式和属性
- **拖拽交互** - 流畅的拖拽体验，支持重新排序
- **尺寸调整** - 容器、行、列和图片组件支持宽度调整

### 🎯 增强功能

- **组件嵌套** - 支持容器内嵌套其他组件，构建复杂布局
- **表单验证** - 为输入框和选择框配置验证规则
- **撤销/重做** - 完整的历史记录管理
- **数据持久化** - 自动保存到本地存储
- **导入/导出** - 支持 JSON 格式导入导出
- **键盘快捷键** - 提升操作效率
- **错误边界** - 优雅的错误处理
- **组件删除** - 支持删除不需要的组件

## 支持的组件

### 布局组件 (Layout)
- **容器 (Container)** - 通用容器组件，可以包含任意类型的子组件
- **表单容器 (Form Container)** - 表单专用容器，支持表单布局配置和验证规则
- **标签页容器 (Tab Container)** - 多标签页容器，可以组织不同内容到标签页中

### 表单控件 (Form Control)
- **输入框 (Input)** - 文本输入，支持验证规则
- **选择框 (Select)** - 下拉选择，支持验证规则
- **按钮 (Button)** - 操作按钮
- **图片 (Image)** - 图片展示
- **文本 (Text)** - 静态文本

## 快捷键

| 快捷键 | 功能 |
|--------|------|
| `Ctrl/Cmd + Z` | 撤销 |
| `Ctrl/Cmd + Y` 或 `Ctrl/Cmd + Shift + Z` | 重做 |
| `Delete` | 删除选中组件 |
| `Escape` | 取消选择 |

## 使用指南

### 1. 添加组件
- 从左侧组件面板拖拽组件到中间画布
- 组件会自动垂直排列
- **容器组件支持嵌套：** 将组件拖拽到容器内部即可创建嵌套结构

### 2. 嵌套布局
- **容器组件** - 拖拽任意组件到容器内部
- **表单容器** - 拖拽表单控件到表单容器内，可以配置布局方式（垂直/水平/行内）
- **标签页容器** - 拖拽组件到标签页容器内，内容会显示在当前标签页中

### 3. 配置组件
- 点击画布上的组件进行选择
- 右侧属性面板会自动打开
- 配置基本属性（标签、必填项等）
- 配置样式属性（宽度、高度、颜色等）

### 4. 调整尺寸
- 选中容器类组件（容器、行、列、图片）
- 拖动左右边缘调整宽度

### 5. 重新排序
- 在画布上拖拽组件即可重新排序

### 6. 删除组件
- 选中组件后点击右上角红色删除按钮
- 或按 `Delete` 键

### 7. 保存/加载
- 点击工具栏的"保存"按钮保存设计
- 点击"加载"按钮加载之前的设计
- 系统会自动保存当前设计

### 8. 导入/导出
- 点击"导出"下载 JSON 文件
- 点击"导入"加载 JSON 文件

## 技术架构

### 技术栈
- **React 18** - UI 框架
- **TypeScript** - 类型安全
- **Zustand** - 状态管理
- **react-dnd** - 拖拽功能
- **re-resizable** - 尺寸调整
- **Tailwind CSS** - 样式系统
- **Shadcn/ui** - UI 组件库

### 项目结构
```
/
├── components/          # React 组件
│   ├── FormDesigner.tsx    # 主设计器组件
│   ├── Canvas.tsx          # 画布组件
│   ├── ComponentPanel.tsx  # 组件面板
│   ├── PropertiesPanel.tsx # 属性面板
│   ├── Toolbar.tsx         # 工具栏
│   ├── CanvasComponent.tsx # 画布组件包装器
│   ├── FormComponentRenderer.tsx # 组件渲染器
│   ├── ErrorBoundary.tsx   # 错误边界
│   └── ui/                 # UI 基础组件
├── store/               # 状态管理
│   └── form-designer-store.ts # Zustand store
├── types/               # TypeScript 类型定义
│   └── form-designer.ts
└── App.tsx             # 应用入口
```

## 数据模型

### FormComponent
```typescript
interface FormComponent {
  id: string;                    // 唯一标识
  type: ComponentType;           // 组件类型
  label: string;                 // 组件标签
  properties: {                  // 组件属性
    required?: boolean;          // 是否必填
    imageUrl?: string;           // 图片URL
    textContent?: string;        // 文本内容
    options?: string[];          // 选项列表
    placeholder?: string;        // 占位符
    buttonText?: string;         // 按钮文本
    // CSS 属性
    width?: string;
    height?: string;
    padding?: string;
    margin?: string;
    backgroundColor?: string;
    borderRadius?: string;
    border?: string;
  };
  children?: FormComponent[];    // 子组件（未来支持）
}
```

## 未来规划

- [x] 组件嵌套支持
- [x] 表单验证配置
- [ ] 表单预览模式
- [ ] 更多组件类型（日期选择、上传、富文本等）
- [ ] 主题定制
- [ ] 协同编辑
- [ ] 模板库
- [ ] 条件显示逻辑

## 开发说明

本项目使用 Figma Make 构建，支持热重载和实时预览。