import { create } from 'zustand';
import { FormComponent } from '../types/form-designer';

interface HistoryState {
  past: FormComponent[][];
  present: FormComponent[];
  future: FormComponent[][];
}

interface FormDesignerState {
  // 表单组件数据
  components: FormComponent[];
  
  // UI 状态
  selectedComponentId: string | null;
  propertyPanelOpen: boolean;
  
  // 历史记录
  history: HistoryState;
  
  // Actions - 组件操作
  addComponent: (component: FormComponent) => void;
  removeComponent: (componentId: string, parentId?: string) => void;
  updateComponent: (component: FormComponent) => void;
  reorderComponents: (dragIndex: number, hoverIndex: number) => void;
  clearComponents: () => void;
  addChildComponent: (parentId: string, child: FormComponent) => void;
  removeChildComponent: (parentId: string, childId: string) => void;
  
  // Actions - 选择操作
  selectComponent: (componentId: string | null) => void;
  
  // Actions - 属性面板
  openPropertyPanel: () => void;
  closePropertyPanel: () => void;
  
  // Actions - 历史记录
  undo: () => void;
  redo: () => void;
  canUndo: () => boolean;
  canRedo: () => boolean;
  
  // Actions - 数据持久化
  saveToStorage: (name?: string) => void;
  loadFromStorage: (name: string) => void;
  exportAsJSON: () => string;
  importFromJSON: (json: string) => void;
  
  // 获取选中的组件
  getSelectedComponent: () => FormComponent | null;
}

// 存储键
const STORAGE_KEY = 'form-designer-autosave';

export const useFormDesignerStore = create<FormDesignerState>((set, get) => ({
  components: [],
  selectedComponentId: null,
  propertyPanelOpen: false,
  
  history: {
    past: [],
    present: [],
    future: [],
  },
  
  // 添加组件
  addComponent: (component) => {
    set((state) => {
      const newComponents = [...state.components, component];
      return {
        components: newComponents,
        history: {
          past: [...state.history.past, state.components],
          present: newComponents,
          future: [],
        },
      };
    });
    get().saveToStorage();
  },
  
  // 删除组件
  removeComponent: (componentId, parentId) => {
    set((state) => {
      let newComponents: FormComponent[];
      
      if (parentId) {
        // 从父组件的子组件中删除
        newComponents = state.components.map(c => {
          if (c.id === parentId) {
            return {
              ...c,
              children: c.children?.filter(child => child.id !== componentId)
            };
          }
          return c;
        });
      } else {
        // 从根级别删除
        newComponents = state.components.filter(c => c.id !== componentId);
      }
      
      const newSelectedId = state.selectedComponentId === componentId ? null : state.selectedComponentId;
      
      return {
        components: newComponents,
        selectedComponentId: newSelectedId,
        propertyPanelOpen: newSelectedId !== null,
        history: {
          past: [...state.history.past, state.components],
          present: newComponents,
          future: [],
        },
      };
    });
    get().saveToStorage();
  },
  
  // 更新组件
  updateComponent: (updatedComponent) => {
    set((state) => {
      // 递归更新组件（包括子组件）
      const updateComponentRecursive = (components: FormComponent[]): FormComponent[] => {
        return components.map(c => {
          if (c.id === updatedComponent.id) {
            return updatedComponent;
          }
          if (c.children) {
            return {
              ...c,
              children: updateComponentRecursive(c.children),
            };
          }
          return c;
        });
      };
      
      const newComponents = updateComponentRecursive(state.components);
      
      return {
        components: newComponents,
        selectedComponentId: updatedComponent.id,
        history: {
          past: [...state.history.past, state.components],
          present: newComponents,
          future: [],
        },
      };
    });
    get().saveToStorage();
  },
  
  // 重新排序组件
  reorderComponents: (dragIndex, hoverIndex) => {
    set((state) => {
      const newComponents = [...state.components];
      const [removed] = newComponents.splice(dragIndex, 1);
      newComponents.splice(hoverIndex, 0, removed);
      
      return {
        components: newComponents,
        history: {
          past: [...state.history.past, state.components],
          present: newComponents,
          future: [],
        },
      };
    });
    get().saveToStorage();
  },
  
  // 清空组件
  clearComponents: () => {
    set((state) => ({
      components: [],
      selectedComponentId: null,
      propertyPanelOpen: false,
      history: {
        past: [...state.history.past, state.components],
        present: [],
        future: [],
      },
    }));
    get().saveToStorage();
  },
  
  // 添加子组件
  addChildComponent: (parentId, child) => {
    set((state) => {
      const newComponents = state.components.map(c =>
        c.id === parentId ? { ...c, children: [...(c.children || []), child] } : c
      );
      
      return {
        components: newComponents,
        history: {
          past: [...state.history.past, state.components],
          present: newComponents,
          future: [],
        },
      };
    });
    get().saveToStorage();
  },
  
  // 删除子组件
  removeChildComponent: (parentId, childId) => {
    set((state) => {
      const newComponents = state.components.map(c =>
        c.id === parentId ? { ...c, children: c.children?.filter(child => child.id !== childId) } : c
      );
      
      return {
        components: newComponents,
        history: {
          past: [...state.history.past, state.components],
          present: newComponents,
          future: [],
        },
      };
    });
    get().saveToStorage();
  },
  
  // 选择组件
  selectComponent: (componentId) => {
    set({
      selectedComponentId: componentId,
      propertyPanelOpen: componentId !== null,
    });
  },
  
  // 打开属性面板
  openPropertyPanel: () => {
    set({ propertyPanelOpen: true });
  },
  
  // 关闭属性面板
  closePropertyPanel: () => {
    set({ propertyPanelOpen: false });
  },
  
  // 撤销
  undo: () => {
    set((state) => {
      if (state.history.past.length === 0) return state;
      
      const previous = state.history.past[state.history.past.length - 1];
      const newPast = state.history.past.slice(0, -1);
      
      return {
        components: previous,
        history: {
          past: newPast,
          present: previous,
          future: [state.components, ...state.history.future],
        },
      };
    });
    get().saveToStorage();
  },
  
  // 重做
  redo: () => {
    set((state) => {
      if (state.history.future.length === 0) return state;
      
      const next = state.history.future[0];
      const newFuture = state.history.future.slice(1);
      
      return {
        components: next,
        history: {
          past: [...state.history.past, state.components],
          present: next,
          future: newFuture,
        },
      };
    });
    get().saveToStorage();
  },
  
  // 是否可以撤销
  canUndo: () => {
    return get().history.past.length > 0;
  },
  
  // 是否可以重做
  canRedo: () => {
    return get().history.future.length > 0;
  },
  
  // 保存到本地存储
  saveToStorage: (name?: string) => {
    const state = get();
    const data = {
      components: state.components,
      timestamp: Date.now(),
    };
    localStorage.setItem(name || STORAGE_KEY, JSON.stringify(data));
  },
  
  // 从本地存储加载
  loadFromStorage: (name) => {
    try {
      const data = localStorage.getItem(name || STORAGE_KEY);
      if (data) {
        const parsed = JSON.parse(data);
        set((state) => ({
          components: parsed.components || [],
          selectedComponentId: null,
          propertyPanelOpen: false,
          history: {
            past: [...state.history.past, state.components],
            present: parsed.components || [],
            future: [],
          },
        }));
      }
    } catch (error) {
      console.error('加载失败:', error);
    }
  },
  
  // 导出为 JSON
  exportAsJSON: () => {
    const state = get();
    return JSON.stringify({
      components: state.components,
      version: '1.0.0',
      exportTime: new Date().toISOString(),
    }, null, 2);
  },
  
  // 从 JSON 导入
  importFromJSON: (json) => {
    try {
      const parsed = JSON.parse(json);
      set((state) => ({
        components: parsed.components || [],
        selectedComponentId: null,
        propertyPanelOpen: false,
        history: {
          past: [...state.history.past, state.components],
          present: parsed.components || [],
          future: [],
        },
      }));
      get().saveToStorage();
    } catch (error) {
      console.error('导入失败:', error);
      throw new Error('无效的JSON格式');
    }
  },
  
  // 获取选中的组件
  getSelectedComponent: () => {
    const state = get();
    if (!state.selectedComponentId) return null;
    
    // 递归查找组件（包括子组件）
    const findComponent = (components: FormComponent[], id: string): FormComponent | null => {
      for (const component of components) {
        if (component.id === id) return component;
        if (component.children) {
          const found = findComponent(component.children, id);
          if (found) return found;
        }
      }
      return null;
    };
    
    return findComponent(state.components, state.selectedComponentId);
  },
}));