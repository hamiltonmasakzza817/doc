import { useRef, useState } from "react";
import { useDrag, useDrop } from "react-dnd";
import { Resizable } from "re-resizable";
import { Trash2 } from "lucide-react";
import { FormComponent } from "../types/form-designer";
import { FormComponentRenderer } from "./FormComponentRenderer";
import { useFormDesignerStore } from "../store/form-designer-store";
import { getComponentDefinition, canAcceptChild } from "../utils/component-definitions";

interface CanvasComponentProps {
  component: FormComponent;
  index: number;
  parentId?: string;
  isSelected: boolean;
  onSelect: (componentId: string | null) => void;
  onReorder: (dragIndex: number, hoverIndex: number) => void;
  onUpdateComponent: (component: FormComponent) => void;
  depth?: number;
}

export function CanvasComponent({
  component,
  index,
  parentId,
  isSelected,
  onSelect,
  onReorder,
  onUpdateComponent,
  depth = 0,
}: CanvasComponentProps) {
  const ref = useRef<HTMLDivElement>(null);
  const [isHovering, setIsHovering] = useState(false);
  const removeComponent = useFormDesignerStore((state) => state.removeComponent);
  const addChildComponent = useFormDesignerStore((state) => state.addChildComponent);

  const componentDef = getComponentDefinition(component.type);
  const isResizable = ['container', 'formContainer', 'tabContainer', 'image'].includes(component.type);
  const canHaveChildren = componentDef?.canHaveChildren || false;

  const handleDelete = (e: React.MouseEvent) => {
    e.stopPropagation();
    removeComponent(component.id, parentId);
  };

  // 拖拽：可以拖拽组件到画布其他位置
  const [{ isDragging }, drag] = useDrag({
    type: 'canvas-component',
    item: () => {
      return { component, index, parentId };
    },
    collect: (monitor) => ({
      isDragging: monitor.isDragging(),
    }),
  });

  // 放置：接受其他组件拖拽过来（重新排序）
  const [{ isOver: isOverForReorder }, dropForReorder] = useDrop({
    accept: 'canvas-component',
    hover(item: { component: FormComponent; index: number; parentId?: string }, monitor) {
      if (!ref.current) return;
      
      // 只有同一父级才能重新排序
      if (item.parentId !== parentId) return;

      const dragIndex = item.index;
      const hoverIndex = index;

      if (dragIndex === hoverIndex) return;

      onReorder(dragIndex, hoverIndex);
      item.index = hoverIndex;
    },
    collect: (monitor) => ({
      isOver: monitor.isOver() && monitor.getItem()?.parentId === parentId,
    }),
  });

  // 放置：接受新组件或其他组件拖入（作为子组件）
  const [{ isOver: isOverForChild, canDrop }, dropForChild] = useDrop({
    accept: ['component', 'canvas-component'],
    canDrop: (item: any) => {
      if (!canHaveChildren) return false;
      
      // 检查是否可以接受该类型的子组件
      const childType = item.component?.type || item.type;
      if (!componentDef?.acceptedChildTypes) return true;
      
      return canAcceptChild(component.type, childType);
    },
    drop: (item: any, monitor) => {
      // 只处理直接放到这个组件上的，不处理放到子组件的
      if (monitor.didDrop()) return;

      const droppedComponent = item.component || item;
      
      // 如果是新组件，添加为子组件
      if (item.type && !item.component) {
        addChildComponent(component.id, droppedComponent);
      } 
      // 如果是已有组件，移动到此容器
      else if (item.component && item.parentId !== component.id) {
        // 移动组件逻辑
        removeComponent(item.component.id, item.parentId);
        addChildComponent(component.id, item.component);
      }
    },
    collect: (monitor) => ({
      isOver: monitor.isOver({ shallow: true }),
      canDrop: monitor.canDrop(),
    }),
  });

  // 合并 drop refs
  drag(dropForReorder(ref));

  const handleClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    onSelect(component.id);
  };

  const handleResize = (
    e: MouseEvent | TouchEvent,
    direction: string,
    ref: HTMLElement,
    delta: { width: number; height: number }
  ) => {
    const newWidth = ref.style.width;
    onUpdateComponent({
      ...component,
      properties: {
        ...component.properties,
        width: newWidth,
      },
    });
  };

  // 渲染子组件
  const renderChildren = (children: FormComponent[]) => {
    return (
      <div className="space-y-2 mt-2">
        {children.map((child, idx) => (
          <CanvasComponent
            key={child.id}
            component={child}
            index={idx}
            parentId={component.id}
            isSelected={isSelected && child.id === useFormDesignerStore.getState().selectedComponentId}
            onSelect={onSelect}
            onReorder={(dragIdx, hoverIdx) => {
              // 重新排序子组件
              const newChildren = [...children];
              const [removed] = newChildren.splice(dragIdx, 1);
              newChildren.splice(hoverIdx, 0, removed);
              onUpdateComponent({
                ...component,
                children: newChildren,
              });
            }}
            onUpdateComponent={(updatedChild) => {
              // 更新子组件
              const newChildren = children.map(c => c.id === updatedChild.id ? updatedChild : c);
              onUpdateComponent({
                ...component,
                children: newChildren,
              });
            }}
            depth={depth + 1}
          />
        ))}
      </div>
    );
  };

  const componentContent = (
    <div
      ref={canHaveChildren ? dropForChild(ref) : ref}
      onClick={handleClick}
      onMouseEnter={() => setIsHovering(true)}
      onMouseLeave={() => setIsHovering(false)}
      className={`relative transition-all ${
        isDragging ? 'opacity-30' : ''
      } ${
        isSelected ? 'ring-2 ring-blue-500' : 'border-2 border-dashed border-gray-300'
      } ${
        isOverForReorder ? 'border-blue-400 bg-blue-50' : ''
      } ${
        canHaveChildren && isOverForChild && canDrop ? 'ring-2 ring-green-500 bg-green-50' : ''
      }`}
      style={{
        marginLeft: depth > 0 ? '16px' : '0',
        marginBottom: '8px',
        cursor: 'move',
      }}
    >
      {/* Component Label */}
      <div className="absolute -top-3 left-2 px-2 py-0.5 bg-white text-xs text-gray-600 border border-gray-300 rounded z-10">
        {component.label}
        {canHaveChildren && ` (${component.children?.length || 0})`}
      </div>

      {/* Delete Button */}
      {(isSelected || isHovering) && (
        <button
          onClick={handleDelete}
          className="absolute -top-3 right-2 p-1 bg-red-500 text-white rounded hover:bg-red-600 transition-colors z-10"
          title="删除组件 (Delete)"
        >
          <Trash2 className="w-3 h-3" />
        </button>
      )}

      {/* Actual Component */}
      <FormComponentRenderer 
        component={component} 
        onUpdateComponent={onUpdateComponent}
        renderChildren={component.children ? () => renderChildren(component.children!) : undefined}
      />
    </div>
  );

  // 如果可调整大小，包裹在 Resizable 中
  if (isResizable && (isSelected || isHovering)) {
    return (
      <Resizable
        size={{ 
          width: component.properties.width || '100%', 
          height: component.properties.height || 'auto' 
        }}
        onResizeStop={handleResize}
        enable={{
          right: true,
          left: true,
        }}
        minWidth="100px"
        handleStyles={{
          right: {
            right: '-4px',
            width: '8px',
            cursor: 'ew-resize',
            backgroundColor: isSelected ? '#3b82f6' : 'transparent',
          },
          left: {
            left: '-4px',
            width: '8px',
            cursor: 'ew-resize',
            backgroundColor: isSelected ? '#3b82f6' : 'transparent',
          },
        }}
      >
        {componentContent}
      </Resizable>
    );
  }

  return componentContent;
}
