import { useDrop } from "react-dnd";
import { FormComponent } from "../types/form-designer";
import { CanvasComponent } from "./CanvasComponent";

interface CanvasProps {
  components: FormComponent[];
  selectedComponentId: string | null;
  onSelectComponent: (componentId: string | null) => void;
  onReorderComponents: (dragIndex: number, hoverIndex: number) => void;
  onAddComponent: (component: FormComponent) => void;
  onUpdateComponent: (component: FormComponent) => void;
}

export function Canvas({ 
  components, 
  selectedComponentId,
  onSelectComponent,
  onReorderComponents,
  onAddComponent,
  onUpdateComponent
}: CanvasProps) {
  const [{ isOver }, drop] = useDrop(() => ({
    accept: 'component',
    drop: (item: FormComponent) => {
      // 生成新的 ID 以防重复
      const newComponent = {
        ...item,
        id: `${item.type}-${Date.now()}`,
      };
      onAddComponent(newComponent);
    },
    collect: (monitor) => ({
      isOver: monitor.isOver(),
    }),
  }), [onAddComponent]);

  return (
    <div className="flex-1 p-8 overflow-auto">
      <div className="max-w-4xl mx-auto">
        <div
          ref={drop}
          className={`min-h-[600px] bg-white rounded-lg border-2 border-dashed p-6 transition-all ${
            isOver ? 'border-blue-500 bg-blue-50' : 'border-gray-300'
          }`}
          onClick={() => onSelectComponent(null)}
        >
          {components.length === 0 ? (
            <div className="flex items-center justify-center h-[400px] text-gray-400">
              从左侧拖拽组件到这里开始设计表单
            </div>
          ) : (
            <div className="flex flex-col gap-4">
              {components.map((component, index) => (
                <CanvasComponent
                  key={component.id}
                  component={component}
                  index={index}
                  isSelected={selectedComponentId === component.id}
                  onSelect={onSelectComponent}
                  onReorder={onReorderComponents}
                  onUpdateComponent={onUpdateComponent}
                />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}