import { useEffect, useState } from "react";
import { FormComponent, ValidationRule } from "../types/form-designer";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "./ui/sheet";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Switch } from "./ui/switch";
import { Textarea } from "./ui/textarea";
import { Button } from "./ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Plus, Trash2 } from "lucide-react";
import { Separator } from "./ui/separator";

interface PropertiesPanelProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  component: FormComponent | null;
  onUpdateComponent: (component: FormComponent) => void;
}

export function PropertiesPanel({
  open,
  onOpenChange,
  component,
  onUpdateComponent,
}: PropertiesPanelProps) {
  const [localComponent, setLocalComponent] = useState<FormComponent | null>(component);

  useEffect(() => {
    setLocalComponent(component);
  }, [component]);

  if (!localComponent) {
    return null;
  }

  const updateProperty = (key: string, value: any) => {
    const updated = {
      ...localComponent,
      properties: {
        ...localComponent.properties,
        [key]: value,
      },
    };
    setLocalComponent(updated);
    onUpdateComponent(updated);
  };

  const updateLabel = (value: string) => {
    const updated = {
      ...localComponent,
      label: value,
    };
    setLocalComponent(updated);
    onUpdateComponent(updated);
  };

  const addValidationRule = () => {
    const rules = localComponent.properties.validationRules || [];
    const newRule: ValidationRule = {
      type: 'required',
      message: '',
    };
    updateProperty('validationRules', [...rules, newRule]);
  };

  const updateValidationRule = (index: number, field: keyof ValidationRule, value: any) => {
    const rules = [...(localComponent.properties.validationRules || [])];
    rules[index] = { ...rules[index], [field]: value };
    updateProperty('validationRules', rules);
  };

  const removeValidationRule = (index: number) => {
    const rules = [...(localComponent.properties.validationRules || [])];
    rules.splice(index, 1);
    updateProperty('validationRules', rules);
  };

  const addTab = () => {
    const tabs = localComponent.properties.tabs || [];
    const newTab = {
      key: `tab${tabs.length + 1}`,
      label: `标签页${tabs.length + 1}`,
    };
    updateProperty('tabs', [...tabs, newTab]);
  };

  const updateTab = (index: number, field: 'key' | 'label', value: string) => {
    const tabs = [...(localComponent.properties.tabs || [])];
    tabs[index] = { ...tabs[index], [field]: value };
    updateProperty('tabs', tabs);
  };

  const removeTab = (index: number) => {
    const tabs = [...(localComponent.properties.tabs || [])];
    tabs.splice(index, 1);
    updateProperty('tabs', tabs);
  };

  const addOption = () => {
    const options = localComponent.properties.options || [];
    updateProperty('options', [...options, `选项${options.length + 1}`]);
  };

  const updateOption = (index: number, value: string) => {
    const options = [...(localComponent.properties.options || [])];
    options[index] = value;
    updateProperty('options', options);
  };

  const removeOption = (index: number) => {
    const options = [...(localComponent.properties.options || [])];
    options.splice(index, 1);
    updateProperty('options', options);
  };

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="right" className="w-96 overflow-y-auto">
        <SheetHeader>
          <SheetTitle>属性配置</SheetTitle>
          <SheetDescription>
            配置选中组件的属性
          </SheetDescription>
        </SheetHeader>

        <div className="mt-6 space-y-6">
          {/* 基本属性 */}
          <div className="space-y-4">
            <h3 className="text-sm text-gray-900">基本属性</h3>

            <div className="space-y-2">
              <Label>组件标签</Label>
              <Input
                value={localComponent.label}
                onChange={(e) => updateLabel(e.target.value)}
              />
            </div>

            {/* 容器组件属性 */}
            {localComponent.type === 'container' && (
              <div className="text-sm text-gray-500">
                可以拖拽任意组件到此容器内
              </div>
            )}

            {/* 表单容器属性 */}
            {localComponent.type === 'formContainer' && (
              <>
                <div className="space-y-2">
                  <Label>表单名称</Label>
                  <Input
                    value={localComponent.properties.formName || ''}
                    onChange={(e) => updateProperty('formName', e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label>表单布局</Label>
                  <Select
                    value={localComponent.properties.formLayout || 'vertical'}
                    onValueChange={(value) => updateProperty('formLayout', value)}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="vertical">垂直布局</SelectItem>
                      <SelectItem value="horizontal">水平布局</SelectItem>
                      <SelectItem value="inline">行内布局</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>标签宽度</Label>
                  <Input
                    value={localComponent.properties.labelWidth || ''}
                    onChange={(e) => updateProperty('labelWidth', e.target.value)}
                    placeholder="例如: 120px"
                  />
                </div>
              </>
            )}

            {/* 标签页容器属性 */}
            {localComponent.type === 'tabContainer' && (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <Label>标签页配置</Label>
                  <Button size="sm" variant="outline" onClick={addTab}>
                    <Plus className="w-3 h-3 mr-1" />
                    添加标签页
                  </Button>
                </div>
                {(localComponent.properties.tabs || []).map((tab, index) => (
                  <div key={index} className="flex gap-2 items-start">
                    <div className="flex-1 space-y-2">
                      <Input
                        value={tab.key}
                        onChange={(e) => updateTab(index, 'key', e.target.value)}
                        placeholder="key"
                        className="text-xs"
                      />
                      <Input
                        value={tab.label}
                        onChange={(e) => updateTab(index, 'label', e.target.value)}
                        placeholder="标签"
                      />
                    </div>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => removeTab(index)}
                      className="mt-1"
                    >
                      <Trash2 className="w-3 h-3 text-red-500" />
                    </Button>
                  </div>
                ))}
              </div>
            )}

            {/* 输入框属性 */}
            {localComponent.type === 'input' && (
              <>
                <div className="space-y-2">
                  <Label>占位符文本</Label>
                  <Input
                    value={localComponent.properties.placeholder || ''}
                    onChange={(e) => updateProperty('placeholder', e.target.value)}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label>是否必填</Label>
                  <Switch
                    checked={localComponent.properties.required || false}
                    onCheckedChange={(checked) => updateProperty('required', checked)}
                  />
                </div>
              </>
            )}

            {/* 选择框属性 */}
            {localComponent.type === 'select' && (
              <>
                <div className="space-y-2">
                  <Label>占位符文本</Label>
                  <Input
                    value={localComponent.properties.placeholder || ''}
                    onChange={(e) => updateProperty('placeholder', e.target.value)}
                  />
                </div>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label>选项列表</Label>
                    <Button size="sm" variant="outline" onClick={addOption}>
                      <Plus className="w-3 h-3 mr-1" />
                      添加选项
                    </Button>
                  </div>
                  {(localComponent.properties.options || []).map((option, index) => (
                    <div key={index} className="flex gap-2">
                      <Input
                        value={option}
                        onChange={(e) => updateOption(index, e.target.value)}
                        className="flex-1"
                      />
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => removeOption(index)}
                      >
                        <Trash2 className="w-3 h-3 text-red-500" />
                      </Button>
                    </div>
                  ))}
                </div>
              </>
            )}

            {/* 按钮属性 */}
            {localComponent.type === 'button' && (
              <div className="space-y-2">
                <Label>按钮文本</Label>
                <Input
                  value={localComponent.properties.buttonText || ''}
                  onChange={(e) => updateProperty('buttonText', e.target.value)}
                />
              </div>
            )}

            {/* 图片属性 */}
            {localComponent.type === 'image' && (
              <div className="space-y-2">
                <Label>图片URL</Label>
                <Input
                  value={localComponent.properties.imageUrl || ''}
                  onChange={(e) => updateProperty('imageUrl', e.target.value)}
                />
              </div>
            )}

            {/* 文本属性 */}
            {localComponent.type === 'text' && (
              <div className="space-y-2">
                <Label>文本内容</Label>
                <Textarea
                  value={localComponent.properties.textContent || ''}
                  onChange={(e) => updateProperty('textContent', e.target.value)}
                  rows={3}
                />
              </div>
            )}
          </div>

          {/* 验证规则 - 仅表单控件 */}
          {['input', 'select'].includes(localComponent.type) && (
            <>
              <Separator />
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm text-gray-900">验证规则</h3>
                  <Button size="sm" variant="outline" onClick={addValidationRule}>
                    <Plus className="w-3 h-3 mr-1" />
                    添加规则
                  </Button>
                </div>
                {(localComponent.properties.validationRules || []).map((rule, index) => (
                  <div key={index} className="p-3 border rounded-lg space-y-2">
                    <div className="flex items-center justify-between">
                      <Label className="text-xs">规则类型</Label>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => removeValidationRule(index)}
                      >
                        <Trash2 className="w-3 h-3 text-red-500" />
                      </Button>
                    </div>
                    <Select
                      value={rule.type}
                      onValueChange={(value: any) => updateValidationRule(index, 'type', value)}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="required">必填</SelectItem>
                        <SelectItem value="min">最小长度</SelectItem>
                        <SelectItem value="max">最大长度</SelectItem>
                        <SelectItem value="pattern">正则表达式</SelectItem>
                        <SelectItem value="email">邮箱格式</SelectItem>
                        <SelectItem value="url">URL格式</SelectItem>
                      </SelectContent>
                    </Select>
                    {['min', 'max', 'pattern'].includes(rule.type) && (
                      <Input
                        value={rule.value || ''}
                        onChange={(e) => updateValidationRule(index, 'value', e.target.value)}
                        placeholder={
                          rule.type === 'pattern' ? '正则表达式' : 
                          rule.type === 'min' ? '最小值' : 
                          '最大值'
                        }
                      />
                    )}
                    <Input
                      value={rule.message || ''}
                      onChange={(e) => updateValidationRule(index, 'message', e.target.value)}
                      placeholder="错误提示信息"
                    />
                  </div>
                ))}
              </div>
            </>
          )}

          {/* 样式属性 */}
          <Separator />
          <div className="space-y-4">
            <h3 className="text-sm text-gray-900">样式属性</h3>

            <div className="space-y-2">
              <Label>宽度</Label>
              <Input
                value={localComponent.properties.width || ''}
                onChange={(e) => updateProperty('width', e.target.value)}
                placeholder="例如: 100%, 400px"
              />
            </div>

            <div className="space-y-2">
              <Label>高度</Label>
              <Input
                value={localComponent.properties.height || ''}
                onChange={(e) => updateProperty('height', e.target.value)}
                placeholder="例如: auto, 200px"
              />
            </div>

            <div className="space-y-2">
              <Label>内边距</Label>
              <Input
                value={localComponent.properties.padding || ''}
                onChange={(e) => updateProperty('padding', e.target.value)}
                placeholder="例如: 16px, 10px 20px"
              />
            </div>

            <div className="space-y-2">
              <Label>外边距</Label>
              <Input
                value={localComponent.properties.margin || ''}
                onChange={(e) => updateProperty('margin', e.target.value)}
                placeholder="例如: 8px, 10px 20px"
              />
            </div>

            <div className="space-y-2">
              <Label>背景颜色</Label>
              <Input
                type="color"
                value={localComponent.properties.backgroundColor || '#ffffff'}
                onChange={(e) => updateProperty('backgroundColor', e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label>圆角</Label>
              <Input
                value={localComponent.properties.borderRadius || ''}
                onChange={(e) => updateProperty('borderRadius', e.target.value)}
                placeholder="例如: 8px, 4px 8px"
              />
            </div>

            <div className="space-y-2">
              <Label>边框</Label>
              <Input
                value={localComponent.properties.border || ''}
                onChange={(e) => updateProperty('border', e.target.value)}
                placeholder="例如: 1px solid #ccc"
              />
            </div>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
}
