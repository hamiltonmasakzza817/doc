import { useEffect } from "react";
import { DndProvider } from "react-dnd";
import { HTML5Backend } from "react-dnd-html5-backend";
import { Toaster } from "./ui/sonner";
import { ComponentPanel } from "./ComponentPanel";
import { Canvas } from "./Canvas";
import { PropertiesPanel } from "./PropertiesPanel";
import { Toolbar } from "./Toolbar";
import { ErrorBoundary } from "./ErrorBoundary";
import { useFormDesignerStore } from "../store/form-designer-store";

export function FormDesigner() {
  const {
    components,
    selectedComponentId,
    propertyPanelOpen,
    addComponent,
    updateComponent,
    reorderComponents,
    selectComponent,
    closePropertyPanel,
    getSelectedComponent,
    loadFromStorage,
  } = useFormDesignerStore();

  // 组件挂载时加载自动保存
  useEffect(() => {
    loadFromStorage('form-designer-autosave');
  }, []);

  // 键盘快捷键
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ctrl/Cmd + Z: 撤销
      if ((e.ctrlKey || e.metaKey) && e.key === 'z' && !e.shiftKey) {
        e.preventDefault();
        useFormDesignerStore.getState().undo();
      }
      // Ctrl/Cmd + Y 或 Ctrl/Cmd + Shift + Z: 重做
      if ((e.ctrlKey || e.metaKey) && (e.key === 'y' || (e.key === 'z' && e.shiftKey))) {
        e.preventDefault();
        useFormDesignerStore.getState().redo();
      }
      // Delete: 删除选中组件
      if (e.key === 'Delete' && selectedComponentId) {
        e.preventDefault();
        useFormDesignerStore.getState().removeComponent(selectedComponentId);
      }
      // Escape: 取消选择
      if (e.key === 'Escape') {
        e.preventDefault();
        selectComponent(null);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedComponentId, selectComponent]);

  const selectedComponent = getSelectedComponent();

  return (
    <ErrorBoundary>
      <DndProvider backend={HTML5Backend}>
        <div className="flex flex-col h-screen bg-gray-50">
          {/* Toolbar */}
          <Toolbar />

          <div className="flex flex-1 overflow-hidden">
            {/* Left Panel - Component Selector */}
            <ComponentPanel onAddComponent={addComponent} />

            {/* Middle - Canvas */}
            <Canvas
              components={components}
              selectedComponentId={selectedComponentId}
              onSelectComponent={selectComponent}
              onReorderComponents={reorderComponents}
              onAddComponent={addComponent}
              onUpdateComponent={updateComponent}
            />

            {/* Right Panel - Properties */}
            <PropertiesPanel
              open={propertyPanelOpen}
              onOpenChange={(open) => {
                if (!open) {
                  closePropertyPanel();
                }
              }}
              component={selectedComponent}
              onUpdateComponent={updateComponent}
            />
          </div>
        </div>

        {/* Toast Notifications */}
        <Toaster position="top-right" />
      </DndProvider>
    </ErrorBoundary>
  );
}