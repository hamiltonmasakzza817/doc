import { useState } from "react";
import { FormComponent } from "../types/form-designer";
import { Input } from "./ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Button } from "./ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Resizable } from "re-resizable";

interface FormComponentRendererProps {
  component: FormComponent;
  onUpdateComponent?: (component: FormComponent) => void;
  renderChildren?: (children: FormComponent[]) => React.ReactNode;
}

export function FormComponentRenderer({ 
  component, 
  onUpdateComponent,
  renderChildren 
}: FormComponentRendererProps) {
  const [activeTab, setActiveTab] = useState(component.properties.activeTab || 'tab1');

  const containerStyle = {
    width: component.properties.width,
    height: component.properties.height,
    padding: component.properties.padding,
    margin: component.properties.margin,
    backgroundColor: component.properties.backgroundColor,
    borderRadius: component.properties.borderRadius,
    border: component.properties.border,
  };

  // 容器组件
  if (component.type === 'container') {
    return (
      <div style={containerStyle} className="min-h-[100px]">
        {component.children && component.children.length > 0 && renderChildren ? (
          renderChildren(component.children)
        ) : (
          <div className="flex items-center justify-center h-full text-gray-400 text-sm">
            拖拽组件到此处
          </div>
        )}
      </div>
    );
  }

  // 表单容器组件
  if (component.type === 'formContainer') {
    const layoutClass = 
      component.properties.formLayout === 'horizontal' ? 'space-y-0 flex flex-wrap gap-4' :
      component.properties.formLayout === 'inline' ? 'flex flex-wrap gap-4' :
      'space-y-4';

    return (
      <div style={containerStyle} className="min-h-[120px]">
        <div className="mb-4 pb-2 border-b border-gray-200">
          <h3 className="text-gray-800">{component.properties.formName || '表单'}</h3>
        </div>
        <div className={layoutClass}>
          {component.children && component.children.length > 0 && renderChildren ? (
            renderChildren(component.children)
          ) : (
            <div className="flex items-center justify-center h-20 text-gray-400 text-sm w-full">
              拖拽表单控件到此处
            </div>
          )}
        </div>
      </div>
    );
  }

  // 标签页容器组件
  if (component.type === 'tabContainer') {
    const tabs = component.properties.tabs || [
      { key: 'tab1', label: '标签页1' },
      { key: 'tab2', label: '标签页2' },
    ];

    return (
      <div style={containerStyle}>
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList>
            {tabs.map((tab) => (
              <TabsTrigger key={tab.key} value={tab.key}>
                {tab.label}
              </TabsTrigger>
            ))}
          </TabsList>
          {tabs.map((tab) => (
            <TabsContent key={tab.key} value={tab.key} className="min-h-[100px] p-4 border border-t-0 rounded-b">
              {component.children && component.children.length > 0 && renderChildren ? (
                renderChildren(component.children)
              ) : (
                <div className="flex items-center justify-center h-20 text-gray-400 text-sm">
                  拖拽组件到此标签页
                </div>
              )}
            </TabsContent>
          ))}
        </Tabs>
      </div>
    );
  }

  // 输入框
  if (component.type === 'input') {
    return (
      <div style={{ width: component.properties.width }}>
        <Input
          placeholder={component.properties.placeholder}
          required={component.properties.required}
          style={{
            height: component.properties.height,
            backgroundColor: component.properties.backgroundColor,
            borderRadius: component.properties.borderRadius,
            border: component.properties.border,
          }}
        />
        {component.properties.validationRules && component.properties.validationRules.length > 0 && (
          <div className="mt-1 text-xs text-gray-500">
            {component.properties.validationRules.map((rule, idx) => (
              <div key={idx}>
                {rule.type === 'required' && '* 必填'}
                {rule.type === 'min' && `* 最小长度: ${rule.value}`}
                {rule.type === 'max' && `* 最大长度: ${rule.value}`}
                {rule.type === 'pattern' && `* 格式: ${rule.value}`}
                {rule.type === 'email' && '* 邮箱格式'}
                {rule.message && ` - ${rule.message}`}
              </div>
            ))}
          </div>
        )}
      </div>
    );
  }

  // 选择框
  if (component.type === 'select') {
    return (
      <div style={{ width: component.properties.width }}>
        <Select>
          <SelectTrigger
            style={{
              height: component.properties.height,
              backgroundColor: component.properties.backgroundColor,
              borderRadius: component.properties.borderRadius,
              border: component.properties.border,
            }}
          >
            <SelectValue placeholder={component.properties.placeholder || '请选择'} />
          </SelectTrigger>
          <SelectContent>
            {(component.properties.options || []).map((option, index) => (
              <SelectItem key={index} value={option}>
                {option}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
    );
  }

  // 按钮
  if (component.type === 'button') {
    return (
      <Button
        style={{
          width: component.properties.width,
          height: component.properties.height,
          backgroundColor: component.properties.backgroundColor,
          borderRadius: component.properties.borderRadius,
          border: component.properties.border,
        }}
      >
        {component.properties.buttonText || '按钮'}
      </Button>
    );
  }

  // 图片
  if (component.type === 'image') {
    return (
      <img
        src={component.properties.imageUrl || 'https://via.placeholder.com/400x200'}
        alt={component.label}
        style={{
          width: component.properties.width,
          height: component.properties.height,
          borderRadius: component.properties.borderRadius,
          border: component.properties.border,
          objectFit: 'cover',
        }}
      />
    );
  }

  // 文本
  if (component.type === 'text') {
    return (
      <div
        style={{
          width: component.properties.width,
          padding: component.properties.padding,
          backgroundColor: component.properties.backgroundColor,
          borderRadius: component.properties.borderRadius,
          border: component.properties.border,
        }}
      >
        {component.properties.textContent || '这是一段文本'}
      </div>
    );
  }

  return <div>未知组件类型: {component.type}</div>;
}
