import { 
  Undo2, 
  Redo2, 
  Save, 
  FolderOpen, 
  Download, 
  Upload,
  Trash2,
  Eye
} from "lucide-react";
import { Button } from "./ui/button";
import { useFormDesignerStore } from "../store/form-designer-store";
import { toast } from "sonner@2.0.3";
import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "./ui/dialog";
import { Input } from "./ui/input";
import { Label } from "./ui/label";

export function Toolbar() {
  const {
    components,
    canUndo,
    canRedo,
    undo,
    redo,
    clearComponents,
    saveToStorage,
    loadFromStorage,
    exportAsJSON,
    importFromJSON,
  } = useFormDesignerStore();

  const [saveName, setSaveName] = useState('');
  const [loadName, setLoadName] = useState('');
  const [saveDialogOpen, setSaveDialogOpen] = useState(false);
  const [loadDialogOpen, setLoadDialogOpen] = useState(false);

  const handleUndo = () => {
    if (canUndo()) {
      undo();
      toast.success('已撤销');
    }
  };

  const handleRedo = () => {
    if (canRedo()) {
      redo();
      toast.success('已重做');
    }
  };

  const handleSave = () => {
    if (saveName.trim()) {
      saveToStorage(saveName);
      toast.success(`已保存: ${saveName}`);
      setSaveDialogOpen(false);
      setSaveName('');
    } else {
      saveToStorage();
      toast.success('已自动保存');
    }
  };

  const handleLoad = () => {
    if (loadName.trim()) {
      loadFromStorage(loadName);
      toast.success(`已加载: ${loadName}`);
      setLoadDialogOpen(false);
      setLoadName('');
    } else {
      loadFromStorage('form-designer-autosave');
      toast.success('已加载自动保存');
    }
  };

  const handleExport = () => {
    const json = exportAsJSON();
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `form-design-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success('已导出JSON文件');
  };

  const handleImport = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json';
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = (event) => {
          try {
            const json = event.target?.result as string;
            importFromJSON(json);
            toast.success('已导入表单设计');
          } catch (error) {
            toast.error('导入失败，请检查文件格式');
          }
        };
        reader.readAsText(file);
      }
    };
    input.click();
  };

  const handleClear = () => {
    if (confirm('确定要清空所有组件吗？')) {
      clearComponents();
      toast.success('已清空画布');
    }
  };

  const handlePreview = () => {
    toast.info('预览功能开发中...');
  };

  return (
    <div className="h-14 bg-white border-b border-gray-200 px-4 flex items-center justify-between">
      <div className="flex items-center gap-2">
        <h1 className="text-gray-900 mr-4">表单设计器</h1>
        
        {/* Undo/Redo */}
        <Button
          variant="ghost"
          size="sm"
          onClick={handleUndo}
          disabled={!canUndo()}
          title="撤销 (Ctrl+Z)"
        >
          <Undo2 className="w-4 h-4" />
        </Button>
        <Button
          variant="ghost"
          size="sm"
          onClick={handleRedo}
          disabled={!canRedo()}
          title="重做 (Ctrl+Y)"
        >
          <Redo2 className="w-4 h-4" />
        </Button>

        <div className="w-px h-6 bg-gray-300 mx-2" />

        {/* Save */}
        <Dialog open={saveDialogOpen} onOpenChange={setSaveDialogOpen}>
          <DialogTrigger asChild>
            <Button variant="ghost" size="sm" title="保存">
              <Save className="w-4 h-4 mr-2" />
              保存
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>保存表单设计</DialogTitle>
              <DialogDescription>
                输入名称保存，留空则使用自动保存
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label>保存名称（可选）</Label>
                <Input
                  value={saveName}
                  onChange={(e) => setSaveName(e.target.value)}
                  placeholder="例如：用户注册表单"
                />
              </div>
              <Button onClick={handleSave} className="w-full">
                确认保存
              </Button>
            </div>
          </DialogContent>
        </Dialog>

        {/* Load */}
        <Dialog open={loadDialogOpen} onOpenChange={setLoadDialogOpen}>
          <DialogTrigger asChild>
            <Button variant="ghost" size="sm" title="加载">
              <FolderOpen className="w-4 h-4 mr-2" />
              加载
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>加载表单设计</DialogTitle>
              <DialogDescription>
                输入保存的名称，留空则加载自动保存
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label>保存名称（可选）</Label>
                <Input
                  value={loadName}
                  onChange={(e) => setLoadName(e.target.value)}
                  placeholder="例如：用户注册表单"
                />
              </div>
              <Button onClick={handleLoad} className="w-full">
                确认加载
              </Button>
            </div>
          </DialogContent>
        </Dialog>

        <div className="w-px h-6 bg-gray-300 mx-2" />

        {/* Export/Import */}
        <Button variant="ghost" size="sm" onClick={handleExport} title="导出JSON">
          <Download className="w-4 h-4 mr-2" />
          导出
        </Button>
        <Button variant="ghost" size="sm" onClick={handleImport} title="导入JSON">
          <Upload className="w-4 h-4 mr-2" />
          导入
        </Button>
      </div>

      <div className="flex items-center gap-2">
        {/* Component Count */}
        <div className="text-sm text-gray-500 mr-2">
          {components.length} 个组件
        </div>

        {/* Preview */}
        <Button variant="ghost" size="sm" onClick={handlePreview}>
          <Eye className="w-4 h-4 mr-2" />
          预览
        </Button>

        {/* Clear */}
        <Button
          variant="ghost"
          size="sm"
          onClick={handleClear}
          disabled={components.length === 0}
          title="清空画布"
        >
          <Trash2 className="w-4 h-4" />
        </Button>
      </div>
    </div>
  );
}
