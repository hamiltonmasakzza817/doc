import { useDrag } from "react-dnd";
import { useState } from "react";
import { 
  Box, 
  FileText,
  LayoutPanelTop,
  Type, 
  ChevronDown, 
  Square, 
  Image as ImageIcon, 
  Text as TextIcon 
} from "lucide-react";
import { ComponentType, FormComponent } from "../types/form-designer";
import { componentDefinitions, ComponentDefinition } from "../utils/component-definitions";

const iconMap = {
  Box,
  FileText,
  Tabs: LayoutPanelTop,
  Type,
  ChevronDown,
  Square,
  Image: ImageIcon,
  Text: TextIcon,
};

interface ComponentPanelProps {
  onAddComponent: (component: FormComponent) => void;
}

function DraggableComponentItem({ 
  definition, 
  onAddComponent 
}: { 
  definition: ComponentDefinition;
  onAddComponent: (component: FormComponent) => void;
}) {
  const [{ isDragging }, drag] = useDrag(() => ({
    type: 'component',
    item: () => {
      const newComponent: FormComponent = {
        id: `${definition.type}-${Date.now()}`,
        type: definition.type,
        label: definition.label,
        properties: definition.defaultProperties,
        children: definition.canHaveChildren ? [] : undefined,
      };
      return newComponent;
    },
    collect: (monitor) => ({
      isDragging: monitor.isDragging(),
    }),
  }));

  const getIcon = () => {
    const Icon = iconMap[definition.icon as keyof typeof iconMap];
    return Icon ? <Icon className="w-5 h-5" /> : null;
  };

  return (
    <div
      ref={drag}
      className={`flex items-center gap-3 p-3 bg-white rounded-lg border border-gray-200 cursor-move hover:border-blue-400 hover:bg-blue-50 transition-all ${
        isDragging ? 'opacity-50' : ''
      }`}
    >
      <div className="text-gray-600">{getIcon()}</div>
      <span className="text-sm">{definition.label}</span>
    </div>
  );
}

export function ComponentPanel({ 
  onAddComponent 
}: { 
  onAddComponent: (component: FormComponent) => void;
}) {
  const [expandedCategory, setExpandedCategory] = useState<'layout' | 'control' | null>('layout');

  const layoutComponents = componentDefinitions.filter(c => c.category === 'layout');
  const controlComponents = componentDefinitions.filter(c => c.category === 'control');

  return (
    <div className="w-64 bg-white border-r border-gray-200 p-4 overflow-y-auto">
      <h2 className="mb-4 text-gray-900">组件库</h2>

      {/* Layout Components */}
      <div className="mb-4">
        <button
          onClick={() => setExpandedCategory(expandedCategory === 'layout' ? null : 'layout')}
          className="flex items-center justify-between w-full mb-2 text-sm text-gray-700"
        >
          <span>布局组件</span>
          <ChevronDown className={`w-4 h-4 transition-transform ${expandedCategory === 'layout' ? 'rotate-180' : ''}`} />
        </button>
        {expandedCategory === 'layout' && (
          <div className="space-y-2">
            {layoutComponents.map((def) => (
              <DraggableComponentItem
                key={def.type}
                definition={def}
                onAddComponent={onAddComponent}
              />
            ))}
          </div>
        )}
      </div>

      {/* Form Controls */}
      <div>
        <button
          onClick={() => setExpandedCategory(expandedCategory === 'control' ? null : 'control')}
          className="flex items-center justify-between w-full mb-2 text-sm text-gray-700"
        >
          <span>表单控件</span>
          <ChevronDown className={`w-4 h-4 transition-transform ${expandedCategory === 'control' ? 'rotate-180' : ''}`} />
        </button>
        {expandedCategory === 'control' && (
          <div className="space-y-2">
            {controlComponents.map((def) => (
              <DraggableComponentItem
                key={def.type}
                definition={def}
                onAddComponent={onAddComponent}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}