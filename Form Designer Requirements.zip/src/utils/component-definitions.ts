import { ComponentDefinition, ComponentType } from '../types/form-designer';

export const componentDefinitions: ComponentDefinition[] = [
  // 布局组件
  {
    type: 'container',
    label: '容器',
    category: 'layout',
    icon: 'Box',
    canHaveChildren: true,
    acceptedChildTypes: ['container', 'formContainer', 'tabContainer', 'input', 'select', 'button', 'image', 'text'],
    defaultProperties: {
      width: '100%',
      padding: '16px',
      backgroundColor: '#f9fafb',
      border: '1px solid #e5e7eb',
      borderRadius: '8px',
    },
  },
  {
    type: 'formContainer',
    label: '表单容器',
    category: 'layout',
    icon: 'FileText',
    canHaveChildren: true,
    acceptedChildTypes: ['container', 'input', 'select', 'button', 'image', 'text'],
    defaultProperties: {
      formName: '表单',
      formLayout: 'vertical',
      labelWidth: '120px',
      width: '100%',
      padding: '24px',
      backgroundColor: '#ffffff',
      border: '1px solid #d1d5db',
      borderRadius: '8px',
    },
  },
  {
    type: 'tabContainer',
    label: '标签页容器',
    category: 'layout',
    icon: 'Tabs',
    canHaveChildren: true,
    acceptedChildTypes: ['container', 'formContainer', 'input', 'select', 'button', 'image', 'text'],
    defaultProperties: {
      tabs: [
        { key: 'tab1', label: '标签页1' },
        { key: 'tab2', label: '标签页2' },
      ],
      activeTab: 'tab1',
      width: '100%',
      padding: '16px',
      backgroundColor: '#ffffff',
      border: '1px solid #e5e7eb',
      borderRadius: '8px',
    },
  },
  // 表单控件
  {
    type: 'input',
    label: '输入框',
    category: 'control',
    icon: 'Type',
    canHaveChildren: false,
    defaultProperties: {
      placeholder: '请输入...',
      width: '100%',
    },
  },
  {
    type: 'select',
    label: '选择框',
    category: 'control',
    icon: 'ChevronDown',
    canHaveChildren: false,
    defaultProperties: {
      options: ['选项1', '选项2', '选项3'],
      placeholder: '请选择...',
      width: '100%',
    },
  },
  {
    type: 'button',
    label: '按钮',
    category: 'control',
    icon: 'Square',
    canHaveChildren: false,
    defaultProperties: {
      buttonText: '按钮',
      width: 'auto',
    },
  },
  {
    type: 'image',
    label: '图片',
    category: 'control',
    icon: 'Image',
    canHaveChildren: false,
    defaultProperties: {
      imageUrl: 'https://via.placeholder.com/400x200',
      width: '400px',
      height: '200px',
    },
  },
  {
    type: 'text',
    label: '文本',
    category: 'control',
    icon: 'Text',
    canHaveChildren: false,
    defaultProperties: {
      textContent: '这是一段文本',
      width: '100%',
    },
  },
];

export function getComponentDefinition(type: ComponentType): ComponentDefinition | undefined {
  return componentDefinitions.find(def => def.type === type);
}

export function canAcceptChild(parentType: ComponentType, childType: ComponentType): boolean {
  const parentDef = getComponentDefinition(parentType);
  if (!parentDef?.canHaveChildren) return false;
  if (!parentDef.acceptedChildTypes) return true;
  return parentDef.acceptedChildTypes.includes(childType);
}
