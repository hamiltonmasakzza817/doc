import { FormDesigner } from "./components/FormDesigner";

export default function App() {
  return <FormDesigner />;
}
