export type ComponentType = 
  | 'container' 
  | 'formContainer' 
  | 'tabContainer' 
  | 'input' 
  | 'select' 
  | 'button' 
  | 'image' 
  | 'text';

export interface ValidationRule {
  type: 'required' | 'min' | 'max' | 'pattern' | 'email' | 'url' | 'custom';
  value?: string | number;
  message?: string;
}

export interface FormComponent {
  id: string;
  type: ComponentType;
  label: string;
  properties: {
    // 通用属性
    required?: boolean;
    placeholder?: string;
    
    // 特定组件属性
    imageUrl?: string;
    textContent?: string;
    options?: string[];
    buttonText?: string;
    
    // 表单容器属性
    formName?: string;
    formLayout?: 'horizontal' | 'vertical' | 'inline';
    labelWidth?: string;
    
    // 标签页容器属性
    tabs?: { key: string; label: string }[];
    activeTab?: string;
    
    // 验证规则（用于表单控件）
    validationRules?: ValidationRule[];
    
    // CSS 属性
    width?: string;
    height?: string;
    padding?: string;
    margin?: string;
    backgroundColor?: string;
    borderRadius?: string;
    border?: string;
  };
  children?: FormComponent[];
}

export interface ComponentDefinition {
  type: ComponentType;
  label: string;
  category: 'layout' | 'control';
  icon: string;
  defaultProperties: FormComponent['properties'];
  canHaveChildren?: boolean;
  acceptedChildTypes?: ComponentType[];
}
