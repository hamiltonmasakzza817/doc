
  # Form Designer Requirements

  This is a code bundle for Form Designer Requirements. The original project is available at https://www.figma.com/design/Dk4E1I0CmPvIxWkXunsZYc/Form-Designer-Requirements.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  