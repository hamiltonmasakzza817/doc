
  # Create React Flow Project

  This is a code bundle for Create React Flow Project. The original project is available at https://www.figma.com/design/oAj1X0nwCLLBlaXrwktcXS/Create-React-Flow-Project.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  