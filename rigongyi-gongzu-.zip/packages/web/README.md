# `gongzu-web`

> gongzu 网页端设计器运行时，包含桌面 Ant Design 5 与移动端 Ant Design Mobile 5

## 发布

### 准备工作

创建`.env`文件或设置全局环境变量，需包含如下变量

+ `COS_SECRET_ID` 腾讯云对象存储 Secret ID
+ `COS_SECRET_KEY` 腾讯云对象存储 Secret Key
+ `COS_BUCKET` 腾讯云对象存储桶
+ `COS_REGION` 腾讯云对象存储 Region
+ `CDN_DOMAIN` 静态资源的CDN域名
+ `VERSION` 版本，若不提供则，则从`package.json`文件中自动获取

### 编译、上传

```
npm run package
```

发布路径为`gongzu/${version}/web`
