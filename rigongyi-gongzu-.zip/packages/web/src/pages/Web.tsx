import { ICompContext } from '@gongzu/core/common/CompContext';
import Loading from '@gongzu/core/common/Loading';
import { BaseStoresContext } from '@gongzu/core/contexts/store-contexts';
import EngineStore from '@gongzu/core/engine/EngineStore';
import DesignerStore from '@gongzu/core/stores/DesignerStore';
import {
  Page,
  PageModelData,
  PageModelType,
} from '@gongzu/core/types/entities';
import entries from 'lodash-es/entries';
import get from 'lodash-es/get';
import qs from 'qs';
import React from 'react';
import Loadable from 'react-loadable';
import {
  loggerStore,
  messageStore,
  pageStore,
  sessionStore,
  streamStore,
} from '../container';
import codeInterpreter from '../utils/codeInterpreter';
import router from "../utils/router";

const Player = Loadable({
  loader: () => import('./Player'),
  loading: Loading,
});

const Preview = Loadable({
  loader: () => import('./Preview'),
  loading: Loading,
});

const Canvas = Loadable({
  loader: () => import('./Canvas'),
  loading: Loading,
});

export default () => {
  const inDesigner = get(window, 'parent.inDesigner');

  const [designerElement, setDesignerElement] = React.useState(<Loading />);

  React.useEffect(() => {
    if (inDesigner) {
      window.addEventListener('canvas/init', (event) => {
        const detail = (event as any).detail as {
          designerStore: DesignerStore;
          compContext: ICompContext;
        };
        setDesignerElement(<Canvas {...detail} />);
      });

      window.addEventListener('preview/init', (event) => {
        const detail = (event as any).detail as {
          page: Page;
          modelData: string;
          state: Record<string, unknown>;
        };

        const modelData = JSON.parse(detail.modelData) as PageModelData;

        const engineStore = new EngineStore(
          {
            page: {
              ...detail.page,
              model: {
                modelData,
                type: PageModelType.DRAFT,
              },
            },
            inPagePortal: false,
            inDesigner: false,
            portal: document.body,
          },
          loggerStore,
          messageStore,
          codeInterpreter,
          router
        );

        entries(detail.state).forEach(([key, value]) => {
          engineStore.updateData(key, value);
        });

        setDesignerElement(<Preview engineStore={engineStore} />);
      });

      window.parent.dispatchEvent(new CustomEvent('designer/ready'));
    }
  }, []);

  if (inDesigner) {
    return designerElement;
  }

  const { pageId, pageUrl } = qs.parse(window.location.search, {
    ignoreQueryPrefix: true,
  }) as {
    pageId?: string;
    pageUrl?: string;
  };

  return (
    <BaseStoresContext.Provider
      value={{
        loggerStore,
        messageStore,
        streamStore,
        sessionStore,
        pageStore,
      }}
    >
      <Player
        pageId={pageId}
        pageUrl={pageUrl || window.location.pathname}
        portal={document.body}
      />
    </BaseStoresContext.Provider>
  );
};
