import CanvasCompMarks from '@gongzu/core/common/CanvasCompMarks';
import CompContext, { ICompContext } from '@gongzu/core/common/CompContext';
import Loading from '@gongzu/core/common/Loading';
import ToolsHotKeys from '@gongzu/core/common/ToolsHotKeys';
import {
  BaseStoresContext,
  DesignerStoreContext,
  EngineStoresContext,
} from '@gongzu/core/contexts/store-contexts';
import DesignerStore from '@gongzu/core/stores/DesignerStore';
import { PagePlatform } from '@gongzu/core/types/entities';
import { ResizeObserver } from '@juggle/resize-observer';
import { observer, useLocalObservable } from 'mobx-react';
import React from 'react';
import Loadable from 'react-loadable';
import { pageStore, sessionStore, streamStore } from '../../container';

const DesktopCompPortal = Loadable({
  loader: () =>
    import(/* webpackChunkName: "CompPortalDesktop" */ './CompPortalDesktop'),
  loading: Loading,
});

const MobileCompPortal = Loadable({
  loader: () =>
    import(/* webpackChunkName: "CompPortalMobile" */ './CompPortalMobile'),
  loading: Loading,
});

export default observer(
  (props: { designerStore: DesignerStore; compContext: ICompContext }) => {
    const { designerStore, compContext } = props;

    const localState = useLocalObservable<{
      ready: boolean;
    }>(() => ({
      ready: false,
    }));

    const isMobile =
      designerStore.engineStore.page.platform === PagePlatform.MOBILE;

    React.useEffect(() => {
      if (!isMobile) {
        document.body.style.overflow = 'hidden';
      }
      designerStore.engineStore.loadCssResources(window.document);
    }, [isMobile]);

    React.useEffect(() => {
      const viewportRo = new ResizeObserver((e) => {
        window.parent.dispatchEvent(
          new CustomEvent('designer/viewport-change', {
            detail: e[0].contentRect,
          }),
        );
      });

      const target = document.querySelector('#gongzu-web');

      if (target) {
        viewportRo.observe(target);
      }

      return () => {
        viewportRo.disconnect();
      };
    }, []);

    const {
      engineStore,
      editing: { tab: config },
    } = designerStore;

    return (
      <BaseStoresContext.Provider
        value={{
          loggerStore: engineStore.loggerStore,
          messageStore: engineStore.messageStore,
          streamStore,
          sessionStore,
          pageStore,
        }}
      >
        <DesignerStoreContext.Provider value={designerStore}>
          <EngineStoresContext.Provider
            value={{
              engineStore,
              ...engineStore,
            }}
          >
            <CompContext.Provider
              value={{
                ...compContext,
                inDesigner: true,
                portal: document.body,
              }}
            >
              <>
                {isMobile ? (
                  <MobileCompPortal
                    config={config!}
                    onLoad={() => {
                      localState.ready = true;
                    }}
                  />
                ) : (
                  <DesktopCompPortal
                    config={config!}
                    onLoad={() => {
                      localState.ready = true;
                    }}
                  />
                )}

                <CanvasCompMarks ready={localState.ready} />

                <ToolsHotKeys />
              </>
            </CompContext.Provider>
          </EngineStoresContext.Provider>
        </DesignerStoreContext.Provider>
      </BaseStoresContext.Provider>
    );
  },
);
