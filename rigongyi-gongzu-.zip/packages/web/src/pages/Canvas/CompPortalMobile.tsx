import CompContext from '@gongzu/core/common/CompContext';
import FactoryCompCanvas from '@gongzu/core/common/FactoryCompCanvas';
import { CompConfig } from '@gongzu/core/types/comps-common';
import { isPageComp } from '@gongzu/core/utils/comp';
import '@vant/touch-emulator';
import 'antd-mobile/es/global';
import { observer } from 'mobx-react';
import React from 'react';
import ErrorBoundaryMobile from '../../components/ErrorBoundaryMobile';
import mobileCompFactory from '../../components/mobile/mobileCompFactory';
import pageCompFactory from '../../components/page/pageCompFactory';
import WebProxyComp from '../../components/WebProxyComp';

export default observer(
  (props: { config: CompConfig; onLoad?: () => void }) => {
    const { onLoad = () => {} } = props;

    const pageCompContext = React.useContext(CompContext);

    React.useLayoutEffect(() => {
      onLoad();
    }, []);

    return (
      <CompContext.Provider
        value={{
          ...pageCompContext,
          proxyComp: WebProxyComp,
          factoryComp: FactoryCompCanvas,
          factory: (config) => {
            if (isPageComp(config.type)) {
              return pageCompFactory(config);
            }

            return mobileCompFactory(config);
          },
        }}
      >
        <ErrorBoundaryMobile>
          <FactoryCompCanvas key={props.config.id} {...props} />
        </ErrorBoundaryMobile>
      </CompContext.Provider>
    );
  },
);
