import CompContext from '@gongzu/core/common/CompContext';
import FactoryCompCanvas from '@gongzu/core/common/FactoryCompCanvas';
import { CompConfig } from '@gongzu/core/types/comps-common';
import { isPageComp } from '@gongzu/core/utils/comp';
import { ConfigProvider } from 'antd';
import zhCN from 'antd/lib/locale-provider/zh_CN';
import 'dayjs/locale/zh-cn';
import { observer } from 'mobx-react';
import React from 'react';
import desktopCompFactory from '../../components/desktop/desktopCompFactory';
import ErrorBoundaryDesktop from '../../components/ErrorBoundaryDesktop';
import pageCompFactory from '../../components/page/pageCompFactory';
import WebProxyComp from '../../components/WebProxyComp';

export default observer(
  (props: { config: CompConfig; onLoad?: () => void }) => {
    const { onLoad = () => {} } = props;

    const pageCompContext = React.useContext(CompContext);

    React.useLayoutEffect(() => {
      onLoad();
    }, []);

    return (
      <CompContext.Provider
        value={{
          ...pageCompContext,
          proxyComp: WebProxyComp,
          factoryComp: FactoryCompCanvas,
          factory: (config) => {
            if (isPageComp(config.type)) {
              return pageCompFactory(config);
            }

            return desktopCompFactory(config);
          },
        }}
      >
        <ErrorBoundaryDesktop>
          <ConfigProvider locale={zhCN}>
            <FactoryCompCanvas key={props.config.id} {...props} />
          </ConfigProvider>
        </ErrorBoundaryDesktop>
      </CompContext.Provider>
    );
  },
);
