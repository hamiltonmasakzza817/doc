import Central from '@gongzu/core/common/Central';
import CompContext from '@gongzu/core/common/CompContext';
import Loading from '@gongzu/core/common/Loading';
import {
  BaseStoresContext,
  EngineStoresContext,
} from '@gongzu/core/contexts/store-contexts';
import EngineStore from '@gongzu/core/engine/EngineStore';
import { PagePlatform } from '@gongzu/core/types/entities';
import cloneDeep from 'lodash-es/cloneDeep';
import compact from 'lodash-es/compact';
import pick from 'lodash-es/pick';
import { observer } from 'mobx-react';
import React from 'react';
import Loadable from 'react-loadable';
import { pageStore, sessionStore, streamStore } from '../container';
import { useLocationChange } from '../hooks';

const DesktopCompPortal = Loadable({
  loader: () =>
    import(
      /* webpackChunkName: "DesktopCompPortal" */ '../components/CompPortalDesktop'
    ),
  loading: Loading,
});

const MobileCompPortal = Loadable({
  loader: () =>
    import(
      /* webpackChunkName: "MobileCompPortal" */ '../components/CompPortalMobile'
    ),
  loading: Loading,
});

export default observer((props: { engineStore: EngineStore }) => {
  const { engineStore } = props;

  const compContext = React.useContext(CompContext);

  useLocationChange(engineStore);

  React.useEffect(() => {
    if (engineStore.page.platform === PagePlatform.MOBILE) {
      // @ts-ignore
      import('@vant/touch-emulator');
    }

    window.addEventListener('preview/on-dispose', () => {
      window.parent.dispatchEvent(
        new CustomEvent('preview/dispose', {
          detail: {
            state: cloneDeep(engineStore.engineRuntimeStore.state),
          },
        }),
      );
    });

    engineStore.start();
  }, []);

  const { elements } = engineStore.engineModelStore;

  return (
    <BaseStoresContext.Provider
      value={{
        loggerStore: engineStore.loggerStore,
        messageStore: engineStore.messageStore,
        streamStore,
        sessionStore,
        pageStore,
      }}
    >
      <EngineStoresContext.Provider
        value={{
          engineStore,
          ...pick(engineStore, [
            'engineActionStore',
            'engineEventStore',
            'engineDataStore',
            'engineFormStore',
            'engineModelStore',
            'engineRuntimeStore',
          ]),
        }}
      >
        {elements != null && elements.length > 0 ? (
          <CompContext.Provider
            value={{
              ...compContext,
              pageIds: compact([engineStore.page.id]),
              inDesigner: false,
              state: engineStore.engineRuntimeStore.state,
              viewportQuerySelector: `[data-viewport="${engineStore.page.id}"]`,
              loading: <Loading />,
            }}
          >
            <>
              {engineStore.page.platform === PagePlatform.MOBILE ? (
                <MobileCompPortal />
              ) : (
                <DesktopCompPortal />
              )}
            </>
          </CompContext.Provider>
        ) : (
          <Central>
            <div>无权限或未加载到数据</div>
          </Central>
        )}
      </EngineStoresContext.Provider>
    </BaseStoresContext.Provider>
  );
});
