import Central from '@gongzu/core/common/Central';
import PageCompContext from '@gongzu/core/common/CompContext';
import Loading from '@gongzu/core/common/Loading';
import {
  BaseStoresContext,
  EngineStoresContext,
  PlayerStoreContext,
} from '@gongzu/core/contexts/store-contexts';
import PageEngineStore from '@gongzu/core/engine/EngineStore';
import PlayerStore from '@gongzu/core/stores/PlayerStore';
import { PagePlatform } from '@gongzu/core/types/entities';
import compact from 'lodash-es/compact';
import { configure } from 'mobx';
import { observer, useLocalStore } from 'mobx-react';
import React from 'react';
import Loadable from 'react-loadable';
import { sessionStore } from '../container';
import { useLocationChange } from '../hooks';
import codeInterpreter from '../utils/codeInterpreter';
import router from '../utils/router';

const DesktopCompPortal = Loadable({
  loader: () =>
    import(
      /* webpackChunkName: "CompPortalDesktop" */ '../components/CompPortalDesktop'
    ),
  loading: Loading,
});

const MobileCompPortal = Loadable({
  loader: () =>
    import(
      /* webpackChunkName: "CompPortalMobile" */ '../components/CompPortalMobile'
    ),
  loading: Loading,
});

configure({
  isolateGlobalState: true,
});

const Player = observer(
  (props: { playerStore: PlayerStore; portal: HTMLElement }) => {
    const { playerStore, portal } = props;

    const { streamStore } = React.useContext(BaseStoresContext);

    const { engineStore } = playerStore;

    useLocationChange(engineStore);

    const pageCompContext = React.useContext(PageCompContext);

    React.useEffect(() => {
      playerStore.init().subscribe();
    }, []);

    if (streamStore.getPending(`${engineStore.page.id},init`)) {
      return <Loading />;
    }

    const { elements } = engineStore.engineModelStore;

    return (
      <EngineStoresContext.Provider
        value={{
          engineStore,
          ...engineStore,
        }}
      >
        <PlayerStoreContext.Provider value={playerStore}>
          {elements != null && elements.length > 0 ? (
            <PageCompContext.Provider
              value={{
                ...pageCompContext,
                pageIds: compact([engineStore.page.id]),
                inDesigner: false,
                state: engineStore.engineRuntimeStore.state,
                viewportQuerySelector: `[data-viewport="${engineStore.page.id}"]`,
                portal,
              }}
            >
              {engineStore.page.platform === PagePlatform.MOBILE ? (
                <MobileCompPortal />
              ) : (
                <DesktopCompPortal />
              )}
            </PageCompContext.Provider>
          ) : (
            <Central>
              <div>无权限或未加载到数据</div>
            </Central>
          )}
        </PlayerStoreContext.Provider>
      </EngineStoresContext.Provider>
    );
  },
);

export default observer(
  (props: {
    pageId?: string;
    pageUrl?: string;
    params?: Record<string, unknown>;
    portal: HTMLElement;
  }) => {
    const { pageId, pageUrl, params, portal } = props;

    const { streamStore, loggerStore, messageStore, pageStore } =
      React.useContext(BaseStoresContext);

    const localStore = useLocalStore<{
      playerStore: PlayerStore | null;
    }>(() => ({ playerStore: null }));

    React.useEffect(() => {
      if (pageId || pageUrl) {
        pageStore
          .fetchPage({ id: pageId, url: pageUrl }, 'publish')
          .subscribe((page) => {
            const pageEngineStore = new PageEngineStore(
              {
                page,
                params,
                portal,
              },
              loggerStore,
              messageStore,
              codeInterpreter,
              router,
            );

            localStore.playerStore = new PlayerStore(
              pageEngineStore,
              streamStore,
            );
          });
      }

      window.onbeforeunload = () => {
        if (localStore.playerStore) {
          localStore.playerStore.dispose();
        }
      };

      return () => {
        if (localStore.playerStore) {
          localStore.playerStore.dispose();
        }
      };
    }, []);

    if (localStore.playerStore == null) {
      return <Loading />;
    }

    return (
      <BaseStoresContext.Provider
        value={{
          streamStore,
          loggerStore,
          messageStore,
          sessionStore,
          pageStore,
        }}
      >
        <Player
          playerStore={localStore.playerStore}
          key={pageId}
          portal={portal}
        />
      </BaseStoresContext.Provider>
    );
  },
);
