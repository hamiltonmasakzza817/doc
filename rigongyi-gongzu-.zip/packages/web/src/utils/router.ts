import { getHistory } from '@gongzu/core/config/history';
import { Router } from '@gongzu/core/types/engine';
import get from 'lodash-es/get';
import qs from 'qs';

const router: Router = {
  location: {
    href: window.location.href,
    pathname: window.location.pathname,
    origin: window.location.origin,
  },
  searchParams:
    qs.parse(get(window, 'location.search'), { ignoreQueryPrefix: true }) ?? {},
  navigateTo: (url, mode) => {
    switch (mode) {
      case 'open': {
        const a = document.createElement('a');
        a.setAttribute('href', url);
        a.setAttribute('target', '_blank');
        a.setAttribute('style', 'display:none');
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        break;
      }

      case 'replace': {
        window.location.replace(url);
        break;
      }

      case 'pushState': {
        getHistory().push(url, {
          url,
        });
        break;
      }

      default: {
        window.location.href = url;
      }
    }
  },
};

export default router;
