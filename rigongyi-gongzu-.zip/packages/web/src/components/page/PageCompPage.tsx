import { css, Global } from '@emotion/react';
import CompContext from '@gongzu/core/common/CompContext';
import { useActionDispatcher, useParseValue } from '@gongzu/core/common/hooks';
import { CompProps } from '@gongzu/core/common/types';
import { EngineStoresContext } from '@gongzu/core/contexts/store-contexts';
import { PageCompPageConfig } from '@gongzu/core/types/comps-page';
import classNames from 'classnames';
import last from 'lodash-es/last';
import { observer } from 'mobx-react';
import React from 'react';

export default observer((props: CompProps<PageCompPageConfig>) => {
  const { className, config, children, innerRef, rawProps, ...rest } = props;

  const { engineModelStore, engineStore } =
    React.useContext(EngineStoresContext);

  const compContext = React.useContext(CompContext);

  const documentTitle = React.useRef<string>(document.title);

  const dispatchOnLoad = useActionDispatcher(config.onLoad);

  const parseValue = useParseValue();

  React.useEffect(() => {
    if (!compContext.inDesigner) {
      dispatchOnLoad();
    }
  }, [compContext.inDesigner]);

  React.useEffect(() => {
    const title = parseValue(config.documentTitle);

    if (title) {
      document.title = title;
    } else if (!engineStore.inPagePortal) {
      document.title = 'Gongzu Designer';
    }

    return () => {
      document.title = documentTitle.current;
    };
  }, []);

  return (
    <>
      <Global styles={css(engineModelStore.globalStyle)} />

      <div
        {...rest}
        className={classNames(
          className,
          `gongzu-designer-page-${last(compContext.pageIds)}`,
        )}
        ref={innerRef}
        data-id={config.id}
        {...rawProps}
      >
        {children}
      </div>
    </>
  );
});
