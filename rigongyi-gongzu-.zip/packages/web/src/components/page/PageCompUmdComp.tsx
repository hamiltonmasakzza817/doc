import CompContext from '@gongzu/core/common/CompContext';
import { CompProps } from '@gongzu/core/common/types';
import { parseValue, parseValueDeep } from '@gongzu/core/common/utils';
import WrapperComp from '@gongzu/core/common/WrapperComp';
import { gzdnBem } from '@gongzu/core/config/constants';
import { EngineStoresContext } from '@gongzu/core/contexts/store-contexts';
import { PageCompUmdCompConfig } from '@gongzu/core/types/comps-page';
import classNames from 'classnames';
import get from 'lodash-es/get';
import { observer } from 'mobx-react';
import React from 'react';
// @ts-ignore
import $script from 'scriptjs';

export default observer((props: CompProps<PageCompUmdCompConfig>) => {
  const { config, innerRef, className, ...rest } = props;

  const compContext = React.useContext(CompContext);

  const {
    engineRuntimeStore: { eventEmitter },
  } = React.useContext(EngineStoresContext);

  const component = React.useRef();

  const [ready, setReady] = React.useState(false);

  const params = parseValueDeep({
    source: config.params,
    compContext,
  });

  React.useEffect(() => {
    if (!compContext.inDesigner && config.url && config.moduleName) {
      const url = parseValue({
        expression: config.url,
        compContext,
      });

      const moduleName = parseValue({
        expression: config.moduleName,
        compContext,
      });

      const memberName = parseValue({
        expression: config.memberName,
        compContext,
      });

      $script(url, () => {
        const comp = get(window, `${moduleName}.${memberName || 'default'}`);

        if (comp) {
          component.current = comp;
          setReady(true);
        }
      });
    }
  }, []);

  if (compContext.inDesigner) {
    return (
      <WrapperComp
        className={classNames(gzdnBem('empty-block')(), className)}
        ref={innerRef}
        {...rest}
      >
        UMD模块：{config.url || '--'}
      </WrapperComp>
    );
  }

  if (ready && component.current) {
    return (
      <WrapperComp className={className} {...rest}>
        {React.createElement(component.current, { ...params, eventEmitter })}
      </WrapperComp>
    );
  }

  return <></>;
});
