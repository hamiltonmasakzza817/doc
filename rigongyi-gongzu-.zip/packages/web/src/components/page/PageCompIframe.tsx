import CompContext from '@gongzu/core/common/CompContext';
import { useParseValue } from '@gongzu/core/common/hooks';
import { CompProps } from '@gongzu/core/common/types';
import { gzdnBem } from '@gongzu/core/config/constants';
import { EngineStoresContext } from '@gongzu/core/contexts/store-contexts';
import { PageCompIframeConfig } from '@gongzu/core/types/comps-page';
import classNames from 'classnames';
import set from 'lodash-es/set';
import { observer } from 'mobx-react';
import React from 'react';

export default observer((props: CompProps<PageCompIframeConfig>) => {
  const { config, className, rawProps, innerRef, ...rest } = props;

  const { inDesigner } = React.useContext(CompContext);

  const parseValue = useParseValue();

  const {
    engineRuntimeStore: { eventEmitter },
  } = React.useContext(EngineStoresContext);

  const src = parseValue(config.src);

  React.useEffect(() => {
    set(window, 'eventEmitter', eventEmitter);
  }, []);

  if (inDesigner) {
    return (
      <div
        className={classNames(className, gzdnBem('empty-block')())}
        ref={innerRef}
        {...rest}
        {...rawProps}
      >
        iframe，src: {src}
      </div>
    );
  }

  return (
    <iframe
      title={`iframe_${config.id}`}
      className={className}
      src={src?.toString()}
      style={{
        width: '100%',
        height: '100%',
        border: 'none',
      }}
      {...rest}
      {...rawProps}
    />
  );
});
