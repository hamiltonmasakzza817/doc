import { useParseValue } from '@gongzu/core/common/hooks';
import { CompProps } from '@gongzu/core/common/types';
import { PageCompTextConfig } from '@gongzu/core/types/comps-page';
import classNames from 'classnames';
import { observer } from 'mobx-react';
import React from 'react';

export default observer((props: CompProps<PageCompTextConfig>) => {
  const { config, className, rawProps, innerRef, ...rest } = props;

  const parseValue = useParseValue();

  const text = parseValue(config.text);

  const { textType } = config;

  const content = text?.toString() || '--';

  let textTypeClassName: string | undefined;

  if (parseValue(config.disabled)) {
    textTypeClassName = 'text-disabled';
  } else if (textType) {
    textTypeClassName = `text-${textType === 'danger' ? 'error' : textType}`;
  }

  return (
    <span
      ref={innerRef}
      className={classNames(textTypeClassName, className)}
      {...rest}
      {...rawProps}
    >
      {content}
    </span>
  );
});
