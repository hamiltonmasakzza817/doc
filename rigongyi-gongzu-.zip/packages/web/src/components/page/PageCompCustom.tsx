import { useParseValue } from '@gongzu/core/common/hooks';
import { CompProps } from '@gongzu/core/common/types';
import WrapperComp from '@gongzu/core/common/WrapperComp';
import { PageCompCustomConfig } from '@gongzu/core/types/comps-page';
import classNames from 'classnames';
import { observer } from 'mobx-react';
import React from 'react';

export default observer((props: CompProps<PageCompCustomConfig>) => {
  const { className, config, innerRef, children, rawProps, ...rest } = props;

  const parseValue = useParseValue();

  const loading = Boolean(parseValue(config.loading));

  return (
    <WrapperComp
      ref={innerRef}
      data-id={config.id}
      className={classNames({ relative: loading }, className)}
      {...rest}
      {...rawProps}
    >
      {children}
    </WrapperComp>
  );
});
