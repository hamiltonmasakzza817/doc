import CompContext from '@gongzu/core/common/CompContext';
import { CompProps } from '@gongzu/core/common/types';
import { parseValue, parseValueDeep } from '@gongzu/core/common/utils';
import { getHistory } from '@gongzu/core/config/history';
import {
  HyperlinkTarget,
  PageCompHyperlinkConfig,
} from '@gongzu/core/types/comps-page';
import { observer } from 'mobx-react';
import qs from 'qs';
import React from 'react';

export default observer((props: CompProps<PageCompHyperlinkConfig>) => {
  const { config, className, rawProps, innerRef, ...rest } = props;

  const compContext = React.useContext(CompContext);

  const text = parseValue({
    expression: config.text,
    compContext,
  });
  const url = parseValue({
    expression: config.url,
    compContext,
  });
  const usePushState = parseValue({
    expression: config.usePushState,
    compContext,
  });

  const params = parseValueDeep({
    source: config.params,
    compContext,
  });

  const url1 = url
    ? `${url}${params != null ? `?${qs.stringify(params)}` : ''}`
    : undefined;

  return (
    <a
      href={url1}
      onClick={
        usePushState
          ? (e) => {
              e.preventDefault();
              e.stopPropagation();
              getHistory().push(url, {});
            }
          : undefined
      }
      download={config.target === HyperlinkTarget.DOWNLOAD}
      target={config.target === HyperlinkTarget.BLANK ? '_blank' : undefined}
      rel="noreferrer"
      className={className}
      ref={innerRef}
      {...rest}
      {...rawProps}
    >
      {text?.toString() ?? '--'}
    </a>
  );
});
