import { useParseValue } from '@gongzu/core/common/hooks';
import { CompProps } from '@gongzu/core/common/types';
import { PageCompBlockConfig } from '@gongzu/core/types/comps-page';
import DOMPurify from 'dompurify';
import { observer } from 'mobx-react';
import React from 'react';

export default observer((props: CompProps<PageCompBlockConfig>) => {
  const { config, rawProps, innerRef, ...rest } = props;

  const parseValue = useParseValue();

  const rawHtml = parseValue(config.rawHtml);

  let html = '';

  try {
    if (rawHtml) {
      html = DOMPurify.sanitize(rawHtml);
    }
    // eslint-disable-next-line no-empty
  } catch (e) {}

  return (
    <div
      dangerouslySetInnerHTML={
        rawHtml
          ? {
              __html: html,
            }
          : undefined
      }
      ref={innerRef}
      {...rest}
      {...rawProps}
    />
  );
});
