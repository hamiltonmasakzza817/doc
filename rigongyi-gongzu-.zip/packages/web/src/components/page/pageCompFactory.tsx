import { CompProps } from '@gongzu/core/common/types';
import PageCompCustom from '@gongzu/core/gongzu-components/PageCompCustom';
import PageCompDefault from '@gongzu/core/gongzu-components/PageCompDefault';
import PageCompPagePortal from '@gongzu/core/gongzu-components/PageCompPagePortal';
import PageCompRepeat from '@gongzu/core/gongzu-components/PageCompRepeat';
import { PageCompConfig, PageCompType } from '@gongzu/core/types/comps-page';
import React from 'react';
import PageCompBlock from './PageCompBlock';
import PageCompHyperlink from './PageCompHyperlink';
import PageCompIframe from './PageCompIframe';
import PageCompPage from './PageCompPage';
import PageCompText from './PageCompText';
import PageCompUmdComp from './PageCompUmdComp';

export default function pageCompFactory(config: PageCompConfig) {
  let el: React.FunctionComponent<CompProps<any>>;

  switch (config.type) {
    case PageCompType.TEXT: {
      el = PageCompText;
      break;
    }

    case PageCompType.HYPERLINK: {
      el = PageCompHyperlink;
      break;
    }

    case PageCompType.REPEAT: {
      el = PageCompRepeat;
      break;
    }

    case PageCompType.PAGE: {
      el = PageCompPage;
      break;
    }

    case PageCompType.CUSTOM: {
      el = PageCompCustom;
      break;
    }

    case PageCompType.PAGE_PORTAL: {
      el = PageCompPagePortal;
      break;
    }

    case PageCompType.IFRAME: {
      // eslint-disable-next-line @typescript-eslint/ban-ts-comment
      // @ts-ignore
      el = PageCompIframe;
      break;
    }

    case PageCompType.BLOCK: {
      el = PageCompBlock;
      break;
    }

    case PageCompType.UMD_COMP: {
      el = PageCompUmdComp;
      break;
    }

    default:
      el = PageCompDefault;
      break;
  }

  return el;
}
