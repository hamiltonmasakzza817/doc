import { Toast } from 'antd-mobile';
import React from 'react';

class ErrorBoundaryMobile extends React.Component {
  componentDidCatch(error: Error) {
    Toast.show({ content: error.message, icon: 'fail' });
    this.forceUpdate();
  }

  render() {
    return this.props.children;
  }
}

export default ErrorBoundaryMobile;
