import { css, cx } from '@emotion/css';
import { CompProps } from '@gongzu/core/common/types';
import { EngineStoresContext } from '@gongzu/core/contexts/store-contexts';
import { CompConfig } from '@gongzu/core/types/comps-common';
import forEach from 'lodash-es/forEach';
import { observer } from 'mobx-react';
import React from 'react';

export default observer(
  (
    props: CompProps<CompConfig> & {
      el:
        | React.FunctionComponent<any>
        | React.ComponentClass<any, any>
        | string;
    },
  ) => {
    const { config, className, children, el, ...rest } = props;

    const {
      engineModelStore: { styles },
    } = React.useContext(EngineStoresContext);

    let clx = className;

    if (config.styleIds) {
      forEach(config.styleIds, (styleId) => {
        const style = styles[styleId];
        if (style) {
          clx = cx(clx, css(style.style));
        }
      });
    }

    if (config.css) {
      clx = cx(clx, css(config.css));
    }

    return React.createElement(
      el,
      {
        className: clx,
        config,
        ...rest,
      },
      children,
    );
  },
);
