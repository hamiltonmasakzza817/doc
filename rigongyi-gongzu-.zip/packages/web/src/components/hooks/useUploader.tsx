import CompContext from '@gongzu/core/common/CompContext';
import { CompProps } from '@gongzu/core/common/types';
import {
  parsePathname,
  parseValue,
  parseValueDeep,
} from '@gongzu/core/common/utils';
import FileUploader from '@gongzu/core/components/FileUploader';
import api from '@gongzu/core/config/api';
import {
  BaseStoresContext,
  EngineStoresContext,
} from '@gongzu/core/contexts/store-contexts';
import { CompUploader } from '@gongzu/core/types/comps-common';
import { LoggerType } from '@gongzu/core/types/entities';
import React from 'react';

export default function useUploader(props: CompProps<CompUploader>) {
  const { config, rawProps, children } = props;

  const compContext = React.useContext(CompContext);

  const { loggerStore } = React.useContext(BaseStoresContext);

  const { engineStore } = React.useContext(EngineStoresContext);

  let url = config.url
    ? parseValue({
        expression: config.url,
        compContext,
      })
    : null;

  if (url == null) {
    url = api.file.upload;
  }

  let loadingPathname: string | undefined;

  if (config.loading) {
    loadingPathname = parsePathname({
      expression: config.loading,
      compContext,
    }).pathname;
  }

  return (
    <FileUploader
      maxSize={parseValue({
        expression: config.maxSize,
        compContext,
      })}
      minSize={parseValue({
        expression: config.minSize,
        compContext,
      })}
      onError={(msg) => {
        loggerStore.error(msg, LoggerType.NOTIFICATION);
      }}
      accept={config.accept}
      multiple={config.multiple}
      url={url}
      onStart={() => {
        if (loadingPathname) {
          engineStore.updateData(loadingPathname, true);
        }
      }}
      onFinally={() => {
        if (loadingPathname) {
          engineStore.updateData(loadingPathname, false);
        }
      }}
      getParams={
        config.params
          ? (files) =>
              parseValueDeep({
                source: config.params,
                compContext: {
                  ...compContext,
                  state: {
                    ...compContext.state,
                    _files: files,
                  },
                },
              })
          : undefined
      }
      disabled={Boolean(
        parseValue({
          expression: config.disabled,
          compContext,
        }),
      )}
      {...rawProps}
    >
      {children as any}
    </FileUploader>
  );
}
