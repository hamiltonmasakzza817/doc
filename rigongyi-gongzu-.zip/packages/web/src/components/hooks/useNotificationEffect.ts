import { BaseStoresContext } from '@gongzu/core/contexts/store-contexts';
import { LoggerLevel, LoggerType } from '@gongzu/core/types/entities';
import { message, notification } from 'antd';
import React from 'react';

export default () => {
  const { loggerStore } = React.useContext(BaseStoresContext);

  React.useEffect(() => {
    const { current } = loggerStore;

    if (current) {
      const { level, message: msg, type } = current;

      switch (`${type}-${level}`) {
        case `${LoggerType.CONSOLE}-${LoggerLevel.INFO}`: {
          // eslint-disable-next-line no-console
          console.info(msg);
          break;
        }

        case `${LoggerType.CONSOLE}-${LoggerLevel.ERROR}`: {
          // eslint-disable-next-line no-console
          console.error(msg);
          break;
        }

        case `${LoggerType.CONSOLE}-${LoggerLevel.SUCCESS}`: {
          // eslint-disable-next-line no-console
          console.info(msg);
          break;
        }

        case `${LoggerType.MESSAGE}-${LoggerLevel.INFO}`: {
          message.info(msg);
          break;
        }

        case `${LoggerType.MESSAGE}-${LoggerLevel.ERROR}`: {
          message.error(msg);
          break;
        }

        case `${LoggerType.MESSAGE}-${LoggerLevel.SUCCESS}`: {
          message.success(msg);
          break;
        }

        case `${LoggerType.NOTIFICATION}-${LoggerLevel.INFO}`: {
          notification.info({
            message: '通知',
            description: msg,
          });
          break;
        }

        case `${LoggerType.NOTIFICATION}-${LoggerLevel.ERROR}`: {
          notification.error({
            message: '错误',
            description: msg,
          });
          break;
        }

        case `${LoggerType.NOTIFICATION}-${LoggerLevel.SUCCESS}`: {
          notification.success({
            message: '成功',
            description: msg,
          });
          break;
        }

        default:
          break;
      }

      loggerStore.hide();
    }
  }, [loggerStore.current]);
};
