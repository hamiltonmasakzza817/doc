import { useCustomElement, useParseValue } from '@gongzu/core/common/hooks';
import { CompProps } from '@gongzu/core/common/types';
import { MobileCompListItemConfig } from '@gongzu/core/types/comps-mobile';
import { List } from 'antd-mobile';
import { observer } from 'mobx-react';
import React from 'react';

export default observer((props: CompProps<MobileCompListItemConfig>) => {
  const { config, rawProps, children, innerRef, ...rest } = props;

  const parseValue = useParseValue();

  const prefix = useCustomElement(config.prefix);

  return (
    <List.Item
      prefix={prefix || parseValue(config.prefixText) || '--'}
      data-id={config.id}
      disabled={parseValue(config.disabled)}
      description={parseValue(config.description)}
      extra={parseValue(config.extra)}
      arrow={config.arrow}
      {...rest}
      {...rawProps}
    >
      <>
        {children}

        {innerRef && (
          <span
            ref={(el) => {
              innerRef.current = el?.parentNode?.parentNode?.parentNode;
            }}
            className="none"
          />
        )}
      </>
    </List.Item>
  );
});
