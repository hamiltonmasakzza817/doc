import CompContext from '@gongzu/core/common/CompContext';
import { CompProps } from '@gongzu/core/common/types';
import { parsePathname } from '@gongzu/core/common/utils';
import { MobileCompFormConfig } from '@gongzu/core/types/comps-mobile';
import { Form } from 'antd-mobile';
import compact from 'lodash-es/compact';
import concat from 'lodash-es/concat';
import { observer } from 'mobx-react';
import React from 'react';

export default observer((props: CompProps<MobileCompFormConfig>) => {
  const { config, innerRef, rawProps, children, ...rest } = props;

  const compContext = React.useContext(CompContext);

  const { pathname } = parsePathname({
    expression: config.value,
    compContext,
  });

  const layout =
    config.layout == null || config.layout === 'none'
      ? compContext.formLayout.layout
      : config.layout;

  return (
    <CompContext.Provider
      value={{
        ...compContext,
        dataBinding: {
          ...compContext.dataBinding,
          pathname,
          pathnames: compact(
            concat(pathname, compContext.dataBinding.pathnames),
          ),
        },
        formLayout: {
          layout,
        },
      }}
    >
      <Form
        data-id={config.id}
        layout={layout}
        mode={config.mode}
        {...rest}
        {...rawProps}
      >
        {children}

        {innerRef && (
          <span
            className="none"
            ref={(el) => {
              innerRef.current = el?.parentNode;
            }}
          />
        )}
      </Form>
    </CompContext.Provider>
  );
});
