import {
  useActionDispatcher,
  useParseValue,
  useParseValueWithContext,
} from '@gongzu/core//common/hooks';
import CompContext from '@gongzu/core/common/CompContext';
import { getOptions } from '@gongzu/core/common/form-helpers';
import { CompProps } from '@gongzu/core/common/types';
import { MobileCompSegmentConfig } from '@gongzu/core/types/comps-mobile';
import { CapsuleTabs } from 'antd-mobile';
import { observer } from 'mobx-react';
import React from 'react';

export default observer((props: CompProps<MobileCompSegmentConfig>) => {
  const { config, rawProps, innerRef, ...rest } = props;

  const parseValue = useParseValue();

  const compContext = React.useContext(CompContext);

  const parseValueWithContext = useParseValueWithContext();

  const dispatchOnChange = useActionDispatcher(config.onChange);

  const options = config.options
    ? getOptions(config.options, compContext)
    : undefined;

  return (
    <div ref={innerRef} {...rest}>
      <CapsuleTabs
        activeKey={parseValue(config.activeKey)}
        onChange={(key) => {
          dispatchOnChange({
            value: key,
          });
        }}
      >
        {options?.map((opt) => (
            <CapsuleTabs.Tab
              key={parseValueWithContext({
                expression: config.options?.value,
                context: opt,
              })}
              title={parseValueWithContext({
                expression: config.options?.label,
                context: opt,
              })}
              disabled={parseValueWithContext({
                expression: config.options?.disabled,
                context: opt,
              })}
            />
          ))}
      </CapsuleTabs>
    </div>
  );
});
