import { BaseStoresContext } from '@gongzu/core/contexts/store-contexts';
import { MessageConfirm, MessageType } from '@gongzu/core/stores/MessageStore';
import { LoggerLevel, LoggerType } from '@gongzu/core/types/entities';
import { Dialog, Toast } from 'antd-mobile';
import React from 'react';

export default () => {
  const { messageStore } = React.useContext(BaseStoresContext);

  React.useEffect(() => {
    if (messageStore.current) {
      const { type } = messageStore.current;

      const msg = messageStore.current as MessageConfirm;

      let handled = false;

      if (type === MessageType.CONFIRM) {
        Dialog.show({
          title: '提示',
          content: msg.title,
          closeOnAction: true,
          onClose: () => {
            msg.reject();
          },
          actions: [
            [
              {
                key: 'cancel',
                text: '取消',
                danger: true,
                onClick: () => {
                  msg.reject();
                },
              },
              {
                key: 'confirm',
                text: '确定',
                bold: true,
                onClick: () => {
                  msg.resolve();
                },
              },
            ],
          ],
        });

        handled = true;
      }

      if (handled) {
        messageStore.receive(messageStore.current);
      }
    }
  }, [messageStore.current]);
};
