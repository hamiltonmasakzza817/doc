import { useActionDispatcher, useParseValue } from '@gongzu/core/common/hooks';
import { CompProps } from '@gongzu/core/common/types';
import { MobileCompTabsConfig } from '@gongzu/core/types/comps-mobile';
import { Tabs } from 'antd-mobile';
import get from 'lodash-es/get';
import { observer } from 'mobx-react';
import React from 'react';

export default observer((props: CompProps<MobileCompTabsConfig>) => {
  const { innerRef, config, children, ...rest } = props;

  const parseValue = useParseValue();

  const dispatchOnChange = useActionDispatcher(config.onChange);

  return (
    <div ref={innerRef} {...rest}>
      <Tabs
        activeKey={parseValue(config.activeKey)}
        onChange={(key) => {
          dispatchOnChange({ key });
        }}
      >
        {React.Children.map(children, (child, index) => {
          const tab = get(config.children, index);

          return (
            <Tabs.Tab key={tab.code} title={parseValue(tab.title)}>
              {child}
            </Tabs.Tab>
          );
        })}
        {children}
      </Tabs>
    </div>
  );
});
