import CompContext from '@gongzu/core/common/CompContext';
import { findOptionName, getOptions } from '@gongzu/core/common/form-helpers';
import { CompProps } from '@gongzu/core/common/types';
import { useParseValue } from '@gongzu/core/common/hooks';
import { MobileCompSelectConfig } from '@gongzu/core/types/comps-mobile';
import { Picker } from 'antd-mobile';
import { observer, useLocalObservable } from 'mobx-react';
import React from 'react';
import MobileFormItem from './MobileFormItem';

export default observer((props: CompProps<MobileCompSelectConfig>) => {
  const { config, rawProps, innerRef, ...rest } = props;

  const localState = useLocalObservable(() => ({
    pickerVisible: false,
  }));

  const compContext = React.useContext(CompContext);

  const parseValue = useParseValue();

  const options = config.options ? getOptions(config.options, compContext) : [];

  return (
    <MobileFormItem
      ref={innerRef}
      config={config}
      wrapperProps={rest}
      showInExtra
      onClick={() => {
        if (
          compContext.inDesigner ||
          parseValue(config.disabled) ||
          parseValue(config.readOnly)
        ) {
          return;
        }

        localState.pickerVisible = true;
      }}
      renderFormControl={({ bind, placeholder }) => {
        const optionName = findOptionName(bind?.value, options);

        return (
          <>
            {optionName || placeholder}

            <Picker
              visible={localState.pickerVisible}
              onClose={() => {
                localState.pickerVisible = false;
              }}
              columns={[
                options.map((opt) => ({ label: opt.name, value: opt.value })),
              ]}
              value={bind?.value}
              onConfirm={(v) => {
                bind.onChange(v);
              }}
            />
          </>
        );
      }}
    />
  );
});
