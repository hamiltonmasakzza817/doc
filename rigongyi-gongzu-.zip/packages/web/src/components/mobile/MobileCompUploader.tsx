import { useParseValueWithContext } from '@gongzu/core/common/hooks';
import { CompProps } from '@gongzu/core/common/types';
import useFormItem from '@gongzu/core/common/useFormItem';
import { FileEntity } from '@gongzu/core/components/FileUploader';
import { MobileCompUploaderConfig } from '@gongzu/core/types/comps-mobile';
import { observer } from 'mobx-react';
import React from 'react';
import useUploader from '../hooks/useUploader';

export default observer((props: CompProps<MobileCompUploaderConfig>) => {
  const { config, innerRef, ...rest } = props;

  const parseValueWithContext = useParseValueWithContext();

  const uploader = useUploader(props);

  return useFormItem(config, ({ bind, disabled }) => {
    const { onChange } = bind || {};

    return (
      <div ref={innerRef} {...rest}>
        {React.cloneElement(uploader, {
          onChange: (files: FileEntity[]) => {
            if (onChange) {
              const formatter = config.formatter || `$\{_context.url}`;

              if (config.multiple) {
                onChange(
                  files.map((f) =>
                    parseValueWithContext({
                      expression: formatter,
                      context: f,
                    }),
                  ),
                );
              } else {
                onChange(
                  parseValueWithContext({
                    expression: formatter,
                    context: files[0],
                  }),
                );
              }
            }
          },

          disabled,
        })}
      </div>
    );
  }).content;
});
