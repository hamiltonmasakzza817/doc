import CompContext from '@gongzu/core/common/CompContext';
import { useActionDispatcher, useParseValue } from '@gongzu/core/common/hooks';
import { CompProps } from '@gongzu/core/common/types';
import { parsePathname } from '@gongzu/core/common/utils';
import { EngineStoresContext } from '@gongzu/core/contexts/store-contexts';
import { MobileCompSearchBarConfig } from '@gongzu/core/types/comps-mobile';
import { SearchBar } from 'antd-mobile';
import get from 'lodash-es/get';
import { observer } from 'mobx-react';
import React from 'react';

export default observer((props: CompProps<MobileCompSearchBarConfig>) => {
  const { config, rawProps, innerRef, ...rest } = props;

  const compContext = React.useContext(CompContext);

  const { engineStore } = React.useContext(EngineStoresContext);

  const parseValue = useParseValue();

  const dispatchOnBlur = useActionDispatcher(config.onBlur);

  const dispatchOnSearch = useActionDispatcher(config.onSearch);

  const dispatchOnClear = useActionDispatcher(config.onClear);

  const dispatchOnChange = useActionDispatcher(config.onChange);

  const dispatchOnFocus = useActionDispatcher(config.onFocus);

  let pathname: string | undefined;

  if (config.pathname) {
    ({ pathname } = parsePathname({
      expression: config.value,
      compContext,
    }));
  }

  return (
    <div ref={innerRef} {...rest}>
      <SearchBar
        value={
          pathname != null
            ? (get(compContext.state, pathname) as string) ?? ''
            : ''
        }
        onChange={
          pathname
            ? (value) => {
                if (!compContext.inDesigner) {
                  engineStore.updateData(pathname!, value);
                  dispatchOnChange({ value });
                }
              }
            : undefined
        }
        placeholder={parseValue(config.placeholder)}
        showCancelButton={config.showCancelButton}
        cancelText={config.cancelText}
        maxLength={config.maxLength}
        onSearch={() => dispatchOnSearch()}
        onBlur={dispatchOnBlur}
        onClear={dispatchOnClear}
        onFocus={dispatchOnFocus}
        {...rawProps}
      />
    </div>
  );
});
