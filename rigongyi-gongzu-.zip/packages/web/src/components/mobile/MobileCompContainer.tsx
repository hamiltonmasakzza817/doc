import CompContext from '@gongzu/core/common/CompContext';
import {
  useActionDispatcher,
  useCustomElement,
  useParseValue,
} from '@gongzu/core/common/hooks';
import Loading from '@gongzu/core/common/Loading';
import { CompProps } from '@gongzu/core/common/types';
import FlexWrapper from '@gongzu/core/components/FlexWrapper';
import {
  BaseStoresContext,
  EngineStoresContext,
} from '@gongzu/core/contexts/store-contexts';
import { MobileCompContainerConfig } from '@gongzu/core/types/comps-mobile';
import { Popover } from 'antd-mobile';
import classNames from 'classnames';
import { observer } from 'mobx-react';
import React from 'react';

export default observer((props: CompProps<MobileCompContainerConfig>) => {
  const { className, config, children, innerRef, rawProps, ...rest } = props;

  const parseValue = useParseValue();

  const compContext = React.useContext(CompContext);

  const engineStoresContext = React.useContext(EngineStoresContext);

  const baseStoresContext = React.useContext(BaseStoresContext);

  const dispatchOnHeightChange = useActionDispatcher(config.onHeightChange);

  const { engineModelStore } = engineStoresContext;

  let customElement = useCustomElement(config.renderCompId);

  if (compContext.inDesigner && customElement) {
    customElement = (
      <div
        style={{
          height: 80,
          outline: '1px dashed',
          outlineOffset: -1,
        }}
        className={classNames('flex justify-center items-center', className)}
      >
        {customElement}
      </div>
    );
  }

  let content = customElement || children;

  const loading = Boolean(parseValue(config.loading));

  if (loading) {
    content = (
      <>
        {content}
        <Loading
          style={{
            backgroundColor: 'rgba(255, 255, 255, 0.4)',
          }}
        />
      </>
    );
  }

  const wrapperProps = {
    ...rest,
    id: config.id,
    className: classNames(className, { relative: loading }),
  };

  if (config.flexBottom) {
    return (
      <FlexWrapper
        bottom={parseValue(config.flexBottom)}
        innerRef={innerRef}
        container={
          compContext.inDesigner ? compContext.viewportQuerySelector : undefined
        }
        portal={compContext.portal}
        onHeightChange={(height: number) => {
          dispatchOnHeightChange({ height });
        }}
        {...wrapperProps}
      >
        {content}
      </FlexWrapper>
    );
  }

  let popover;

  if (config.popoverCompId) {
    const dropdownComp = engineModelStore.customs[config.popoverCompId];

    if (dropdownComp) {
      popover = (
        <>
          <BaseStoresContext.Provider value={baseStoresContext}>
            <EngineStoresContext.Provider value={engineStoresContext}>
              <CompContext.Provider value={compContext}>
                {React.createElement(compContext.factoryComp, {
                  config: dropdownComp,
                })}
              </CompContext.Provider>
            </EngineStoresContext.Provider>
          </BaseStoresContext.Provider>
        </>
      );
    }
  }

  const container = (
    <div {...wrapperProps} ref={innerRef} data-id={config.id} {...rawProps}>
      {content}
    </div>
  );

  if (popover && !compContext.inDesigner) {
    return (
      <Popover content={popover} placement={config.placement || 'bottomLeft'}>
        {container}
      </Popover>
    );
  }

  return container;
});
