import { useParseValue } from '@gongzu/core/common/hooks';
import { CompProps } from '@gongzu/core/common/types';
import { MobileCompSwitchConfig } from '@gongzu/core/types/comps-mobile';
import { Switch } from 'antd-mobile';
import { observer } from 'mobx-react';
import React from 'react';
import MobileFormItem from './MobileFormItem';

export default observer((props: CompProps<MobileCompSwitchConfig>) => {
  const { config, rawProps, innerRef, ...rest } = props;

  const parseValue = useParseValue();

  const checkedValue = parseValue(config.checkedValue) ?? true;

  const uncheckedValue = parseValue(config.uncheckedValue) ?? false;

  return (
    <MobileFormItem
      ref={innerRef}
      config={config}
      wrapperProps={rest}
      showInExtra
      renderFormControl={({ bind, disabled, readOnly }) => (
          <Switch
            checked={bind.value === checkedValue}
            onChange={(checked) => {
              if (!readOnly) {
                bind.onChange(checked ? checkedValue : uncheckedValue);
              }
            }}
            disabled={disabled}
            {...rawProps}
          />
        )}
    />
  );
});
