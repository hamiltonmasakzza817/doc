import { useActionDispatcher, useCustomElement , useParseValue } from '@gongzu/core/common/hooks';
import { CompProps } from '@gongzu/core/common/types';
import { MobileCompImageConfig } from '@gongzu/core/types/comps-mobile';
import { Image } from 'antd-mobile';
import classNames from 'classnames';
import { observer } from 'mobx-react';
import React from 'react';
import { gzmBem } from '../../constants';

export default observer((props: CompProps<MobileCompImageConfig>) => {
  const { config, rawProps, innerRef, className, ...rest } = props;

  const parseValue = useParseValue();

  const placeholder = useCustomElement(config.placeholder);

  const fallback = useCustomElement(config.fallback);

  const dispatchOnLoad = useActionDispatcher(config.onLoad);

  return (
    <div
      className={classNames(
        gzmBem('image')(),
        'inline-block',
        className,
      )}
      ref={innerRef}
      {...rest}
    >
      <Image
        src={parseValue(config.src)}
        width={config.styles?.width}
        height={config.styles?.height}
        alt={parseValue(config.alt)}
        fit={config.fit}
        placeholder={placeholder}
        fallback={fallback}
        lazy={config.lazy}
        onLoad={() => {
          dispatchOnLoad();
        }}
        {...rawProps}
      />
    </div>
  );
});
