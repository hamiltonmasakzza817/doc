import CompContext from '@gongzu/core/common/CompContext';
import { getOptions } from '@gongzu/core/common/form-helpers';
import {
  useParseValue,
  useParseValueWithContext,
} from '@gongzu/core/common/hooks';
import { CompProps } from '@gongzu/core/common/types';
import useFormItem from '@gongzu/core/common/useFormItem';
import { MobileCompCheckboxConfig } from '@gongzu/core/types/comps-mobile';
import { Checkbox, List, Space } from 'antd-mobile';
import classNames from 'classnames';
import compact from 'lodash-es/compact';
import split from 'lodash-es/split';
import { observer } from 'mobx-react';
import React from 'react';
import { gzmBem } from '../../constants';

export default observer((props: CompProps<MobileCompCheckboxConfig>) => {
  const { className, config, rawProps, innerRef, ...rest } = props;

  const compContext = React.useContext(CompContext);

  const options = getOptions(config.options, compContext);

  const parseValueWithContext = useParseValueWithContext();
  const parseValue = useParseValue();

  return useFormItem(config, ({ bind, label, disabled, readOnly }) => {
    const values = split(bind.value, ',');

    return (
      <div
        className={classNames(className, gzmBem('checkbox')())}
        ref={innerRef}
        {...rest}
      >
        <List header={label}>
          <Checkbox.Group
            disabled={parseValue(config.disabled)}
            value={values}
            onChange={(value) => {
              if (disabled || readOnly) {
                return;
              }

              bind.onChange(compact(value).join(','));
            }}
          >
            <Space direction={config.block ? 'vertical' : 'horizontal'}>
              {options.map((opt) => (
                <Checkbox
                  key={opt.value}
                  value={opt.value}
                  checked={values.includes(opt.value)}
                  block={config.block}
                  disabled={parseValueWithContext({
                    expression: config.options?.disabled,
                    context: opt,
                  })}
                >
                  {opt.name}
                </Checkbox>
              ))}
            </Space>
          </Checkbox.Group>
        </List>
      </div>
    );
  }).content;
});
