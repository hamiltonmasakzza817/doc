import Central from '@gongzu/core/common/Central';
import CompContext from '@gongzu/core/common/CompContext';
import { CompProps } from '@gongzu/core/common/types';
import { parsePathname, parseValue } from '@gongzu/core/common/utils';
import { MobileCompSwiperConfig } from '@gongzu/core/types/comps-mobile';
import { Swiper } from 'antd-mobile';
import get from 'lodash-es/get';
import map from 'lodash-es/map';
import size from 'lodash-es/size';
import { observer } from 'mobx-react';
import React from 'react';

export default observer((props: CompProps<MobileCompSwiperConfig>) => {
  const { config, rawProps, innerRef, ...rest } = props;

  const compContext = React.useContext(CompContext);

  const { pathname } = parsePathname({
    expression: config.items?.dataSource,
    compContext,
  });

  const dataSource = pathname
    ? (get(compContext.state, pathname) as [])
    : undefined;

  if (size(dataSource) === 0) {
    return (
      <div ref={innerRef} {...rest}>
        <Central
          style={{
            minHeight: 100,
          }}
        >
          未指定图片
        </Central>
      </div>
    );
  }

  return (
    <div ref={innerRef} {...rest}>
      <Swiper
        autoplay={config.autoplay}
        autoplayInterval={config.autoplayInterval}
        loop={config.loop}
        slideSize={config.slideSize}
        direction={config.direction}
        style={{
          minHeight: 100,
        }}
        {...rawProps}
      >
        {map(dataSource, (slide, index) => {
          const src = parseValue({
            expression: config.items?.imageUrl,
            compContext,
            context: slide,
          });

          return (
            <Swiper.Item key={index}>
              {src ? (
                <img
                  alt="slide"
                  style={{ width: '100%', verticalAlign: 'top' }}
                  src={src}
                  onLoad={() => {
                    // fire window resize event to change height
                    window.dispatchEvent(new Event('resize'));
                  }}
                />
              ) : (
                '未指定图片'
              )}
            </Swiper.Item>
          );
        })}
      </Swiper>
    </div>
  );
});
