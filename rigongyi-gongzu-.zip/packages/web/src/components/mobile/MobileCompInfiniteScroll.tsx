import CompContext from '@gongzu/core/common/CompContext';
import { useActionDispatcher, useParseValue } from '@gongzu/core/common/hooks';
import { CompProps } from '@gongzu/core/common/types';
import { MobileCompInfiniteScrollConfig } from '@gongzu/core/types/comps-mobile';
import { InfiniteScroll } from 'antd-mobile';
import { observer } from 'mobx-react';
import React from 'react';

export default observer((props: CompProps<MobileCompInfiniteScrollConfig>) => {
  const { config, innerRef, rawProps, ...rest } = props;

  const { inDesigner } = React.useContext(CompContext);

  const parseValue = useParseValue();
  const loadMore = useActionDispatcher(config.onLoadMore);

  return (
    <div ref={innerRef} {...rest}>
      <InfiniteScroll
        loadMore={() =>
          new Promise<void>((resolve, reject) => {
            if (inDesigner) {
              resolve();
            } else {
              loadMore({}, () => resolve(), reject);
            }
          })
        }
        hasMore={parseValue(config.hasMore)}
        threshold={config.threshold}
      />
    </div>
  );
});
