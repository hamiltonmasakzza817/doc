import CompContext from '@gongzu/core/common/CompContext';
import { useParseValue } from '@gongzu/core/common/hooks';
import { CompProps } from '@gongzu/core/common/types';
import { MobileCompDatePickerConfig } from '@gongzu/core/types/comps-mobile';
import { DatePicker } from 'antd-mobile';
import dayjs from 'dayjs';
import isNumber from 'lodash-es/isNumber';
import { observer, useLocalObservable } from 'mobx-react';
import React from 'react';
import MobileFormItem from './MobileFormItem';

export default observer((props: CompProps<MobileCompDatePickerConfig>) => {
  const { config, rawProps, innerRef, ...rest } = props;

  const localState = useLocalObservable(() => ({
    pickerVisible: false,
  }));

  const compContext = React.useContext(CompContext);

  const parseValue = useParseValue();

  const format = parseValue(config.format);

  return (
    <MobileFormItem
      ref={innerRef}
      config={config}
      wrapperProps={rest}
      showInExtra
      onClick={() => {
        if (
          compContext.inDesigner ||
          parseValue(config.disabled) ||
          parseValue(config.readOnly)
        ) {
          return;
        }

        localState.pickerVisible = true;
      }}
      renderFormControl={({ bind, placeholder }) => (
        <DatePicker
          visible={localState.pickerVisible}
          value={bind.value && new Date(bind.value)}
          onClose={() => {
            localState.pickerVisible = false;
          }}
          onConfirm={(value) => {
            if (isNumber(bind.value)) {
              bind.onChange(+value);
            } else {
              bind.onChange(dayjs(value).format(format || 'YYYY-MM-DD'));
            }
          }}
          precision={config.precision}
          {...rawProps}
        >
          {() => bind.value ?? placeholder}
        </DatePicker>
      )}
    />
  );
});
