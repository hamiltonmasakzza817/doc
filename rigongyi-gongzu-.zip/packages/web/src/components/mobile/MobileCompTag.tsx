import { useParseValue } from '@gongzu/core/common/hooks';
import { CompProps } from '@gongzu/core/common/types';
import { MobileCompTagConfig } from '@gongzu/core/types/comps-mobile';
import { Tag } from 'antd-mobile';
import classNames from 'classnames';
import { observer } from 'mobx-react';
import React from 'react';

export default observer((props: CompProps<MobileCompTagConfig>) => {
  const { config, rawProps, className, innerRef, ...rest } = props;

  const parseValue = useParseValue();

  const color = parseValue(config.color);

  return (
    <Tag
      className={classNames(className, 'whitespace-nowrap')}
      color={color === 'custom' ? parseValue(config.customColor) : color}
      fill={config.fill}
      round={config.round}
      {...rest}
      {...rawProps}
    >
      {parseValue(config.text) ?? '--'}

      {innerRef && (
        <span
          className="none"
          ref={(el) => {
            innerRef.current = el?.parentNode;
          }}
        />
      )}
    </Tag>
  );
});
