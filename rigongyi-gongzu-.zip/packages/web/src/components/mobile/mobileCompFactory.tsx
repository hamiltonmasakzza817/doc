import PageCompDefault from '@gongzu/core/gongzu-components/PageCompDefault';
import { MobileCompConfig, MobileCompType, } from '@gongzu/core/types/comps-mobile';
import MobileCompButton from './MobileCompButton';
import MobileCompCapsuleTabs from './MobileCompCapsuleTabs';
import MobileCompCheckbox from './MobileCompCheckbox';
import MobileCompContainer from './MobileCompContainer';
import MobileCompDatePicker from './MobileCompDatePicker';
import MobileCompForm from './MobileCompForm';
import MobileCompFormItem from './MobileCompFormItem';
import MobileCompImage from './MobileCompImage';
import MobileCompInfiniteScroll from './MobileCompInfiniteScroll';
import MobileCompInput from './MobileCompInput';
import MobileCompList from './MobileCompList';
import MobileCompListItem from './MobileCompListItem';
import MobileCompModal from './MobileCompModal';
import MobileCompNumberInput from './MobileCompNumberInput';
import MobileCompRadio from './MobileCompRadio';
import MobileCompSearchBar from './MobileCompSearchBar';
import MobileCompSelect from './MobileCompSelect';
import MobileCompSwiper from './MobileCompSwiper';
import MobileCompSwitch from './MobileCompSwitch';
import MobileCompTabs from './MobileCompTabs';
import MobileCompTag from './MobileCompTag';
import MobileCompTextArea from './MobileCompTextArea';
import MobileCompUploader from './MobileCompUploader';
import './style.scss';

export default function mobileCompFactory(config: MobileCompConfig) {
  switch (config.type) {
    case MobileCompType.BUTTON: {
      return MobileCompButton;
    }

    case MobileCompType.CONTAINER: {
      return MobileCompContainer;
    }

    case MobileCompType.CAPSULE_TABS: {
      return MobileCompCapsuleTabs;
    }

    case MobileCompType.TAG: {
      return MobileCompTag;
    }

    case MobileCompType.FORM: {
      return MobileCompForm;
    }

    case MobileCompType.FORM_ITEM: {
      return MobileCompFormItem;
    }

    case MobileCompType.INPUT: {
      return MobileCompInput;
    }

    case MobileCompType.NUMBER_INPUT: {
      return MobileCompNumberInput;
    }

    case MobileCompType.DATE_PICKER: {
      return MobileCompDatePicker;
    }

    case MobileCompType.SELECT: {
      return MobileCompSelect;
    }

    case MobileCompType.SWITCH: {
      return MobileCompSwitch;
    }

    case MobileCompType.CHECKBOX: {
      return MobileCompCheckbox;
    }

    case MobileCompType.RADIO: {
      return MobileCompRadio;
    }

    case MobileCompType.SEARCH_BAR: {
      return MobileCompSearchBar;
    }

    case MobileCompType.TEXT_AREA: {
      return MobileCompTextArea;
    }

    case MobileCompType.LIST: {
      return MobileCompList;
    }

    case MobileCompType.LIST_ITEM: {
      return MobileCompListItem;
    }

    case MobileCompType.MODAL: {
      return MobileCompModal;
    }

    case MobileCompType.UPLOADER: {
      return MobileCompUploader;
    }

    case MobileCompType.SWIPER: {
      return MobileCompSwiper;
    }

    case MobileCompType.IMAGE: {
      return MobileCompImage;
    }

    case MobileCompType.TABS: {
      return MobileCompTabs;
    }

    case MobileCompType.INFINITE_SCROLL: {
      return MobileCompInfiniteScroll;
    }

    default: {
      return PageCompDefault;
    }
  }
}
