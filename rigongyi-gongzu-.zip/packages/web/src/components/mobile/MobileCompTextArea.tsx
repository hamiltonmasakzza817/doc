import { CompProps } from '@gongzu/core/common/types';
import useFormItem from '@gongzu/core/common/useFormItem';
import { MobileCompTextAreaConfig } from '@gongzu/core/types/comps-mobile';
import { List, TextArea } from 'antd-mobile';
import classNames from 'classnames';
import { observer } from 'mobx-react';
import React from 'react';
import { gzmBem } from '../../constants';

export default observer((props: CompProps<MobileCompTextAreaConfig>) => {
  const { className, config, rawProps, innerRef, ...rest } = props;

  return useFormItem(
    config,
    ({ bind, label, disabled, readOnly, placeholder }) => (
      <div
        ref={innerRef}
        className={classNames(className, gzmBem('textarea')())}
        {...rest}
      >
        <List header={label || '--'}>
          {readOnly ? (
            <div>{bind.value}</div>
          ) : (
            <TextArea
              {...bind}
              disabled={disabled}
              readOnly={readOnly}
              maxLength={config.maxLength}
              rows={config.rows}
              placeholder={placeholder}
              autoSize={config.autoSize}
              showCount={config.showCount}
              {...rawProps}
            />
          )}
        </List>
      </div>
    ),
  ).content;
});
