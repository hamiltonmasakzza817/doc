import CompContext from '@gongzu/core/common/CompContext';
import useFormItem, {
  RenderFormControl,
} from '@gongzu/core/common/useFormItem';
import {
  MobileCompConfig,
  MobileCompFormItem,
} from '@gongzu/core/src/types/comps-mobile';
import { List } from 'antd-mobile';
import { FormItemProps } from 'antd-mobile/es/components/form/form-item';
import 'antd-mobile/es/components/form/form-item.css';
import classNames from 'classnames';
import { observer } from 'mobx-react';
import React from 'react';
import { gzmBem } from '../../constants';

export type MobileFormItemProps = Omit<FormItemProps, 'children'> & {
  config: MobileCompConfig & MobileCompFormItem;
  wrapperProps: any;
  showInExtra?: boolean;
  renderFormControl: RenderFormControl;
};

const classPrefix = `adm-form-item`;

type FormItemLayoutProps = Pick<
  FormItemProps,
  | 'className'
  | 'style'
  | 'required'
  | 'hasFeedback'
  | 'disabled'
  | 'label'
  | 'help'
  | 'onClick'
  | 'hidden'
  | 'layout'
  | 'extra'
> & {
  htmlFor?: string;
  error?: string;
};

const FormItemLayout: React.FC<FormItemLayoutProps> = (props) => {
  const {
    className,
    style,
    extra,
    label,
    help,
    required,
    disabled,
    children,
    htmlFor,
    hidden,
    error,
    layout,
    hasFeedback,
  } = props;

  const feedback = hasFeedback && error;

  const labelElement = label ? (
    <label className={`${classPrefix}-label`} htmlFor={htmlFor}>
      {label}
      {required && <span className={`${classPrefix}-label-required`}>*</span>}
      {help && <span className={`${classPrefix}-label-help`}>{help}</span>}
    </label>
  ) : null;

  const descriptionElement = feedback && (
    <div className={`${classPrefix}-footer`}>{feedback}</div>
  );

  return (
    <List.Item
      style={style}
      title={layout === 'vertical' && labelElement}
      prefix={layout === 'horizontal' && labelElement}
      extra={extra}
      description={descriptionElement}
      className={classNames(classPrefix, className, {
        [`${classPrefix}-hidden`]: hidden,
      })}
      disabled={disabled}
      onClick={props.onClick}
    >
      {children}
    </List.Item>
  );
};

const MobileFormItem = observer(
  (
    props: MobileFormItemProps & {
      innerRef: React.ForwardedRef<any>;
    },
  ) => {
    const {
      config,
      innerRef,
      renderFormControl,
      showInExtra,
      wrapperProps,
      ...rest
    } = props;

    const compContext = React.useContext(CompContext);

    return useFormItem(config, (formItem) => {
      const control = renderFormControl(formItem);

      const { error, required, label } = formItem;

      return (
        <div
          ref={innerRef}
          {...wrapperProps}
          className={classNames(
            wrapperProps.className,
            gzmBem('form-item')(),
          )}
        >
          {config.pure ? (
            control
          ) : (
            <FormItemLayout
              name={config.id}
              label={label}
              layout={
                config.layout == null || config.layout === 'none'
                  ? compContext.formLayout.layout
                  : config.layout
              }
              required={required}
              hasFeedback={Boolean(error)}
              error={error}
              extra={showInExtra ? control : undefined}
              {...rest}
            >
              {showInExtra ? null : control}
            </FormItemLayout>
          )}
        </div>
      );
    }).content;
  },
);

export default React.forwardRef((props: MobileFormItemProps, ref) => (
  <MobileFormItem {...props} innerRef={ref} />
));
