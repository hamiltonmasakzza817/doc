import { useParseValueWithContext } from '@gongzu/core/common/hooks';
import CompContext from '@gongzu/core/common/CompContext';
import { getOptions } from '@gongzu/core/common/form-helpers';
import { CompProps } from '@gongzu/core/common/types';
import useFormItem from '@gongzu/core/common/useFormItem';
import { MobileCompCheckboxConfig } from '@gongzu/core/types/comps-mobile';
import { List, Radio, Space } from 'antd-mobile';
import classNames from 'classnames';
import { observer } from 'mobx-react';
import React from 'react';
import { gzmBem } from '../../constants';

export default observer((props: CompProps<MobileCompCheckboxConfig>) => {
  const { className, config, rawProps, innerRef, ...rest } = props;

  const compContext = React.useContext(CompContext);

  const options = getOptions(config.options, compContext);

  const parseValueWithContext = useParseValueWithContext();

  return useFormItem(config, ({ bind, label, disabled, readOnly }) => (
    <div
      className={classNames(className, gzmBem('checkbox')())}
      ref={innerRef}
      {...rest}
    >
      <List header={label}>
        <Radio.Group
          disabled={disabled || readOnly}
          value={bind.value}
          onChange={(value) => {
            if (disabled || readOnly) {
              return;
            }

            bind.onChange(value);
          }}
        >
          <Space direction={config.block ? 'vertical' : 'horizontal'}>
            {options.map((opt) => (
              <Radio
                key={opt.value}
                value={opt.value}
                block={config.block}
                disabled={parseValueWithContext({
                  expression: config.options?.disabled,
                  context: opt,
                })}
                {...rawProps}
              >
                {opt.name}
              </Radio>
            ))}
          </Space>
        </Radio.Group>
      </List>
    </div>
  )).content;
});
