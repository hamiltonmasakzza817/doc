import { CompProps } from '@gongzu/core/common/types';
import { MobileCompFormItemConfig } from '@gongzu/core/src/types/comps-mobile';
import { observer } from 'mobx-react';
import React from 'react';
import MobileFormItem from './MobileFormItem';

export default observer((props: CompProps<MobileCompFormItemConfig>) => {
  const { config, innerRef, children, rawProps, ...rest } = props;

  return (
    <MobileFormItem
      ref={innerRef}
      config={config}
      wrapperProps={rest}
      renderFormControl={() => <>{children}</>}
    />
  );
});
