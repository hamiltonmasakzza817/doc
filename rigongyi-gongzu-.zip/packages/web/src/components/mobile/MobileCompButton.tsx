import CompContext from '@gongzu/core/common/CompContext';
import { useParseValue } from '@gongzu/core/common/hooks';
import { CompProps } from '@gongzu/core/common/types';
import { MobileCompButtonConfig } from '@gongzu/core/types/comps-mobile';
import { Button } from 'antd-mobile';
import { observer } from 'mobx-react';
import React from 'react';

export default observer((props: CompProps<MobileCompButtonConfig>) => {
  const { config, className, rawProps, innerRef, ...rest } = props;

  const compContext = React.useContext(CompContext);

  const parseValue = useParseValue();

  return (
    <Button
      disabled={
        compContext.inDesigner ? false : Boolean(parseValue(config.disabled))
      }
      color={config.color || 'primary'}
      size={config.size}
      shape={config.shape}
      block={config.block}
      loading={Boolean(parseValue(config.loading))}
      loadingText={parseValue(config.loadingText)}
      fill={config.fill}
      className={className}
      {...rest}
      {...rawProps}
    >
      {parseValue(config.text) || '--'}

      {innerRef && (
        <span
          className="none"
          ref={(el) => {
            innerRef.current = el?.parentElement;
          }}
        />
      )}
    </Button>
  );
});
