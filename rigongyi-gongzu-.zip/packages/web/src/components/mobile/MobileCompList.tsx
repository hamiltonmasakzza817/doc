import { useParseValue } from '@gongzu/core/common/hooks';
import { CompProps } from '@gongzu/core/common/types';
import { MobileCompListConfig } from '@gongzu/core/types/comps-mobile';
import { List } from 'antd-mobile';
import { observer } from 'mobx-react';
import React from 'react';

export default observer((props: CompProps<MobileCompListConfig>) => {
  const { config, rawProps, innerRef, style, children, ...rest } = props;

  const parseValue = useParseValue();

  const header = parseValue(config.header);

  return (
    <div ref={innerRef} {...rest}>
      <List
        style={style}
        header={header}
        mode={config.mode}
        data-id={config.id}
        {...rawProps}
      >
        {children}
      </List>
    </div>
  );
});
