import { CompProps } from '@gongzu/core/common/types';
import { MobileCompInputConfig } from '@gongzu/core/types/comps-mobile';
import { Input } from 'antd-mobile';
import { observer } from 'mobx-react';
import React from 'react';
import MobileFormItem from './MobileFormItem';

export default observer((props: CompProps<MobileCompInputConfig>) => {
  const { config, rawProps, innerRef, ...rest } = props;

  return (
    <MobileFormItem
      ref={innerRef}
      config={config}
      wrapperProps={rest}
      renderFormControl={({ bind, disabled, readOnly, placeholder }) => {
        if (readOnly) {
          return bind?.value ?? '--';
        }

        return (
          <Input
            readOnly={readOnly}
            disabled={disabled}
            placeholder={placeholder}
            clearable={config.allowClear}
            type={config.inputType || 'text'}
            {...bind}
            {...rawProps}
          />
        );
      }}
    />
  );
});
