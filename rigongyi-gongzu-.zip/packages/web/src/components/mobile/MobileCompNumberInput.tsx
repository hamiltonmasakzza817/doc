import { CompProps } from '@gongzu/core/common/types';
import { MobileCompNumberInputConfig } from '@gongzu/core/types/comps-mobile';
import { Stepper } from 'antd-mobile';
import { observer } from 'mobx-react';
import React from 'react';
import MobileFormItem from './MobileFormItem';

export default observer((props: CompProps<MobileCompNumberInputConfig>) => {
  const { config, rawProps, innerRef, ...rest } = props;

  return (
    <MobileFormItem
      ref={innerRef}
      config={config}
      wrapperProps={rest}
      renderFormControl={({ bind, disabled, readOnly }) => readOnly ? (
          bind.value
        ) : (
          <Stepper
            className="w-full"
            max={config.max}
            min={config.min}
            step={config.step}
            disabled={disabled}
            {...bind}
            {...rawProps}
          />
        )}
    />
  );
});
