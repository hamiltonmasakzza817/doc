import CompContext from '@gongzu/core/common/CompContext';
import { useActionDispatcher, useParseValue } from '@gongzu/core/common/hooks';
import { CompProps } from '@gongzu/core/common/types';
import { EngineStoresContext } from '@gongzu/core/contexts/store-contexts';
import { MobileCompModalConfig } from '@gongzu/core/types/comps-mobile';
import { Popup } from 'antd-mobile';
import { Action } from 'antd-mobile/es/components/dialog';
import { Dialog } from 'antd-mobile/es/components/dialog/dialog';
import classNames from 'classnames';
import get from 'lodash-es/get';
import isEmpty from 'lodash-es/isEmpty';
import { observer } from 'mobx-react';
import React from 'react';

export default observer((props: CompProps<MobileCompModalConfig>) => {
  const { config, className, style, children, innerRef, rawProps, ...rest } =
    props;

  const compContext = React.useContext(CompContext);

  const parseValue = useParseValue();

  const { engineModelStore, engineStore } =
    React.useContext(EngineStoresContext);

  const dispatchOk = useActionDispatcher(config.onOk);

  const dispatchCancel = useActionDispatcher(config.onCancel);

  if (compContext.inDesigner) {
    return (
      <div
        ref={innerRef}
        data-id={config.id}
        className={classNames(
          className,
          `gongzu-designer-page-${engineModelStore.pageId}`,
        )}
        style={style}
        {...rest}
      >
        {children}
      </div>
    );
  }

  const visiblePathname = `_system.modalOpen.${config.id}`;

  const onClose = () => {
    dispatchCancel();
    engineStore.updateData(`${visiblePathname}`, false);
  };

  const actions: Action[] = [];

  const cancelText = parseValue(config.cancelText);

  if (!isEmpty(cancelText)) {
    actions.push({
      key: 'cancel',
      danger: true,
      text: parseValue(config.cancelText),
      onClick: onClose,
    });
  }

  actions.push({
    key: 'confirm',
    text: parseValue(config.okText) || '确定',
    bold: true,
    onClick: dispatchOk,
  });

  const visible = Boolean(get(compContext.state, visiblePathname));

  if (config.modalType === 'popup') {
    return (
      <Popup
        visible={visible}
        className={className}
        bodyStyle={style}
        position={config.position}
        onMaskClick={config.closeOnMaskClick ? onClose : undefined}
        {...rawProps}
      >
        {children}
      </Popup>
    );
  }

  return (
    <Dialog
      visible={visible}
      className={className}
      bodyStyle={style}
      title={parseValue(config.title)}
      closeOnMaskClick={config.closeOnMaskClick}
      onClose={onClose}
      content={children}
      actions={config.noFooter ? [] : [actions]}
      {...rawProps}
    />
  );
});
