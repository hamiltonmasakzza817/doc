import PageCompContext from '@gongzu/core/common/CompContext';
import FactoryComp from '@gongzu/core/common/FactoryComp';
import Loading from '@gongzu/core/common/Loading';
import useCompPortal from '@gongzu/core/common/useCompPortal';
import { EngineStoresContext } from '@gongzu/core/contexts/store-contexts';
import { isPageComp } from '@gongzu/core/utils/comp';
import { ConfigProvider, message, notification } from 'antd';
import zhCN from 'antd/lib/locale/zh_CN';
import 'dayjs/locale/zh-cn';
import last from 'lodash-es/last';
import { observer } from 'mobx-react';
import React from 'react';
import { useMessageStoreEffectWeb } from '../hooks';
import desktopCompFactory from './desktop/desktopCompFactory';
import useMessageStoreEffect from './desktop/hooks/useMessageStoreEffect';
import ErrorBoundaryDesktop from './ErrorBoundaryDesktop';
import useNotificationEffect from './hooks/useNotificationEffect';
import pageCompFactory from './page/pageCompFactory';
import WebProxyComp from './WebProxyComp';

const SideEffects = observer((props: { pageId: string }) => {
  useMessageStoreEffectWeb();
  useNotificationEffect();
  useMessageStoreEffect(props.pageId);
  return <></>;
});

// 页面元素渲染根入口
export default observer(() => {
  const { engineStore, engineModelStore } =
    React.useContext(EngineStoresContext);

  const pageCompContext = useCompPortal(engineStore);

  const { elements, modals } = engineModelStore;

  const pageId = last(pageCompContext.pageIds);

  React.useEffect(() => {
    engineStore.loadCssResources();

    const msgConfig = {
      getContainer: () =>
        (pageCompContext.portal.querySelector(`[data-viewport]`) ||
          document.body) as HTMLElement,
    };

    message.config(msgConfig);
    notification.config(msgConfig);
  }, []);

  return (
    <div data-viewport={pageId}>
      <PageCompContext.Provider
        value={{
          ...pageCompContext,
          loading: <Loading />,
          proxyComp: WebProxyComp,
          factoryComp: FactoryComp,
          factory: (config) => {
            if (isPageComp(config.type)) {
              return pageCompFactory(config);
            }

            return desktopCompFactory(config);
          },
        }}
      >
        <ConfigProvider locale={zhCN}>
          <ErrorBoundaryDesktop>
            {elements[0] != null && (
              <FactoryComp config={elements[0]} key="1" />
            )}

            {modals.map((modal) => (
              <FactoryComp config={modal} key={modal.id} />
            ))}

            <SideEffects pageId={pageId!} />
          </ErrorBoundaryDesktop>
        </ConfigProvider>
      </PageCompContext.Provider>
    </div>
  );
});
