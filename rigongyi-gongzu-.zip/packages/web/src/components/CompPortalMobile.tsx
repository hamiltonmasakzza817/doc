import PageCompContext from '@gongzu/core/common/CompContext';
import FactoryComp from '@gongzu/core/common/FactoryComp';
import Loading from '@gongzu/core/common/Loading';
import useCompPortal from '@gongzu/core/common/useCompPortal';
import { EngineStoresContext } from '@gongzu/core/contexts/store-contexts';
import { isPageComp } from '@gongzu/core/utils/comp';
import 'antd-mobile/es/global';
import last from 'lodash-es/last';
import { observer } from 'mobx-react';
import React from 'react';
import { useMessageStoreEffectWeb } from '../hooks';
import ErrorBoundaryMobile from './ErrorBoundaryMobile';
import useNotificationEffect from './hooks/useNotificationEffect';
import useMessageStoreEffect from './mobile/hooks/useMessageStoreEffect';
import mobileCompFactory from './mobile/mobileCompFactory';
import pageCompFactory from './page/pageCompFactory';
import WebProxyComp from './WebProxyComp';

const SideEffects = observer(() => {
  useMessageStoreEffectWeb();
  useNotificationEffect();
  useMessageStoreEffect();

  return <></>;
});

// 页面元素渲染根入口
export default observer(() => {
  const { engineStore, engineModelStore } =
    React.useContext(EngineStoresContext);

  const pageCompContext = useCompPortal(engineStore);

  const { elements, modals } = engineModelStore;

  React.useEffect(() => {
    engineStore.loadCssResources();
  }, []);

  const pageId = last(pageCompContext.pageIds);

  return (
    <div data-viewport={pageId}>
      <PageCompContext.Provider
        value={{
          ...pageCompContext,
          loading: <Loading />,
          proxyComp: WebProxyComp,
          factoryComp: FactoryComp,
          factory: (config) => {
            if (isPageComp(config.type)) {
              return pageCompFactory(config);
            }

            return mobileCompFactory(config);
          },
        }}
      >
        <ErrorBoundaryMobile>
          {elements[0] != null && <FactoryComp config={elements[0]} key="1" />}

          {modals.map((modal) => (
            <FactoryComp config={modal} key={modal.id} />
          ))}

          <SideEffects />
        </ErrorBoundaryMobile>
      </PageCompContext.Provider>
    </div>
  );
});
