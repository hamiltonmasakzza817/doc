import CompContext from '@gongzu/core/common/CompContext';
import { CompProps } from '@gongzu/core/common/types';
import useFormItem, {
  RenderFormControl,
} from '@gongzu/core/common/useFormItem';
import { EngineStoresContext } from '@gongzu/core/contexts/store-contexts';
import { getItemErrorProps } from '@gongzu/core/mobx-form/utils';
import { CompFormItem } from '@gongzu/core/types/comps-common';
import { Form } from 'antd';
import get from 'lodash-es/get';
import { observer } from 'mobx-react';
import React from 'react';

export default observer(
  (
    props: Omit<CompProps<CompFormItem>, 'children'> & {
      children: RenderFormControl;
    },
  ) => {
    const { config, children, rawProps, innerRef, ...rest } = props;

    const compContext = React.useContext(CompContext);

    const { engineFormStore } = React.useContext(EngineStoresContext);

    const { form } = engineFormStore;

    const { formLayout } = compContext;

    const { label, content, extra, pathname, readOnly, required } = useFormItem(
      config,
      children,
    );

    if (config.pure) {
      return (
        <div ref={innerRef} {...rest}>
          {content}
        </div>
      );
    }

    const labelSpan = config.label?.span ?? formLayout.label?.span;

    return (
      <div ref={innerRef} {...rest}>
        <Form.Item
          label={label}
          labelAlign={config.label?.align ?? formLayout.label?.align}
          labelCol={labelSpan ? { span: labelSpan } : undefined}
          required={required && !readOnly}
          extra={extra}
          {...(pathname ? getItemErrorProps(get(form?.errors, pathname)) : {})}
          {...rest}
          {...rawProps}
        >
          {content}
        </Form.Item>
      </div>
    );
  },
);
