import { useParseValue } from '@gongzu/core/common/hooks';
import { CompProps } from '@gongzu/core/common/types';
import { DesktopCompProgressConfig } from '@gongzu/core/types/comps-desktop';
import { Progress } from 'antd';
import { observer } from 'mobx-react';
import React from 'react';
import ReactDOM from 'react-dom';

export default observer((props: CompProps<DesktopCompProgressConfig>) => {
  const { config, rawProps, innerRef, ...rest } = props;

  const parseValue = useParseValue();

  return (
    <div ref={innerRef} {...rest}>
      <Progress
        percent={parseValue(config.value)}
        showInfo={false}
        strokeColor={config.strokeColor}
        trailColor={config.trailColor}
        {...rawProps}
      />
    </div>
  );
});
