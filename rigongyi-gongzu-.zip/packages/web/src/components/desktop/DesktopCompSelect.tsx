import PageCompContext from '@gongzu/core/common/CompContext';
import { findOptionName, getOptions } from '@gongzu/core/common/form-helpers';
import { useActionDispatcher } from '@gongzu/core/common/hooks';
import { rawPropsDesktopFormItem } from '@gongzu/core/common/raw-props-desktop';
import { CompProps } from '@gongzu/core/common/types';
import {
  getPopupContainer,
  parseValue,
  parseValueDeep,
} from '@gongzu/core/common/utils';
import { DesktopCompSelectConfig } from '@gongzu/core/types/comps-desktop';
import { Select } from 'antd';
import compact from 'lodash-es/compact';
import concat from 'lodash-es/concat';
import isEmpty from 'lodash-es/isEmpty';
import map from 'lodash-es/map';
import pick from 'lodash-es/pick';
import throttle from 'lodash-es/throttle';
import { observer } from 'mobx-react';
import React from 'react';
import DesktopCompFormItem from './DesktopCompFormItem';

export default observer((props: CompProps<DesktopCompSelectConfig>) => {
  const { config, rawProps, ...rest } = props;

  const pageCompContext = React.useContext(PageCompContext);

  const dispatchOnSearch = useActionDispatcher(config.onSearch);

  const onSearch = React.useCallback(
    throttle(
      (search) => {
        dispatchOnSearch({ search });
      },
      300,
      { leading: false },
    ),
    [],
  );

  const options = config.options
    ? getOptions(config.options, pageCompContext)
    : undefined;

  const loading = parseValue({
    expression: config.loading,
    compContext: pageCompContext,
  });

  return (
    <DesktopCompFormItem
      config={config}
      rawProps={pick(
        parseValueDeep({
          source: config.formItemRawProps,
          compContext: pageCompContext,
        }),
        rawPropsDesktopFormItem,
      )}
      {...rest}
    >
      {({ bind, disabled, readOnly, error }) => {
        const { value, onChange } = bind ?? {};
        const { mode, labelInValue } = config;
        const multiple = ['multiple', 'tags'].includes(mode);

        let selectValue = value;

        if (labelInValue) {
          selectValue = selectValue || {};
        }

        if (multiple) {
          selectValue = compact(concat(value));
        }

        if (readOnly && options) {
          let selectLabel;

          if (multiple) {
            selectLabel = map(value, (v) =>
              labelInValue ? v?.label : findOptionName(v, options),
            ).toString();
          } else {
            selectLabel = labelInValue
              ? value?.label
              : findOptionName(value, options);
          }

          return <div>{selectLabel || '--'}</div>;
        }

        return (
          <Select
            disabled={disabled}
            value={selectValue}
            onChange={(e) => {
              console.log('select onchange', e);
              onChange(e);
            }}
            autoFocus={config.autoFocus}
            placeholder={config.placeholder}
            optionLabelProp="label"
            showSearch
            allowClear={config.allowClear}
            loading={loading}
            filterOption={config.search}
            getPopupContainer={getPopupContainer(pageCompContext)}
            onSearch={onSearch}
            onFocus={() => {
              // 基于交互考虑，当用户 focus 时，若没有任何选择，则尝试搜索一下空
              if (isEmpty(selectValue)) {
                onSearch('');
              }
            }}
            mode={config.mode}
            labelInValue={labelInValue}
            status={error ? 'error' : undefined}
            {...rawProps}
          >
            {options?.map((option) => (
              <Select.Option
                value={option.value}
                label={option.label ?? option.name}
                key={option.value}
                disabled={option.disabled}
              >
                {option.name ?? option.label}
              </Select.Option>
            ))}
          </Select>
        );
      }}
    </DesktopCompFormItem>
  );
});
