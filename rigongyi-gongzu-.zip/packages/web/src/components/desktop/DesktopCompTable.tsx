import PageCompContext from '@gongzu/core/common/CompContext';
import CustomCompNav from '@gongzu/core/common/CustomCompNav';
import { useActionDispatcher } from '@gongzu/core/common/hooks';
import { CompProps } from '@gongzu/core/common/types';
import {
  getPopupContainer,
  getTreeLevelKeys,
  parsePathname,
  parseValue,
  parseValueDeep,
} from '@gongzu/core/common/utils';
import { EngineStoresContext } from '@gongzu/core/contexts/store-contexts';
import { DesktopCompTableConfig } from '@gongzu/core/types/comps-desktop';
import { PageCompCustomConfig } from '@gongzu/core/types/comps-page';
import { mapTreeNode } from '@gongzu/core/utils/tree';
import { Table } from 'antd';
import { ColumnProps } from 'antd/es/table';
import { SorterResult } from 'antd/es/table/interface';
import { DataNode } from 'antd/lib/tree';
import assign from 'lodash-es/assign';
import compact from 'lodash-es/compact';
import concat from 'lodash-es/concat';
import get from 'lodash-es/get';
import pick from 'lodash-es/pick';
import set from 'lodash-es/set';
import size from 'lodash-es/size';
import values from 'lodash-es/values';
import { runInAction } from 'mobx';
import { observer, Observer } from 'mobx-react';
import React from 'react';

export default observer((props: CompProps<DesktopCompTableConfig>) => {
  const { config, rawProps, innerRef, ...rest } = props;

  const [expandedKeys, setExpandedKeys] = React.useState<(string | number)[]>(
    [],
  );
  const hasSetDefaultExpanded = React.useRef<boolean>(false);

  const pageCompContext = React.useContext(PageCompContext);

  const { engineModelStore } = React.useContext(EngineStoresContext);

  const dispatchOnRowSelectionChange = useActionDispatcher(
    config.onRowSelectionChange,
  );

  const dispatchOnRowClick = useActionDispatcher(config.onRowClick);

  const dispatchOnSort = useActionDispatcher(config.onSort);

  const { pathname } = parsePathname({
    expression: config.dataSource,
    compContext: pageCompContext,
  });

  const dataSource = pathname
    ? get(pageCompContext.state, pathname)
    : undefined;

  const { childrenKey = 'children' } = config;

  let i = 0;

  const tableDataSource = Array.isArray(dataSource)
    ? mapTreeNode<DataNode, DataNode>(
        dataSource,
        (node, parent, index) => {
          i += 1;

          return {
            ...node,
            key: config.rowKey ? get(node, config.rowKey) : i,
            _pathname: parent
              ? `${get(parent, '_pathname')}.${childrenKey}[${index}]`
              : `${pathname}[${index}]`,
          };
        },
        childrenKey,
      )
    : undefined;

  React.useEffect(() => {
    if (
      !hasSetDefaultExpanded.current &&
      config.defaultExpandLevel != null &&
      size(tableDataSource) > 0
    ) {
      hasSetDefaultExpanded.current = true;
      setExpandedKeys(
        getTreeLevelKeys({
          tree: tableDataSource,
          level: config.defaultExpandLevel,
        }),
      );
    }
  }, [tableDataSource]);

  const { customs } = engineModelStore;

  const sortKey = parseValue({
    expression: config.sortKey,
    compContext: pageCompContext,
  });

  const sortOrder = parseValue({
    expression: config.sortOrder,
    compContext: pageCompContext,
  });

  const scrollY = parseValue({
    expression: config.scrollY,
    compContext: pageCompContext,
  });

  let columnsOptions = config.columns;

  if (config.columnOptions) {
    columnsOptions = values(
      parseValueDeep({
        source: config.columnOptions,
        compContext: pageCompContext,
      }),
    );
  }

  const columns = columnsOptions.map((col, index) => {
    let so: string | undefined;

    if (sortKey === col.key && typeof sortOrder === 'string') {
      so = sortOrder?.toLowerCase().replace(/$/, 'end');
    }

    const filtered = parseValue({
      expression: col.filtered,
      compContext: pageCompContext,
    });

    const filteredValue = parseValue({
      expression: col.filteredValue,
      compContext: pageCompContext,
    });

    const filters = parseValue({
      expression: col.filters,
      compContext: pageCompContext,
    });

    return {
      key: `${index + 1}`,
      ...pick(col, ['key', 'title', 'width', 'align', 'sorter']),
      sortOrder: so,
      filtered,
      filters: Array.isArray(filters) ? filters : undefined,
      filteredValue: Array.isArray(filteredValue) ? filteredValue : undefined,
      fixed: col.fixed,
      render: (_text, record, rowIndex) => {
        let customComp: PageCompCustomConfig | undefined;

        if (col.renderCompId) {
          customComp = customs[col.renderCompId];
        }

        if (pageCompContext.factoryComp) {
          return (
            <Observer>
              {() => {
                const pathnameCurr = get(record, '_pathname');

                const context = {
                  ...pageCompContext,
                  inDesigner: false,
                  dataBinding: {
                    pathname: pathnameCurr,
                    pathnames: compact(
                      concat(
                        pathnameCurr,
                        pathname,
                        pageCompContext.dataBinding.pathnames,
                      ),
                    ),
                    index: rowIndex,
                  },
                };

                context.params = parseValueDeep({
                  source: col.params,
                  compContext: context,
                });

                if (pageCompContext.inDesigner && customComp) {
                  return <CustomCompNav config={customComp} />;
                }

                return (
                  <PageCompContext.Provider value={context}>
                    {customComp ? (
                      React.createElement(pageCompContext.factoryComp!, {
                        config: customComp,
                      })
                    ) : (
                      <span>
                        {parseValue({
                          expression: col.data,
                          compContext: context,
                        }) ?? '--'}
                      </span>
                    )}
                  </PageCompContext.Provider>
                );
              }}
            </Observer>
          );
        }

        return null;
      },
    };
  }) as ColumnProps<any>[];

  const loading =
    parseValue({
      expression: config.loading,
      compContext: pageCompContext,
    }) ?? false;

  const rowSelectionType = config.rowSelection?.type;
  const { pathname: rowSelectionPathname } = parsePathname({
    expression: config.rowSelection?.value,
    compContext: pageCompContext,
  });

  return (
    <div ref={innerRef} {...rest}>
      <Table<any>
        columns={columns}
        loading={loading}
        pagination={false}
        size={config.size}
        expandedRowKeys={expandedKeys}
        onExpandedRowsChange={setExpandedKeys}
        getPopupContainer={getPopupContainer(pageCompContext)}
        dataSource={
          Array.isArray(tableDataSource) && columns.length > 0
            ? tableDataSource.map((d, index) => assign({ _index: index }, d))
            : undefined
        }
        rowKey={config.rowKey || 'key'}
        showSorterTooltip={false}
        scroll={{ y: scrollY || undefined }}
        rowSelection={
          rowSelectionType && rowSelectionPathname
            ? {
                type: rowSelectionType,
                preserveSelectedRowKeys: true,
                selectedRowKeys: get(
                  pageCompContext.state,
                  rowSelectionPathname,
                ) as string[],
                onChange: (selectedRowKeys, selectedRows) => {
                  runInAction(() => {
                    set(
                      pageCompContext.state,
                      rowSelectionPathname,
                      selectedRowKeys,
                    );
                  });

                  dispatchOnRowSelectionChange({ selectedRows });
                },
              }
            : undefined
        }
        onRow={(record, rowIndex) => ({
          onClick: (e) => {
            e.stopPropagation();
            e.preventDefault();

            dispatchOnRowClick({
              record,
              index: rowIndex,
            });
          },
        })}
        onChange={(_pagination, filters, st) => {
          const s = st as SorterResult<any>;

          dispatchOnSort({
            key: s.columnKey,
            order:
              typeof s.order === 'string'
                ? s.order?.replace(/end$/, '')
                : undefined,
            filters,
          });
        }}
        {...rawProps}
      />
    </div>
  );
});
