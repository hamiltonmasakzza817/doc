import CompContext from '@gongzu/core/common/CompContext';
import { useActionDispatcher, useParseValue } from '@gongzu/core/common/hooks';
import { CompProps } from '@gongzu/core/common/types';
import { EngineStoresContext } from '@gongzu/core/contexts/store-contexts';
import { DesktopCompTabsConfig } from '@gongzu/core/types/comps-desktop';
import { Tabs } from 'antd';
import { TabsProps } from 'antd/es/tabs';
import { observer, Observer } from 'mobx-react';
import React from 'react';

const { TabPane } = Tabs;

export default observer((props: CompProps<DesktopCompTabsConfig>) => {
  const { config, rawProps, innerRef, ...rest } = props;

  const { engineModelStore } = React.useContext(EngineStoresContext);

  const compContext = React.useContext(CompContext);

  const p: Pick<TabsProps, 'activeKey' | 'onChange'> = {};

  const parseValue = useParseValue();

  const activeKey = compContext.inDesigner
    ? undefined
    : parseValue(config.activeKey);

  const dispatchOnChange = useActionDispatcher(config.onChange);

  if (activeKey) {
    p.activeKey = activeKey;
    p.onChange = (activeKey1) => {
      dispatchOnChange({ key: activeKey1 });
    };
  }

  return (
    <div ref={innerRef} {...rest}>
      <Tabs
        {...p}
        data-id={config.id}
        animated={false}
        size={config.size}
        type={config.tabsType}
        tabBarExtraContent={
          <CompContext.Provider
            value={{
              ...compContext,
              inDesigner: false,
            }}
          >
            <Observer>
              {() => {
                if (config.tabBarExtraContent == null) {
                  return <></>;
                }

                const comp =
                  engineModelStore.customs[config.tabBarExtraContent];

                if (comp) {
                  return React.createElement(compContext.factoryComp, {
                    config: comp,
                  });
                }

                return <></>;
              }}
            </Observer>
          </CompContext.Provider>
        }
        {...rawProps}
      >
        {config.children?.map((child) => {
          if (compContext.factoryComp) {
            const tab = parseValue(child.name);

            return (
              <TabPane key={child.code ?? child.id} tab={tab || '空标签'}>
                {React.createElement(compContext.factoryComp, {
                  key: child.id,
                  config: child,
                })}
              </TabPane>
            );
          }

          return <></>;
        })}
      </Tabs>
    </div>
  );
});
