import PageCompContext from '@gongzu/core/common/CompContext';
import { rawPropsDesktopFormItem } from '@gongzu/core/common/raw-props-desktop';
import { CompProps } from '@gongzu/core/common/types';
import { parseValueDeep } from '@gongzu/core/common/utils';
import { DesktopCompSliderConfig } from '@gongzu/core/types/comps-desktop';
import { Slider } from 'antd';
import pick from 'lodash-es/pick';
import { observer } from 'mobx-react';
import React from 'react';
import DesktopCompFormItem from './DesktopCompFormItem';

export default observer((props: CompProps<DesktopCompSliderConfig>) => {
  const { config, rawProps, ...rest } = props;

  const pageCompContext = React.useContext(PageCompContext);

  return (
    <DesktopCompFormItem
      config={config}
      rawProps={pick(
        parseValueDeep({
          source: config.formItemRawProps,
          compContext: pageCompContext,
        }),
        rawPropsDesktopFormItem,
      )}
      {...rest}
    >
      {({ bind, disabled, readOnly }) => {
        if (readOnly) {
          return <div>{bind?.value ?? '--'}</div>;
        }

        return (
          <Slider
            disabled={disabled}
            max={config.max}
            min={config.min}
            step={config.step}
            {...(bind ?? {})}
            {...rawProps}
          />
        );
      }}
    </DesktopCompFormItem>
  );
});
