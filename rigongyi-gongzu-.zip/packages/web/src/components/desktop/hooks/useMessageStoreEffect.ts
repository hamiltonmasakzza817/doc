import { BaseStoresContext } from '@gongzu/core/contexts/store-contexts';
import { MessageConfirm, MessageType } from '@gongzu/core/stores/MessageStore';
import { Modal } from 'antd';
import React from 'react';

export default (pageId: string) => {
  const { messageStore } = React.useContext(BaseStoresContext);

  React.useEffect(() => {
    if (messageStore.current) {
      const { type } = messageStore.current;

      const msg = messageStore.current as MessageConfirm;

      let handled = false;

      if (type === MessageType.CONFIRM) {
        Modal.confirm({
          className: `gongzu-designer-page-${pageId}`,
          title: msg.title,
          onOk: () => {
            msg.resolve();
          },
          onCancel: () => {
            msg.reject();
          },
          getContainer: () =>
            (document.querySelector(`[data-viewport]`) ||
              document.body) as HTMLElement,
        });

        handled = true;
      }

      if (handled) {
        messageStore.receive(messageStore.current);
      }
    }
  }, [messageStore.current]);
};
