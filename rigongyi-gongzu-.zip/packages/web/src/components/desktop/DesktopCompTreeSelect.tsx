import CompContext from '@gongzu/core/common/CompContext';
import { findTreeOption } from '@gongzu/core/common/form-helpers';
import { useActionDispatcher } from '@gongzu/core/common/hooks';
import { rawPropsDesktopFormItem } from '@gongzu/core/common/raw-props-desktop';
import { CompProps } from '@gongzu/core/common/types';
import {
  buildTreeData,
  getPopupContainer,
  parsePathname,
  parseValue,
  parseValueDeep,
} from '@gongzu/core/common/utils';
import { DesktopCompTreeSelectConfig } from '@gongzu/core/types/comps-desktop';
import { TreeSelect, TreeSelectProps } from 'antd';
import compact from 'lodash-es/compact';
import concat from 'lodash-es/concat';
import difference from 'lodash-es/difference';
import first from 'lodash-es/first';
import get from 'lodash-es/get';
import map from 'lodash-es/map';
import pick from 'lodash-es/pick';
import throttle from 'lodash-es/throttle';
import uniq from 'lodash-es/uniq';
import { observer } from 'mobx-react';
import React, { Key } from 'react';
import DesktopCompFormItem from './DesktopCompFormItem';

function PageCompTreeSelectControl(
  props: Omit<TreeSelectProps<any>, 'onTreeExpand'> & {
    expandedKeysOuter?: Key[];
    onTreeExpand: (diffKeys: Key[], expandedKeys: Key[]) => void;
  },
) {
  const { value, treeData, onTreeExpand, expandedKeysOuter } = props;

  const [expandedKeys, setExpandedKeys] = React.useState<Key[]>();

  const expandedKeysRef = React.useRef<Key[]>([]);

  React.useEffect(() => {
    if (value && !expandedKeysOuter) {
      const option = findTreeOption(value, treeData as any);

      const keys = uniq(concat(expandedKeys, get(option, 'mpath')));

      setExpandedKeys(keys);
      expandedKeysRef.current = keys;
    }
  }, [value]);

  React.useEffect(() => {
    if (expandedKeysOuter) {
      setExpandedKeys(expandedKeysOuter);
      expandedKeysRef.current = expandedKeysOuter;
    }
  }, [expandedKeysOuter]);

  return (
    <TreeSelect
      {...props}
      // key={`${value}`}
      treeExpandedKeys={expandedKeys}
      onTreeExpand={(expandedKeys1) => {
        if (onTreeExpand) {
          onTreeExpand(
            difference(expandedKeys1, expandedKeysRef.current),
            expandedKeys1,
          );
        }

        if (!expandedKeysOuter) {
          setExpandedKeys(expandedKeys1);
          expandedKeysRef.current = expandedKeys1;
        }
      }}
    />
  );
}

export default observer((props: CompProps<DesktopCompTreeSelectConfig>) => {
  const { config, rawProps, ...rest } = props;

  const compContext = React.useContext(CompContext);

  const dispatchOnSearch = useActionDispatcher(config.onSearch);

  const dispatchOnExpand = useActionDispatcher(config.onExpand);

  const onSearch = React.useCallback(
    throttle(
      (search) => {
        dispatchOnSearch({ search });
      },
      300,
      { leading: false },
    ),
    [],
  );

  let dataSource: any[] | undefined;

  if (config.options.dataSource) {
    const { pathname } = parsePathname({
      expression: config.options.dataSource,
      compContext,
    });

    dataSource = pathname
      ? (get(compContext.state, pathname) as any[])
      : undefined;
  }

  return (
    <DesktopCompFormItem
      config={config}
      rawProps={pick(
        parseValueDeep({
          source: config.formItemRawProps,
          compContext,
        }),
        rawPropsDesktopFormItem,
      )}
      {...rest}
    >
      {({ bind, disabled, readOnly, error }) => {
        const { value, onChange } = bind ?? {};

        const { multiple, labelInValue } = config;

        let selectValue = labelInValue ? value : value?.toString();

        if (multiple) {
          selectValue = compact(concat(value)).map((n) =>
            labelInValue ? n : n.toString(),
          );
        }

        const treeData = buildTreeData({
          dataSource,
          type: config.options.dataSourceType,
          pageCompContext: compContext,
          ...pick(config.options, [
            'childrenKey',
            'parentIdKey',
            'name',
            'value',
            'disabled',
            'isLeaf',
          ]),
        });

        if (readOnly) {
          let selectLabel;

          if (multiple) {
            selectLabel = map(
              value,
              (v) =>
                (labelInValue
                  ? v?.label
                  : findTreeOption(v, treeData)?.names.toString()) || '--',
            ).toString();
          } else {
            selectLabel =
              (labelInValue
                ? value?.label
                : findTreeOption(value, treeData)?.names.toString()) || '--';
          }

          return <div>{selectLabel}</div>;
        }

        // 默认开启本地本地搜索
        const enableLocalSearch = config.search !== false;

        return (
          <PageCompTreeSelectControl
            disabled={disabled}
            autoFocus={config.autoFocus}
            value={selectValue}
            onChange={onChange}
            placeholder={config.placeholder}
            multiple={config.multiple}
            allowClear={config.allowClear}
            labelInValue={labelInValue}
            treeData={treeData}
            showSearch
            onSearch={onSearch}
            getPopupContainer={getPopupContainer(compContext)}
            treeNodeFilterProp="title"
            expandedKeysOuter={
              config.options.expandedKeys
                ? parseValue({
                    expression: config.options.expandedKeys,
                    compContext,
                  })
                : undefined
            }
            // 本地搜索，使用默认过滤规则，否则不使用过滤
            filterTreeNode={enableLocalSearch ? undefined : false}
            onTreeExpand={(diffKeys, expandedKeys) => {
              dispatchOnExpand({
                expandedKey: first(diffKeys),
                expandedKeys,
              });
            }}
            status={error ? 'error' : undefined}
            showCheckedStrategy={TreeSelect.SHOW_ALL}
            {...rawProps}
          />
        );
      }}
    </DesktopCompFormItem>
  );
});
