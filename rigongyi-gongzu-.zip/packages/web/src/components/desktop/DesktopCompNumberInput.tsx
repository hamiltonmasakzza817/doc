import PageCompContext from '@gongzu/core/common/CompContext';
import { useActionDispatcher } from '@gongzu/core/common/hooks';
import { rawPropsDesktopFormItem } from '@gongzu/core/common/raw-props-desktop';
import { CompProps } from '@gongzu/core/common/types';
import { parseValueDeep } from '@gongzu/core/common/utils';
import { DesktopCompNumberInputConfig } from '@gongzu/core/types/comps-desktop';
import { InputNumber } from 'antd';
import pick from 'lodash-es/pick';
import { observer } from 'mobx-react';
import React from 'react';
import DesktopCompFormItem from './DesktopCompFormItem';

export default observer((props: CompProps<DesktopCompNumberInputConfig>) => {
  const { config, rawProps, ...rest } = props;

  const pageCompContext = React.useContext(PageCompContext);
  const dispatchOnPressEnter = useActionDispatcher(config.onPressEnter);

  return (
    <DesktopCompFormItem
      config={config}
      rawProps={pick(
        parseValueDeep({
          source: config.formItemRawProps,
          compContext: pageCompContext,
        }),
        rawPropsDesktopFormItem,
      )}
      {...rest}
    >
      {({ bind, disabled, readOnly, error }) => {
        if (readOnly) {
          return <div>{bind?.value ?? '--'}</div>;
        }

        return (
          <InputNumber
            disabled={disabled}
            max={config.max}
            min={config.min}
            placeholder={config.placeholder}
            maxLength={config.rule?.maxLength}
            onPressEnter={dispatchOnPressEnter}
            precision={config.precision}
            step={config.step}
            status={error ? 'error' : undefined}
            {...(bind ?? {})}
            {...rawProps}
          />
        );
      }}
    </DesktopCompFormItem>
  );
});
