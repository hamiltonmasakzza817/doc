import { useActionDispatcher, useParseValue } from '@gongzu/core/common/hooks';
import { CompProps } from '@gongzu/core/common/types';
import { DesktopCompPaginationConfig } from '@gongzu/core/types/comps-desktop';
import { Pagination } from 'antd';
import get from 'lodash-es/get';
import { observer } from 'mobx-react';
import React from 'react';

const defaultPageSizeOptions = ['5', '10', '20', '30', '40'];

const pagerShowTotal = (total: number) => `共${total}条`;

export default observer((props: CompProps<DesktopCompPaginationConfig>) => {
  const { config, rawProps, innerRef, ...rest } = props;

  const parseValue = useParseValue();

  const page = (parseValue(config.page) ?? 0) + 1;

  const totalPage = parseValue(config.totalPage) ?? 10;

  const total = parseValue(config.total) ?? 0;

  let pageSize = parseValue(config.pageSize);

  const dispatchOnChange = useActionDispatcher(config.onChange);

  const pageSizeOptions =
    (get(rawProps, 'pageSizeOptions') as string[]) || defaultPageSizeOptions;

  if (pageSize == null) {
    pageSize = total / totalPage;
    pageSize = +(pageSizeOptions.find((s) => +s >= pageSize) ?? 5);
  }

  return (
    <div ref={innerRef} {...rest}>
      <Pagination
        current={Number.isNaN(+page) ? 1 : +page}
        pageSizeOptions={defaultPageSizeOptions}
        pageSize={pageSize}
        total={total}
        showTotal={pagerShowTotal}
        showSizeChanger
        onChange={(page1, pageSize1) => {
          dispatchOnChange({
            start: (page1 - 1) * (pageSize1 ?? 0),
            limit: pageSize1,
            size: pageSize1,
            page: page1,
            number: page1 - 1,
          });
        }}
        {...rawProps}
      />
    </div>
  );
});
