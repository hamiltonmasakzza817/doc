import CompContext from '@gongzu/core/common/CompContext';
import { useActionDispatcher } from '@gongzu/core/common/hooks';
import { rawPropsDesktopFormItem } from '@gongzu/core/common/raw-props-desktop';
import { CompProps } from '@gongzu/core/common/types';
import { parseValue, parseValueDeep } from '@gongzu/core/common/utils';
import { DesktopCompInputConfig } from '@gongzu/core/types/comps-desktop';
import { Input } from 'antd';
import assign from 'lodash-es/assign';
import pick from 'lodash-es/pick';
import range from 'lodash-es/range';
import size from 'lodash-es/size';
import { observer } from 'mobx-react';
import React from 'react';
import DesktopCompFormItem from './DesktopCompFormItem';

export default observer((props: CompProps<DesktopCompInputConfig>) => {
  const { config, className, rawProps, ...rest } = props;

  const compContext = React.useContext(CompContext);

  const dispatchOnPressEnter = useActionDispatcher(config.onPressEnter);

  const dispatchOnSearch = useActionDispatcher(config.onSearch);

  return (
    <DesktopCompFormItem
      config={config}
      className={className}
      rawProps={pick(
        parseValueDeep({
          source: config.formItemRawProps,
          compContext,
        }),
        rawPropsDesktopFormItem,
      )}
      {...rest}
    >
      {({ bind, disabled, readOnly, error }) => {
        if (readOnly) {
          let value = bind?.value;
          if (config.password) {
            value = range(size(value)).map(() => '*');
          }
          return <div>{value?.toString() ?? '--'}</div>;
        }

        const p = assign(
          {},
          bind,
          pick(config, ['addonBefore', 'addonAfter', 'autoFocus']),
          {
            placeholder: parseValue({
              expression: config.placeholder,
              compContext,
            }),
            allowClear: config.allowClear,
            disabled,
            maxLength: config.rule?.maxLength,
            onPressEnter: dispatchOnPressEnter,
            status: error ? 'error' : undefined as any
          },
          rawProps,
        );

        if (config.password) {
          return <Input.Password {...p} />;
        }

        if (config.search) {
          return (
            <Input.Search
              enterButton={parseValue({
                expression: config.enterButton,
                compContext,
              })}
              onSearch={() => dispatchOnSearch()}
              {...p}
            />
          );
        }

        return <Input {...p} />;
      }}
    </DesktopCompFormItem>
  );
});
