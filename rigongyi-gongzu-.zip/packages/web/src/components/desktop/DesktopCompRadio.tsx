import PageCompContext from '@gongzu/core/common/CompContext';
import { findOptionName, getOptions } from '@gongzu/core/common/form-helpers';
import { useCustomElement } from '@gongzu/core/common/hooks';
import { rawPropsDesktopFormItem } from '@gongzu/core/common/raw-props-desktop';
import { CompProps } from '@gongzu/core/common/types';
import { parseValueDeep } from '@gongzu/core/common/utils';
import { DesktopCompRadioConfig } from '@gongzu/core/types/comps-desktop';
import { Radio } from 'antd';
import compact from 'lodash-es/compact';
import concat from 'lodash-es/concat';
import pick from 'lodash-es/pick';
import toString from 'lodash-es/toString';
import { observer } from 'mobx-react';
import React from 'react';
import { gzdtBem } from '../../constants';
import DesktopCompFormItem from './DesktopCompFormItem';

export default observer((props: CompProps<DesktopCompRadioConfig>) => {
  const { config, rawProps, ...rest } = props;

  const pageCompContext = React.useContext(PageCompContext);

  const customElement = useCustomElement(config.renderCompId);

  const options = config.options
    ? getOptions(config.options, pageCompContext)
    : undefined;

  const opts = options
    ? options.map((option, index: number) => {
        const p = {
          key: `${index + 1}`,
          value: option.value,
          disabled: option.disabled,
        };

        const context = {
          ...pageCompContext,
          inDesigner: false,
          dataBinding: {
            pathname: option.pathname,
            pathnames: compact(
              concat(option.pathname, pageCompContext.dataBinding.pathnames),
            ),
            index,
          },
        };

        const c = option.name || '--';

        const content = (
          <PageCompContext.Provider value={context}>
            {customElement || toString(c)}
          </PageCompContext.Provider>
        );

        if (config.radioStyle === 'button') {
          return <Radio.Button {...p}>{content}</Radio.Button>;
        }

        return (
          <Radio
            {...p}
            className={gzdtBem('radio')({
              vertical: config.radioStyle === 'vertical',
            })}
          >
            {content}
          </Radio>
        );
      })
    : [];

  return (
    <DesktopCompFormItem
      config={config}
      rawProps={pick(
        parseValueDeep({
          source: config.formItemRawProps,
          compContext: pageCompContext,
        }),
        rawPropsDesktopFormItem,
      )}
      {...rest}
    >
      {({ bind, disabled, readOnly }) => {
        if (readOnly && options) {
          const checkedLabel = findOptionName(bind?.value, options);

          return <div>{checkedLabel}</div>;
        }

        return (
          <Radio.Group
            disabled={disabled}
            {...(bind ?? {})}
            buttonStyle={config.buttonStyle}
            {...rawProps}
          >
            {opts}
          </Radio.Group>
        );
      }}
    </DesktopCompFormItem>
  );
});
