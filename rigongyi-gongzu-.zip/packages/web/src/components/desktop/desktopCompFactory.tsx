import Loading from '@gongzu/core/common/Loading';
import { CompProps } from '@gongzu/core/common/types';
import PageCompDefault from '@gongzu/core/gongzu-components/PageCompDefault';
import {
  DesktopCompConfig,
  DesktopCompType,
} from '@gongzu/core/types/comps-desktop';
import React from 'react';
import Loadable from 'react-loadable';
import DesktopCompButton from './DesktopCompButton';
import DesktopCompCheckbox from './DesktopCompCheckbox';
import PageCompContainer from './DesktopCompContainer';
import DesktopCompDatePicker from './DesktopCompDatePicker';
import PageCompDropdownMenu from './DesktopCompDropdownMenu';
import DesktopCompForm from './DesktopCompForm';
import DesktopCompFormItemContainer from './DesktopCompFormItemContainer';
import DesktopCompIcon from './DesktopCompIcon';
import PageCompImage from './DesktopCompImage';
import DesktopCompInput from './DesktopCompInput';
import PageCompMenu from './DesktopCompMenu';
import PageCompModal from './DesktopCompModal';
import DesktopCompNumberInput from './DesktopCompNumberInput';
import PageCompPagination from './DesktopCompPagination';
import PageCompParagraph from './DesktopCompParagraph';
import PageCompProgress from './DesktopCompProgress';
import DesktopCompRadio from './DesktopCompRadio';
import DesktopCompSelect from './DesktopCompSelect';
import DesktopCompSlider from './DesktopCompSlider';
import PageCompSteps from './DesktopCompSteps';
import DesktopCompSwitch from './DesktopCompSwitch';
import PageCompTable from './DesktopCompTable';
import PageCompTabs from './DesktopCompTabs';
import PageCompTag from './DesktopCompTag';
import DesktopCompTextArea from './DesktopCompTextArea';
import DesktopCompTransfer from './DesktopCompTransfer';
import PageCompTree from './DesktopCompTree';
import DesktopCompTreeSelect from './DesktopCompTreeSelect';
import DesktopCompUploader from './DesktopCompUploader';
import './style.scss';

const PageCompMarkdown = Loadable({
  loader: () => import('./DesktopCompMarkdown'),
  loading: Loading,
});

export default function desktopCompFactory(config: DesktopCompConfig) {
  let el: React.FunctionComponent<CompProps<any>>;

  switch (config.type) {
    case DesktopCompType.BUTTON: {
      el = DesktopCompButton;
      break;
    }

    case DesktopCompType.TABLE: {
      el = PageCompTable;
      break;
    }

    case DesktopCompType.MODAL: {
      el = PageCompModal;
      break;
    }

    case DesktopCompType.PAGINATION: {
      el = PageCompPagination;
      break;
    }

    case DesktopCompType.TABS: {
      el = PageCompTabs;
      break;
    }

    case DesktopCompType.IMAGE: {
      el = PageCompImage;
      break;
    }

    case DesktopCompType.TREE: {
      el = PageCompTree;
      break;
    }

    case DesktopCompType.ICON: {
      el = DesktopCompIcon;
      break;
    }

    case DesktopCompType.TAG: {
      el = PageCompTag;
      break;
    }

    case DesktopCompType.PARAGRAPH: {
      el = PageCompParagraph;
      break;
    }

    case DesktopCompType.CONTAINER: {
      el = PageCompContainer;
      break;
    }

    case DesktopCompType.MENU: {
      el = PageCompMenu;
      break;
    }

    case DesktopCompType.PROGRESS: {
      el = PageCompProgress;
      break;
    }

    case DesktopCompType.DROPDOWN_MENU: {
      el = PageCompDropdownMenu;
      break;
    }

    case DesktopCompType.STEPS: {
      el = PageCompSteps;
      break;
    }

    case DesktopCompType.MARKDOWN: {
      // eslint-disable-next-line @typescript-eslint/ban-ts-comment
      // @ts-ignore
      el = PageCompMarkdown;
      break;
    }

    case DesktopCompType.FORM: {
      el = DesktopCompForm;
      break;
    }

    case DesktopCompType.INPUT: {
      el = DesktopCompInput;
      break;
    }

    case DesktopCompType.TEXT_AREA: {
      el = DesktopCompTextArea;
      break;
    }

    case DesktopCompType.NUMBER_INPUT: {
      el = DesktopCompNumberInput;
      break;
    }

    case DesktopCompType.SWITCH: {
      el = DesktopCompSwitch;
      break;
    }

    case DesktopCompType.SELECT: {
      el = DesktopCompSelect;
      break;
    }

    case DesktopCompType.DATE_PICKER: {
      el = DesktopCompDatePicker;
      break;
    }

    case DesktopCompType.CHECKBOX: {
      el = DesktopCompCheckbox;
      break;
    }

    case DesktopCompType.RADIO: {
      el = DesktopCompRadio;
      break;
    }

    case DesktopCompType.TREE_SELECT: {
      el = DesktopCompTreeSelect;
      break;
    }

    case DesktopCompType.UPLOADER: {
      el = DesktopCompUploader;
      break;
    }

    case DesktopCompType.FORM_ITEM_CONTAINER: {
      el = DesktopCompFormItemContainer;
      break;
    }

    case DesktopCompType.TRANSFER: {
      el = DesktopCompTransfer;
      break;
    }

    case DesktopCompType.SLIDER: {
      el = DesktopCompSlider;
      break;
    }

    default:
      el = PageCompDefault;
      break;
  }

  return el;
}
