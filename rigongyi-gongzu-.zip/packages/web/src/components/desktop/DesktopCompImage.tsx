import { useParseValue } from '@gongzu/core/common/hooks';
import { CompProps } from '@gongzu/core/common/types';
import { DesktopCompImageConfig } from '@gongzu/core/types/comps-desktop';
import { observer } from 'mobx-react';
import React from 'react';

export default observer((props: CompProps<DesktopCompImageConfig>) => {
  const { config, className, rawProps, innerRef, ...rest } = props;

  const parseValue = useParseValue();

  return (
    <img
      className={className}
      src={parseValue(config.url)}
      alt={parseValue(config.alt)}
      ref={innerRef}
      {...rest}
      {...rawProps}
    />
  );
});
