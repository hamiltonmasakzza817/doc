import CompContext from '@gongzu/core/common/CompContext';
import { findOptionName, getOptions } from '@gongzu/core/common/form-helpers';
import { rawPropsDesktopFormItem } from '@gongzu/core/common/raw-props-desktop';
import { CompProps } from '@gongzu/core/common/types';
import { parseValueDeep } from '@gongzu/core/common/utils';
import { DesktopCompCheckboxConfig } from '@gongzu/core/types/comps-desktop';
import { Checkbox, Input } from 'antd';
import compact from 'lodash-es/compact';
import concat from 'lodash-es/concat';
import map from 'lodash-es/map';
import pick from 'lodash-es/pick';
import split from 'lodash-es/split';
import without from 'lodash-es/without';
import { observer } from 'mobx-react';
import React from 'react';
import DesktopCompFormItem from './DesktopCompFormItem';

export default observer((props: CompProps<DesktopCompCheckboxConfig>) => {
  const { config, rawProps, ...rest } = props;

  const compContext = React.useContext(CompContext);

  const options = config.options
    ? getOptions(config.options, compContext)
    : undefined;

  return (
    <DesktopCompFormItem
      config={config}
      rawProps={pick(
        parseValueDeep({
          source: config.formItemRawProps,
          compContext,
        }),
        rawPropsDesktopFormItem,
      )}
      {...rest}
    >
      {({ bind, disabled, readOnly }) => {
        const values = split(bind?.value as string, ',');

        const other = without(
          values,
          ...(options?.map((d: any) => `${d.value}`) ?? []),
        )[0] as string;

        if (readOnly && options) {
          const checkedLabel = map(values, (v) =>
            findOptionName(v, options),
          ).toString();

          return <div>{checkedLabel}</div>;
        }

        return (
          <div>
            {options ? (
              options.map((option: any, index: number) => {
                const { value, name } = option;

                return (
                  <Checkbox
                    key={`${index + 1}`}
                    checked={values.includes(`${value}`)}
                    disabled={disabled}
                    onChange={
                      bind?.onChange
                        ? (e) => {
                            if (bind.onChange) {
                              if (e.target.checked) {
                                bind.onChange(
                                  compact(concat(values, value)).toString(),
                                );
                              } else {
                                bind.onChange(
                                  without(values, `${value}`).toString(),
                                );
                              }
                            }
                          }
                        : undefined
                    }
                    {...rawProps}
                  >
                    {name?.toString() ?? '--'}
                  </Checkbox>
                );
              })
            ) : (
              <div>无数据</div>
            )}

            {config.custom ? (
              <div>
                <Input
                  value={other}
                  onChange={
                    bind?.onChange
                      ? (e) => {
                          if (bind.onChange) {
                            const v = without(values, other);
                            bind.onChange([...v, e.target.value].toString());
                          }
                        }
                      : undefined
                  }
                />
              </div>
            ) : (
              <></>
            )}
          </div>
        );
      }}
    </DesktopCompFormItem>
  );
});
