import PageCompContext from '@gongzu/core/common/CompContext';
import { useActionDispatcher } from '@gongzu/core/common/hooks';
import { CompProps } from '@gongzu/core/common/types';
import {
  buildTreeData,
  getPopupContainer,
  parsePathname,
  parseValue,
} from '@gongzu/core/common/utils';
import { DesktopCompDropdownMenuConfig } from '@gongzu/core/types/comps-desktop';
import { DataNode } from '@gongzu/core/types/entities';
import { findTreeNodeBy } from '@gongzu/core/utils/tree';
import { Dropdown, Menu } from 'antd';
import compact from 'lodash-es/compact';
import concat from 'lodash-es/concat';
import get from 'lodash-es/get';
import pick from 'lodash-es/pick';
import size from 'lodash-es/size';
import { observer } from 'mobx-react';
import React from 'react';

function buildMenuItem(treeData?: DataNode[]) {
  if (treeData) {
    return treeData.map((menu) => {
      if (size(menu.children) === 0) {
        return <Menu.Item key={menu.key}>{menu.title}</Menu.Item>;
      }

      return (
        <Menu.SubMenu title={menu.title} key={menu.key}>
          {buildMenuItem(menu.children)}
        </Menu.SubMenu>
      );
    });
  }

  return <></>;
}

export default observer((props: CompProps<DesktopCompDropdownMenuConfig>) => {
  const { children, config, innerRef, rawProps, ...rest } = props;

  const pageCompContext = React.useContext(PageCompContext);

  const { pathname } = parsePathname({
    expression: config.tree?.dataSource,
    compContext: pageCompContext,
  });

  const dataSource = pathname
    ? (get(pageCompContext.state, pathname) as Record<string, unknown>[])
    : [];

  const dispatchOnSelect = useActionDispatcher(config.onSelect);

  return (
    <Dropdown
      placement={config.placement}
      getPopupContainer={getPopupContainer(pageCompContext)}
      overlay={
        <Menu
          onClick={({ key }) => {
            dispatchOnSelect(
              key && config.tree?.value
                ? findTreeNodeBy(
                    dataSource,
                    (n) => {
                      const key1 = parseValue({
                        expression: config.tree ? config.tree.value : '',
                        compContext: pageCompContext,
                        context: n,
                      });

                      return key1 === key;
                    },
                    config.tree.childrenKey,
                  ) || undefined
                : undefined,
            );
          }}
        >
          {buildMenuItem(
            buildTreeData({
              dataSource: dataSource as any,
              pageCompContext,
              type: 'tree',
              ...pick(config.tree, [
                'childrenKey',
                'parentIdKey',
                'name',
                'value',
              ]),
            }),
          )}
        </Menu>
      }
      trigger={compact(concat(config.dropdownTrigger))}
      disabled={pageCompContext.inDesigner}
      {...rawProps}
    >
      <div {...rest} data-id={config.id}>
        {children}

        <div
          className="hidden"
          ref={(el) => {
            if (innerRef && el) {
              innerRef.current = el.parentElement;
            }
          }}
        />
      </div>
    </Dropdown>
  );
});
