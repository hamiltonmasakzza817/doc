import { useParseValue } from '@gongzu/core/common/hooks';
import { CompProps } from '@gongzu/core/common/types';
import { DesktopCompMarkdownConfig } from '@gongzu/core/types/comps-desktop';
import classNames from 'classnames';
import 'github-markdown-css/github-markdown.css';
import { observer } from 'mobx-react';
import React from 'react';
// eslint-disable-next-line @typescript-eslint/ban-ts-comment
// @ts-ignore
import ReactMarkdown from 'react-markdown/lib/with-html';

export default observer((props: CompProps<DesktopCompMarkdownConfig>) => {
  const { config, className, innerRef, rawProps, ...rest } = props;

  const parseValue = useParseValue();

  return (
    <div
      className={classNames('markdown-body', className)}
      ref={innerRef}
      {...rest}
      {...rawProps}
    >
      <ReactMarkdown
        source={parseValue(config.text) ?? '--'}
        escapeHtml={false}
      />
    </div>
  );
});
