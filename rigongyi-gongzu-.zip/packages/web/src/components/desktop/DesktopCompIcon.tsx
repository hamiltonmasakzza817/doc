import { createFromIconfontCN } from '@ant-design/icons';
import PageCompContext from '@gongzu/core/common/CompContext';
import { useParseValue } from '@gongzu/core/common/hooks';
import { CompProps } from '@gongzu/core/common/types';
import { DesktopCompIconConfig } from '@gongzu/core/types/comps-desktop';
import { observer } from 'mobx-react';
import React from 'react';

const antdIconsUrl = '//at.alicdn.com/t/font_2047187_wlc8k6ivd3.js';

export default observer((props: CompProps<DesktopCompIconConfig>) => {
  const { config, className, rawProps, innerRef, ...rest } = props;

  const parseValue = useParseValue();

  React.useContext(PageCompContext);

  const iconClass = React.useMemo(
    () =>
      createFromIconfontCN({
        scriptUrl: config.custom ? config.url : antdIconsUrl,
      }),
    [],
  );

  return React.createElement(iconClass, {
    type: parseValue(config.iconType),
    className,
    ref: innerRef,
    ...rest,
    ...rawProps,
  });
});
