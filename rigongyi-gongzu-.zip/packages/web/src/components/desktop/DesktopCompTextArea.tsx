import CompContext from '@gongzu/core/common/CompContext';
import { useActionDispatcher } from '@gongzu/core/common/hooks';
import { rawPropsDesktopFormItem } from '@gongzu/core/common/raw-props-desktop';
import { CompProps } from '@gongzu/core/common/types';
import { parseValueDeep } from '@gongzu/core/common/utils';
import { DesktopCompTextAreaConfig } from '@gongzu/core/types/comps-desktop';
import { Input } from 'antd';
import pick from 'lodash-es/pick';
import { observer } from 'mobx-react';
import React from 'react';
import DesktopCompFormItem from './DesktopCompFormItem';

export default observer((props: CompProps<DesktopCompTextAreaConfig>) => {
  const { config, rawProps, ...rest } = props;

  const compContext = React.useContext(CompContext);

  const dispatchOnPressEnter = useActionDispatcher(config.onPressEnter);

  return (
    <DesktopCompFormItem
      config={config}
      rawProps={pick(
        parseValueDeep({
          source: config.formItemRawProps,
          compContext,
        }),
        rawPropsDesktopFormItem,
      )}
      {...rest}
    >
      {({ bind, disabled, readOnly, error }) => {
        if (readOnly) {
          return <div>{bind?.value ?? '--'}</div>;
        }

        return (
          <Input.TextArea
            allowClear={config.allowClear}
            autoFocus={config.autoFocus}
            disabled={disabled}
            autoSize={{ minRows: 2 }}
            maxLength={config.rule?.maxLength}
            placeholder={config.placeholder}
            onPressEnter={dispatchOnPressEnter}
            status={error ? 'error' : undefined}
            {...(bind ?? {})}
            {...rawProps}
          />
        );
      }}
    </DesktopCompFormItem>
  );
});
