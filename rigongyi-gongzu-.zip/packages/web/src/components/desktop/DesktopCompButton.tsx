import CompContext from '@gongzu/core/common/CompContext';
import { useCustomElement, useParseValue } from '@gongzu/core/common/hooks';
import { CompProps } from '@gongzu/core/common/types';
import { DesktopCompButtonConfig } from '@gongzu/core/types/comps-desktop';
import { Button } from 'antd';
import { observer } from 'mobx-react';
import React from 'react';

export default observer((props: CompProps<DesktopCompButtonConfig>) => {
  const { config, className, rawProps, innerRef, ...rest } = props;

  const compContext = React.useContext(CompContext);

  const parseValue = useParseValue();

  const customElement = useCustomElement(config.renderCompId);

  return (
    <Button
      disabled={
        compContext.inDesigner ? false : Boolean(parseValue(config.disabled))
      }
      type={config.buttonType ?? 'primary'}
      className={className}
      ghost={config.ghost}
      size={config.size}
      ref={innerRef}
      {...rest}
      {...rawProps}
    >
      {customElement || parseValue(config.text) || config.name || '--'}
    </Button>
  );
});
