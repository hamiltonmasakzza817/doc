import { useParseValue } from '@gongzu/core/common/hooks';
import { CompProps } from '@gongzu/core/common/types';
import { DesktopCompParagraphConfig } from '@gongzu/core/types/comps-desktop';
import { observer } from 'mobx-react';
import React from 'react';

export default observer((props: CompProps<DesktopCompParagraphConfig>) => {
  const { config, rawProps, innerRef, ...rest } = props;

  const parseValue = useParseValue();

  return (
    <p
      dangerouslySetInnerHTML={{
        __html: parseValue(config.text) ?? '--',
      }}
      ref={innerRef}
      {...rest}
      {...rawProps}
    />
  );
});
