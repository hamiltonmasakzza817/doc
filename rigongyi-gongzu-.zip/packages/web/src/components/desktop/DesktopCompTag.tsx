import { useActionDispatcher, useParseValue } from '@gongzu/core/common/hooks';
import { CompProps } from '@gongzu/core/common/types';
import { DesktopCompTagConfig } from '@gongzu/core/types/comps-desktop';
import { Tag } from 'antd';
import { observer } from 'mobx-react';
import React from 'react';

export default observer((props: CompProps<DesktopCompTagConfig>) => {
  const { config, rawProps, innerRef, ...rest } = props;

  const parseValue = useParseValue();

  const dispatchOnClose = useActionDispatcher(config.onClose);

  return (
    <Tag
      closable={config.closable}
      color={parseValue(config.color)}
      ref={innerRef}
      onClose={dispatchOnClose}
      {...rest}
      {...rawProps}
    >
      {parseValue(config.text)?.toString() ?? '--'}
    </Tag>
  );
});
