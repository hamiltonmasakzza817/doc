import CompContext from '@gongzu/core/common/CompContext';
import { rawPropsDesktopFormItem } from '@gongzu/core/common/raw-props-desktop';
import { CompProps } from '@gongzu/core/common/types';
import { parseValue, parseValueDeep } from '@gongzu/core/common/utils';
import { DesktopCompSwitchConfig } from '@gongzu/core/types/comps-desktop';
import { Switch } from 'antd';
import pick from 'lodash-es/pick';
import { observer } from 'mobx-react';
import React from 'react';
import DesktopCompFormItem from './DesktopCompFormItem';

export default observer((props: CompProps<DesktopCompSwitchConfig>) => {
  const { config, rawProps, ...rest } = props;

  const compContext = React.useContext(CompContext);

  return (
    <DesktopCompFormItem
      config={config}
      rawProps={pick(
        parseValueDeep({
          source: config.formItemRawProps,
          compContext,
        }),
        rawPropsDesktopFormItem,
      )}
      {...rest}
    >
      {({ bind, disabled, readOnly }) => {
        if (readOnly) {
          return <div>{bind?.value ? '是' : '否' ?? '否'}</div>;
        }

        const checkedText = parseValue({
          expression: config.checkedText,
          compContext,
        });

        const uncheckedText = parseValue({
          expression: config.uncheckedText,
          compContext,
        });

        const checkedValue =
          parseValue({
            expression: config.checkedValue,
            compContext,
          }) ?? true;

        const uncheckedValue =
          parseValue({
            expression: config.uncheckedValue,
            compContext,
          }) ?? false;

        return (
          <Switch
            disabled={disabled}
            checked={bind?.value === checkedValue}
            onChange={(checked) => {
              if (bind?.onChange) {
                bind.onChange(checked ? checkedValue : uncheckedValue);
              }
            }}
            checkedChildren={checkedText}
            unCheckedChildren={uncheckedText}
            {...rawProps}
          />
        );
      }}
    </DesktopCompFormItem>
  );
});
