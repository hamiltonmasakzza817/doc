import PageCompContext from '@gongzu/core/common/CompContext';
import { rawPropsDesktopFormItem } from '@gongzu/core/common/raw-props-desktop';
import { CompProps } from '@gongzu/core/common/types';
import { parseValue, parseValueDeep } from '@gongzu/core/common/utils';
import { FileEntity } from '@gongzu/core/components/FileUploader';
import { DesktopCompUploaderConfig } from '@gongzu/core/types/comps-desktop';
import pick from 'lodash-es/pick';
import { observer } from 'mobx-react';
import React from 'react';
import useUploader from '../hooks/useUploader';
import DesktopCompFormItem from './DesktopCompFormItem';

export default observer((props: CompProps<DesktopCompUploaderConfig>) => {
  const { config, rawProps, ...rest } = props;

  const pageCompContext = React.useContext(PageCompContext);

  const uploader = useUploader(props);

  return (
    <DesktopCompFormItem
      config={config}
      rawProps={pick(
        parseValueDeep({
          source: config.formItemRawProps,
          compContext: pageCompContext,
        }),
        rawPropsDesktopFormItem,
      )}
      {...rest}
    >
      {({ bind, disabled }) => {
        const { onChange } = bind ?? {};

        return React.cloneElement(uploader, {
          onChange: (files: FileEntity[]) => {
            if (onChange) {
              const formatter = config.formatter || `$\{_context.url}`;

              if (config.multiple) {
                onChange(
                  files.map((f) =>
                    parseValue({
                      expression: formatter,
                      compContext: pageCompContext,
                      context: f,
                    }),
                  ),
                );
              } else {
                onChange(
                  parseValue({
                    expression: formatter,
                    compContext: pageCompContext,
                    context: files[0],
                  }),
                );
              }
            }
          },
          disabled,
          ...rawProps,
        });
      }}
    </DesktopCompFormItem>
  );
});
