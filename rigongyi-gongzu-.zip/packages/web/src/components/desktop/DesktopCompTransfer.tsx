import PageCompContext from '@gongzu/core/common/CompContext';
import { getOptions } from '@gongzu/core/common/form-helpers';
import { rawPropsDesktopFormItem } from '@gongzu/core/common/raw-props-desktop';
import { CompProps } from '@gongzu/core/common/types';
import { parseValue, parseValueDeep } from '@gongzu/core/common/utils';
import { DesktopCompTransferConfig } from '@gongzu/core/types/comps-desktop';
import { Transfer } from 'antd';
import pick from 'lodash-es/pick';
import { observer } from 'mobx-react';
import React from 'react';
import DesktopCompFormItem from './DesktopCompFormItem';

export default observer((props: CompProps<DesktopCompTransferConfig>) => {
  const { config, rawProps, ...rest } = props;
  const pageCompContext = React.useContext(PageCompContext);

  const options = config.options
    ? getOptions(config.options, pageCompContext)
    : undefined;

  const sourceTitle = parseValue({
    expression: config.titles?.source,
    compContext: pageCompContext,
  });

  const targetTitle = parseValue({
    expression: config.titles?.target,
    compContext: pageCompContext,
  });

  return (
    <DesktopCompFormItem
      config={config}
      rawProps={pick(
        parseValueDeep({
          source: config.formItemRawProps,
          compContext: pageCompContext,
        }),
        rawPropsDesktopFormItem,
      )}
      {...rest}
    >
      {({ bind, disabled }) => (
        <Transfer
          disabled={disabled}
          titles={[sourceTitle || '源数据', targetTitle || '目标数据']}
          dataSource={options}
          targetKeys={bind?.value}
          onChange={bind?.onChange}
          render={(item) => item.name || ''}
          {...rawProps}
        />
      )}
    </DesktopCompFormItem>
  );
});
