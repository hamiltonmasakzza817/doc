import PageCompContext from '@gongzu/core/common/CompContext';
import { useActionDispatcher } from '@gongzu/core/common/hooks';
import { CompProps } from '@gongzu/core/common/types';
import { parsePathname, parseValue } from '@gongzu/core/common/utils';
import { DesktopCompStepsConfig } from '@gongzu/core/types/comps-desktop';
import { Steps } from 'antd';
import classNames from 'classnames';
import get from 'lodash-es/get';
import isArray from 'lodash-es/isArray';
import { observer } from 'mobx-react';
import React from 'react';

const { Step } = Steps;

export default observer((props: CompProps<DesktopCompStepsConfig>) => {
  const { config, rawProps, className, innerRef, ...rest } = props;

  const pageCompContext = React.useContext(PageCompContext);

  const dispatchOnChange = useActionDispatcher(config.onChange);

  const { pathname } = parsePathname({
    expression: config.dataSource,
    compContext: pageCompContext,
  });

  const dataSource = pathname && get(pageCompContext.state, pathname);

  const current = parseValue({
    expression: config.current,
    compContext: pageCompContext,
  });

  return dataSource == null ? (
    <div
      className={classNames('text-center h-5 flex items-center', className)}
      ref={innerRef}
      {...rest}
    >
      无
    </div>
  ) : (
    <div ref={innerRef} className={className} {...rest}>
      <Steps
        current={current}
        onChange={(current1) => {
          dispatchOnChange({
            current: current1,
          });
        }}
        {...rawProps}
      >
        {isArray(dataSource) &&
          dataSource.map((step) => {
            const title = parseValue({
              expression: config.title,
              compContext: pageCompContext,
              context: step,
            });

            const subTitle = parseValue({
              expression: config.subTitle,
              compContext: pageCompContext,
              context: step,
            });

            const description = parseValue({
              expression: config.description,
              compContext: pageCompContext,
              context: step,
            });

            const disabled = parseValue({
              expression: config.disabled,
              compContext: pageCompContext,
              context: step,
            });

            return (
              <Step
                title={title?.toString()}
                subTitle={subTitle?.toString()}
                description={description?.toString()}
                disabled={Boolean(disabled)}
              />
            );
          })}
      </Steps>
    </div>
  );
});
