import PageCompContext, { ICompContext } from '@gongzu/core/common/CompContext';
import { useActionDispatcher } from '@gongzu/core/common/hooks';
import { CompProps } from '@gongzu/core/common/types';
import {
  getTreeLevelKeys,
  parsePathname,
  parseValue,
} from '@gongzu/core/common/utils';
import { getHistory } from '@gongzu/core/config/history';
import { EngineStoresContext } from '@gongzu/core/contexts/store-contexts';
import { ActionBinding } from '@gongzu/core/types/comps-common';
import {
  DesktopCompMenuConfig,
  DesktopCompTreeDataSource,
} from '@gongzu/core/types/comps-desktop';
import { ActionQueue } from '@gongzu/core/types/entities';
import { Menu } from 'antd';
import compact from 'lodash-es/compact';
import concat from 'lodash-es/concat';
import get from 'lodash-es/get';
import size from 'lodash-es/size';
import { observer } from 'mobx-react';
import React from 'react';
import ReactDOM from 'react-dom';

interface MenuData {
  key: string;
  name: string;
  value: string;
  url: string;
  usePushState: boolean;
  targetBlank: boolean;
  children?: MenuData[];
  node: unknown;
}

function buildMenuData(payload: {
  dataSource?: unknown[];
  treeDataSource?: DesktopCompTreeDataSource;
  url?: string;
  selected?: string;
  onSelect?: ActionBinding;
  usePushState?: string;
  targetBlank?: string;
  pageCompContext: ICompContext;
  pathname?: string;
  openParent?: boolean;
}): {
  menuDatas?: MenuData[];
  selectedKeys?: string[];
  openKeys?: string[];
} {
  const { treeDataSource, dataSource, url, pageCompContext } = payload;

  if (!Array.isArray(dataSource) || treeDataSource == null) {
    return {};
  }

  let selectedKeys: string[] = [];
  let openKeys: string[] = [];

  const menuDatas = dataSource.map((n, index) => {
    const children = treeDataSource.childrenKey
      ? get(n, treeDataSource.childrenKey)
      : undefined;

    const pathname = `${payload.pathname ?? ''}.${index}`;

    const value = parseValue({
      expression: treeDataSource.value,
      compContext: pageCompContext,
      context: n,
    });

    const name = parseValue({
      expression: treeDataSource.name,
      compContext: pageCompContext,
      context: n,
    });

    const url1 = parseValue({
      expression: url,
      compContext: pageCompContext,
      context: n,
    });

    const usePushState = parseValue({
      expression: payload.usePushState,
      compContext: pageCompContext,
      context: n,
    });

    const targetBlank = parseValue({
      expression: payload.targetBlank,
      compContext: pageCompContext,
      context: n,
    });

    const selected = parseValue({
      expression: payload.selected,
      compContext: pageCompContext,
      context: n,
    });

    const { openParent } = payload;

    if (selected) {
      selectedKeys.push(value);
      if (openParent) {
        openKeys.push(value);
      }
    }

    const menuData = {
      name,
      value,
      key: value,
      usePushState: usePushState === true,
      targetBlank: targetBlank === true,
      url: url1,
      node: n,
    };

    if (size(children) === 0) {
      return menuData;
    }

    const {
      menuDatas: childrenMenuDatas,
      openKeys: childrenOpenKeys,
      selectedKeys: childrenSelectedKeys,
    } = buildMenuData({
      ...payload,
      dataSource: children,
      pathname,
    });

    if (size(childrenOpenKeys) > 0) {
      openKeys.push(value);
    }

    openKeys = compact(concat(openKeys, childrenOpenKeys));
    selectedKeys = compact(concat(selectedKeys, childrenSelectedKeys));

    return {
      ...menuData,
      children: childrenMenuDatas,
    };
  });

  return {
    menuDatas,
    openKeys,
    selectedKeys,
  };
}

function buildMenuItem(payload: {
  menuDatas?: MenuData[];
  onSelect: (params: any) => void;
  pageCompContext: ICompContext;
  actions: Record<string, ActionQueue>;
}) {
  const { menuDatas, pageCompContext, onSelect } = payload;

  if (menuDatas) {
    return menuDatas.map((menu) => {
      if (size(menu.children) === 0) {
        return (
          <Menu.Item key={menu.value}>
            <a
              href={menu.url}
              target={menu.targetBlank ? '_blank' : undefined}
              rel="noreferrer"
              onClick={
                menu.usePushState
                  ? (e) => {
                      e.preventDefault();
                      e.stopPropagation();

                      if (!pageCompContext.inDesigner) {
                        getHistory().push(menu.url, {
                          name: menu.name,
                          url: menu.url,
                        });

                        if (menu.node) {
                          onSelect(menu.node);
                        }
                      }
                    }
                  : undefined
              }
            >
              {menu.name}
            </a>
          </Menu.Item>
        );
      }

      return (
        <Menu.SubMenu title={menu.name} key={menu.value}>
          {buildMenuItem({
            ...payload,
            menuDatas: menu.children,
          })}
        </Menu.SubMenu>
      );
    });
  }

  return <></>;
}

export default observer((props: CompProps<DesktopCompMenuConfig>) => {
  const { config, rawProps, innerRef, style, ...rest } = props;

  const pageCompContext = React.useContext(PageCompContext);

  const [openKeys, setOpenKeys] = React.useState<string[]>([]);
  const defaultExpandHandled = React.useRef<boolean>(false);

  const { engineModelStore } = React.useContext(EngineStoresContext);

  const { pathname } = parsePathname({
    expression: config.tree?.dataSource,
    compContext: pageCompContext,
  });

  const dataSource = pathname
    ? (get(pageCompContext.state, pathname) as Record<string, unknown>[])
    : [];

  const menuData = buildMenuData({
    dataSource,
    usePushState: config.usePushState,
    targetBlank: config.targetBlank,
    treeDataSource: config.tree,
    selected: config.selected,
    url: config.url,
    openParent: true,
    pageCompContext,
  });

  React.useEffect(() => {
    let keys = compact(concat(openKeys, menuData.openKeys));

    if (
      !defaultExpandHandled.current &&
      config.tree &&
      config.tree.defaultExpandLevel != null
    ) {
      defaultExpandHandled.current = true;

      keys = compact(
        concat(
          keys,
          getTreeLevelKeys({
            tree: menuData.menuDatas,
            level: config.tree.defaultExpandLevel,
          }) as string[],
        ),
      );
    }

    setOpenKeys(keys);
  }, [menuData.openKeys?.toString()]);

  const dispatchOnSelect = useActionDispatcher(config.onSelect);

  return (
    <Menu
      style={{
        minHeight: config.mode === 'horizontal' ? undefined : 200,
        ...style,
      }}
      mode={config.mode}
      theme={config.theme}
      selectedKeys={menuData.selectedKeys ?? compact(window.location.pathname)}
      openKeys={openKeys}
      onOpenChange={(openKeys1) => setOpenKeys(openKeys1 as string[])}
      triggerSubMenuAction={config.triggerSubMenuAction}
      ref={(el) => {
        if (innerRef) {
          // eslint-disable-next-line react/no-find-dom-node
          innerRef.current = ReactDOM.findDOMNode(el);
        }
      }}
      {...rest}
      {...rawProps}
    >
      {buildMenuItem({
        menuDatas: menuData.menuDatas,
        onSelect: dispatchOnSelect,
        pageCompContext,
        actions: engineModelStore.actions,
      })}
    </Menu>
  );
});
