import PageCompContext from '@gongzu/core/common/CompContext';
import { useActionDispatcher } from '@gongzu/core/common/hooks';
import { CompProps } from '@gongzu/core/common/types';
import {
  buildTreeData,
  parsePathname,
  parseValue,
} from '@gongzu/core/common/utils';
import { EngineStoresContext } from '@gongzu/core/contexts/store-contexts';
import { DesktopCompTreeConfig } from '@gongzu/core/types/comps-desktop';
import { findTreeNodeBy } from '@gongzu/core/utils/tree';
import { Tree, TreeProps } from 'antd';
import classNames from 'classnames';
import compact from 'lodash-es/compact';
import concat from 'lodash-es/concat';
import difference from 'lodash-es/difference';
import first from 'lodash-es/first';
import flatten from 'lodash-es/flatten';
import get from 'lodash-es/get';
import pick from 'lodash-es/pick';
import { observer, Observer } from 'mobx-react';
import React, { Key } from 'react';
import { gzdtBem } from '../../constants';

function TreeControl(
  props: Omit<TreeProps, 'onExpand'> & {
    expandedKeysOuter?: Key[];
    onExpand: (diffKeys: Key[], expandedKeys: Key[]) => void;
  },
) {
  const { onExpand, expandedKeysOuter, ...treeProps } = props;

  const [expandedKeys, setExpandedKeys] = React.useState<Key[]>([]);
  // const hasSetDefaultExpanded = React.useRef<boolean>(false);
  const expandedKeysRef = React.useRef<Key[]>([]);

  React.useEffect(() => {
    if (expandedKeysOuter) {
      setExpandedKeys(expandedKeysOuter);
      expandedKeysRef.current = expandedKeysOuter;
    }
  }, [expandedKeysOuter]);

  return (
    <Tree
      {...treeProps}
      expandedKeys={expandedKeys}
      onExpand={(expandedKeys1) => {
        if (onExpand) {
          onExpand(
            difference(expandedKeys1, expandedKeysRef.current),
            expandedKeys1,
          );
        }

        // 若展开节点是非受控的
        if (!expandedKeysOuter) {
          setExpandedKeys(expandedKeys1);
          expandedKeysRef.current = expandedKeys1;
        }
      }}
    />
  );
}

export default observer((props: CompProps<DesktopCompTreeConfig>) => {
  const { config, rawProps, className, innerRef, ...rest } = props;

  const pageCompContext = React.useContext(PageCompContext);

  const { engineModelStore } = React.useContext(EngineStoresContext);

  const { pathname } = parsePathname({
    expression: config.tree.dataSource,
    compContext: pageCompContext,
  });

  const dataSource = pathname
    ? (get(pageCompContext.state, pathname) as Record<string, unknown>[])
    : undefined;

  const dispatchOnExpand = useActionDispatcher(config.onExpand);

  const dispatchOnChange = useActionDispatcher(config.onChange);

  const treeData = buildTreeData({
    dataSource,
    pathname,
    type: config.tree.dataSourceType,
    pageCompContext,
    ...pick(config.tree, [
      'childrenKey',
      'parentIdKey',
      'name',
      'value',
      'isLeaf',
    ]),
  });

  const selectedKeys = parseValue({
    expression: config.selectedKeys,
    compContext: pageCompContext,
  });

  let titleRender;

  if (config.renderCompId) {
    if (pageCompContext.inDesigner) {
      titleRender = () => <span>自定义组件</span>;
    } else {
      const customComp = engineModelStore.customs[config.renderCompId];

      titleRender = (record: any) => (
        <Observer>
          {() => {
            const pathnameCurr = get(record, 'pathname');

            const context = {
              ...pageCompContext,
              inDesigner: false,
              dataBinding: {
                pathname: pathnameCurr,
                pathnames: compact(
                  concat(
                    pathnameCurr,
                    pathname,
                    pageCompContext.dataBinding.pathnames,
                  ),
                ),
                index: get(record, 'index'),
              },
            };

            return (
              <PageCompContext.Provider value={context}>
                {customComp ? (
                  React.createElement(pageCompContext.factoryComp!, {
                    config: customComp,
                  })
                ) : (
                  <span>--</span>
                )}
              </PageCompContext.Provider>
            );
          }}
        </Observer>
      );
    }
  }

  return (
    <div
      className={classNames(className, gzdtBem('tree')())}
      ref={innerRef}
      {...rest}
    >
      <TreeControl
        expandedKeysOuter={
          config.tree.expandedKeys
            ? parseValue({
                expression: config.tree.expandedKeys,
                compContext: pageCompContext,
              })
            : undefined
        }
        onExpand={(diffKeys, expandedKeys) => {
          dispatchOnExpand({ expandedKey: first(diffKeys), expandedKeys });
        }}
        treeData={treeData}
        loadData={
          config.tree.asyncLoad
            ? () =>
                new Promise<void>((resolve) => {
                  setTimeout(() => resolve(), 0);
                })
            : undefined
        }
        selectedKeys={selectedKeys ? concat(selectedKeys).map(i => `${i}`) : undefined}
        titleRender={titleRender}
        onSelect={(selectedKeys1) => {
          const nodeKey = get(selectedKeys1, 0);

          dispatchOnChange(
            nodeKey && config.tree.value && dataSource
              ? findTreeNodeBy(
                  dataSource,
                  (n) => {
                    const key = parseValue({
                      expression: config.tree.value,
                      compContext: pageCompContext,
                      context: n,
                    });

                    return `${key}` === nodeKey;
                  },
                  config.tree.childrenKey,
                ) || undefined
              : undefined,
          );
        }}
        {...rawProps}
      />
    </div>
  );
});
