import PageCompContext from '@gongzu/core/common/CompContext';
import { rawPropsDesktopFormItem } from '@gongzu/core/common/raw-props-desktop';
import { CompProps } from '@gongzu/core/common/types';
import { parseValueDeep } from '@gongzu/core/common/utils';
import { DesktopCompFormItemContainerConfig } from '@gongzu/core/types/comps-desktop';
import pick from 'lodash-es/pick';
import React from 'react';
import DesktopCompFormItem from './DesktopCompFormItem';

function DesktopCompFormItemContainer(
  props: CompProps<DesktopCompFormItemContainerConfig>,
) {
  const { config, children, rawProps, ...rest } = props;

  const pageCompContext = React.useContext(PageCompContext);

  return (
    <DesktopCompFormItem
      config={config}
      rawProps={pick(
        parseValueDeep({
          source: config.formItemRawProps,
          compContext: pageCompContext,
        }),
        rawPropsDesktopFormItem,
      )}
      {...rest}
    >
      {() => <>{children}</>}
    </DesktopCompFormItem>
  );
}

export default React.memo(DesktopCompFormItemContainer);
