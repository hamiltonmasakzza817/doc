import PageCompContext from '@gongzu/core/common/CompContext';
import { rawPropsDesktopFormItem } from '@gongzu/core/common/raw-props-desktop';
import { CompProps } from '@gongzu/core/common/types';
import { getPopupContainer, parseValueDeep } from '@gongzu/core/common/utils';
import { TimeUnit } from '@gongzu/core/types/comps-common';
import { DesktopCompDatePickerConfig } from '@gongzu/core/types/comps-desktop';
import generatePicker from 'antd/es/date-picker/generatePicker';
import 'antd/es/date-picker/style/index.css';
import dayjs, { Dayjs } from 'dayjs';
import every from 'lodash-es/every';
import first from 'lodash-es/first';
import get from 'lodash-es/get';
import last from 'lodash-es/last';
import map from 'lodash-es/map';
import pick from 'lodash-es/pick';
import { observer, Observer } from 'mobx-react';
import { PickerMode } from 'rc-picker/es/interface';
import dayjsGenerateConfig from 'rc-picker/lib/generate/dayjs';
import React from 'react';
import DesktopCompFormItem from './DesktopCompFormItem';

const DatePicker = generatePicker<Dayjs>(dayjsGenerateConfig);
const { RangePicker } = DatePicker;

export default observer((props: CompProps<DesktopCompDatePickerConfig>) => {
  const { config, rawProps, ...rest } = props;

  const pageCompContext = React.useContext(PageCompContext);

  return (
    <DesktopCompFormItem
      config={config}
      rawProps={pick(
        parseValueDeep({
          source: config.formItemRawProps,
          compContext: pageCompContext,
        }),
        rawPropsDesktopFormItem,
      )}
      {...rest}
    >
      {({ bind, disabled, readOnly, error }) => (
        <Observer>
          {() => {
            const { timeUnit, placeholder } = config;

            let picker: Exclude<PickerMode, 'date' | 'time'> | undefined;

            if (readOnly) {
              if (config.isRange) {
                return <div>{get(bind, 'value[0]') ?? '--'} ~ {get(bind, 'value[1]') ?? '--'}</div>;
              }
              return <div>{bind?.value ?? '--'}</div>;
            }

            switch (timeUnit) {
              case TimeUnit.DATE: {
                break;
              }

              case TimeUnit.WEEK: {
                picker = 'week';
                break;
              }

              case TimeUnit.MONTH: {
                picker = 'month';
                break;
              }

              case TimeUnit.QUARTER: {
                picker = 'quarter';
                break;
              }

              case TimeUnit.YEAR: {
                picker = 'year';
                break;
              }

              default: {
                break;
              }
            }

            const datePickerProps = {
              allowClear: config.allowClear,
              picker: picker as any,
              format: config.format,
              disabled,
              getPopupContainer: getPopupContainer(pageCompContext),
              status: error ? 'error' : undefined as any
            };

            if (config.isRange) {
              return (
                <RangePicker
                  {...datePickerProps}
                  value={
                    bind?.value
                      ? [dayjs(first(bind.value)), dayjs(last(bind.value))]
                      : undefined
                  }
                  placeholder={
                    placeholder ? [placeholder, placeholder] : undefined
                  }
                  onChange={(values) => {
                    const isNumber =
                      bind?.value &&
                      every(
                        bind.value,
                        (value) => !Number.isNaN(+(value as string)),
                      );

                    if (bind) {
                      if (values) {
                        bind.onChange(
                          map(values, (value) =>
                            isNumber
                              ? +(value || 0)
                              : value?.format(config.format || 'YYYY-MM-DD'),
                          ),
                        );
                      } else {
                        bind.onChange(undefined);
                      }
                    }
                  }}
                  {...rawProps}
                />
              );
            }

            return (
              <DatePicker
                {...datePickerProps}
                autoFocus={config.autoFocus}
                placeholder={placeholder}
                value={bind?.value ? dayjs(bind.value as string) : undefined}
                onChange={(v: Dayjs | null) => {
                  const isNumber =
                    bind?.value && !Number.isNaN(+(bind.value as string));

                  if (bind) {
                    if (v) {
                      bind.onChange(
                        isNumber ? +v : v.format(config.format || 'YYYY-MM-DD'),
                      );
                    } else {
                      bind.onChange(undefined);
                    }
                  }
                }}
                {...rawProps}
              />
            );
          }}
        </Observer>
      )}
    </DesktopCompFormItem>
  );
});
