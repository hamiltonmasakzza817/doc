import CompContext from '@gongzu/core/common/CompContext';
import {
  useActionDispatcher,
  useCustomElement,
} from '@gongzu/core/common/hooks';
import { CompProps } from '@gongzu/core/common/types';
import { getPopupContainer, parseValue } from '@gongzu/core/common/utils';
import FlexWrapper from '@gongzu/core/components/FlexWrapper';
import { EngineStoresContext } from '@gongzu/core/contexts/store-contexts';
import { DesktopCompContainerConfig } from '@gongzu/core/types/comps-desktop';
import { Popover, Spin, Tooltip } from 'antd';
import { TooltipPlacement } from 'antd/es/tooltip';
import classNames from 'classnames';
import DOMPurify from 'dompurify';
import compact from 'lodash-es/compact';
import concat from 'lodash-es/concat';
import { observer } from 'mobx-react';
import React from 'react';

export default observer((props: CompProps<DesktopCompContainerConfig>) => {
  const { className, config, children, innerRef, rawProps, ...rest } = props;

  const compContext = React.useContext(CompContext);

  const { engineModelStore } = React.useContext(EngineStoresContext);

  const loading =
    parseValue({
      expression: config.loading,
      compContext,
    }) ?? false;

  const tooltip = parseValue({
    expression: config.tooltip,
    compContext,
  });

  const wrapperProps = {
    ...rest,
    id: config.id,
    className: classNames({ relative: loading }, className),
  };

  const dispatchHeightChange = useActionDispatcher(config.onHeightChange);

  let customElement = useCustomElement(config.renderCompId);

  if (compContext.inDesigner && customElement) {
    customElement = (
      <div
        style={{
          height: 80,
          outline: '1px dashed',
          outlineOffset: -1,
        }}
        className={classNames('flex justify-center items-center', className)}
      >
        {customElement}
      </div>
    );
  }

  let content = customElement || children;

  if (config.loading) {
    content = <Spin spinning={loading}>{content}</Spin>;
  }

  if (config.flexBottom) {
    return (
      <FlexWrapper
        bottom={parseValue({
          expression: config.flexBottom,
          compContext,
        })}
        innerRef={innerRef}
        container={
          compContext.inDesigner ? compContext.viewportQuerySelector : undefined
        }
        portal={compContext.portal}
        onHeightChange={(height: number) => {
          dispatchHeightChange({ height });
        }}
        {...wrapperProps}
      >
        {content}
      </FlexWrapper>
    );
  }

  let dropdown;

  if (config.dropdownCompId && config.dropdownTrigger) {
    const dropdownComp = engineModelStore.customs[config.dropdownCompId];

    if (dropdownComp) {
      dropdown = React.createElement(compContext.factoryComp, {
        config: dropdownComp,
      });
    }
  }

  const container = (
    <div {...wrapperProps} ref={innerRef} data-id={config.id} {...rawProps}>
      {content}
    </div>
  );

  if (dropdown && !compContext.inDesigner) {
    return (
      <Popover
        content={dropdown}
        trigger={compact(concat(config.dropdownTrigger))}
        getPopupContainer={getPopupContainer(compContext)}
        placement={(config.align as TooltipPlacement) || 'bottomLeft'}
      >
        {container}
      </Popover>
    );
  }

  if (tooltip) {
    return (
      <Tooltip
        title={
          <div
            dangerouslySetInnerHTML={{
              __html: DOMPurify.sanitize(tooltip),
            }}
          />
        }
        getPopupContainer={getPopupContainer(compContext)}
      >
        {container}
      </Tooltip>
    );
  }

  return container;
});
