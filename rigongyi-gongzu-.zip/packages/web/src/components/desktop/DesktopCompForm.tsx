import CompContext from '@gongzu/core/common/CompContext';
import { CompProps } from '@gongzu/core/common/types';
import { parsePathname } from '@gongzu/core/common/utils';
import { DesktopCompFormConfig } from '@gongzu/core/types/comps-desktop';
import { Form } from 'antd';
import classNames from 'classnames';
import compact from 'lodash-es/compact';
import concat from 'lodash-es/concat';
import { observer } from 'mobx-react';
import React from 'react';
import { gzdtBem } from '../../constants';

export default observer((props: CompProps<DesktopCompFormConfig>) => {
  const { className, config, innerRef, rawProps, ...rest } = props;

  const compContext = React.useContext(CompContext);

  const { pathname } = parsePathname({
    expression: config.value,
    compContext,
  });

  return (
    <CompContext.Provider
      value={{
        ...compContext,
        dataBinding: {
          ...compContext.dataBinding,
          pathname,
          pathnames: compact(
            concat(pathname, compContext.dataBinding.pathnames),
          ),
        },
        formLayout: {
          ...compContext.formLayout,
          label: config.label,
        },
      }}
    >
      <Form
        data-id={config.id}
        component="div"
        size={config.size}
        layout={
          (config.label?.width as any) === '100%' ? 'vertical' : undefined
        }
        className={classNames(gzdtBem('form')(), className)}
        {...rest}
        {...rawProps}
      >
        {config.children?.map((child) => {
          if (compContext.factoryComp) {
            return React.createElement(compContext.factoryComp, {
              key: child.id,
              config: child,
            });
          }

          return <></>;
        })}

        <div
          className="hidden"
          ref={(el) => {
            if (innerRef && el) {
              innerRef.current = el.parentElement;
            }
          }}
        />
      </Form>
    </CompContext.Provider>
  );
});
