import CompContext from '@gongzu/core/common/CompContext';
import { useActionDispatcher, useParseValue } from '@gongzu/core/common/hooks';
import { CompProps } from '@gongzu/core/common/types';
import { EngineStoresContext } from '@gongzu/core/contexts/store-contexts';
import { DesktopCompModalConfig } from '@gongzu/core/types/comps-desktop';
import { Button, Drawer, Modal } from 'antd';
import classNames from 'classnames';
import assign from 'lodash-es/assign';
import get from 'lodash-es/get';
import omit from 'lodash-es/omit';
import { observer } from 'mobx-react';
import React from 'react';
import { gzdtBem } from '../../constants';

const modalBem = gzdtBem('modal');

export default observer((props: CompProps<DesktopCompModalConfig>) => {
  const { className, config, children, innerRef, rawProps, ...rest } = props;

  const compContext = React.useContext(CompContext);

  const parseValue = useParseValue();

  const dispatchOnOk = useActionDispatcher(config.onOk);

  const dispatchOnCancel = useActionDispatcher(config.onCancel);

  const { engineStore, engineModelStore } =
    React.useContext(EngineStoresContext);

  const [container, setContainer] = React.useState<
    HTMLDivElement | undefined
  >();

  React.useEffect((): void => {
    if (container?.parentNode) {
      container.parentNode.removeChild(container);
    }

    const { portal } = compContext;

    const c = document.createElement('div');

    if (compContext.pageIds) {
      compContext.pageIds.forEach((pageId) => {
        c.classList.add(`gongzu-designer-page-${pageId}`);
      });
    }

    const attach = compContext.viewportQuerySelector
      ? portal.querySelector(compContext.viewportQuerySelector)
      : null;

    if (attach) {
      attach.appendChild(c);
    }

    setContainer(c);
  }, [compContext.viewportQuerySelector, compContext.pageIds]);

  const visiblePathname = `_system.modalOpen.${config.id}`;

  const visible = !!get(compContext.state, visiblePathname);

  if (compContext.inDesigner) {
    return (
      <div
        {...rest}
        ref={innerRef}
        data-id={config.id}
        className={classNames(
          className,
          `gongzu-designer-page-${engineModelStore.pageId}`,
        )}
      >
        {children}
      </div>
    );
  }

  let title = <span>{parseValue(config.title)}</span>;

  if (config.titleRenderCompId) {
    const titleComp = engineModelStore.customs[config.titleRenderCompId];

    if (titleComp) {
      title = React.createElement(compContext.factoryComp, {
        config: titleComp,
      });
    }
  }

  let footer: JSX.Element | undefined;

  if (config.footer) {
    if (config.footer === 'empty') {
      footer = <></>;
    } else {
      const footerComp = engineModelStore.customs[config.footer];

      if (footerComp) {
        footer = React.createElement(compContext.factoryComp, {
          config: footerComp,
        });
      }
    }
  }

  const width = get(config.styles, 'width');

  const modalProps = assign(
    {
      title: title || '对话框',
      visible,
      width,
      maskClosable: config.maskClosable ?? true,
      destroyOnClose: config.destroyOnClose ?? false,
      onOk: config.onOk
        ? (e: React.MouseEvent | React.KeyboardEvent) => {
            e.stopPropagation();
            e.preventDefault();

            dispatchOnOk();
          }
        : undefined,
      getContainer: container ? () => container : undefined,
      onCancel: (e: React.MouseEvent | React.KeyboardEvent) => {
        if (config.onCancel) {
          e.stopPropagation();
          e.preventDefault();

          dispatchOnCancel();
        } else {
          engineStore.updateData(`${visiblePathname}`, false);
        }
      },
      footer,
    },
    config.disableTransition
      ? {
          transitionName: '',
          maskTransitionName: '',
        }
      : undefined,
  );

  const content = <div className="w-auto">{children}</div>;

  return (
    <>
      {config.displayType === 'DRAWER' ? (
        <Drawer
          {...omit(modalProps, ['onOk', 'onCancel', 'footer'])}
          className={classNames(
            className,
            modalBem({
              'no-footer': config.footer === 'empty',
            }),
            { 'w-0': !modalProps.visible },
          )}
          onClose={modalProps.onCancel}
          footer={
            footer ?? (
              <div className="text-right">
                <Button onClick={modalProps.onCancel} className="mr-1">
                  取消
                </Button>
                <Button type="primary" onClick={modalProps.onOk}>
                  确定
                </Button>
              </div>
            )
          }
          {...rawProps}
        >
          {content}
        </Drawer>
      ) : (
        <Modal
          {...modalProps}
          centered={config.centered}
          className={classNames(
            className,
            modalBem({
              'no-footer': config.footer === 'empty',
            }),
          )}
          {...rawProps}
        >
          {content}
        </Modal>
      )}
    </>
  );
});
