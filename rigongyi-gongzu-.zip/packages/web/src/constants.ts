import { setup } from 'bem-cn';

export const gzdtBem = setup({
  ns: 'gzdt-',
});

export const gzmBem = setup({
  ns: 'gzm-',
});

