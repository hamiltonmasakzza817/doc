import { getHistory } from '@gongzu/core/config/history';
import {
  BaseStoresContext,
  EngineStoresContext,
} from '@gongzu/core/contexts/store-contexts';
import EngineStore from '@gongzu/core/engine/EngineStore';
import { MessageExecCode, MessageType } from '@gongzu/core/stores/MessageStore';
import get from 'lodash-es/get';
import qs from 'qs';
import React, { useEffect } from 'react';

export function useMessageStoreEffectWeb() {
  const { messageStore } = React.useContext(BaseStoresContext);
  const {
    engineStore: { codeInterpreter },
  } = React.useContext(EngineStoresContext);

  React.useEffect(() => {
    const message = messageStore.current;

    let handled = false;

    if (message) {
      switch (message.type) {
        case MessageType.EXEC_CODE: {
          const { code, resolve, reject, params } = message as MessageExecCode;

          try {
            /* eslint-disable @typescript-eslint/naming-convention */
            const [
              state,
              _params,
              _context,
              _index,
              _pathname,
              _pathnames,
              utils,
            ] = params;
            /* eslint-enable @typescript-eslint/naming-convention */

            resolve(
              codeInterpreter(code, [
                ['state', state],
                ['_params', _params],
                ['_context', _context],
                ['_index', _index],
                ['_pathname', _pathname],
                ['_pathnames', _pathnames],
                ['utils', utils],
              ]),
            );
          } catch (e) {
            // eslint-disable-next-line
            console.log('eval error', JSON.stringify(e));
            reject();
          }

          handled = true;

          break;
        }

        default:
          break;
      }

      if (handled) {
        messageStore.receive(message);
      }
    }
  }, [messageStore.current]);
}

export function useLocationChange(engineStore: EngineStore) {
  useEffect(() => {
    const syncUrlQueryData = () => {
      engineStore.updateData(
        '_system.query',
        qs.parse(get(window, 'location.search'), { ignoreQueryPrefix: true }) ??
          {},
      );
    };

    const removeListen = getHistory().listen(syncUrlQueryData);

    return () => {
      removeListen();
    };
  }, []);
}
