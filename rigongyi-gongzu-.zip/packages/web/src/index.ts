import '@gongzu/core/config/global-configs';
import { configService } from '@gongzu/core/config/service';
import axios from 'axios';
import React from 'react';
import ReactDOM from 'react-dom';
import Web from './pages/Web';

require('@gongzu/core/style.scss');
require('./tailwindcss.css');

configService({ axios });

ReactDOM.render(
  React.createElement(Web),
  document.querySelector('#gongzu-web'),
);
