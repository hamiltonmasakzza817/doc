# `@gongzu/core`

> gongzu 设计器公共库，包含组件、工具方法、通用逻辑

## 发布

### 准备工作

package.json 修改版本号

```
npm run package
cd dist
npm publish
```

## 发布 beta 版本的方法

```shell
npm run build
cd dist
npm dist-tag add @gongzu/core@<version> beta
npm publish --tag beta
```
