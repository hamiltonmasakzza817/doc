import { setup } from 'bem-cn';

export const addingId = 'adding';

export const gzdnBem = setup({
  ns: 'gzdn-',
});
