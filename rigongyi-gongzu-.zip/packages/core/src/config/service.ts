import {
  AxiosInstance,
  AxiosRequestConfig,
  AxiosResponse,
  AxiosStatic,
} from 'axios';
import assign from "lodash-es/assign";
import get from 'lodash-es/get';
import transform from 'lodash-es/transform';

import qs from 'qs';

export const jsonAxiosOptions = {
  headers: {
    'Content-Type': 'application/json',
  },
  transformRequest: (data: Record<string, unknown>) =>
    JSON.stringify(
      transform(
        data,
        (result: Record<string, unknown>, value, key) => {
          if (value != null) {
            // eslint-disable-next-line no-param-reassign
            result[key] = value;
          }
        },
        Array.isArray(data) ? [] : {},
      ),
    ),
} as AxiosRequestConfig;

export const formAxiosOptions = {
  headers: {
    'Content-Type': 'application/x-www-form-urlencoded',
  },
  transformRequest: (data: any) =>
    qs.stringify(data, {
      skipNulls: true,
      allowDots: true,
      encode: true,
    }),
};

interface ServiceOptions {
  axios?: AxiosStatic;
  getHeader?: () => Record<string, string>;
  tapResponse?: (resp: AxiosResponse) => void;
}

const options: ServiceOptions = {};

export function configService(opt: ServiceOptions) {
  options.axios = opt.axios;
  options.getHeader = opt.getHeader;
  options.tapResponse = opt.tapResponse;
}

export function createService(
  config: AxiosRequestConfig = jsonAxiosOptions,
  ignoreException = false,
): AxiosInstance {
  if (options.getHeader != null) {
    config.headers = assign({}, config.headers, options.getHeader());
  }

  const instance = options.axios!.create(config);

  instance.interceptors.response.use(
    (resp) => {
      if (options.tapResponse != null) {
        options.tapResponse(resp);
      }
      return resp;
    },
    (error) => {
      const data = get(error.response, 'data');

      if (ignoreException) {
        throw data;
      }

      const redirectUrl = get(data, 'redirectUrl');

      if (redirectUrl) {
        window.location.replace(
          `${redirectUrl}?targetUrl=${encodeURIComponent(
            window.location.href,
          )}`,
        );
      }

      const message = get(data, 'error');

      throw message ? new Error(message) : error;
    },
  );

  return instance;
}
