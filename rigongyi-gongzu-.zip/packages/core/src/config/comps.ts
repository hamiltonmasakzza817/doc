import concat from 'lodash-es/concat';
import { CompsAll } from '../types/comps-all';
import { DesktopCompType } from '../types/comps-desktop';
import { MobileCompType } from '../types/comps-mobile';
import { PageCompType } from '../types/comps-page';
import { TaroCompType } from '../types/comps-taro';

export const containablePageCompTypes = [
  PageCompType.PAGE,
  PageCompType.REPEAT,
  PageCompType.CUSTOM,

  DesktopCompType.CONTAINER,
  DesktopCompType.TAB_PANE,
  DesktopCompType.FORM,
  DesktopCompType.MODAL,
  DesktopCompType.DROPDOWN_MENU,

  MobileCompType.CONTAINER,
  MobileCompType.MODAL,
  MobileCompType.FORM,
  MobileCompType.FORM_ITEM,
  MobileCompType.LIST,
  MobileCompType.LIST_ITEM,
  MobileCompType.TAB_PANEL,

  TaroCompType.MODAL,
  TaroCompType.CONTAINER,
  TaroCompType.BOTTOM_CONTAINER,
  TaroCompType.NAV_CONTAINER,
  TaroCompType.FORM,
  TaroCompType.LIST,
  TaroCompType.LIST_ITEM,
  TaroCompType.SCROLL_VIEW,
  TaroCompType.SELECT,
  TaroCompType.DATE_PICKER,
];

export const formItemCompTypes = [
  DesktopCompType.INPUT,
  DesktopCompType.TEXT_AREA,
  DesktopCompType.NUMBER_INPUT,
  DesktopCompType.RADIO,
  DesktopCompType.DATE_PICKER,
  DesktopCompType.CHECKBOX,
  DesktopCompType.SWITCH,
  DesktopCompType.DATE_PICKER,
  DesktopCompType.SELECT,
  DesktopCompType.TREE_SELECT,
  DesktopCompType.UPLOADER,
  DesktopCompType.FORM_ITEM_CONTAINER,
  DesktopCompType.CASCADER,
  DesktopCompType.TRANSFER,
  DesktopCompType.SLIDER,

  MobileCompType.FORM_ITEM,
  MobileCompType.INPUT,
  MobileCompType.DATE_PICKER,
  MobileCompType.TEXT_AREA,
  MobileCompType.NUMBER_INPUT,
  MobileCompType.RADIO,
  MobileCompType.CHECKBOX,
  MobileCompType.SWITCH,
  MobileCompType.SELECT,
  MobileCompType.UPLOADER,

  TaroCompType.INPUT,
  TaroCompType.SELECT,
  TaroCompType.DATE_PICKER,
  TaroCompType.RADIO,
  TaroCompType.CHECKBOX,
  TaroCompType.SWITCH,
  TaroCompType.TEXT_AREA,
  TaroCompType.SLIDER,
];

export const loadableCompTypes = [
  DesktopCompType.IMAGE,
  MobileCompType.IMAGE,
  PageCompType.PAGE,
  PageCompType.UMD_COMP,
];

export const clickableCompTypes = [
  PageCompType.BLOCK,
  PageCompType.TEXT,

  DesktopCompType.BUTTON,
  DesktopCompType.CONTAINER,
  DesktopCompType.IMAGE,
  DesktopCompType.ICON,
  DesktopCompType.TAG,
  DesktopCompType.UPLOADER,

  MobileCompType.BUTTON,
  MobileCompType.CONTAINER,
  MobileCompType.TAG,

  TaroCompType.CONTAINER,
  TaroCompType.BUTTON,
  TaroCompType.IMAGE,
  TaroCompType.LIST_ITEM,
];

export const changeablePageCompTypes = concat<CompsAll>(
  formItemCompTypes,
  DesktopCompType.PAGINATION,
  DesktopCompType.TREE,
  DesktopCompType.STEPS,
  DesktopCompType.TABS,
  MobileCompType.TABS,
  MobileCompType.CAPSULE_TABS,
  MobileCompType.SEARCH_BAR,
  MobileCompType.SWIPER,
  TaroCompType.SWIPER,
);

export const blurPageCompTypes = concat(
  formItemCompTypes,
  MobileCompType.SEARCH_BAR,
);

export const inlinePageTypes = [];

export const actionBindingKeys = [
  'onChange',
  'onClick',
  'onSearch',
  'onLoad',
  'onClose',
  'onSort',
  'onOk',
  'onCancel',
  'onPressEnter',
  'onRowClick',
  'onRowSelectionChange',
  'onSelect',
  'onBlur',
  'onClear',
  'onHeightChange',
  'onExpand',
  'onAction',
];

export const rootPageCompTypes = [
  PageCompType.PAGE,
  DesktopCompType.MODAL,
  MobileCompType.MODAL,
  PageCompType.CUSTOM,
  TaroCompType.MODAL,
];

export const pasteInnerCompTypes = concat(
  rootPageCompTypes,
  MobileCompType.TAB_PANEL,
);

export const indeliblePageCompTypes = [
  PageCompType.PAGE,
  DesktopCompType.MODAL,
  PageCompType.CUSTOM,
];

export const fixedChildPageCompTypes = [
  PageCompType.REPEAT,
  DesktopCompType.FORM_ITEM_CONTAINER,
  DesktopCompType.UPLOADER,
  DesktopCompType.TABS,
];
