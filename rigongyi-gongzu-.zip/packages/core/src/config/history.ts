import { createBrowserHistory, createMemoryHistory, History } from 'history';

let history: History;

export function getHistory() {
  if (history) {
    return history;
  }

  history =
    window.History == null ? createMemoryHistory() : createBrowserHistory();

  return history;
}
