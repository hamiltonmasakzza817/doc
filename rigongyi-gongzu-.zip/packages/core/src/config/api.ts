// @ts-ignore
const prefix = NODE_ENV.DOMAIN || '';

export interface PageKey {
  url?: string;
  pageId?: string;
}

export default {
  login: {
    get: `${prefix}/api/ac/login`,
    remove: `${prefix}/api/ac/login`,
  },

  page: {
    listTree: `${prefix}/api/page/pages/tree`,
    getDraft: (id: string) => `${prefix}/api/page/pages/${id}`,
    getPublish: (key: PageKey) =>
      key.pageId
        ? `${prefix}/api/page/pages/${key.pageId}/published`
        : `${prefix}/api/page/pages/url/published?url=${key.url}`,
    save: `${prefix}/api/page/pages`,
    saveDraft: (id: string) => `${prefix}/api/page/pages/${id}/draft`,
    publish: (id: string) => `${prefix}/api/page/pages/${id}/publish`,
    publishBatch: `${prefix}/api/page/pages/publish/batch`,
    rollback: (id: string) => `${prefix}/api/page/pages/${id}/rollback`,

    update: (id: string) => `${prefix}/api/page/pages/${id}`,

    remove: (id: string) => `${prefix}/api/page/pages/${id}`,

    // @ts-ignore
    model: (key: string) => `${NODE_ENV.CDN_DOMAIN}/page-models/${key}`,
  },

  file: {
    upload: `${prefix}/api/app/files`,
  },
};

// export default {
//   login: {
//     get: `${prefix}/api/ac/login`,
//     remove: `${prefix}/api/ac/login`,
//   },

//   page: {
//     listTree: `${prefix}/api/page/pages/tree`,
//     getDraft: (key: PageKey) =>
//       `${prefix}/api/page/pages/${key.pageId ?? key.url}/draft`,
//     getPublish: (key: PageKey) =>
//       `${prefix}/api/page/pages/${key.pageId ?? key.url}/publish`,

//     save: `${prefix}/api/page/pages`,
//     saveDraft: (id: string) => `${prefix}/api/page/pages/${id}/draft`,
//     publish: (id: string) => `${prefix}/api/page/pages/${id}/publish`,
//     rollback: (id: string) => `${prefix}/api/page/pages/${id}/rollback`,

//     update: (id: string) => `${prefix}/api/page/pages/${id}`,

//     remove: (id: string) => `${prefix}/api/page/pages/${id}`,

//     // @ts-ignore
//     model: (key: string) => `${NODE_ENV.CDN_DOMAIN}/page-models/${key}`,
//   },

//   file: {
//     upload: `${prefix}/api/app/files`,
//   },
// };
