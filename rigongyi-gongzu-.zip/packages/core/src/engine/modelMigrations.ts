import cloneDeep from 'lodash-es/cloneDeep';
import forEach from 'lodash-es/forEach';
import get from 'lodash-es/get';
import map from 'lodash-es/map';
import set from 'lodash-es/set';
import transform from 'lodash-es/transform';
import unset from 'lodash-es/unset';
import { v4 as uuidv4 } from 'uuid';
import { CompConfig } from '../types/comps-common';
import {
  DesktopCompSelectConfig,
  DesktopCompTableConfig,
  DesktopCompTreeConfig,
  DesktopCompType,
} from '../types/comps-desktop';
import { PageCompCustomConfig } from '../types/comps-page';
import {
  ActionOtherActionQueue,
  ActionQueue,
  ActionType,
  PageModelData,
  TreeNode,
} from '../types/entities';
import { normalizeConfig } from '../utils/comp-normalizers';
import { walkTree } from '../utils/tree';

// 迁移旧版 actions v3.0.0 以前
function migrateActions300(actions: Record<string, ActionQueue>) {
  return transform(
    actions,
    (acc, curr, key) => {
      acc[key] = {
        ...curr,
        actions: map(curr.actions, (action) => {
          if (typeof action === 'string') {
            return {
              type: ActionType.OTHER_ACTION_QUEUE,
              actionId: action,
            } as ActionOtherActionQueue;
          }

          return action;
        }),
      };
    },
    {} as Record<string, ActionQueue>,
  );
}

// 迁移旧版 components v3.0.0 以前
function migrateComponents300<T extends CompConfig>(components: Array<T>) {
  walkTree(components, (node) => {
    if (node.type === DesktopCompType.SELECT) {
      const n = node as unknown as DesktopCompSelectConfig;
      if (get(n, 'multiple')) {
        n.mode = 'multiple';
        unset(n, 'multiple');
      }
    }

    if (node.css == null) {
      set(node, 'css', get(node, 'style'));
    }

    unset(node, 'style');

    if (node.styles == null) {
      set(node, 'styles.width', get(node, 'width'));
      set(node, 'styles.widthUnit', get(node, 'widthUnit'));
      set(node, 'styles.grid', get(node, 'grid'));
      set(node, 'styles.gridGap', get(node, 'gridGap'));
      set(node, 'styles.alignSelf', get(node, 'alignSelf'));
    }

    if (node.type === DesktopCompType.TABLE) {
      const config = node as unknown as DesktopCompTableConfig;

      if (config.columns) {
        config.columns.forEach((col) => {
          if (col.id == null) {
            // eslint-disable-next-line no-param-reassign
            col.id = uuidv4();
          }
        });
      }
    }

    if (node.type === DesktopCompType.TREE) {
      const config = node as unknown as DesktopCompTreeConfig;
      if (config.tree == null) {
        config.tree = {
          dataSource: get(node, 'dataSource'),
          dataSourceType: get(node, 'dataSourceType'),
        };
      }
    }
  });

  forEach(components, (comp) => {
    normalizeConfig({
      config: comp,
      rootConfig: components,
      reserveId: true,
    });
  });

  return components;
}

function migrate301(modelData: PageModelData) {
  return {
    customs: transform(
      get(modelData, 'components'),
      (acc, value) => {
        acc[value.id] = cloneDeep(value);
      },
      {} as Record<string, PageCompCustomConfig>,
    ),
    customTree: [
      {
        id: '-1',
        pathname: '-1',
        name: '自定义组件',
        children: map<TreeNode, TreeNode>(
          get(modelData, 'components'),
          (config) => ({
            id: config.id,
            name: config.name || '',
            pathname: `-1,${config.id}`,
            parentId: '-1',
          }),
        ),
      },
    ],
  };
}

export function migrateModel(modelData: PageModelData): PageModelData {
  let data = modelData;

  if (data.version == null) {
    data.version = '1.0.0';
  }

  if (data.version < '3.0.0') {
    data = {
      ...data,
      elements: migrateComponents300(data.elements),
      modals: data.modals ? migrateComponents300(data.modals) : [],
      actions: migrateActions300(data.actions),
      version: '3.0.0',
    };

    set(
      data,
      'components',
      migrateComponents300(get(data, 'components') as any),
    );
  }

  if (data.version < '3.0.1') {
    data = {
      ...data,
      ...migrate301(data),
      version: '3.0.1',
    };
  }

  return data;
}
