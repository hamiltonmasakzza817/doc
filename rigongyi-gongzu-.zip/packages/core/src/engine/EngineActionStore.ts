import assign from 'lodash-es/assign';
import concat from 'lodash-es/concat';
import flatten from 'lodash-es/flatten';
import get from 'lodash-es/get';
import pick from 'lodash-es/pick';
import reduce from 'lodash-es/reduce';
import set from 'lodash-es/set';
import size from 'lodash-es/size';
import split from 'lodash-es/split';
import { action, makeObservable, runInAction } from 'mobx';
import { EMPTY, from, Observable, of, zip } from 'rxjs';
import { catchError, finalize, map, mergeMap, take, tap } from 'rxjs/operators';
import LoggerStore from '../stores/LoggerStore';
import {
  ActionOtherActionQueue,
  ActionPayload,
  ActionStart,
  ActionType,
  asyncActions,
  LoggerType,
  rejectableActions,
} from '../types/entities';
import { parseJexlExpressionDeep } from '../utils/jexl';
import EngineModelStore from './EngineModelStore';
import EngineRuntimeStore from './EngineRuntimeStore';

const CANCEL_LATER = Symbol('CANCEL_LATER');

export default class EngineActionStore {
  constructor(
    readonly pageEngineModelStore: EngineModelStore,
    readonly pageEngineRuntimeStore: EngineRuntimeStore,
    readonly loggerStore: LoggerStore,
  ) {
    makeObservable(this, {
      dispose: action,
      dispatchAction: action.bound,
    });
  }

  dispose() {}

  dispatchAction(
    actionId: string,
    payload: ActionPayload,
    actionIds: string[] = [],
    cancelLater = false,
  ): Observable<any> {
    if (actionIds.includes(actionId)) {
      this.loggerStore.error(`存在循环调用的Action，队列id: ${actionId}`);
      return from(EMPTY);
    }

    const { actions } = this.pageEngineModelStore;

    const { state, execAction } = this.pageEngineRuntimeStore;

    const actionQueue = actions[actionId];

    if (actionQueue == null) {
      this.loggerStore.error(
        `未找到当前Action，${split(actionId, '-')[0]}`,
        LoggerType.CONSOLE,
      );
      return from(EMPTY);
    }

    const key = `_system.actionPending.${actionQueue.code || actionQueue.id}`;

    set(state, key, true);

    const clearPending = () => {
      runInAction(() => {
        set(state, key, false);
      });
    };

    const actionsSize = size(actionQueue.actions);

    return reduce(
      concat(
        {
          type: ActionType.START,
          confirm: actionQueue.confirm,
          context: actionQueue.context,
        } as ActionStart,
        actionQueue.actions,
      ),

      (prev$, act, index) =>
        prev$.pipe(
          mergeMap((actionPayload) => {
            if (actionPayload === CANCEL_LATER) {
              return from(EMPTY);
            }

            let { context } = actionPayload;

            if (act.context) {
              context = assign(
                {},
                actionPayload.context,
                parseJexlExpressionDeep(
                  act.context,
                  assign({}, state, {
                    _state: state,
                    _params: actionPayload.params,
                    _context: actionPayload.context,
                    _index: actionPayload.contextIndex,
                    _indexes: actionPayload.contextIndexes,
                    _pathname: actionPayload.contextPathname,
                    _pathnames: actionPayload.contextPathnames,
                  }),
                ),
              );
            }

            let curr$ = execAction(assign({}, actionPayload, { context }), act);

            if (asyncActions.includes(act.type)) {
              const parallelActionId = get(act, 'parallelActionId');

              if (parallelActionId) {
                curr$ = zip(
                  curr$,
                  this.dispatchAction(
                    parallelActionId,
                    payload,
                    concat(actionIds, actionId),
                  ).pipe(map((n) => n.params)),
                ).pipe(map((n) => flatten(n)));
              }
            }

            return curr$.pipe(
              mergeMap((result) => {
                if (act.type === ActionType.START) {
                  return of(actionPayload);
                }

                const nextPayload = {
                  ...actionPayload,
                  params: result,
                  context,
                };

                let ob = of(nextPayload);

                if (act.type === ActionType.OTHER_ACTION_QUEUE) {
                  const otherActionId = (act as ActionOtherActionQueue)
                    .actionId;

                  ob = this.dispatchAction(
                    otherActionId,
                    nextPayload,
                    concat(actionIds, actionId),
                  );
                }

                if (rejectableActions.includes(act.type)) {
                  if (!result) {
                    const rejectActionId = get(act, 'rejectActionId');

                    if (!rejectActionId) {
                      return from(EMPTY);
                    }

                    ob = this.dispatchAction(
                      rejectActionId,
                      nextPayload,
                      concat(actionIds, actionId),
                      true,
                    );
                  }
                }

                if (index === actionsSize && cancelLater) {
                  return ob.pipe(map(() => CANCEL_LATER));
                }

                return ob;
              }),
            );
          }),
        ),

      of(
        pick(payload, [
          'params',
          'context',
          'contextIndex',
          'contextIndexes',
          'contextPathname',
          'contextPathnames',
        ]),
      ) as Observable<any>,
    ).pipe(
      take(1),
      tap(() => {
        if (actionQueue.success) {
          this.loggerStore.success(actionQueue.success);
        }
      }),
      catchError((err) => {
        this.loggerStore.error(
          err.message,
          err.isAxiosError ? LoggerType.NOTIFICATION : LoggerType.MESSAGE,
        );
        return of();
      }),
      finalize(clearPending),
    );
  }
}
