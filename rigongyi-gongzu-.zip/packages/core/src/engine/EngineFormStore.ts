import { tap } from 'rxjs/operators';
import set from 'lodash-es/set';
import MobxFormStore from '../mobx-form/MobxFormStore';
import LoggerStore from '../stores/LoggerStore';
import { Page, PagePlatform } from '../types/entities';
import EngineRuntimeStore from './EngineRuntimeStore';

export default class EngineFormStore {
  form = new MobxFormStore<Record<string, unknown>>({
    name: 'pageEngineForm',
  });

  constructor(
    readonly pageEngineRuntimeStore: EngineRuntimeStore,
    readonly page: Page,
    readonly loggerStore: LoggerStore,
  ) {
    this.form.reset(pageEngineRuntimeStore.state);
  }

  clearErrors(pathname: string) {
    const filterExp = new RegExp(
      `^${pathname?.replace(/(\[|\])/g, '\\$1')}(\\.|\\[|$)`,
    );

    this.form.clearErrors({ filter: (key) => filterExp.test(key) });
  }

  triggerValidation(
    collection: {
      pathname?: string;
      filter?: (key: string) => boolean;
      scrollIntoView?: boolean;
    } = {},
  ) {
    const { pathname, filter, scrollIntoView } = collection;

    const { form } = this;

    const filterExp = new RegExp(
      `^${pathname?.replace(/(\[|\])/g, '\\$1')}(\\.|\\[|$)`,
    );

    return form
      .triggerValidation({
        filter: pathname ? (key) => filterExp.test(key) : filter,
      })
      .pipe(
        tap((validated) => {
          if (!validated) {
            if (PagePlatform.PC === this.page.platform && scrollIntoView) {
              const errorFormItem = document.querySelector(
                '[data-validate-error]',
              );

              if (errorFormItem) {
                errorFormItem.scrollIntoView();
              }
            }

            const { bindingKeys } = form;

            const firstErrorKey = bindingKeys.find((key) =>
              key in form.errors,
            );

            if (firstErrorKey) {
              this.loggerStore.error(
                form.errors[firstErrorKey] || '表单错误',
              );
            }

            set(this.pageEngineRuntimeStore.state, '_system.formErrors', form.errors);
          }
        }),
      );
  }
}
