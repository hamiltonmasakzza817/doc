import dayjs from 'dayjs';
import EventEmitter from 'eventemitter3';
import assign from 'lodash-es/assign';
import cloneDeep from 'lodash-es/cloneDeep';
import concat from 'lodash-es/concat';
import filter from 'lodash-es/filter';
import forEach from 'lodash-es/forEach';
import get from 'lodash-es/get';
import groupBy from 'lodash-es/groupBy';
import last from 'lodash-es/last';
import lodashMap from 'lodash-es/map';
import pull from 'lodash-es/pull';
import set from 'lodash-es/set';
import size from 'lodash-es/size';
import transform from 'lodash-es/transform';
import unset from 'lodash-es/unset';
import values from 'lodash-es/values';
import { action, makeObservable, observable, runInAction, toJS } from 'mobx';
import qs from 'qs';
import { defer, EMPTY, from, Observable, of, zip } from 'rxjs';
import { delay, map, mergeMap, tap } from 'rxjs/operators';
import { ValuesType } from 'utility-types';
import lodashUtils from '../common/lodash-utils';
import {
  createService,
  formAxiosOptions,
  jsonAxiosOptions,
} from '../config/service';
import LoggerStore from '../stores/LoggerStore';
import MessageStore, {
  MessageActionSheet,
  MessageConfirm,
  MessageExecCode,
  MessageType,
} from '../stores/MessageStore';
import { PageCompType } from '../types/comps-page';
import { CodeInterpreter, Router, RouterNavigateMode } from '../types/engine';
import {
  Action,
  ActionCancelActionQueue,
  ActionClearFormErrors,
  ActionControlEvent,
  ActionControlModal,
  ActionDelay,
  ActionDispatchPageEvent,
  ActionExecCode,
  ActionFetchData,
  ActionGo,
  ActionGuard,
  ActionNotification,
  ActionPayload,
  ActionSendRequest,
  ActionStart,
  ActionType,
  ActionValidateForm,
  Data,
  DataType,
  LoggerLevel,
  LoggerType,
  Page,
  Resource,
  ResourceType,
} from '../types/entities';
import { parseJSON } from '../utils/data';
import { parseJexlExpression, parseJexlExpressionDeep } from '../utils/jexl';
import {
  filterTree,
  findTreeNode,
  findTreeNodeBy,
  walkTree,
} from '../utils/tree';
import EngineActionStore from './EngineActionStore';
import EngineDataStore from './EngineDataStore';
import EngineEventStore from './EngineEventStore';
import EngineFormStore from './EngineFormStore';
import EngineModelStore from './EngineModelStore';
import EngineRuntimeStore from './EngineRuntimeStore';

export default class EngineStore {
  readonly engineModelStore: EngineModelStore;

  readonly engineRuntimeStore: EngineRuntimeStore;

  readonly engineEventStore: EngineEventStore;

  readonly engineDataStore: EngineDataStore;

  readonly engineActionStore: EngineActionStore;

  readonly engineFormStore: EngineFormStore;

  readonly resources: Resource[];

  readonly page: Page;

  inPagePortal = false;

  inDesigner = false;

  params?: Record<string, unknown>;

  version: string | undefined;

  loadings: Record<string, boolean> = {};

  running?: boolean;

  constructor(
    options: {
      page: Page;
      inPagePortal?: boolean;
      inDesigner?: boolean;
      params?: Record<string, unknown>;
      portal: HTMLElement | null;
      eventEmitter?: EventEmitter;
    },
    readonly loggerStore: LoggerStore,
    readonly messageStore: MessageStore,
    readonly codeInterpreter: CodeInterpreter,
    readonly router: Router,
  ) {
    makeObservable(this, {
      params: observable,
      version: observable,
      loadings: observable.shallow,
      running: observable,
      init: action,
      start: action,
      dispose: action,
      stop: action,
      syncUrlQueryData: action.bound,
      syncSystemData: action,
      updateData: action,
      execAction: action.bound,
      dispatchAction: action.bound,
    });
    const {
      params,
      page,
      inPagePortal = false,
      inDesigner = false,
      eventEmitter = get(window, 'parent.eventEmitter') || new EventEmitter(),
    } = options;

    this.page = page;

    this.inPagePortal = inPagePortal;

    if (page.model?.modelData == null) {
      throw Object({ message: '模型为空' });
    }

    this.params = params;

    this.inDesigner = inDesigner;

    const { modelData } = page.model;

    this.version = modelData.version;

    this.resources = modelData.resources;

    const { datas } = modelData;

    const { elements } = modelData;

    if (elements.length === 0) {
      const { id } = page;

      elements.push({
        id,
        pathname: id,
        type: PageCompType.PAGE,
        name: '页面',
      });
    }

    if (elements[0].type !== PageCompType.PAGE) {
      elements[0].type = PageCompType.PAGE;
    }

    this.engineModelStore = new EngineModelStore(
      page.id,
      datas,
      modelData.events || [],
      modelData.actions,
      elements,
      modelData.modals,
      modelData.customs,
      modelData.customTree,
      modelData.styles,
      modelData.globalStyle || '',
      modelData.resources || [],
      modelData.version,
    );

    this.engineRuntimeStore = new EngineRuntimeStore(
      this.dispatchAction,
      this.execAction,
      this.engineModelStore,
      this.loggerStore,
      eventEmitter,
      codeInterpreter,
    );

    this.engineActionStore = new EngineActionStore(
      this.engineModelStore,
      this.engineRuntimeStore,
      this.loggerStore,
    );

    this.engineDataStore = new EngineDataStore(
      this.engineModelStore,
      this.engineRuntimeStore,
    );

    this.engineEventStore = new EngineEventStore(
      this.engineModelStore,
      this.engineRuntimeStore,
    );

    this.engineFormStore = new EngineFormStore(
      this.engineRuntimeStore,
      page,
      loggerStore,
    );
  }

  init() {
    this.syncSystemData();

    const { manual, autoLoad } = groupBy(
      values(this.engineModelStore.datas),
      (data) => {
        if (data.type === DataType.MANUAL) {
          return 'manual';
        }

        if (data.autoLoad) {
          return 'autoLoad';
        }

        return 'other';
      },
    );

    const fetchDataMapper = (data: Data) =>
      this.fetchData({ dataCode: data.code });

    return defer(() => {
      if (size(manual) > 0) {
        return zip(...lodashMap(manual, fetchDataMapper));
      }

      return of(null);
    }).pipe(
      mergeMap(() => {
        if (size(autoLoad) > 0) {
          return zip(...lodashMap(autoLoad, fetchDataMapper));
        }

        return of(null);
      }),
    );
  }

  start() {
    const { events } = this.engineModelStore;

    this.syncScriptResources();

    this.engineEventStore.registerAllEvents(events);

    this.running = true;
  }

  dispose() {
    this.engineRuntimeStore.dispose();
    this.engineEventStore.dispose();
    this.engineActionStore.dispose();
    this.removeCssResources();
  }

  stop() {
    this.dispose();
    this.running = false;
  }

  syncUrlQueryData() {
    const { state } = this.engineRuntimeStore;

    set(
      state,
      '_system.query',
      qs.parse(get(window, 'location.search'), { ignoreQueryPrefix: true }) ??
        {},
    );
  }

  loadCssResources(doc: Document = window.document) {
    const { resources } = this;

    forEach(
      filter(resources, (r) => r.type === ResourceType.CSS),
      (resource) => {
        const link = doc.createElement('link');
        link.setAttribute('rel', 'stylesheet');
        link.setAttribute('href', resource.url);

        doc.body.appendChild(link);
      },
    );
  }

  removeCssResources() {
    const { resources } = this;

    forEach(
      filter(resources, (r) => r.type === ResourceType.CSS),
      (resource) => {
        const link = document.querySelector(`[href="${resource.url}"]`);

        if (link) {
          link.remove();
        }
      },
    );
  }

  syncScriptResources() {
    const { resources } = this;

    forEach(
      filter(resources, (r) => r.type === ResourceType.SCRIPT),
      (resource) => {
        const link = document.createElement('script');

        link.setAttribute('type', 'text/javascript');
        link.setAttribute('src', resource.url);

        document.body.appendChild(link);
      },
    );
  }

  syncSystemData() {
    const { datas, actions, modals } = this.engineModelStore;

    const systemData = {
      params: this.params,
      ...(this.router.location || {}),
      query: this.router.searchParams,
      modalOpen: transform(
        modals,
        (result, value) => {
          // eslint-disable-next-line no-param-reassign
          result[value.id] = false;
        },
        {} as { [key: string]: boolean },
      ),
      actionPending: assign(
        transform(
          actions,
          (result, value) => {
            if (value.code) {
              // eslint-disable-next-line no-param-reassign
              result[value.code] = false;
            }
          },
          {} as { [key: string]: boolean },
        ),
        transform(
          datas,
          (result, value) => {
            // eslint-disable-next-line no-param-reassign
            result[`${value.code}Fetching`] = false;
          },
          {} as { [key: string]: boolean },
        ),
      ),
    };

    set(datas, '_system', {
      id: '_system',
      name: '系统',
      code: '_system',
      type: DataType.MANUAL,
      data: systemData,
    } as Data);

    set(this.engineRuntimeStore.state, '_system', systemData);
  }

  fetchData(payload: { dataCode: string; params?: Record<string, unknown> }) {
    return this.engineDataStore.fetchData(payload);
  }

  updateData(code: string, data: unknown) {
    set(this.engineRuntimeStore.state, code, data);
  }

  execAction(
    actionPayload: ActionPayload | ActionPayload[],
    act: Action,
  ): Observable<unknown> {
    const { state } = this.engineRuntimeStore;

    const payload = last(concat(actionPayload)) as ActionPayload;

    const expressionContext = assign({}, state, {
      _state: state,
      _params: Array.isArray(actionPayload)
        ? concat(actionPayload).map((p) => p.params)
        : payload.params,
      _context: payload.context,
      _index: payload.contextIndex,
      _indexes: payload.contextIndexes,
      _pathname: payload.contextPathname,
      _pathnames: payload.contextPathnames,
    });

    const params = parseJexlExpressionDeep(act.params, expressionContext);

    const actionType = act.type;

    let ob: Observable<unknown> = of(null);

    switch (actionType) {
      case ActionType.OTHER_ACTION_QUEUE: {
        ob = of(params);
        break;
      }

      case ActionType.FETCH_DATA: {
        ob = this.engineDataStore.fetchData({
          dataCode: (act as ActionFetchData).dataCode,
          params,
        });
        break;
      }

      case ActionType.SET_DATA: {
        runInAction(() => {
          if (typeof params === 'object') {
            Object.entries(params).forEach(([pathname, value]) => {
              const slitted = pathname.split(/\[\d*]$/);
              const isArray = size(slitted) > 1;

              if (value === undefined) {
                if (isArray) {
                  pull(get(state, slitted[0]) as [], get(state, pathname));
                } else {
                  unset(state, pathname);
                }
              } else {
                set(state, pathname, value);
              }
            });
          }
        });

        ob = of(params);

        break;
      }

      // 控制对话框 Action
      case ActionType.CONTROL_MODAL: {
        const { modalId, open } = act as ActionControlModal;
        set(state, `_system.modalOpen.${modalId}`, !!open);

        ob = of(open).pipe(delay(50));

        break;
      }

      // 启动 Action
      case ActionType.START: {
        const act1 = act as ActionStart;

        ob = from(
          new Promise((resolve) => {
            if (act1.confirm) {
              this.messageStore.send({
                type: MessageType.CONFIRM,
                title: parseJexlExpression(act1.confirm, expressionContext),
                resolve: () => {
                  resolve(payload);
                },
                reject: () => {
                  resolve(null);
                },
              } as MessageConfirm);
            } else {
              resolve(payload);
            }
          }),
        ).pipe(
          mergeMap((n) => {
            if (n == null) {
              return from(EMPTY);
            }

            return of(n);
          }),
        );
        break;
      }

      case ActionType.GUARD: {
        const act1 = act as ActionGuard;

        ob = from(
          new Promise((resolve) => {
            if (act1.confirm) {
              this.messageStore.send({
                type: MessageType.CONFIRM,
                title: parseJexlExpression(act1.confirm, expressionContext),
                resolve: () => {
                  resolve(payload);
                },
                reject: () => {
                  resolve(null);
                },
              } as MessageConfirm);
            } else if (act1.code) {
              let result;

              try {
                result = this.engineRuntimeStore.codeInterpreter(act1.code, [
                  ['state', cloneDeep(toJS(state))],
                  ['_params', cloneDeep(payload.params)],
                  ['_context', cloneDeep(toJS(payload.context))],
                  ['_index', payload.contextIndex],
                  ['_pathname', payload.contextPathname],
                  ['_pathnames', payload.contextPathnames],
                  [
                    'utils',
                    {
                      ...lodashUtils,
                      dispatchAction: this.dispatchAction,
                      walkTree,
                      findTreeNode,
                      findTreeNodeBy,
                      filterTree,
                      moment: dayjs,
                    },
                  ],
                ]);
              } catch (e) {
                // eslint-disable-next-line
                console.log('eval error', JSON.stringify(e));
                result = false;
              }

              resolve(result);
            } else {
              resolve(act1.params ? !!params : true);
            }
          }),
        );

        break;
      }

      case ActionType.ACTION_SHEET: {
        ob = from(
          new Promise((resolve) => {
            this.messageStore.send({
              type: MessageType.ACTION_SHEET,
              params,
              resolve: (tapIndex) => {
                resolve(tapIndex);
              },
              reject: () => {
                resolve(null);
              },
            } as MessageActionSheet);
          }),
        );
        break;
      }

      case ActionType.EXEC_CODE: {
        if (act.params) {
          // 自定义参数优先
          ob = of(params);
        } else {
          ob = from(
            new Promise((resolve, reject) => {
              this.messageStore.send({
                type: MessageType.EXEC_CODE,
                code: (act as ActionExecCode).code,
                resolve,
                reject,
                params: [
                  cloneDeep(toJS(state)),
                  cloneDeep(payload.params),
                  cloneDeep(toJS(payload.context)),
                  payload.contextIndex,
                  payload.contextPathname,
                  payload.contextPathnames,
                  {
                    ...lodashUtils,
                    dispatchAction: this.dispatchAction,
                    walkTree,
                    findTreeNode,
                    findTreeNodeBy,
                    filterTree,
                    moment: dayjs,
                    eventEmitter: this.engineRuntimeStore.eventEmitter,
                    createAxios: createService,
                    set: (p: string, v: any) => {
                      runInAction(() => {
                        set(state, p, v);
                      });
                    },
                    unset: (p: string) => {
                      runInAction(() => {
                        unset(state, p);
                      });
                    },
                  },
                ],
              } as MessageExecCode);
            }),
          );
        }

        break;
      }

      case ActionType.SEND_REQUEST: {
        const act1 = act as ActionSendRequest;

        const service = createService(
          act1.format === 'json' ? jsonAxiosOptions : formAxiosOptions,
          act1.ignoreException,
        );

        const url = parseJexlExpression(act1.url, expressionContext);

        const stringifyOptions = parseJexlExpressionDeep(
          parseJSON(act1.stringifyOptions),
          expressionContext,
        );

        let promise: Promise<unknown> | null = null;

        switch (act1.method) {
          case 'POST': {
            promise = service.post(url, params);
            break;
          }
          case 'PUT': {
            promise = service.put(url, params);
            break;
          }
          case 'DELETE': {
            promise = service.delete(url, { params });
            break;
          }
          case 'GET':
          default: {
            promise = service.get(url, {
              params,
              paramsSerializer: stringifyOptions
                ? (p) => qs.stringify(p, stringifyOptions)
                : undefined,
            });
          }
        }

        if (promise) {
          if (act1.ignoreException) {
            const p = promise;

            promise = new Promise((resolve) => {
              p.then((resp) => resolve(resp));
              p.catch((e) => {
                resolve({
                  data: e,
                });
              });
            });
          }

          ob = from(promise);
        }

        ob = ob.pipe(map((n: any) => n.data));

        break;
      }

      case ActionType.VALIDATE_FORM: {
        const { pathname, scrollIntoView } = act as ActionValidateForm;

        ob = this.engineFormStore.triggerValidation({
          pathname: pathname
            ? parseJexlExpression(pathname, expressionContext)
            : pathname,
          scrollIntoView,
        });

        break;
      }

      case ActionType.CLEAR_FORM_ERRORS: {
        const { pathname } = act as ActionClearFormErrors;

        ob = ob.pipe(
          tap(() => {
            this.engineFormStore.clearErrors(
              parseJexlExpression(pathname, expressionContext),
            );
          }),
        );

        break;
      }

      case ActionType.GO: {
        const act1 = act as ActionGo;

        let url = parseJexlExpression(act1.url, expressionContext);

        url = `${url}${qs.stringify(params, {
          skipNulls: true,
          addQueryPrefix: true,
        })}`;

        let mode: RouterNavigateMode | undefined;

        if (act1.open) {
          mode = 'open';
        } else if (act1.usePushState) {
          mode = 'pushState';
        } else if (act1.useReplace) {
          mode = 'replace';
        }

        this.router.navigateTo(url, mode);

        ob = from(EMPTY);

        break;
      }

      case ActionType.CONTROL_EVENTS: {
        const { eventId, start } = act as ActionControlEvent;

        const event = this.engineEventStore.getEventById(eventId);

        if (event) {
          if (start) {
            this.engineEventStore.registerEvent(event);
          } else {
            this.engineEventStore.disposeEvent(event);
          }
        }

        break;
      }

      case ActionType.NOTIFICATION: {
        let { message: msg } = act as ActionNotification;

        const {
          loggerLevel = LoggerLevel.SUCCESS,
          loggerType = LoggerType.NOTIFICATION,
        } = act as ActionNotification;

        msg = parseJexlExpression(msg || '', expressionContext);

        if (msg) {
          if (loggerLevel === LoggerLevel.SUCCESS) {
            this.loggerStore.success(msg, loggerType);
          } else if (loggerLevel === LoggerLevel.INFO) {
            this.loggerStore.info(msg, loggerType);
          } else if (loggerLevel === LoggerLevel.ERROR) {
            this.loggerStore.error(msg, loggerType);
          }
        }

        ob = ob.pipe(delay(50));

        break;
      }

      case ActionType.DISPATCH_PAGE_EVENT: {
        const { pageEventName } = act as ActionDispatchPageEvent;

        this.engineRuntimeStore.eventEmitter.emit(pageEventName, params);

        break;
      }

      case ActionType.CANCEL_ACTION_QUEUE: {
        const { actionId } = act as ActionCancelActionQueue;

        this.engineRuntimeStore.unsubscribeAction(actionId);

        break;
      }

      case ActionType.DELAY: {
        const { duration } = act as ActionDelay;

        ob = ob.pipe(delay(duration || 0));

        break;
      }

      default: {
        break;
      }
    }

    return ob;
  }

  dispatchAction(
    ...args: Parameters<ValuesType<Pick<EngineActionStore, 'dispatchAction'>>>
  ) {
    return this.engineActionStore.dispatchAction(...args);
  }
}
