import dayjs from 'dayjs';
import cloneDeep from 'lodash-es/cloneDeep';
import merge from 'lodash-es/merge';
import set from 'lodash-es/set';

import { action, makeObservable, runInAction } from 'mobx';
import qs from 'qs';
import { defer, from, of } from 'rxjs';
import { finalize, map, tap } from 'rxjs/operators';
import lodashUtils from '../common/lodash-utils';
import {
  createService,
  formAxiosOptions,
  jsonAxiosOptions,
} from '../config/service';
import { DataType } from '../types/entities';
import { parseJSON } from '../utils/data';
import { parseJexlExpression, parseJexlExpressionDeep } from '../utils/jexl';
import {
  filterTree,
  findTreeNode,
  findTreeNodeBy,
  mapTreeNode,
  walkTree,
} from '../utils/tree';
import EngineModelStore from './EngineModelStore';
import EngineRuntimeStore from './EngineRuntimeStore';

export default class EngineDataStore {
  constructor(
    readonly pageEngineModelStore: EngineModelStore,
    readonly pageEngineRuntimeStore: EngineRuntimeStore,
  ) {
    makeObservable(this, {
      fetchData: action,
    });
  }

  fetchData(payload: { dataCode: string; params?: unknown }) {
    const { dataCode } = payload;

    const { datas } = this.pageEngineModelStore;
    const { state } = this.pageEngineRuntimeStore;

    const pageData = datas[dataCode];

    if (pageData == null) {
      return of(null);
    }

    const actionPendingKey = `_system.actionPending.${pageData.code}Fetching`;

    set(state, actionPendingKey, true);

    const clearPending = () => {
      runInAction(() => {
        set(state, actionPendingKey, false);
      });
    };

    const params = merge(
      {},
      parseJexlExpressionDeep(pageData.params, state),
      payload.params,
    );

    return defer(() => {
      switch (pageData.type) {
        case DataType.MANUAL: {
          return of(parseJexlExpressionDeep(pageData.data, state));
        }

        case DataType.URL: {
          const service = createService(
            pageData.format === 'form' ? formAxiosOptions : jsonAxiosOptions,
            pageData.ignoreQueryException,
          );

          const url = parseJexlExpression(pageData.url || '', state);

          const method = pageData.method || 'GET';

          const stringifyOptions = parseJexlExpressionDeep(
            parseJSON(pageData.stringifyOptions),
            state,
          );

          let promise =
            method === 'GET'
              ? service.get(url, {
                  params,
                  paramsSerializer: stringifyOptions
                    ? (p) => qs.stringify(p, stringifyOptions)
                    : undefined,
                })
              : service.post(url, params);

          if (pageData.ignoreQueryException) {
            const p = promise;

            promise = new Promise((resolve) => {
              p.then((resp) => resolve(resp));
              p.catch((e) => {
                // @ts-ignore
                resolve({ data: e });
              });
            });
          }

          const ob = from(promise);

          return ob.pipe(map((n) => n.data));
        }

        default:
          break;
      }

      return of(null);
    }).pipe(
      map((n) => {
        if (pageData.formatter) {
          try {
            return this.pageEngineRuntimeStore.codeInterpreter(
              pageData.formatter,
              [
                ['result', cloneDeep(n)],
                ['state', cloneDeep(state)],
                ['params', cloneDeep(params)],
                [
                  'utils',
                  {
                    ...lodashUtils,
                    walkTree,
                    findTreeNode,
                    findTreeNodeBy,
                    mapTreeNode,
                    filterTree,
                    moment: dayjs,
                  },
                ],
              ],
            );
          } catch (e) {
            return n;
          }
        }

        return n;
      }),
      tap((n) => {
        runInAction(() => {
          set(state, pageData.code, n);
          clearPending();
        });
      }),
      finalize(clearPending),
    );
  }
}
