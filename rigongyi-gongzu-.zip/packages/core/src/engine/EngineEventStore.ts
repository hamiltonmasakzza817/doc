import assign from 'lodash-es/assign';
import get from 'lodash-es/get';
import isEqual from 'lodash-es/isEqual';
import isNumber from 'lodash-es/isNumber';
import { action, autorun, makeObservable } from 'mobx';
import { fromEvent, interval, Observable, of, Subscription } from 'rxjs';
import { take, tap } from 'rxjs/operators';
import { Event, EventType } from '../types/entities';
import { parseJexlExpression, parseJexlExpressionDeep } from '../utils/jexl';
import EngineModelStore from './EngineModelStore';
import EngineRuntimeStore from './EngineRuntimeStore';

export default class EngineEventStore {
  dataChangeValues: Map<string, unknown> = new Map<string, unknown>();

  private events: Event[] = [];

  private eventSubscriptions = new Map<string, Subscription>();

  constructor(
    readonly pageEngineModelStore: EngineModelStore,
    readonly pageEngineRuntimeStore: EngineRuntimeStore,
  ) {
    makeObservable(this, {
      registerAllEvents: action,
      registerEvent: action,
      disposeEvent: action,
      dispose: action,
    });
  }

  getEventById(id: string) {
    return this.events.find((e) => e.id === id);
  }

  registerAllEvents(events: Event[]) {
    this.events = events;

    const { state } = this.pageEngineRuntimeStore;

    const filteredEvents = events.filter((event) => {
      if (event.guard) {
        return !!parseJexlExpression(event.guard, state);
      }

      return true;
    });

    filteredEvents.forEach((event) => {
      this.registerEvent(event);
    });
  }

  registerEvent(event: Event) {
    const { dispatchAction, state } = this.pageEngineRuntimeStore;

    const { actionId } = event;

    const subscription = this.eventSubscriptions.get(event.id);

    if (subscription) {
      subscription.unsubscribe();
    }

    let observable: Observable<unknown> = of();

    if (actionId) {
      const act = this.pageEngineModelStore.actions[actionId];

      if (act == null) {
        return;
      }

      switch (event.type) {
        // 定时器流
        case EventType.INTERVAL: {
          const eventInterval = +parseJexlExpression(event.interval, state);

          observable = interval(
            isNumber(eventInterval) ? eventInterval : 0,
          ).pipe(
            tap(() => {
              this.pageEngineRuntimeStore.subscribeAction({
                $action: dispatchAction(actionId, {
                  context: act.context
                    ? parseJexlExpressionDeep(act.context, state)
                    : null,
                }),
                actionQueueId: actionId,
              });
            }),
          );

          break;
        }

        // mobx 数据变更流
        case EventType.DATA_CHANGE: {
          const { pathname } = event;

          if (pathname) {
            observable = new Observable((observer) => {
              const unsubscribe = autorun(() => {
                const data = get(state, pathname);
                // 取出该路径上次变更的数据，对其进行 shallow equal 对比
                const origin = this.dataChangeValues.get(event.id);

                if (
                  this.dataChangeValues.has(event.id) &&
                  !isEqual(data, origin)
                ) {
                  observer.next(data);
                }

                this.dataChangeValues.set(event.id, data);
              });

              return () => {
                unsubscribe();
              };
            }).pipe(
              tap((data) => {
                this.pageEngineRuntimeStore.subscribeAction({
                  $action: dispatchAction(actionId, {
                    context: act.context
                      ? parseJexlExpressionDeep(act.context, {
                          ...state,
                          _params: data,
                        })
                      : null,
                  }),
                  actionQueueId: actionId,
                });
              }),
            );
          }

          break;
        }

        // DOM 事件流
        case EventType.DOM_EVENT: {
          const { eventName, querySelector } = event;

          if (eventName && querySelector) {
            const dom =
              querySelector === 'window'
                ? window
                : document.querySelector(querySelector);

            if (dom) {
              observable = fromEvent(dom, eventName).pipe(
                tap(() => {
                  const params = {
                    height: window.innerHeight,
                    width: window.innerWidth,
                  };

                  this.pageEngineRuntimeStore.subscribeAction({
                    $action: dispatchAction(actionId, {
                      params,
                      context: act.context
                        ? parseJexlExpressionDeep(act.context, {
                            ...state,
                            _params: params,
                          })
                        : null,
                    }),
                    actionQueueId: actionId,
                  });
                }),
              );
            }
          }

          break;
        }

        case EventType.PAGE_EVENT: {
          const { pageEventName } = event;

          if (pageEventName) {
            observable = fromEvent(
              this.pageEngineRuntimeStore.eventEmitter,
              pageEventName,
            ).pipe(
              tap((params: unknown) => {
                this.pageEngineRuntimeStore.subscribeAction({
                  $action: dispatchAction(actionId, {
                    params: params as any,
                    context: act.context
                      ? parseJexlExpressionDeep(
                          act.context,
                          assign({}, state, {
                            _params: params,
                          }),
                        )
                      : null,
                  }),
                  actionQueueId: actionId,
                });
              }),
            );
          }

          break;
        }

        case EventType.PAGE_LOAD: {
          observable = of(0).pipe(
            tap(() => {
              this.pageEngineRuntimeStore.subscribeAction({
                $action: dispatchAction(actionId, {
                  context: act.context
                    ? parseJexlExpressionDeep(act.context, state)
                    : null,
                }),
                actionQueueId: actionId,
              });
            }),
          );

          break;
        }

        default: {
          break;
        }
      }
    }

    if (event.take) {
      observable = observable.pipe(take(event.take));
    }

    this.eventSubscriptions.set(event.id, observable.subscribe());
  }

  disposeEvent(event: Event) {
    const subscription = this.eventSubscriptions.get(event.id);
    if (subscription) {
      subscription.unsubscribe();
      this.eventSubscriptions.delete(event.id);
      this.dataChangeValues.delete(event.id);
    }
  }

  dispose() {
    this.eventSubscriptions.forEach((subscription) => {
      subscription.unsubscribe();
    });
    this.dataChangeValues.clear();
    this.eventSubscriptions.clear();
  }
}
