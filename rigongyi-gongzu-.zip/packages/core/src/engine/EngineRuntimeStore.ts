import EventEmitter from 'eventemitter3';
import { action, makeObservable, observable } from 'mobx';
import { Observable, Subscription } from 'rxjs';
import LoggerStore from '../stores/LoggerStore';
import {
  Action,
  ActionPayload,
  ActionQueue,
  ActionQueueConflictResolver,
  LoggerType,
} from '../types/entities';
import { CodeInterpreter } from '../types/engine';
import EngineModelStore from './EngineModelStore';

export type DispatchAction = (
  actionId: string,
  payload: ActionPayload,
) => Observable<unknown>;

export type ExecAction = (
  payload: ActionPayload | ActionPayload[],
  act: Action,
) => Observable<unknown>;

export type SubscribeAction = (
  $action: Observable<unknown>,
  actionQueueId: string,
) => void;

export type UnsubscribeAction = (actionQueueId: string) => void;

export default class EngineRuntimeStore {
  state: Record<string, unknown> = {};

  actionQueueSubscriptions = new Map<string, Subscription>();

  constructor(
    readonly dispatchAction: DispatchAction,
    readonly execAction: ExecAction,
    readonly pageEngineModelStore: EngineModelStore,
    readonly loggerStore: LoggerStore,
    readonly eventEmitter: EventEmitter,
    readonly codeInterpreter: CodeInterpreter,
  ) {
    makeObservable(this, {
      state: observable,
      subscribeAction: action.bound,
      unsubscribeAction: action.bound,
    });
  }

  subscribeAction(payload: {
    $action: Observable<unknown>;
    actionQueueId: string;
    success?: (v: unknown) => void;
    fail?: (v: unknown) => void;
  }) {
    const { $action, actionQueueId, success, fail } = payload;

    const { actions } = this.pageEngineModelStore;

    const actionQueue = actions[actionQueueId];

    if (actionQueue) {
      const subscription = this.actionQueueSubscriptions.get(actionQueueId);

      if (subscription && !subscription.closed) {
        const { conflictResolver } = actionQueue;

        this.loggerStore.info(
          `当前有冲突 ${conflictResolver}`,
          LoggerType.CONSOLE,
        );

        if (conflictResolver === ActionQueueConflictResolver.EXISTING) {
          this.loggerStore.info('使用当前的, 返回', LoggerType.CONSOLE);
          return;
        }

        if (conflictResolver === ActionQueueConflictResolver.COMING) {
          this.loggerStore.info('使用新来的的, 取消以前的', LoggerType.CONSOLE);
          this.unsubscribeAction(actionQueueId);
        }
      }
      this.actionQueueSubscriptions.set(
        actionQueueId,
        $action.subscribe(success, fail),
      );
    }
  }

  unsubscribeAction(actionQueueId: string) {
    const { actions } = this.pageEngineModelStore;

    const actionQueue: ActionQueue | undefined = actions[actionQueueId];

    if (actionQueue) {
      const subscription = this.actionQueueSubscriptions.get(actionQueueId);

      if (subscription) {
        subscription.unsubscribe();
        this.actionQueueSubscriptions.delete(actionQueueId);
      }
    }
  }

  dispose() {
    this.actionQueueSubscriptions.forEach((subscription) =>
      subscription.unsubscribe(),
    );
    this.actionQueueSubscriptions.clear();
  }
}
