import { makeObservable, observable } from 'mobx';
import { CompConfig } from '../types/comps-common';
import {
  ActionQueue,
  Data,
  Event,
  Resource,
  Style,
  TreeNode,
} from '../types/entities';

export default class EngineModelStore {
  modals: CompConfig[] = [];

  customTree: TreeNode[] = [];

  globalStyle: string;

  constructor(
    readonly pageId: string,
    readonly datas: Record<string, Data>,
    readonly events: Event[],
    readonly actions: Record<string, ActionQueue>,
    readonly elements: CompConfig[],
    modals: CompConfig[],
    readonly customs: Record<string, CompConfig>,
    customTree: TreeNode[],
    readonly styles: Record<string, Style>,
    globalStyle: string,
    readonly resources: Resource[],
    readonly version: string,
  ) {
    this.modals = modals;
    this.customTree = customTree;
    this.globalStyle = globalStyle;

    makeObservable(this, {
      datas: observable,
      events: observable,
      actions: observable,
      elements: observable,
      modals: observable,
      styles: observable,
      resources: observable,
      customs: observable,
      customTree: observable,
      globalStyle: observable,
    });
  }
}
