import defer from 'lodash-es/defer';
import entries from 'lodash-es/entries';
import find from 'lodash-es/find';
import uniqueId from 'lodash-es/uniqueId';
import Upload from 'rc-upload';
import { RcFile } from 'rc-upload/lib/interface';
import React from 'react';
import { createService } from '../config/service';

export interface FileEntity {
  name: string;
  url: string;
}

export interface FileUploaderProps {
  onChange?: (files: FileEntity[]) => void;
  disabled?: boolean;
  children?: JSX.Element;
  accept?: string;
  multiple?: boolean;
  url?: string;
  getParams?: (files: RcFile[]) => Record<string, string | Blob>;
  onStart?: () => void;
  onFinally?: () => void;
  onError?: (msg: string) => void;
  maxSize?: number;
  minSize?: number;
}

export default function FileUploader(props: FileUploaderProps) {
  const {
    onChange,
    children,
    disabled,
    accept,
    url = '',
    multiple = false,
    getParams,
    onError = () => {},
    onStart = () => {},
    onFinally = () => {},
    maxSize,
    minSize,
  } = props;

  const [key, setKey] = React.useState(uniqueId());
  const [loading, setLoading] = React.useState(false);

  const uploadDefer = React.useRef<number>();

  return (
    <Upload
      style={{
        display: 'inline-block',
      }}
      customRequest={() => null}
      onBatchStart={(fileList) => {
        const files = fileList.map((f) => f.file);

        const overSizeFile = maxSize
          ? find(files, (f: File) => f.size > maxSize * 1024 * 1024)
          : null;

        if (overSizeFile) {
          onError(`文件"${overSizeFile.name}"，超出了最大尺寸${maxSize}MB`);
          setKey(uniqueId());
          return;
        }

        const belowSizeFile = minSize
          ? find(files, (f) => f.size < minSize * 1024 * 1024)
          : null;

        if (belowSizeFile) {
          onError(`文件"${belowSizeFile.name}"，不足最小尺寸${minSize}MB`);
          setKey(uniqueId());
          return;
        }

        if (uploadDefer.current) {
          clearTimeout(uploadDefer.current);
        }

        uploadDefer.current = defer((fs: RcFile[]) => {
          const formData = new FormData();

          if (getParams) {
            const params = getParams(fs);

            entries(params).forEach(([paramKey, paramValue]) => {
              if (Array.isArray(paramValue)) {
                paramValue.forEach((v) => {
                  formData.append(paramKey, v);
                });
              } else {
                formData.append(paramKey, paramValue);
              }
            });
          } else {
            fs.forEach((file) => {
              formData.append('files[]', file);
            });
          }

          onStart();

          setLoading(true);

          const service = createService({
            headers: {
              'Content-Type': 'multipart/form-data',
            },
          });

          service
            .post<FileEntity[]>(url, formData)
            .then((res) => {
              if (onChange) {
                onChange(res.data);
              }
            })
            .finally(() => {
              setKey(uniqueId());
              setLoading(false);
              onFinally();
            });
        }, files);
      }}
      multiple={multiple}
      key={key}
      accept={accept}
      disabled={loading || disabled}
    >
      {children}
    </Upload>
  );
}
