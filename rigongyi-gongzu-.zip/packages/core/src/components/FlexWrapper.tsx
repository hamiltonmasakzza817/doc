import React, { CSSProperties } from 'react';

export default function FlexWrapper(
  props: {
    bottom?: number;
    absolute?: boolean;
    isFixedHeight?: boolean;
    onHeightChange?: (height: number) => void;
    innerRef?: React.MutableRefObject<any>;
    container?: string;
    className?: string;
    disabled?: boolean;
    portal?: HTMLElement;
  } & React.HTMLAttributes<HTMLDivElement>,
) {
  const {
    children,
    bottom = 0,
    absolute = false,
    isFixedHeight = true,
    onHeightChange,
    innerRef,
    container,
    disabled = false,
    className,
    portal,

    ...divProps
  } = props;

  const [absoluteTop, setAbsoluteTop] = React.useState<number | null>(null);

  const wrapper = React.useRef<HTMLDivElement | null>(null);

  const resize = React.useCallback(() => {
    if (disabled) {
      return;
    }

    if (wrapper.current != null) {
      if (absolute) {
        if (absoluteTop != null) {
          return;
        }

        setAbsoluteTop(wrapper.current.offsetTop);

        return;
      }

      const wrapperTop = wrapper.current.getBoundingClientRect().top;
      const windowHeight = window.innerHeight;

      let calcBottom = bottom;

      if (container) {
        const containerElement = (portal || document).querySelector(container);

        if (containerElement) {
          const containerBottom =
            containerElement.getBoundingClientRect().bottom;
          calcBottom += windowHeight - containerBottom;
        }
      }

      const height = windowHeight - wrapperTop - calcBottom;

      if (wrapper.current) {
        if (isFixedHeight) {
          wrapper.current.style.height = `${height}px`;
        } else {
          wrapper.current.style.minHeight = `${height}px`;
        }
      }

      if (onHeightChange) {
        onHeightChange(height);
      }
    }
  }, [absolute, bottom]);

  React.useEffect(() => {
    window.addEventListener('resize', resize);
    return () => window.removeEventListener('resize', resize);
  }, [absolute, bottom]);

  React.useEffect(() => {
    if (!disabled) {
      resize();
    }
  }, [disabled]);

  const styl = React.useMemo<CSSProperties>(() => {
    const s: CSSProperties = {};

    if (absolute) {
      s.position = 'relative';

      if (absoluteTop) {
        s.position = 'absolute';
        s.left = 0;
        s.right = 0;
      }
    }

    return s;
  }, [absolute, absoluteTop]);

  if (disabled) {
    return (
      <div className={className} {...divProps}>
        {children}
      </div>
    );
  }

  return (
    <div
      {...divProps}
      ref={(el) => {
        if (el) {
          wrapper.current = el;

          if (innerRef) {
            innerRef.current = el;
          }
        }
      }}
      style={{
        ...styl,
        top: absoluteTop ?? undefined,
        bottom: absolute ? bottom : undefined,
      }}
      className={className}
      data-id={props.id}
    >
      {children}
    </div>
  );
}
