// @ts-ignore
import React from 'react';

export default function IdsRoller() {
  return (
    <div className="lds-roller-container">
      <div className="lds-roller">
        <div/>
        <div/>
        <div/>
        <div/>
        <div/>
        <div/>
        <div/>
        <div/>
      </div>
    </div>
  );
}
