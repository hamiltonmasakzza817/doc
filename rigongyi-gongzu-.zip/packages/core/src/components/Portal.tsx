import entries from 'lodash-es/entries';
import React, { CSSProperties } from 'react';
import ReactDOM from 'react-dom';

export default function Portal(props: {
  getContainer?: () => HTMLElement;
  children: JSX.Element | null;
  className?: string;
  style?: CSSProperties;
}) {
  const {
    getContainer = () => document.body,
    children,
    className,
    style,
  } = props;

  const wrapper = React.useMemo(() => {
    const w = document.createElement('div');
    if (className) {
      w.setAttribute('class', className);
    }
    if (style) {
      entries(style).forEach(([key, value]) => {
        // @ts-ignore
        w.style[key] = value;
      });
    }
    return w;
  }, []);

  React.useEffect(() => {
    getContainer().appendChild(wrapper);

    return () => {
      if (wrapper && wrapper.parentNode) {
        wrapper.parentNode.removeChild(wrapper);
      }
    };
  }, [wrapper]);

  return ReactDOM.createPortal(children, wrapper);
}
