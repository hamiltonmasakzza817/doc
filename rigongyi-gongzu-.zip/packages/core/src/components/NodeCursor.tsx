import domAlign from 'dom-align';
import React from 'react';
import NodeOutline from './NodeOutline';
import Portal from './Portal';

export default function NodeCursor(props: {
  getContainer?: () => HTMLElement;
  target?: HTMLElement | null;
  color?: string;
  size?: number;
  contains?: boolean;
  position?: 'front' | 'rear';
  display: 'block' | 'inline';
  className?: string;
}) {
  const {
    getContainer = () => document.body,
    color = 'red',
    className,
    contains = false,
    position = 'front',
    display = 'block',
    size = 1,
    target,
  } = props;

  const top = React.useRef<HTMLDivElement>(null);
  const bottom = React.useRef<HTMLDivElement>(null);
  const left = React.useRef<HTMLDivElement>(null);
  const right = React.useRef<HTMLDivElement>(null);

  const targetRect = target ? target.getBoundingClientRect() : null;

  React.useEffect(() => {
    if (target && !contains) {
      if (top.current) {
        domAlign(top.current, target, {
          points: ['tl', 'tl'],
        });
      }

      if (bottom.current) {
        domAlign(bottom.current, target, {
          points: ['bl', 'bl'],
        });
      }

      if (left.current) {
        domAlign(left.current, target, {
          points: ['tl', 'tl'],
        });
      }

      if (right.current) {
        domAlign(right.current, target, {
          points: ['tr', 'tr'],
        });
      }
    }
  }, [target, contains]);

  const key = `${display}-${position}`;

  return (
    <Portal getContainer={getContainer} className={className}>
      <>
        {contains && (
          <NodeOutline
            target={target}
            getContainer={getContainer}
            size={size}
            color={color}
          />
        )}

        <div
          ref={top}
          className="node-cursor absolute"
          style={{
            background: color,
            height: size,
            width: key === 'block-front' && !contains ? targetRect?.width : 0,
          }}
        />

        <div
          ref={bottom}
          className="node-cursor absolute"
          style={{
            background: color,
            height: size,
            width: key === 'block-rear' && !contains ? targetRect?.width : 0,
          }}
        />

        <div
          ref={left}
          className="node-cursor absolute"
          style={{
            background: color,
            width: size,
            height:
              key === 'inline-front' && !contains ? targetRect?.height : 0,
          }}
        />

        <div
          ref={right}
          className="node-cursor absolute"
          style={{
            background: color,
            width: size,
            height: key === 'inline-rear' && !contains ? targetRect?.height : 0,
          }}
        />
      </>
    </Portal>
  );
}
