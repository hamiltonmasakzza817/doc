import domAlign from 'dom-align';
import get from 'lodash-es/get';
import React, { CSSProperties } from 'react';
import useWindowSize from 'react-use/lib/useWindowSize';
import Portal from './Portal';

export default function NodeOutline(props: {
  getContainer?: () => HTMLElement;
  target?: HTMLElement | null;
  color?: string;
  size?: number;
  tag?: JSX.Element;
  tagInside?: boolean;
  className?: string;
  style?: CSSProperties;
}) {
  const {
    getContainer = () => document.body,
    color = 'blue',
    size = 1,
    tag,
    className,
    target,
    style,
    tagInside = false,
  } = props;

  const top = React.useRef<HTMLDivElement>(null);
  const bottom = React.useRef<HTMLDivElement>(null);
  const left = React.useRef<HTMLDivElement>(null);
  const right = React.useRef<HTMLDivElement>(null);
  const tagRef = React.useRef<HTMLDivElement>(null);

  React.useEffect(() => {
    if (target && target.ownerDocument.defaultView) {
      try {
        const targetRect = target.getBoundingClientRect();

        if (top.current) {
          top.current.style.top = '0';
          top.current.style.width = `${targetRect.width}px`;

          domAlign(top.current, target, {
            points: ['tl', 'tl'],
          });
        }

        if (bottom.current) {
          bottom.current.style.top = '0';
          bottom.current.style.width = `${targetRect.width}px`;

          domAlign(bottom.current, target, {
            points: ['bl', 'bl'],
          });
        }

        if (left.current) {
          left.current.style.top = '0';
          left.current.style.height = `${targetRect.height}px`;

          domAlign(left.current, target, {
            points: ['tl', 'tl'],
          });
        }

        if (right.current) {
          right.current.style.top = '0';
          right.current.style.height = `${targetRect.height}px`;

          domAlign(right.current, target, {
            points: ['tr', 'tr'],
          });
        }

        if (tagRef.current) {
          domAlign(tagRef.current, target, {
            points: [tagInside ? 'tl' : 'bl', 'tl'],
            overflow: { adjustY: true, adjustX: true, alwaysByViewport: true },
          });
        }
      } catch (e) {
        // eslint-disable-next-line no-console
        console.info(get(e, 'message'));
      }
    }
  }, [target, useWindowSize()]);

  if (target == null) {
    return <></>;
  }

  return (
    <Portal getContainer={getContainer} className={className} style={style}>
      <>
        <div
          ref={top}
          key="top"
          style={{
            height: size,
            background: color,
          }}
          className="node-outline absolute"
        />

        <div
          ref={bottom}
          key="bottom"
          className="node-outline absolute"
          style={{
            height: size,
            background: color,
          }}
        />

        <div
          ref={left}
          className="node-outline absolute"
          style={{
            width: size,
            background: color,
          }}
        />

        <div
          ref={right}
          className="node-outline absolute"
          style={{
            width: size,
            background: color,
          }}
        />

        {tag && (
          <div ref={tagRef} className="node-outline absolute">
            {tag}
          </div>
        )}
      </>
    </Portal>
  );
}
