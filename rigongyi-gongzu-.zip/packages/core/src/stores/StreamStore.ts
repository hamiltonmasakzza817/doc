import { observable } from 'mobx';
import { Observable, of } from 'rxjs';
import { catchError, finalize } from 'rxjs/operators';
import { LoggerType } from '../types/entities';
import LoggerStore from './LoggerStore';

export default class StreamStore {
  pending = observable.map<string, boolean>();

  constructor(readonly loggerStore: LoggerStore) {}

  fromStream<T = unknown>(
    stream$: Observable<T>,
    pendingKey?: string,
  ): Observable<T> {
    if (pendingKey) {
      this.pending.set(pendingKey, true);
    }

    return stream$.pipe(
      catchError((err) => {
        const message = err.msg || err.message;
        this.loggerStore.error(message, LoggerType.NOTIFICATION);
        return of(err);
      }),
      finalize(() => {
        if (pendingKey) {
          this.pending.set(pendingKey, false);
        }
      }),
    );
  }

  getPending(key: string, strict = false) {
    const pending = this.pending.get(key);
    return strict ? pending : pending !== false;
  }
}
