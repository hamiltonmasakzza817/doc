import { AxiosInstance } from 'axios';
import assign from 'lodash-es/assign';
import cloneDeep from 'lodash-es/cloneDeep';
import concat from 'lodash-es/concat';
import difference from 'lodash-es/difference';
import entries from 'lodash-es/entries';
import filter from 'lodash-es/filter';
import findIndex from 'lodash-es/findIndex';
import first from 'lodash-es/first';
import forEach from 'lodash-es/forEach';
import get from 'lodash-es/get';
import includes from 'lodash-es/includes';
import lodashMap from 'lodash-es/map';
import omit from 'lodash-es/omit';
import set from 'lodash-es/set';
import size from 'lodash-es/size';
import split from 'lodash-es/split';
import unset from 'lodash-es/unset';
import {
  action,
  IObservableArray,
  makeObservable,
  observable,
  runInAction,
  toJS,
} from 'mobx';
import { from, of, Subject } from 'rxjs';
import { map, mergeMap, tap } from 'rxjs/operators';
import { ValuesType } from 'utility-types';
import { v4 as uuidv4 } from 'uuid';
import api from '../config/api';
import {
  actionBindingKeys,
  fixedChildPageCompTypes,
  pasteInnerCompTypes,
  rootPageCompTypes,
} from '../config/comps';
import { addingId } from '../config/constants';
import { createService } from '../config/service';
import EngineStore from '../engine/EngineStore';
import { CompsAll } from '../types/comps-all';
import { ActionBinding, CompConfig } from '../types/comps-common';
import {
  DesktopCompModalConfig,
  DesktopCompType,
} from '../types/comps-desktop';
import { MobileCompModalConfig, MobileCompType } from '../types/comps-mobile';
import {
  PageCompCustomConfig,
  PageCompPageConfig,
  PageCompType,
} from '../types/comps-page';
import { TaroCompModalConfig, TaroCompType } from '../types/comps-taro';
import {
  ActionQueue,
  ActionQueueType,
  Data,
  Event,
  PageDevice,
  PagePlatform,
  Resource,
  Schema,
  SchemaDataType,
  Style,
  TreeNode,
} from '../types/entities';
import { createCompConfig } from '../utils/comp-creators';
import { moveTreeNode } from '../utils/comp-normalizers';
import { parseJexlExpressionDeep } from '../utils/jexl';
import { findTreeNode, walkTree } from '../utils/tree';
import LoggerStore from './LoggerStore';
import StreamStore from './StreamStore';

export interface DragItem {
  type: CompsAll;
  id?: string;
}

export interface PageDesignerEnv {
  device: PageDevice;
  isPreview: boolean;
  scale: number;
}

export enum ToolModule {
  COMPONENTS,
  MODALS,
  CUSTOM,
  DATAS,
  NAVIGATOR,
  ACTIONS,
  STYLES,
  EVENTS,
  PAGES,
  RESOURCES,

  SETTINGS,
}

type RootComp =
  | PageCompPageConfig
  | DesktopCompModalConfig
  | PageCompCustomConfig
  | MobileCompModalConfig;

type DroppingPosition = 'front' | 'rear';

interface Hovering {
  config: CompConfig;
  position?: DroppingPosition;
  contains?: boolean;
}

class DesignerStore {
  service: AxiosInstance;

  leftDock?: ToolModule = ToolModule.COMPONENTS;

  rightDock?: ToolModule = ToolModule.SETTINGS;

  dirty = false;

  configUpdating$ = new Subject();

  rollbacks: Array<() => void> = [];

  env: PageDesignerEnv = {
    device: PageDevice.CURRENT,
    isPreview: false,
    scale: 1,
  };

  expendedKeys: Record<string, string[]> = {};

  hovering?: Hovering | null;

  dragging?: DragItem;

  dropping?: Hovering;

  focusing?: CompConfig;

  editing: {
    tabs: RootComp[];
    tab: RootComp | null;
  } = {
    tabs: [],
    tab: null,
  };

  modeling: CompConfig | null = null;

  clipboard?: {
    config: CompConfig;
    cut: boolean;
  };

  private focusingStashed?: CompConfig | null;

  constructor(
    readonly loggerStore: LoggerStore,
    readonly streamStore: StreamStore,
    readonly engineStore: EngineStore,
  ) {
    makeObservable(this, {
      leftDock: observable,
      rightDock: observable,
      dirty: observable,
      rollbacks: observable,
      pushRollback: observable,
      env: observable,
      hovering: observable.ref,
      expendedKeys: observable,

      dragging: observable.ref,
      focusing: observable.ref,
      dropping: observable,
      editing: observable,
      modeling: observable,
      clipboard: observable,

      initPage: action,
      resetEditing: action,
      updateLeftDock: action,
      updateRightDock: action,
      rollback: action,
      updateEnv: action,
      hover: action,
      updateExpendedKeys: action,
      clearHover: action,
      startDragging: action,
      endDragging: action,
      hoverDropping: action,
      measureDropping: action,
      drop: action,
      focus: action,
      blur: action,
      changeEditing: action,
      discardEditing: action,
      openModeling: action,
      closeModeling: action,

      saveCustom: action,
      deleteCustom: action,

      saveModal: action,
      updateModals: action,
      deleteModal: action,

      copy: action,
      cut: action,
      paste: action,

      duplicateActions: action,

      updateConfig: action,
      deleteConfig: action,

      saveData: action,
      deleteData: action,

      saveStyle: action,
      deleteStyle: action,

      saveAction: action,
      deleteAction: action,

      saveEvent: action,
      deleteEvent: action,

      savePage: action,
      analysisSchema: action,
    });

    this.service = createService();
  }

  get pageId() {
    return this.engineStore.page.id;
  }

  init() {
    this.resetEditing();

    return this.streamStore.fromStream(
      this.initPage().pipe(
        tap(() => {
          runInAction(() => {
            const { page } = this.engineStore;

            this.updateEnv({
              device: [PagePlatform.MOBILE, PagePlatform.TARO].includes(
                page.platform,
              )
                ? PageDevice.MOBILE
                : PageDevice.CURRENT,
            });
          });
        }),
      ),
      'init',
    );
  }

  getComponents(type?: ValuesType<Pick<RootComp, 'type'>>) {
    const { engineModelStore } = this.engineStore;

    let elements: CompConfig[];

    switch (type) {
      case PageCompType.PAGE: {
        elements = engineModelStore.elements;
        break;
      }

      case DesktopCompType.MODAL:
      case MobileCompType.MODAL: {
        elements = engineModelStore.modals ?? [];
        break;
      }

      case PageCompType.CUSTOM: {
        elements = Object.values(engineModelStore.customs);
        break;
      }

      default:
        elements = concat(
          engineModelStore.elements,
          engineModelStore.modals,
          Object.values(engineModelStore.customs),
        );
        break;
    }

    return elements || [];
  }

  getEditingComponents() {
    const {
      editing: { tab },
    } = this;

    return this.getComponents(tab?.type ?? PageCompType.PAGE);
  }

  updateLeftDock(dock?: ToolModule) {
    this.leftDock = dock;
  }

  updateRightDock(dock?: ToolModule) {
    this.rightDock = dock;
  }

  pushRollback(rollback: () => void) {
    this.rollbacks.push(rollback);
  }

  rollback() {
    const process = this.rollbacks.pop();

    if (process) {
      process.call(this);
    }

    this.blur();

    this.configUpdating$.next(true);
  }

  initPage() {
    const { engineModelStore, engineRuntimeStore } = this.engineStore;

    return this.engineStore.init().pipe(
      mergeMap(() =>
        this.analysisSchema(get(engineRuntimeStore.state, '_system')).pipe(
          tap((systemDataSchema) => {
            runInAction(() => {
              this.dirty = false;

              set(engineModelStore.datas, '_system.schema', systemDataSchema);

              if (this.focusing) {
                const components = this.getEditingComponents();
                this.focusing = findTreeNode(
                  components,
                  'id',
                  this.focusing.id,
                );
              }

              this.editing.tabs = this.editing.tabs.map((tab) => {
                const components = this.getComponents(tab.type);
                return findTreeNode(components, 'id', tab.id) as RootComp;
              });

              if (this.editing.tab) {
                const components = this.getComponents(this.editing.tab.type);
                this.editing.tab = findTreeNode(
                  components,
                  'id',
                  this.editing.tab.id,
                ) as RootComp;
              }
            });
          }),
        ),
      ),
    );
  }

  resetEditing() {
    const rootElement = this.engineStore.engineModelStore
      .elements[0] as CompConfig;

    this.editing.tabs = [rootElement];
    this.editing.tab = rootElement;

    this.focus(rootElement);
  }

  updateEnv(env: Partial<PageDesignerEnv>) {
    if ('isPreview' in env) {
      this.engineStore.engineFormStore.form.clearBindings();

      if (env.isPreview) {
        this.focusingStashed = this.focusing;
        this.blur();
        assign(this.env, env);
      } else {
        const designerCanvas = document.getElementById(
          'designer-canvas',
        ) as HTMLIFrameElement;

        const dispose = (event: any) => {
          window.removeEventListener('preview/dispose', dispose);

          const state = event.detail.state as Record<string, unknown>;

          entries(state).forEach(([key, value]) => {
            this.engineStore.updateData(key, value);
          });

          if (this.focusingStashed) {
            this.focus(this.focusingStashed);
          }

          assign(this.env, env);
        };

        window.addEventListener('preview/dispose', dispose);

        designerCanvas.contentWindow?.dispatchEvent(
          new CustomEvent('preview/on-dispose'),
        );
      }
    } else {
      assign(this.env, env);
    }
  }

  updateExpendedKeys(type: string, keys: string[]) {
    set(this.expendedKeys, type, keys);
  }

  hover(hovering: Hovering) {
    if (this.dragging == null) {
      this.hovering = hovering;
    }
  }

  clearHover() {
    this.hovering = undefined;
  }

  startDragging(dragItem: DragItem) {
    this.dragging = dragItem;
  }

  endDragging() {
    this.dragging = undefined;
    this.dropping = undefined;
  }

  hoverDropping(dropping: Hovering) {
    if (
      this.dropping == null ||
      this.dropping.config.id !== dropping.config.id
    ) {
      this.dropping = dropping;
    }
  }

  measureDropping(position: DroppingPosition, contains: boolean) {
    if (this.dropping) {
      this.dropping.position = position;
      this.dropping.contains = contains;
    }
  }

  drop(payload: { dragging?: DragItem; dropping?: Hovering } = {}) {
    const { dragging = this.dragging, dropping = this.dropping } = payload;

    const elements = this.getComponents();

    if (dropping == null || dragging == null) {
      this.loggerStore.error('没有正在拖拽的组件或目标位置');
      this.endDragging();
      return;
    }

    let insertParent: CompConfig | undefined;

    if (dropping.contains) {
      insertParent = dropping.config;
    } else {
      // 不在 dropping 元素内部，则继续寻找其父节点作为插入点
      insertParent = findTreeNode(elements, 'id', dropping.config.parentId);
    }

    if (!insertParent) {
      this.loggerStore.error('未找到放置节点');
      this.endDragging();
      return;
    }

    if (insertParent.children == null) {
      insertParent.children = [];
    }

    const draggingConfig =
      dragging.id == null
        ? createCompConfig({
            type: dragging.type,
            parent: insertParent,
            platform: this.engineStore.page.platform,
          })
        : findTreeNode(elements, 'id', dragging.id);

    if (draggingConfig == null) {
      this.loggerStore.error('未找到拖拽节点');
      return;
    }

    if (draggingConfig.indelible) {
      this.loggerStore.error('此元素不允许移动');
      return;
    }

    if (fixedChildPageCompTypes.includes(insertParent.type)) {
      this.loggerStore.error('该区域不允许接收元素');
      return;
    }

    let insertIndex: number;

    if (dropping.contains) {
      insertIndex = size(insertParent.children);
    } else {
      // 找到 dropping 目标在其兄弟中的 index
      const droppingIndex = findIndex(
        insertParent.children,
        (c) => c.id === dropping.config.id,
      );
      insertIndex =
        dropping.position === 'front' ? droppingIndex : droppingIndex + 1;
    }

    const { rollbacks, result } = moveTreeNode({
      source: draggingConfig,
      getTree: () => this.getComponents(),
      insertParentId: insertParent.id,
      insertIndex,
      remove: dragging.id != null,
    });

    this.dirty = true;

    this.dropping = undefined;

    this.blur();

    this.focus(result);

    this.pushRollback(() => {
      rollbacks.forEach((f) => f());
    });
  }

  focus(config: CompConfig) {
    if (config) {
      const { tab } = this.editing;

      const rootId = first(split(config.pathname ?? '', ','));

      if (tab == null || rootId !== tab.id) {
        const root = findTreeNode(this.getComponents(), 'id', rootId);

        if (root && includes(rootPageCompTypes, root.type)) {
          this.changeEditing(root as RootComp);

          // [TODO] 这里不清楚为何不能直接走下去，
          //  Node Focusing 组件找不到当前 focusing 便会报全局异常
          setTimeout(() => {
            this.focus(config);
          }, 0);

          this.clearHover();

          return;
        }
      }
    }

    this.focusing = config;

    this.updateRightDock(ToolModule.SETTINGS);
  }

  blur() {
    this.focusing = undefined;
  }

  changeEditing(config: RootComp) {
    const { editing } = this;

    if (!editing.tabs.includes(config)) {
      editing.tabs.push(config);
    }

    editing.tab = config;

    return config;
  }

  discardEditing(deleting?: RootComp | RootComp[]) {
    const { tabs } = this.editing;

    const deletingList = concat(deleting || this.editing.tab || []);

    let firstDeletingIndex;
    let deletingCount = 0;

    deletingList.forEach((tab, i) => {
      if (tab.type !== PageCompType.PAGE) {
        const index = tabs.indexOf(tab);

        if (index !== -1) {
          (tabs as IObservableArray).remove(tab);

          deletingCount += 1;

          if (i === 0) {
            firstDeletingIndex = index;
          }
        }
      }
    });

    if (firstDeletingIndex != null) {
      this.focus(get(tabs, `[${firstDeletingIndex - deletingCount}]`));
      this.blur();
    }
  }

  openModeling(config: CompConfig | null) {
    this.modeling = config;
  }

  closeModeling() {
    this.modeling = null;
  }

  saveCustom(treeNode: TreeNode<{ name: string }>) {
    const { customTree, customs } = this.engineStore.engineModelStore;

    const parent = findTreeNode(customTree, 'id', treeNode.parentId);

    if (parent) {
      this.dirty = true;

      moveTreeNode({
        source: findTreeNode(customTree, 'id', treeNode.id) || treeNode,
        getTree: () => customTree,
        insertParentId: parent.id,
        insertIndex: size(parent.children),
        remove: true,
      });

      const custom = customs[treeNode.id];

      if (custom) {
        custom.name = treeNode.name;
      } else {
        customs[treeNode.id] = {
          type: PageCompType.CUSTOM,
          pathname: treeNode.id,
          id: treeNode.id,
          name: treeNode.name,
        };
      }
    }
  }

  deleteCustom(custom: TreeNode) {
    this.dirty = true;

    const { customTree, customs } = this.engineStore.engineModelStore;

    moveTreeNode({
      source: custom,
      getTree: () => customTree,
      remove: true,
    });

    const all = [custom.id];

    if (custom.children) {
      walkTree(custom.children, (treeNode) => {
        all.push(treeNode.id);
      });
    }

    this.discardEditing(all.map((id) => customs[id]));

    all.forEach((id) => {
      delete customs[id];
    });
  }

  saveModal(modal: { name: string }) {
    this.dirty = true;

    const { name } = modal;

    const id = uuidv4();

    let type;

    switch (this.engineStore.page.platform) {
      case PagePlatform.MOBILE:
        type = MobileCompType.MODAL;
        break;
      case PagePlatform.PC:
        type = DesktopCompType.MODAL;
        break;
      case PagePlatform.TARO:
        type = TaroCompType.MODAL;
        break;
      default:
        break;
    }

    const config = {
      type,
      id,
      pathname: id,
      parentId: null,
      name,
      title: name,
      okText: '确定',
      cancelText: '取消'
    } as DesktopCompModalConfig | MobileCompModalConfig | TaroCompModalConfig;

    const modals = this.getComponents(DesktopCompType.MODAL);
    const index = size(modals);

    const { rollbacks } = moveTreeNode({
      source: config,
      getTree: () => modals,
      remove: false,
      insertIndex: index,
    });

    this.engineStore.syncSystemData();

    this.focus(modals[index]);

    this.pushRollback(() => {
      rollbacks.forEach((r) => r());
    });
  }

  deleteModal(modal: DesktopCompModalConfig) {
    this.dirty = true;

    const { rollbacks } = moveTreeNode({
      source: modal,
      getTree: () => this.getComponents(DesktopCompType.MODAL),
      remove: true,
    });

    this.discardEditing(modal);

    this.rollbacks.push(() => {
      rollbacks.forEach((r) => r());
    });
  }

  updateModals(modals: DesktopCompModalConfig[]) {
    this.dirty = true;
    this.engineStore.engineModelStore.modals = modals;
  }

  copy(config: CompConfig) {
    this.clipboard = {
      config,
      cut: false,
    };
    this.loggerStore.info('已复制');
  }

  cut(config: CompConfig) {
    this.clipboard = {
      config,
      cut: true,
    };
    this.loggerStore.info('已剪切');
  }

  paste(clipboard: { config: CompConfig; cut: boolean }) {
    const { focusing } = this;

    if (clipboard == null || focusing == null) {
      return;
    }

    const targetParent = includes(pasteInnerCompTypes, focusing.type)
      ? focusing
      : findTreeNode(this.getComponents(), 'id', focusing.parentId);

    if (targetParent == null) {
      return;
    }

    const targetIndex = includes(pasteInnerCompTypes, focusing.type)
      ? size(focusing.children)
      : findIndex(targetParent?.children, (n) => n.id === focusing.id) + 1;

    let { config } = clipboard;

    if (!clipboard.cut) {
      config = cloneDeep(config);
      this.duplicateActions(config);
    }

    const { rollbacks, result } = moveTreeNode({
      source: config,
      getTree: () => this.getComponents(),
      remove: clipboard.cut,
      insertIndex: targetIndex,
      insertParentId: targetParent.id,
    });

    this.rollbacks.push(() => {
      rollbacks.forEach((r) => r());
    });

    this.dirty = true;

    this.clearHover();

    this.focus(result);
  }

  duplicateActions(config: CompConfig) {
    const { actions } = this.engineStore.engineModelStore;

    walkTree([config], (node) => {
      actionBindingKeys.forEach((key) => {
        const actionBinding = get(node, key) as ActionBinding | undefined;

        if (actionBinding && actionBinding.actionId in actions) {
          const act = actions[actionBinding.actionId];

          const actionId = uuidv4();

          set(
            actions,
            actionId,
            cloneDeep({
              ...act,
              code: null,
              id: actionId,
            }),
          );

          set(node, key, { ...actionBinding, actionId });
        }
      });
    });
  }

  updateConfig(payload: {
    config?: CompConfig | null;
    values?: Record<string, unknown>;
    replaceAll?: boolean;
  }) {
    const { config, values, replaceAll = false } = payload;

    this.dirty = true;

    let valuesBak = {};

    if (config != null && values != null) {
      if (replaceAll) {
        // 直接修改模型的场景，需整体替换模型，并记录替换之前的样子，相当于所有的值都被修改了
        valuesBak = cloneDeep(toJS(config));
        Object.keys(config).forEach((k) => unset(config, k));
      }

      Object.entries(values).forEach(([key, value]) => {
        if (!replaceAll) {
          // 若非整体替换，则仅需记录修改过得值
          set(valuesBak, key, cloneDeep(toJS(get(config, key))));
        }
        set(config, key, value);
      });

      const configId = config.id;

      this.pushRollback(() => {
        const c = findTreeNode(this.getComponents(), 'id', configId);
        if (c) {
          if (replaceAll) {
            // 若整体替换，回滚时也需先将目标清空，再使用记录值整体替换
            Object.keys(c).forEach((k) => unset(config, k));
          }

          Object.entries(valuesBak).forEach(([key, value]) => {
            set(c, key, value);
          });
        }
      });

      this.configUpdating$.next(config);
    }
  }

  deleteConfig(config?: CompConfig | null) {
    if (
      config &&
      !config.indelible &&
      !includes(rootPageCompTypes, config.type)
    ) {
      this.dirty = true;

      const { rollbacks } = moveTreeNode({
        source: config,
        getTree: () => this.getComponents(),
        remove: true,
      });

      this.blur();

      this.pushRollback(() => {
        rollbacks.forEach((r) => r());
      });
    }
  }

  saveData(pageData: Data, prefetch = false) {
    this.engineStore.engineModelStore.datas[pageData.code] = {
      ...pageData,
      id: pageData.id === addingId ? uuidv4() : pageData.id,
      ts: pageData.id === addingId ? +new Date() : pageData.ts,
    };

    this.engineStore.syncSystemData();

    this.dirty = true;

    this.engineStore.updateData(pageData.code, pageData.defaultData);

    if (prefetch) {
      return this.engineStore.fetchData({
        dataCode: pageData.code,
        params: parseJexlExpressionDeep(
          pageData.params,
          this.engineStore.engineRuntimeStore.state,
        ),
      });
    }

    return of(pageData);
  }

  deleteData(dataCode: string) {
    this.dirty = true;
    delete this.engineStore.engineModelStore.datas[dataCode];
    delete this.engineStore.engineRuntimeStore.state[dataCode];
  }

  saveStyle(pageStyle: Style) {
    this.dirty = true;

    if (pageStyle.id === 'global') {
      this.engineStore.engineModelStore.globalStyle = pageStyle.style || '';
      return;
    }

    const style = {
      ...pageStyle,
      id: pageStyle.id === addingId ? uuidv4() : pageStyle.id,
    };

    this.engineStore.engineModelStore.styles[style.id] = style;
  }

  deleteStyle(id: string) {
    this.dirty = true;
    delete this.engineStore.engineModelStore.styles[id];
  }

  deleteGlobalStyle() {
    this.dirty = true;
    this.engineStore.engineModelStore.globalStyle = '';
  }

  saveAction(actionQueue: ActionQueue) {
    const action1 = {
      ...actionQueue,
      id: actionQueue.id === addingId ? uuidv4() : actionQueue.id,
      ts: actionQueue.id === addingId ? +new Date() : actionQueue.ts,
    };

    this.engineStore.engineModelStore.actions[action1.id] = action1;

    this.dirty = true;

    this.engineStore.syncSystemData();

    return action1.id;
  }

  deleteAction(id: string) {
    this.dirty = true;
    delete this.engineStore.engineModelStore.actions[id];
  }

  saveEvent(event: Event) {
    const { events } = this.engineStore.engineModelStore;

    this.dirty = true;

    if (event.id === addingId) {
      events.push({
        ...event,
        id: uuidv4(),
      });
    } else {
      const index = events.findIndex((i) => i.id === event.id);
      events.splice(index, 1, event);
    }
  }

  deleteEvent(event: Event) {
    this.dirty = true;
    (this.engineStore.engineModelStore.events as IObservableArray).remove(
      event,
    );
  }

  saveResource(resource: Resource) {
    const { resources } = this.engineStore.engineModelStore;

    this.dirty = true;

    if (resource.id === addingId) {
      resources.push({
        ...resource,
        id: uuidv4(),
      });
    } else {
      const index = resources.findIndex((i) => i.id === resource.id);
      resources.splice(index, 1, resource);
    }
  }

  deleteResource(resource: Resource) {
    this.dirty = true;
    (this.engineStore.engineModelStore.resources as IObservableArray).remove(
      resource,
    );
  }

  saveDraft() {
    const { version } = this.engineStore;

    const {
      actions,
      datas,
      events,
      elements,
      modals,
      styles,
      globalStyle,
      resources,
      customTree,
      customs,
    } = this.engineStore.engineModelStore;

    const { page } = this.engineStore;

    return from(
      this.service.post(api.page.saveDraft(page.id), {
        modelData: JSON.stringify({
          elements,
          modals,
          customs,
          customTree,
          actions,
          datas: omit(datas, ['_system']),
          styles,
          globalStyle,
          events,
          version,
          resources,
        }),
      }),
    );
  }

  publishPage() {
    return this.streamStore.fromStream(
      this.saveDraft().pipe(
        mergeMap(() => {
          this.dirty = false;
          return from(this.service.post(api.page.publish(this.pageId)));
        }),
        tap(() => {
          this.loggerStore.success('发布成功');
        }),
      ),
      'publishPage',
    );
  }

  rollbackPage() {
    return this.streamStore.fromStream(
      from(this.service.post(api.page.rollback(this.pageId))).pipe(
        tap(() => {
          this.loggerStore.success('回滚成功');
        }),
      ),
      'rollbackPage',
    );
  }

  savePage() {
    const { page } = this.engineStore;

    return this.streamStore.fromStream(
      this.saveDraft().pipe(
        map(() => page.id),
        tap(() => {
          this.loggerStore.success('保存成功');
          runInAction(() => {
            this.dirty = false;
            this.rollbacks = [];
          });
        }),
      ),
      'savePage',
    );
  }

  analysisSchema(_data: unknown) {
    return of({
      dataType: SchemaDataType.JSON_OBJECT,
      properties: {},
    } as Schema);
  }

  clearUnusedActions() {
    const components = this.getComponents();
    const usedActionIds = new Set<string>();
    walkTree(components, (config) => {
      actionBindingKeys.forEach((key) => {
        const actionId = get(config, `${key}.actionId`);
        if (actionId) {
          usedActionIds.add(actionId);
        }
      });
    });
    this.engineStore.engineModelStore.events.forEach((event) => {
      const { actionId } = event;
      if (actionId) {
        usedActionIds.add(actionId);
      }
    });

    const { actions } = this.engineStore.engineModelStore;

    const localActions = filter(
      actions,
      (act) => act.type === ActionQueueType.LOCAL,
    );

    const unUsedActionIds = difference(
      lodashMap(localActions, (n) => n.id),
      Array.from(usedActionIds),
    );

    forEach(unUsedActionIds, (id) => {
      delete actions[id];
    });

    this.loggerStore.success(`清除无效Action：${size(unUsedActionIds)} 个`);
  }
}

export default DesignerStore;
