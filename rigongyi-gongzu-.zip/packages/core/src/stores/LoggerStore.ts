import { action, IObservableArray, makeObservable, observable } from 'mobx';
import { Logger, LoggerLevel, LoggerType } from '../types/entities';

export default class LoggerStore {
  logs: Logger[] = [];

  current?: Logger | null = null;

  constructor() {
    makeObservable(this, {
      logs: observable,
      current: observable.ref,
      push: action,
      hide: action,
      remove: action,
      success: action,
      info: action,
      error: action,
    });
  }

  push(logger: Logger): void {
    this.logs.push(logger);
    this.current = logger;
  }

  remove(logger: Logger): void {
    (this.logs as IObservableArray).remove(logger);
  }

  hide() {
    this.current = undefined;
  }

  success(message: string, type: LoggerType = LoggerType.MESSAGE): void {
    const logger: Logger = {
      message,
      type,
      level: LoggerLevel.SUCCESS,
    };

    this.push(logger);
  }

  info(message: string, type: LoggerType = LoggerType.MESSAGE): void {
    const logger: Logger = {
      message,
      type,
      level: LoggerLevel.INFO,
    };

    this.push(logger);
  }

  error(message: string, type: LoggerType = LoggerType.MESSAGE): void {
    const logger: Logger = {
      message,
      type,
      level: LoggerLevel.ERROR,
    };

    // eslint-disable-next-line no-console
    console.error(message);

    this.push(logger);
  }
}
