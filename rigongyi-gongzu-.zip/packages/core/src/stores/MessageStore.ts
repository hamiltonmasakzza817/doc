import last from 'lodash-es/last';
import remove from 'lodash-es/remove';
import uniqueId from 'lodash-es/uniqueId';
import { action, computed, makeObservable, observable } from 'mobx';

export enum MessageType {
  CONFIRM = 'CONFIRM',
  ACTION_SHEET = 'ACTION_SHEET',
  NAVIGATE = 'NAVIGATE',
  EXEC_CODE = 'EXEC_CODE',
}

export interface Message {
  type: MessageType;
  id: string;
}

export interface MessageConfirm extends Message {
  type: MessageType.CONFIRM;
  title: string;
  resolve: () => void;
  reject: () => void;
}

export interface MessageActionSheet extends Message {
  type: MessageType.ACTION_SHEET;
  params: any;
  resolve: (tapIndex: number) => void;
  reject: () => void;
}

export interface MessageNavigate extends Message {
  type: MessageType.NAVIGATE;
  url: string;
  open: boolean;
  usePushState?: boolean;
  useReplace?: boolean;
}

export interface MessageExecCode extends Message {
  code: string;
  type: MessageType.EXEC_CODE;
  params: any[];
  resolve: (result: any) => void;
  reject: () => void;
}

export default class MessageStore {
  messages: Message[] = [];

  constructor() {
    makeObservable(this, {
      messages: observable.shallow,
      send: action,
      receive: action,
      current: computed,
    });
  }

  get current() {
    return last(this.messages);
  }

  send(message: Omit<Message, 'id'>) {
    this.messages.push({
      ...message,
      id: uniqueId(),
    });
  }

  receive(message: Message) {
    remove(this.messages, (msg) => msg.id === message.id);
  }
}
