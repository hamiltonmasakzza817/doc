import set from 'lodash-es/set';
import { action, makeObservable } from 'mobx';
import { tap } from 'rxjs/operators';
import EngineStore from '../engine/EngineStore';
import StreamStore from './StreamStore';

export default class PlayerStore {
  constructor(
    readonly engineStore: EngineStore,
    readonly streamStore: StreamStore,
  ) {
    makeObservable(this, {
      init: action,
      updateParams: action,
    });
  }

  init() {
    return this.streamStore.fromStream(
      this.engineStore.init().pipe(tap(() => this.engineStore.start())),
      `${this.engineStore.page.id},init`,
    );
  }

  updateParams(params: any) {
    set(this.engineStore.engineRuntimeStore.state, '_system.params', params);
  }

  dispose() {
    this.engineStore.dispose();
  }
}
