import { action, makeObservable, observable, runInAction } from 'mobx';
import { from } from 'rxjs';
import { tap } from 'rxjs/operators';
import api from '../config/api';
import { createService } from '../config/service';
import { LoginData } from '../types/entities';
import StreamStore from './StreamStore';

export default class SessionStore {
  login: LoginData | null = null;

  constructor(readonly streamStore: StreamStore) {
    makeObservable(this, {
      login: observable.ref,
      fetchLogin: action,
    });
  }

  fetchLogin() {
    return this.streamStore.fromStream(
      from(createService().get<LoginData>(api.login.get)).pipe(
        tap((n) => {
          runInAction(() => {
            this.login = n.data;
          });
        }),
      ),
      'fetchLogin',
    );
  }

  logout() {
    return from(createService().delete(api.login.remove)).pipe(
      tap(() => {
        window.location.reload();
      }),
    );
  }
}
