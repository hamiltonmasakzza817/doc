import set from 'lodash-es/set';
import { action, makeObservable, observable } from 'mobx';
import { from, of } from 'rxjs';
import { map, mergeMap, tap } from 'rxjs/operators';
import api from '../config/api';
import { createService } from '../config/service';
import {
  DataType,
  Page,
  PageCustomCompTreeNodeType,
  PageModelData,
  PageModelType,
  TreeNode,
} from '../types/entities';
import { mergeEntities, normalizeTree } from '../utils/data';
import StreamStore from './StreamStore';

function formatPage(page: Page): Page {
  const modelData: PageModelData = page.model?.modelData || {
    elements: [],
    modals: [],
    customs: {},
    customTree: [
      {
        id: '-1',
        pathname: '-1',
        name: '自定义组件',
        type: PageCustomCompTreeNodeType.CATEGORY,
      },
    ],
    actions: {},
    datas: {
      tempData: {
        id: '_tempData',
        code: 'tempData',
        name: 'tempData',
        type: DataType.MANUAL,
        autoLoad: true,
        format: 'form',
        ignoreQueryException: false,
        ts: +new Date(),
      },
    },
    styles: {},
    events: [],
    resources: [],
    version: '3.0.1',
  };

  return {
    ...page,
    model: {
      modelData,
      type: PageModelType.DRAFT,
    },
  };
}

export default class PageStore {
  pages: Record<string, Page> = {};

  constructor(readonly streamStore: StreamStore) {
    makeObservable(this, {
      pages: observable.shallow,

      fill: action,
      fetchTree: action,
      fetchPage: action,
      savePageModel: action,
    });
  }

  fill(entities: Record<string, Page>) {
    mergeEntities(this.pages, entities, 'id');
  }

  fetchTree() {
    return from(
      createService().get<TreeNode<Page>[]>(api.page.listTree, { params: {} }),
    ).pipe(
      map((n) => normalizeTree<TreeNode<Page>, TreeNode<Page>>(n.data)),
      tap((n) => this.fill(n.entities)),
    );
  }

  fetchPage(params: { id?: string; url?: string }, type: 'publish' | 'draft') {
    const { id } = params;

    let { url } = params;

    url = encodeURIComponent(url || '');

    const service = createService();

    return this.streamStore.fromStream(
      from(
        service.get<any>(
          type === 'publish'
            ? api.page.getPublish({ pageId: id, url })
            : api.page.getDraft(id!),
        ),
      ).pipe(
        mergeMap((n) => {
          const { modelKey } =
            (type === 'publish' ? n.data.publishedModel : n.data.draftModel) ??
            {};

          if (modelKey) {
            return from(
              service.get<PageModelData>(api.page.model(modelKey)),
            ).pipe(
              map((s) => {
                if (s.data) {
                  set(n.data, 'model.modelData', s.data);
                }

                return n.data;
              }),
            );
          }

          return of(n.data);
        }),
        map((n) => {
          let page = n;

          if (type === 'draft') {
            page = formatPage(page);
          }

          return page;
        }),
        tap((page) => {
          const key = id || page.id;

          this.fill({ [key]: page });
        }),
      ),
    );
  }

  savePageModel(id: string, model: string) {
    return from(
      createService().post(api.page.saveDraft(id), {
        modelData: model,
      }),
    );
  }

}
