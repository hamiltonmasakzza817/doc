import includes from 'lodash-es/includes';
import React from 'react';
import { mergeMap } from 'rxjs/operators';
import { indeliblePageCompTypes, rootPageCompTypes } from '../config/comps';
import {
  BaseStoresContext,
  DesignerStoreContext,
} from '../contexts/store-contexts';

type E = Pick<Event, 'preventDefault'> | undefined;

export default () => {
  const preventDefault = React.useCallback((e: E) => {
    if (e) {
      e.preventDefault();
    }
  }, []);

  const { loggerStore, pageStore } = React.useContext(BaseStoresContext);

  const designerStore = React.useContext(DesignerStoreContext);

  return {
    saveModel: (e?: E) => {
      if (e) {
        preventDefault(e);
      }
      designerStore
        .savePage()
        .pipe(mergeMap((id) => pageStore.fetchPage({ id }, 'draft')))
        .subscribe();
    },
    copy: (e: E) => {
      const { focusing } = designerStore;
      if (focusing) {
        if (!includes(rootPageCompTypes, focusing.type)) {
          preventDefault(e);
          designerStore.copy(focusing);
        } else {
          loggerStore.error('该元素不可复制');
        }
      }
    },
    cut: (e: E) => {
      const { focusing } = designerStore;
      if (focusing) {
        if (!includes(rootPageCompTypes, focusing.type)) {
          preventDefault(e);
          designerStore.cut(focusing);
        } else {
          loggerStore.error('该元素不可剪切');
        }
      }
    },
    paste: (e: E) => {
      if (designerStore.clipboard) {
        preventDefault(e);
        designerStore.paste(designerStore.clipboard);
      }
    },
    delete: (e: E) => {
      const { focusing } = designerStore;
      if (focusing) {
        if (
          !focusing.indelible &&
          !includes(indeliblePageCompTypes, focusing.type)
        ) {
          preventDefault(e);
          designerStore.deleteConfig(focusing);
        } else {
          loggerStore.error('该元素不可删除');
        }
      }
    },
    model: (e: E) => {
      const { focusing } = designerStore;
      if (focusing) {
        preventDefault(e);
        designerStore.openModeling(focusing);
      }
    },
    rollback: (e: E) => {
      preventDefault(e);
      designerStore.rollback();
    },
  };
};
