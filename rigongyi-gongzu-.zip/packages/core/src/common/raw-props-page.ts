export default ['id', 'title', 'style', 'className'];
