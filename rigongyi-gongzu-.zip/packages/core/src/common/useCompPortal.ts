import React from 'react';
import EngineStore from '../engine/EngineStore';
import CompContext, { ICompContext } from './CompContext';

export default function useCompPortal(pageEngineStore: EngineStore) {
  const compContext = React.useContext(CompContext);

  React.useEffect(() => () => pageEngineStore.stop(), []);

  return {
    ...compContext,
    state: pageEngineStore.engineRuntimeStore.state,
    inDesigner: false,
    codeInterpreter: pageEngineStore.engineRuntimeStore.codeInterpreter,
    dispatchAction: (...args) => {
      pageEngineStore.engineRuntimeStore.subscribeAction({
        $action: pageEngineStore.dispatchAction(...args),
        actionQueueId: args[0],
      });
    },
  } as ICompContext;
}
