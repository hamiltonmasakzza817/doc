import get from 'lodash-es/get';
import { Observer, observer } from 'mobx-react';
import React from 'react';
import { delay } from 'rxjs/operators';
import NodeOutline from '../components/NodeOutline';
import { gzdnBem } from '../config/constants';
import language from '../config/language';
import { DesignerStoreContext } from '../contexts/store-contexts';

const focusingOutlineBlock = gzdnBem('focusing-outline');

export default observer(
  (props: { target: HTMLElement | null; getContainer?: () => HTMLElement }) => {
    const { target, getContainer } = props;

    const designerStore = React.useContext(DesignerStoreContext);

    React.useEffect(() => {
      const subscriber = designerStore.configUpdating$
        .pipe(delay(0))
        .subscribe(() => {
          window.dispatchEvent(new Event('resize'));
        });

      return () => {
        subscriber.unsubscribe();
      };
    }, []);

    const { dropping, focusing } = designerStore;

    return (
      <NodeOutline
        className="z-20"
        style={{
          position: 'absolute',
          top: 0,
          left: 0,
        }}
        color="green"
        target={dropping ? undefined : target}
        getContainer={getContainer}
        tag={
          <div className={focusingOutlineBlock('tag')}>
            <Observer>
              {() => {
                const typeName = focusing
                  ? get(language.compTypes, focusing.type)
                  : undefined;

                const name = focusing
                  ? focusing.name || focusing.alias
                  : undefined;

                return <>{name ? `${name}(${typeName})` : typeName}</>;
              }}
            </Observer>
          </div>
        }
      />
    );
  },
);
