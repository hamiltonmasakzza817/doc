import classNames from 'classnames';
import includes from 'lodash-es/includes';

import { CSSProperties } from 'react';
import { containablePageCompTypes, inlinePageTypes } from '../config/comps';
import {
  CompConfig,
  PageCompStyles,
  VerticalAlign,
} from '../types/comps-common';

export function getAlignSelf(verticalAlign?: VerticalAlign) {
  switch (verticalAlign) {
    case VerticalAlign.BASELINE: {
      return 'baseline';
    }

    case VerticalAlign.TOP: {
      return 'top';
    }

    case VerticalAlign.CENTER: {
      return 'center';
    }

    case VerticalAlign.BOTTOM: {
      return 'end';
    }

    default: {
      return null;
    }
  }
}

export function getCompStyles(styles?: PageCompStyles): {
  className: string;
  style?: CSSProperties;
} {
  let className = '';

  let style: CSSProperties | undefined;

  if (styles != null) {
    const {
      width,
      height,
      span,
      bold,
      italic,
      fontSize,
      underline,
      lineThrough,
      fontFamily,
      backgroundImage,
      alignSelf,
    } = styles;

    style = {};

    if (width != null) {
      style.width = width;
    }

    if (height != null) {
      style.height = height;
    }

    if (fontSize != null) {
      style.fontSize = fontSize;
    }

    if (fontFamily != null) {
      style.fontFamily = fontFamily;
    }

    if (backgroundImage != null) {
      style.backgroundImage = `url(${backgroundImage})`;
    }

    const af = getAlignSelf(alignSelf);

    if (af) {
      className = classNames(className, `self-${af}`);
    }

    className = classNames(
      className,
      span != null ? `col-span-${span}` : undefined,
      bold ? 'font-bold' : underline,
      { italic },
      { underline },
      { 'line-through': lineThrough },
    );
  }

  return {
    className,
    style,
  };
}

export function getCompStyle(config: CompConfig): {
  className: string;
  style?: CSSProperties;
} {
  const composeStyle = getCompStyles(config.styles);

  let { className } = composeStyle;

  const { style = {} } = composeStyle;

  if (includes(inlinePageTypes, config.type)) {
    style.display = 'inline-block';
  }

  if (includes(containablePageCompTypes, config.type)) {
    const {
      grid,
      alignSelf,
      gridGap = 0,
    } = config.styles || ({} as PageCompStyles);

    const align = getAlignSelf(alignSelf);

    className = classNames(
      className,
      align ? `text-${align}` : undefined,
      grid && grid !== 'flex' ? `grid-cols-${grid}` : undefined,
    );

    if (grid) {
      if (grid === 'flex') {
        className = classNames(className, 'flex flex-wrap');

        if (gridGap) {
          className = classNames(className, `gap-${gridGap}`);
        }
      } else {
        className = classNames(className, `grid gap-${gridGap}`);
      }
    }
  }

  return { className, style };
}
