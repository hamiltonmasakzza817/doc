import classNames from 'classnames';
import React from 'react';
import WrapperComp from './WrapperComp';

export default function Central(props: React.HTMLAttributes<HTMLDivElement>) {
  const { children, className, ...divProps } = props;

  return (
    <WrapperComp
      {...divProps}
      className={classNames(
        className,
        'absolute flex items-center justify-center inset-0',
      )}
    >
      {props.children}
    </WrapperComp>
  );
}
