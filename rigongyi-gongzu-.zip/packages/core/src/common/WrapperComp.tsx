import React from 'react';
import CompContext from './CompContext';

export default React.forwardRef(
  (
    props: {
      children: JSX.Element | JSX.Element[] | string;
      className?: string;
    } & any,
    ref,
  ) => {
    const { children, ...rest } = props;

    const compContext = React.useContext(CompContext);

    return React.createElement(
      compContext.wrapperComp,
      { ref, ...rest },
      children,
    );
  },
);
