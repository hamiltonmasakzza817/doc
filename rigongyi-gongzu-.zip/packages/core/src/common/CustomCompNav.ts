import { observer } from 'mobx-react';
import React from 'react';
import { DesignerStoreContext } from '../contexts/store-contexts';
import { PageCompCustomConfig } from '../types/comps-page';

export default observer(
  (props: {
    config: PageCompCustomConfig;
    wrapper?: React.FunctionComponent<any>
      | React.ComponentClass<any, any>
      | string;
  }) => {
    const { config, wrapper = 'div' } = props;

    const designerStore = React.useContext(DesignerStoreContext);

    return React.createElement(
      wrapper,
      {
        onClick: (e: MouseEvent) => {
          e.stopPropagation();
          e.preventDefault();
          designerStore.focus(config);
        },
        className: 'text-primary',
      },
      config.name,
    );
  },
);
