import get from 'lodash-es/get';
import { observer } from 'mobx-react';
import React from 'react';
import NodeOutline from '../components/NodeOutline';
import { gzdnBem } from '../config/constants';
import language from '../config/language';
import { DesignerStoreContext } from '../contexts/store-contexts';

const overingOutlineBem = gzdnBem('overing-outline');

export default observer(
  (props: { target: HTMLElement | null; getContainer?: () => HTMLElement }) => {
    const { target, getContainer } = props;

    const designerStore = React.useContext(DesignerStoreContext);

    const { hovering, dropping } = designerStore;

    const node = dropping ?? hovering;

    let displayName = null;

    if (node) {
      const typeName = get(language.compTypes, node.config.type);

      const name = node.config.name || node.config.alias;

      displayName = name ? `${name}(${typeName})` : typeName;
    }

    return (
      <NodeOutline
        className="z-10"
        style={{
          position: 'absolute',
          top: 0,
          left: 0,
        }}
        target={target}
        getContainer={getContainer}
        tag={<div className={overingOutlineBem('tag')}>{displayName}</div>}
      />
    );
  },
);
