import assign from 'lodash-es/assign';
import find from 'lodash-es/find';
import get from 'lodash-es/get';
import transform from 'lodash-es/transform';
import { ReactNode } from 'react';
import { CompOptions } from '../types/comps-common';
import { findTreeNodeBy } from '../utils/tree';
import { ICompContext } from './CompContext';
import { parsePathname, parseValue } from './utils';

export function getOptions(
  options?: CompOptions,
  compContext?: ICompContext,
): {
  value: any;
  label: string;
  disabled?: boolean;
  name?: string;
  pathname: string;
}[] {
  if (options == null || compContext == null) {
    return [];
  }

  const { pathname } = parsePathname({
    expression: options?.dataSource,
    compContext,
  });

  let dataSource = pathname
    ? (get(compContext.state, pathname) as unknown[])
    : [];

  if (typeof dataSource !== 'object') {
    return [];
  }

  if (!Array.isArray(dataSource)) {
    dataSource = transform(
      dataSource,
      (result, value, key) => {
        result.push(
          assign(
            {
              _key: key,
              _value: typeof value === 'object' ? undefined : value,
            },
            typeof value === 'object' ? value : null,
          ),
        );
      },
      [] as unknown[],
    );
  }

  return dataSource.map((option: unknown, index) => {
    const key = parseValue({
      expression: options?.value,
      compContext,
      context: option,
    });

    return {
      value: key,

      key: `${key}`,

      pathname: `${pathname}[${index}]`,

      name: parseValue({
        expression: options?.name,
        compContext,
        context: option,
      }),

      disabled:
        parseValue({
          expression: options?.disabled,
          compContext,
          context: option,
        }) === true,

      label: options?.label
        ? parseValue({
            expression: options.label,
            compContext,
            context: option,
          })
        : null,
    };
  });
}

export function findOptionName(
  value: string | number | null,
  options: { value?: string | number; name?: string; label?: string }[],
  key = 'name'
) {
  if (!value) {
    return value;
  }

  return (
    get(find(options, (opt) => opt.value?.toString() === value.toString()), key) ??
    value
  );
}

export function findTreeOption(
  value: string,
  options: {
    key: string | number;
    title?: string | ReactNode;
    names: string[];
  }[],
  childrenKey = 'children',
) {
  if (!value) {
    return null;
  }

  return findTreeNodeBy(
    options,
    (opt) => opt.key?.toString() === value?.toString(),

    childrenKey,
  );
}
