import dayjs from 'dayjs';
import assign from 'lodash-es/assign';
import cloneDeep from 'lodash-es/cloneDeep';
import { toJS } from 'mobx';
import React from 'react';
import { createService } from '../config/service';
import { EngineStoresContext } from '../contexts/store-contexts';
import { BindOptions } from '../mobx-form/types';
import { CompFormItem } from '../types/comps-common';
import { parseJexlExpressionDeep } from '../utils/jexl';
import {
  filterTree,
  findTreeNode,
  findTreeNodeBy,
  walkTree,
} from '../utils/tree';
import CompContext from './CompContext';
import { useActionDispatcher } from './hooks';
import lodashUtils from './lodash-utils';
import { makeParamsToDispatcher, parsePathname, parseValue } from './utils';

export type RenderFormControl = (option: {
  bind: {
    value: any;
    onChange: (value: any) => void;
    onBlur: () => void;
  };
  disabled?: boolean;
  readOnly?: boolean;
  error?: string;
  required?: boolean;
  label?: string;
  placeholder?: string;
  pathname?: string;
}) => React.ReactElement;

export default function useFormItem(
  config: CompFormItem,
  children: RenderFormControl,
) {
  const { engineFormStore, engineStore } = React.useContext(EngineStoresContext);

  const compContext = React.useContext(CompContext);

  let pathname: string | undefined;

  if (config.value) {
    ({ pathname } = parsePathname({
      expression: config.value,
      compContext,
    }));
  }

  React.useEffect(
    () => () => {
      if (pathname) {
        engineFormStore.form.unbind(pathname);
      }
    },
    [compContext.inDesigner, pathname],
  );

  const { form } = engineFormStore;

  const error = pathname ? form.errors[pathname] : undefined;

  const label = parseValue({
    expression: config.label?.text,
    compContext,
  });

  const extra = parseValue({
    expression: config.extra,
    compContext,
  });

  const disabled =
    parseValue({
      expression: config.disabled,
      compContext,
    }) === true;

  const readOnly =
    parseValue({
      expression: config.readOnly,
      compContext,
    }) === true;

  const dispatchOnChange = useActionDispatcher(config.onChange);

  const onChange = (value: any) => {
    dispatchOnChange({ value });
  };

  const dispatchOnBlur = useActionDispatcher(config.onBlur);

  const onBlur = (value: any) => {
    dispatchOnBlur({ value });
  };

  const { rule } = config;

  const validateRule: BindOptions = {};

  let required = false;

  if (rule) {
    required = rule.requiredExp
      ? parseValue({
          expression: rule.requiredExp,
          compContext,
        })
      : rule.required;

    validateRule.required = {
      value: required,
      message: rule.requiredMsg,
    };

    if (rule.pattern) {
      validateRule.pattern = {
        value: new RegExp(rule.pattern, rule.patternFlag),
        message: rule.patternMsg,
      };
    }

    if (rule.validate) {
      validateRule.validate = {
        value: (value) => {
          let result;

          try {
            result = engineStore.codeInterpreter(rule.validate!, [
              ['value', cloneDeep(value)],
              ['state', cloneDeep(toJS(compContext.state))],
              ['_index', compContext.dataBinding.index],
              ['_pathname', compContext.dataBinding.pathname],
              ['_pathnames', compContext.dataBinding.pathnames],
              [
                'utils',
                {
                  ...lodashUtils,
                  walkTree,
                  findTreeNode,
                  findTreeNodeBy,
                  filterTree,
                  createAxios: createService,
                  moment: dayjs,
                },
              ],
            ]);
          } catch (e) {
            // eslint-disable-next-line
            console.log('eval error', JSON.stringify(e));
            result = false;
          }

          return result;
        },
        message: rule.validateMsg,
      };
    }

    if (rule.remoteValidate?.url) {
      validateRule.remoteValidate = {
        value: {
          url: rule.remoteValidate.url,
          method: rule.remoteValidate.method,
          getParams: (value) => {
            const payload = makeParamsToDispatcher({
              compContext,
              params: {
                value,
              },
            });

            const expressionContext = cloneDeep(
              assign({}, compContext.state, {
                _params: payload.params,
                _context: payload.context,
                _index: payload.contextIndex,
                _pathname: payload.contextPathname,
                _pathnames: payload.contextPathnames,
                _indexes: payload.contextIndexes,
              }),
            );

            const p = parseJexlExpressionDeep(
              rule.remoteValidate?.params,
              expressionContext,
            );

            return p;
          },
        },
        message: rule.remoteValidateMsg,
      };
    }
  }

  const bind = pathname
    ? form?.bind(pathname, readOnly || disabled ? undefined : validateRule)
    : {
        onChange: () => {},
        value: null,
      };

  const content = children({
    bind: assign({}, bind, {
      onChange: compContext.inDesigner
        ? () => {}
        : (valueOrEvent: any) => {
            let value: any;

            if (!config.onWayBinding) {
              value = bind.onChange(valueOrEvent);
            } else {
              value =
                valueOrEvent != null &&
                typeof valueOrEvent === 'object' &&
                'target' in valueOrEvent
                  ? valueOrEvent.target.value
                  : valueOrEvent;
            }

            if (onChange) {
              onChange(value);
            }
          },
      onBlur: () => {
        if (onBlur) {
          setTimeout(onBlur);
        }
      },
    }),
    disabled,
    readOnly,
    error,
    label,
    required,
    pathname,
    placeholder: parseValue({
      expression: config.placeholder,
      compContext,
    }),
  });

  return { content, label, extra, pathname, readOnly, required };
}
