import React, { CSSProperties } from 'react';
import IdsRoller from '../components/IdsRoller';
import Central from './Central';
import WrapperComp from './WrapperComp';

export default (props: {
  children?: React.ReactNode;
  className?: string;
  style?: CSSProperties;
}) => (
  <Central className={props.className} style={props.style}>
    <WrapperComp>{props.children || React.createElement(IdsRoller)}</WrapperComp>
  </Central>
);
