import EventEmitter from 'eventemitter3';
import React from 'react';
import { CompConfig, TextAlign } from '../types/comps-common';
import { CompProps } from './types';

export interface ICompContext {
  // 局部表单布局
  formLayout: {
    label?: {
      width?: number;
      span?: number;
      align: 'left' | 'right';
    };
    layout: 'vertical' | 'horizontal';
  };

  // 局部数据绑定
  dataBinding: {
    pathname?: string;
    pathnames: string[];
    index?: number;
    indexes?: number[];
  };

  dispatchAction: (
    actionId: string,
    payload: {
      params?: any;
      context?: any;
      contextIndex?: number;
    },
  ) => any;

  portal: HTMLElement;

  proxyComp:
    | React.FunctionComponent<any>
    | React.ComponentClass<any, any>
    | string;

  // 当前平台的代理组件，用于动态渲染组件的情况
  factoryComp:
    | React.FunctionComponent<any>
    | React.ComponentClass<any, any>
    | string;

  // 当前平台的组件 wrapper 类（非容器类组件使用），用于帮助目标组件接收 className 与 style
  wrapperComp:
    | React.FunctionComponent<any>
    | React.ComponentClass<any, any>
    | string;

  loading: React.ReactElement;

  // 页面根容器 query selector，用于 popup 挂载，如 Select Modal 等等
  // https://github.com/react-component/trigger/blob/master/src/index.tsx#L72
  containerQuerySelector?: string;

  // 视口 query selector
  viewportQuerySelector?: string;

  // 全局唯一数据源
  state: Record<string, unknown>;

  // 非 state 的上下文数据，每个可容纳自定义组件的挂载点，可向下传递，参数会层层合并
  // 如 Table Column 信息
  params: Record<string, unknown>;

  // 页面传送门路径队列
  pageIds?: string[];

  inDesigner: boolean;

  eventEmitter?: EventEmitter;

  // 组件类工厂方法，用于返回模型对应的组件类
  factory: (config: CompConfig) => React.FunctionComponent<CompProps<any>>;
}

export default React.createContext<ICompContext>({
  formLayout: {
    label: {
      width: 80,
      align: TextAlign.LEFT,
    },
    layout: 'vertical',
  },

  viewportQuerySelector: '',

  portal: document.body,

  dataBinding: {
    pathnames: [],
    indexes: [],
  },

  dispatchAction: async () => {},

  proxyComp: 'div',

  factoryComp: 'div',

  wrapperComp: 'div',

  loading: React.createElement(React.Fragment),

  state: {},

  params: {},

  inDesigner: false,

  factory: () => React.Fragment,
});
