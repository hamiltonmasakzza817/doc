import assign from 'lodash-es/assign';
import cloneDeep from 'lodash-es/cloneDeep';
import concat from 'lodash-es/concat';
import flatten from 'lodash-es/flatten';
import get from 'lodash-es/get';
import map from 'lodash-es/map';
import { DataNode } from '../types/entities';
import { parseJexlExpression, parseJexlExpressionDeep } from '../utils/jexl';
import { ICompContext } from './CompContext';

export const toPx = (value: string | number | undefined) =>
  !Number.isNaN(+(value ?? 'NaN')) ? `${value}px` : value;

export function parseValueDeep(payload: {
  source: any;
  compContext: Pick<ICompContext, 'state' | 'dataBinding' | 'params'>;
  context?: any;
}) {
  const { source, compContext } = payload;

  if (!source) {
    return source;
  }

  const { state, dataBinding } = compContext;

  const context = dataBinding.pathname
    ? get(state, dataBinding.pathname)
    : null;

  return parseJexlExpressionDeep(source, {
    ...state,
    _params: compContext.params,
    _state: state,
    _pathname: dataBinding.pathname,
    _pathnames: dataBinding.pathnames,
    _index: dataBinding.index,
    _indexes: dataBinding.indexes,
    _context: payload.context == null ? context : payload.context,
  });
}

export function parseValue(payload: {
  expression?: string;
  compContext: ICompContext;
  context?: any;
}): any {
  const { expression, compContext } = payload;

  if (!expression) {
    return expression;
  }

  const { state, dataBinding } = compContext;

  const context = dataBinding.pathname
    ? get(state, dataBinding.pathname)
    : null;

  return parseJexlExpression(expression, {
    ...state,
    _params: compContext.params,
    _state: state,
    _context: payload.context == null ? context : payload.context,
    _pathname: dataBinding.pathname,
    _pathnames: dataBinding.pathnames,
    _index: dataBinding?.index,
    _indexes: dataBinding.indexes,
  });
}

export function parsePathname(payload: {
  expression?: string;
  compContext: ICompContext;
}) {
  const {
    expression,
    compContext: { dataBinding },
  } = payload;

  const pathname = expression
    ? (parseValue(payload) as string)
    : dataBinding?.pathname;

  return {
    pathname,
    isContext:
      pathname && dataBinding?.pathname && /^_context\./.test(pathname),
  };
}

export function parseValueByPathname(payload: {
  expression?: string;
  compContext: ICompContext;
}) {
  const { pathname } = parsePathname(payload);
  return pathname ? get(payload.compContext.state, pathname) : null;
}

export function buildTreeData(payload: {
  dataSource?: any[];
  type: 'tree' | 'list';
  childrenKey?: string;
  parentIdKey?: string;
  name?: string;
  names?: string[];
  mpath?: string[];
  value?: string;
  disabled?: string;
  isLeaf?: string;
  pageCompContext: ICompContext;
  pathname?: string;
}): Array<DataNode & { names: string[] }> {
  const {
    dataSource,
    type,
    childrenKey,
    pageCompContext,
    name,
    value,
    disabled,
    pathname = '',
    isLeaf,
  } = payload;

  if (dataSource == null) {
    return [];
  }

  if (type === 'tree' && Array.isArray(dataSource)) {
    return dataSource.map((n, index) => {
      const children = childrenKey ? get(n, childrenKey) : undefined;

      const title = parseValue({
        expression: name,
        compContext: pageCompContext,
        context: n,
      });

      const names = concat(payload.names || [], title);

      const key = `${parseValue({
        expression: value,
        compContext: pageCompContext,
        context: n,
      })}`;

      const mpath = concat(payload.mpath || [], key);

      const path = `${pathname}[${index}]`;

      return {
        key,
        value: key,
        title,
        children: buildTreeData({
          ...payload,
          dataSource: children,
          pathname: `${path}.${childrenKey}`,
          names,
          mpath,
        }),
        disabled: parseValue({
          expression: disabled,
          compContext: pageCompContext,
          context: n,
        }),
        isLeaf: isLeaf
          ? parseValue({
              expression: isLeaf,
              compContext: pageCompContext,
              context: n,
            })
          : undefined,
        pathname: path,
        names,
        mpath,
        index,
      };
    });
  }

  return [];
}

export function getTreeLevelKeys(options: {
  tree?: Array<DataNode>;
  level: number;
  rootLevel?: number;
}): (string | number)[] {
  const { tree, rootLevel = 1, level } = options;

  if (level === rootLevel) {
    return map(tree, (d) => d.key);
  }

  if (level > rootLevel) {
    return flatten(
      map(tree, (d) =>
        concat(
          d.key,
          getTreeLevelKeys({
            tree: d.children,
            level,
            rootLevel: rootLevel + 1,
          }),
        ),
      ),
    );
  }

  return [];
}

export function getPopupContainer(pageCompContext: ICompContext) {
  return () => {
    let container;

    if (pageCompContext.viewportQuerySelector) {
      container = pageCompContext.portal.querySelector(
        pageCompContext.viewportQuerySelector,
      );
    }

    return (container || document.body) as HTMLElement;
  };
}

export function makeParamsToDispatcher(payload: {
  compContext: Pick<ICompContext, 'state' | 'dataBinding' | 'params'>;
  actionContext?: Record<string, unknown>;
  context?: Record<string, unknown>;
  params?: Record<string, unknown>;
}) {
  const { compContext } = payload;

  const { state, dataBinding } = compContext;

  let context =
    payload.context ||
    (dataBinding.pathname ? get(state, dataBinding.pathname) : null);

  const params = {
    contextIndex: dataBinding.index,
    contextPathname: dataBinding.pathname,
    contextPathnames: dataBinding.pathnames,
    contextIndexes: dataBinding.indexes,
    context: cloneDeep(context),
    params: cloneDeep(payload.params),
  };

  if (payload.actionContext) {
    context = assign(
      {},
      context,
      parseValueDeep({
        source: payload.actionContext,
        compContext,
        context,
      }),
    );
  }

  return assign(params, { context: context as Record<string, unknown> });
}
