import { observer, useLocalObservable } from 'mobx-react';
import React from 'react';
import { DesignerStoreContext } from '../contexts/store-contexts';
import DropNodeCursor from './DropNodeCursor';
import FocusingOutline from './FocusingOutline';
import OveringOutline from './OveringOutline';

export default observer(
  (props: { ready: boolean; getContainer?: () => HTMLElement }) => {
    const { ready, getContainer } = props;

    const designerStore = React.useContext(DesignerStoreContext);

    const { focusing, hovering, dropping } = designerStore;

    const localState = useLocalObservable<{
      focusingElement: HTMLElement | null;
      hoveringElement: HTMLElement | null;
      droppingElement: HTMLElement | null;
    }>(() => ({
      focusingElement: null,
      hoveringElement: null,
      droppingElement: null,
    }));

    React.useEffect(() => {
      if (ready) {
        if (focusing) {
          localState.focusingElement = document.querySelector(
            `[data-id="${focusing.id}"]`,
          );
        } else {
          localState.focusingElement = null;
        }

        // window.dispatchEvent(new Event('resize'));
      }
    }, [focusing, ready]);

    React.useEffect(() => {
      if (hovering) {
        localState.hoveringElement = document.querySelector(
          `[data-id="${hovering.config.id}"]`,
        );

        // window.dispatchEvent(new Event('resize'));
      } else {
        localState.hoveringElement = null;
      }
    }, [hovering]);

    React.useEffect(() => {
      if (dropping) {
        localState.droppingElement = document.querySelector(
          `[data-id="${dropping.config.id}"]`,
        );
      } else {
        localState.droppingElement = null;
      }
    }, [dropping]);

    return (
      <>
        {ready && (
          <>
            <DropNodeCursor
              target={localState.droppingElement}
              getContainer={getContainer}
            />

            <FocusingOutline
              target={localState.focusingElement}
              getContainer={getContainer}
            />

            <OveringOutline
              target={localState.droppingElement || localState.hoveringElement}
              getContainer={getContainer}
            />
          </>
        )}
      </>
    );
  },
);
