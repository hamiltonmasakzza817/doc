import classNames from 'classnames';
import concat from 'lodash-es/concat';
import includes from 'lodash-es/includes';
import pick from 'lodash-es/pick';
import size from 'lodash-es/size';
import { observer } from 'mobx-react';
import React from 'react';
import { CompClickable, CompConfig } from '../types/comps-common';
import { DesktopCompType } from '../types/comps-desktop';
import { PageCompType } from '../types/comps-page';
import { getRawPropsKeys } from '../utils/comp';
import CompContext from './CompContext';
import { useActionDispatcher } from './hooks';
import { getCompStyle } from './style';
import { parseValue, parseValueDeep } from './utils';

export default observer((props: { config: CompConfig }) => {
  const { config } = props;

  const compContext = React.useContext(CompContext);

  const display =
    size(config.display) === 0 ||
    !!parseValue({
      expression: config.display,
      compContext,
    });

  if (!display) {
    return null;
  }

  let children;

  if (
    !includes(
      concat<PageCompType | DesktopCompType>(
        PageCompType.REPEAT,
        DesktopCompType.FORM,
        DesktopCompType.TABS,
      ),
      config.type,
    )
  ) {
    children =
      size(config.children) === 0
        ? undefined
        : config.children?.map((cf) =>
            React.createElement(compContext.factoryComp, {
              config: cf,
              key: cf.id,
            }),
          );
  }

  const composeStyle = getCompStyle(config);

  let { className } = composeStyle;
  const { style } = composeStyle;

  const el = compContext.factory(config);

  const dispatchOnClick = useActionDispatcher(
    (config as CompClickable).onClick,
  );

  let onClick;

  if ('onClick' in config) {
    onClick = (e: MouseEvent) => {
      e.stopPropagation();
      e.preventDefault();
      dispatchOnClick();
    };
    className = classNames(className, 'cursor-pointer');
  }

  className = classNames(
    className,
    parseValue({
      expression: config.className,
      compContext,
    }),
  );

  const rawProps = pick(
    parseValueDeep({
      source: config.rawProps,
      compContext,
    }),
    concat(['id', 'className', 'style'], getRawPropsKeys(config.type)),
  );

  return React.createElement(
    compContext.proxyComp,
    {
      config,
      id: config.id,
      onClick,
      className,
      style,
      rawProps,
      el,
    },
    children && concat(children),
  );
});
