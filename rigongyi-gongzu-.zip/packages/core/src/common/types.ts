import React, { CSSProperties, ReactNode } from 'react';
import { CompConfig } from '../types/comps-common';

export type CompProps<T = CompConfig> = {
  id?: string;
  config: T;
  className?: string;
  onClick?: (event: any) => void;
  style?: CSSProperties;
  innerRef?: React.MutableRefObject<any>;
  children?: ReactNode;
  rawProps: Record<string, unknown>;
};
