import assign from 'lodash-es/assign';
import compact from 'lodash-es/compact';
import cloneDeep from 'lodash-es/cloneDeep';
import entries from 'lodash-es/entries';
import every from 'lodash-es/every';
import filter from 'lodash-es/filter';
import find from 'lodash-es/find';
import findIndex from 'lodash-es/findIndex';
import forEach from 'lodash-es/forEach';
import get from 'lodash-es/get';
import includes from 'lodash-es/includes';
import keys from 'lodash-es/keys';
import map from 'lodash-es/map';
import merge from 'lodash-es/merge';
import omit from 'lodash-es/omit';
import pick from 'lodash-es/pick';
import reduce from 'lodash-es/reduce';
import set from 'lodash-es/set';
import some from 'lodash-es/some';
import trim from 'lodash-es/trim';
import concat from 'lodash-es/concat';
import sortBy from 'lodash-es/sortBy';
import groupBy from 'lodash-es/groupBy';
import sum from 'lodash-es/sum';

export default {
  get,
  set,
  includes,
  pick,
  omit,
  cloneDeep,
  assign,
  merge,
  filter,
  every,
  some,
  map,
  reduce,
  entries,
  keys,
  forEach,
  trim,
  find,
  findIndex,
  concat,
  sortBy,
  groupBy,
  compact,
  sum
};
