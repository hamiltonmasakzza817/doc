import React from 'react';
import { EngineStoresContext } from '../contexts/store-contexts';
import { ActionBinding } from '../types/comps-common';
import CompContext from './CompContext';
import CustomCompNav from './CustomCompNav';
import { makeParamsToDispatcher, parseValue } from './utils';

export function useCustomElement(id?: string) {
  const { engineModelStore } = React.useContext(EngineStoresContext);

  const compContext = React.useContext(CompContext);

  if (id == null) {
    return null;
  }

  const comp = engineModelStore.customs[id];

  if (comp) {
    if (compContext.inDesigner) {
      return React.createElement(CustomCompNav, {
        config: comp,
        wrapper: compContext.wrapperComp,
      });
    }

    return React.createElement(compContext.factoryComp, {
      config: comp,
    });
  }

  return null;
}

export function useActionDispatcher(actionBinding?: ActionBinding) {
  const { engineModelStore, engineRuntimeStore, engineStore } =
    React.useContext(EngineStoresContext);

  const compContext = React.useContext(CompContext);

  if (actionBinding != null) {
    const action = engineModelStore.actions[actionBinding.actionId];

    if (action) {
      return (
        params: Record<string, any> = {},
        success?: (v: unknown) => void,
        fail?: (v: unknown) => void,
      ) => {
        if (compContext.inDesigner) {
          return;
        }

        engineRuntimeStore.subscribeAction({
          $action: engineStore.dispatchAction(
            actionBinding.actionId,
            makeParamsToDispatcher({
              compContext,
              actionContext: action.context,
              params,
            }),
          ),
          actionQueueId: actionBinding.actionId,
          success,
          fail,
        });

        // compContext.dispatchAction(
        //   actionBinding.actionId,
        //   makeParamsToDispatcher({
        //     compContext,
        //     actionContext: action.context,
        //     params,
        //   }),
        //   success,
        //   fail,
        // );
      };
    }
  }

  return () => {};
}

export function useParseValue() {
  const compContext = React.useContext(CompContext);

  return (expression?: string) =>
    parseValue({
      expression,
      compContext,
    });
}

export function useParseValueWithContext() {
  const compContext = React.useContext(CompContext);

  return (options: { expression?: string; context?: any }) =>
    parseValue({
      expression: options.expression,
      compContext,
      context: options.context,
    });
}
