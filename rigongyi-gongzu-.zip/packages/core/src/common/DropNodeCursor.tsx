import includes from 'lodash-es/includes';
import { observer } from 'mobx-react';
import React from 'react';
import NodeCursor from '../components/NodeCursor';
import { inlinePageTypes } from '../config/comps';
import { DesignerStoreContext } from '../contexts/store-contexts';

export default observer(
  (props: { target: HTMLElement | null; getContainer?: () => HTMLElement }) => {
    const { target, getContainer } = props;

    const designerStore = React.useContext(DesignerStoreContext);

    const { dropping } = designerStore;

    return (
      <NodeCursor
        size={3}
        className="z-30 absolute"
        target={target}
        getContainer={getContainer}
        display={
          dropping && includes(inlinePageTypes, dropping.config.type)
            ? 'inline'
            : 'block'
        }
        contains={dropping?.contains}
        position={dropping?.position}
      />
    );
  },
);
