import React from 'react';
import { GlobalHotKeys } from 'react-hotkeys';
import usePageCompTools from './usePageCompTools';

export default function ToolsHotKeys(props: {
  handlers?: Record<string, (e: any) => void>;
}) {
  const { handlers = {} } = props;

  const pageCompTools = usePageCompTools();

  return React.createElement(
    GlobalHotKeys,
    {
      keyMap: {
        SAVE: ['command+s', 'ctrl+s'],
        COPY: ['command+c', 'ctrl+c'],
        CUT: ['command+x', 'ctrl+x'],
        PASTE: ['command+v', 'ctrl+v'],
        ROLLBACK: ['command+z', 'ctrl+z'],
        DELETE: ['backspace'],
      },
      handlers: {
        SAVE: pageCompTools.saveModel,
        COPY: pageCompTools.copy,
        CUT: pageCompTools.cut,
        PASTE: pageCompTools.paste,
        DELETE: pageCompTools.delete,
        ROLLBACK: pageCompTools.rollback,
        ...handlers,
      },
    },
    null,
  );
}
