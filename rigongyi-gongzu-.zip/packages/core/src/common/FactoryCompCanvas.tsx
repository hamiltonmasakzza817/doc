import classNames from 'classnames';
import assign from 'lodash-es/assign';
import get from 'lodash-es/get';
import includes from 'lodash-es/includes';
import merge from 'lodash-es/merge';
import pick from 'lodash-es/pick';
import size from 'lodash-es/size';
import { observer } from 'mobx-react';
import React, { CSSProperties, useEffect } from 'react';
import {
  containablePageCompTypes,
  inlinePageTypes,
  pasteInnerCompTypes,
} from '../config/comps';
import { DesignerStoreContext } from '../contexts/store-contexts';
import { CompConfig } from '../types/comps-common';
import { PageCompType } from '../types/comps-page';
import { getRawPropsKeys } from '../utils/comp';
import CompContext from './CompContext';
import { getCompStyle } from './style';
import { parseValue, parseValueDeep } from './utils';

export default observer((props: { config: CompConfig }) => {
  const { config } = props;

  const stashStyle = React.useRef<CSSProperties | null>(null);

  const hasRegistered = React.useRef(false);

  const compContext = React.useContext(CompContext);

  const designerStore = React.useContext(DesignerStoreContext);

  const display = React.useMemo(
    () => (includes(inlinePageTypes, config.type) ? 'inline' : 'block'),
    [config],
  );

  const containable = React.useMemo(
    () => includes(containablePageCompTypes, config.type),
    [config],
  );

  const onlyInner = React.useMemo(
    () => includes(pasteInnerCompTypes, config.type),
    [config],
  );

  const dragDropRef = React.useRef<HTMLDivElement>(null);

  const dragover = React.useCallback((e: DragEvent) => {
    const { dragging } = designerStore;

    if (dragging && dragging.id === config.id) {
      return;
    }

    e.stopPropagation();
    e.preventDefault();

    const dropRect = dragDropRef.current!.getBoundingClientRect();

    designerStore.hoverDropping({
      config,
    });

    if (dropRect) {
      const dimension = display === 'block' ? dropRect.height : dropRect.width;

      const diff =
        display === 'block' ? e.clientY - dropRect.y : e.clientX - dropRect.x;

      const position = diff < dimension / 2 ? 'front' : 'rear';

      designerStore.measureDropping(
        position,
        onlyInner ||
          (containable &&
            diff < (3 / 4) * dimension &&
            diff > (1 / 4) * dimension),
      );
    }
  }, []);

  const dragstart = React.useCallback((e: DragEvent) => {
    e.stopPropagation();
    designerStore.startDragging({
      type: config.type,
      id: config.id,
    });
  }, []);

  const dragend = React.useCallback((e: DragEvent) => {
    e.stopPropagation();
    designerStore.endDragging();
  }, []);

  const drop = React.useCallback((e: DragEvent) => {
    e.stopPropagation();
    designerStore.drop();
    designerStore.endDragging();
  }, []);

  const mouseover = React.useCallback(
    (e: Event) => {
      if (dragDropRef.current) {
        e.stopPropagation();
        e.preventDefault();
        designerStore.hover({
          config,
        });
      }
    },
    [config],
  );

  const click = React.useCallback(
    (event: Event) => {
      event.preventDefault();
      event.stopPropagation();

      if (config !== designerStore.focusing) {
        designerStore.focus(config);
      }
    },
    [config],
  );

  React.useEffect(() => {
    if (dragDropRef.current != null && !hasRegistered.current) {
      hasRegistered.current = true;

      dragDropRef.current.setAttribute('data-id', config.id);
      dragDropRef.current.setAttribute('draggable', 'true');

      dragDropRef.current.addEventListener('dragover', dragover);
      dragDropRef.current.addEventListener('dragstart', dragstart);
      dragDropRef.current.addEventListener('dragend', dragend);
      dragDropRef.current.addEventListener('drop', drop);
      dragDropRef.current.addEventListener('mouseover', mouseover);
    }
  }, [dragDropRef.current]);

  React.useEffect(
    () => () => {
      if (dragDropRef.current) {
        dragDropRef.current.removeEventListener('dragover', dragover);
        dragDropRef.current.removeEventListener('dragstart', dragstart);
        dragDropRef.current.removeEventListener('dragend', dragend);
        dragDropRef.current.removeEventListener('drop', drop);
        dragDropRef.current.removeEventListener('mouseover', mouseover);
      }
    },
    [],
  );


  let children;

  if (![PageCompType.REPEAT].includes(config.type as PageCompType)) {
    children =
      size(config.children) === 0
        ? undefined
        : config.children?.map((cf) =>
            React.createElement(compContext.factoryComp, {
              config: cf,
              key: cf.id,
            }),
          );
  }

  const composeStyle = getCompStyle(config);

  let { className, style } = composeStyle;

  style = merge(style, stashStyle.current);

  useEffect(() => {
    // 若可包含元素的组件没有children，则其高度有可能为零而不可见
    // 进而导致设计模式下无法被选中
    // 因此这里附加一个最小高度和宽度
    if (
      dragDropRef.current != null &&
      includes(containablePageCompTypes, config.type) &&
      get(config, 'renderCompId') == null
    ) {
      const s: CSSProperties = {};


      if (size(config.children) === 0) {
        if (dragDropRef.current) {
          const rect = dragDropRef.current.getBoundingClientRect();

          if (rect.width === 0) {
            s.minWidth = '80px';
          }

          if ((style == null || style.height == null) && rect.height === 0) {
            s.minHeight = '80px';
          }

          s.outline = '1px dashed';
          s.outlineOffset = '-1px';
        }
      } else {
        s.minHeight = '';
        s.minWidth = '';
        s.outline = '';
      }

      merge(dragDropRef.current.style, s);
      stashStyle.current = s;
    }
  }, [
    config.type,
    get(config, 'renderCompId'),
    size(config.children),
    style.height,
  ]);

  const el = compContext.factory(config);

  className = classNames(
    className,
    parseValue({
      expression: config.className,
      compContext,
    }),
  );

  const rawPropKeys = getRawPropsKeys(config.type);

  const rawProps = pick(
    parseValueDeep({
      source: config.rawProps,
      compContext,
    }),
    rawPropKeys,
  );

  return React.createElement(
    compContext.proxyComp,
    assign({
      config,
      id: config.id,
      innerRef: dragDropRef,
      className,
      style,
      onClick: click,
      rawProps,
      el,
    }),
    children,
  );
});
