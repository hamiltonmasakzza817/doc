import classNames from 'classnames';
import { observer } from 'mobx-react';
import React from 'react';
import CompContext from '../common/CompContext';
import { CompProps } from '../common/types';
import { parseValue } from '../common/utils';
import WrapperComp from '../common/WrapperComp';
import { PageCompCustomConfig } from '../types/comps-page';

export default observer((props: CompProps<PageCompCustomConfig>) => {
  const { className, config, innerRef, children, rawProps, ...rest } = props;

  const compContext = React.useContext(CompContext);

  const loading =
    parseValue({
      expression: config.loading,
      compContext,
    }) ?? false;

  return (
    <WrapperComp
      ref={innerRef}
      data-id={config.id}
      className={classNames({ relative: loading }, className)}
      {...rest}
      {...rawProps}
    >
      {children}
    </WrapperComp>
  );
});
