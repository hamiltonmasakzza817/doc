import assign from 'lodash-es/assign';
import compact from 'lodash-es/compact';
import concat from 'lodash-es/concat';
import get from 'lodash-es/get';
import map from 'lodash-es/map';
import size from 'lodash-es/size';
import values from 'lodash-es/values';
import { observer, Observer } from 'mobx-react';
import React from 'react';
import CompContext from '../common/CompContext';
import { CompProps } from '../common/types';
import { parsePathname, parseValue } from '../common/utils';
import { PageCompRepeatConfig } from '../types/comps-page';

export default observer((props: CompProps<PageCompRepeatConfig>) => {
  const { config, innerRef, rawProps, ...rest } = props;

  const compContext = React.useContext(CompContext);

  const { pathname } = parsePathname({
    expression: config.dataSource,
    compContext,
  });

  let contexts = pathname
    ? (get(compContext.state, pathname) as Record<string, unknown>[])
    : [];

  if (size(contexts) === 0 && compContext.inDesigner) {
    contexts = [{}];
  }

  if (size(compact(values(contexts))) === 0) {
    return <></>;
  }

  return (
    <div ref={innerRef} {...rest} data-id={config.id} {...rawProps}>
      {map(contexts, (context, index: number | string) => {
        const key = parseValue({
          expression: config.key,
          compContext,
          context,
        });

        const pathnameCurr = `${pathname}${
          typeof index === 'number' ? `[${index}]` : `.${index}`
        }`;

        const { dataBinding } = compContext;

        return (
          <CompContext.Provider
            value={assign({}, compContext, {
              dataBinding: {
                ...dataBinding,
                pathname: pathnameCurr,
                pathnames: compact(
                  concat(pathnameCurr, pathname, dataBinding.pathnames),
                ),
                index,
                indexes: concat(index, dataBinding.indexes)
              },
            })}
            key={key == null ? index : key}
          >
            <Observer>
              {() => (
                <>
                  {config.children?.map((child) => {
                    if (compContext.factoryComp) {
                      return React.createElement(compContext.factoryComp, {
                        key: child.id,
                        config: child,
                      });
                    }

                    return <></>;
                  })}
                </>
              )}
            </Observer>
          </CompContext.Provider>
        );
      })}
    </div>
  );
});
