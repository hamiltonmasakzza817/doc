import { observer } from 'mobx-react';
import React from 'react';
import CompContext from '../common/CompContext';
import { CompProps } from '../common/types';

export default observer((props: CompProps<any>) => {
  const { config, innerRef, children, rawProps, ...rest } = props;

  const compContext = React.useContext(CompContext);

  return React.createElement(
    compContext.wrapperComp,
    {
      ...rest,
      ref: innerRef,
      ...rawProps,
    },
    children,
  );
});
