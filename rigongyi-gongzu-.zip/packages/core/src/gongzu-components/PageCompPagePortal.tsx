import classNames from 'classnames';
import compact from 'lodash-es/compact';
import concat from 'lodash-es/concat';
import includes from 'lodash-es/includes';
import { runInAction } from 'mobx';
import { observer, useLocalObservable } from 'mobx-react';
import React from 'react';
import Central from '../common/Central';
import CompContext from '../common/CompContext';
import { CompProps } from '../common/types';
import useCompPortal from '../common/useCompPortal';
import { parseValue, parseValueDeep } from '../common/utils';
import WrapperComp from '../common/WrapperComp';
import { gzdnBem } from '../config/constants';
import {
  BaseStoresContext,
  EngineStoresContext,
  PlayerStoreContext,
} from '../contexts/store-contexts';
import EngineStore from '../engine/EngineStore';
import PlayerStore from '../stores/PlayerStore';
import { PageCompPagePortalConfig } from '../types/comps-page';

const PageCompPagePortalContent = observer((props: { pageKey: string }) => {
  const { pageKey } = props;

  const {
    engineStore,
    engineModelStore,
    engineRuntimeStore: { eventEmitter },
  } = React.useContext(EngineStoresContext);

  const pageViewerStore = React.useContext(PlayerStoreContext);

  const compContext = useCompPortal(engineStore);

  const localState = useLocalObservable(() => ({ ready: false }));

  React.useEffect(() => {
    pageViewerStore.init().subscribe(() => {
      engineStore.loadCssResources();
      runInAction(() => {
        localState.ready = true;
      });
    });
  }, []);

  const { elements, modals } = engineModelStore;

  const { factoryComp } = compContext;

  const pageIds = compact(concat(compContext.pageIds, engineStore.page.id));

  return !localState.ready ? (
    compContext.loading
  ) : (
    <React.Fragment key={pageKey}>
      {factoryComp && elements != null && elements.length > 0 ? (
        <CompContext.Provider
          value={{
            ...compContext,
            pageIds,
            eventEmitter,
          }}
        >
          <>
            {elements[0] != null &&
              React.createElement(factoryComp, {
                config: elements[0],
                key: '1',
              })}

            {modals.map((modal) =>
              React.createElement(factoryComp, {
                config: modal,
                key: modal.id,
              }),
            )}
          </>
        </CompContext.Provider>
      ) : (
        <Central>
          <WrapperComp>无权限或未加载到数据</WrapperComp>
        </Central>
      )}
    </React.Fragment>
  );
});

const PageCompPagePortal = observer(
  (props: {
    pageId: string;
    pageUrl?: string;
    pageKey: string;
    params?: any;
  }) => {
    const { pageKey, params, pageId, pageUrl } = props;

    const { streamStore, loggerStore, messageStore, pageStore } =
      React.useContext(BaseStoresContext);

    const {
      engineRuntimeStore: { eventEmitter },
      engineStore
    } = React.useContext(EngineStoresContext);

    const compContext = React.useContext(CompContext);

    const state = useLocalObservable<{
      playerStore: PlayerStore | null;
      loading: boolean;
    }>(() => ({
      playerStore: null,
      loading: true,
    }));

    React.useEffect(() => {
      const { playerStore } = state;

      if (
        playerStore &&
        (playerStore.engineStore.page.id === pageId ||
          playerStore.engineStore.page.url === pageUrl)
      ) {
        playerStore.init().subscribe();
        return;
      }

      runInAction(() => {
        state.loading = true;
        state.playerStore = null;
      });

      pageStore
        .fetchPage({ id: pageId, url: pageUrl }, 'publish')
        .subscribe((page) => {
          if (page) {
            const engineStore1 = new EngineStore(
              {
                page,
                params,
                portal: compContext.portal,
                inPagePortal: true,
                eventEmitter,
              },
              loggerStore,
              messageStore,
              engineStore.codeInterpreter,
              engineStore.router
            );

            state.playerStore = new PlayerStore(engineStore1, streamStore);
          }

          runInAction(() => {
            state.loading = false;
          });
        });
    }, [pageId, pageUrl]);

    React.useEffect(() => {
      const { playerStore } = state;

      if (playerStore) {
        playerStore.updateParams(params);
      }
    });

    if (state.loading) {
      return compContext.loading;
    }

    if (state.playerStore == null) {
      return <Central>未获取到页面模型</Central>;
    }

    const { engineStore: playerEngineStore } = state.playerStore;

    const {
      engineModelStore,
      engineRuntimeStore,
      engineFormStore,
      engineDataStore,
      engineActionStore,
      engineEventStore,
    } = playerEngineStore;

    return (
      <WrapperComp data-viewport={playerEngineStore.page.id}>
        <PlayerStoreContext.Provider value={state.playerStore}>
          <EngineStoresContext.Provider
            value={{
              engineStore: playerEngineStore,
              engineDataStore,
              engineActionStore,
              engineRuntimeStore,
              engineModelStore,
              engineFormStore,
              engineEventStore,
            }}
          >
            <PageCompPagePortalContent pageKey={pageKey} />
          </EngineStoresContext.Provider>
        </PlayerStoreContext.Provider>
      </WrapperComp>
    );
  },
);

// 传送门组件
export default observer((props: CompProps<PageCompPagePortalConfig>) => {
  const { config, innerRef, className, ...rest } = props;

  const pageCompContextRoot = React.useContext(CompContext);

  const pageId = parseValue({
    expression: config.pageId,
    compContext: pageCompContextRoot,
  });

  const pageUrl = parseValue({
    expression: config.pageUrl,
    compContext: pageCompContextRoot,
  });

  const key =
    parseValue({
      expression: config.key,
      compContext: pageCompContextRoot,
    }) || pageId;

  const params = parseValueDeep({
    source: config.params,
    compContext: pageCompContextRoot,
  });

  let message;

  if (!pageId && !pageUrl) {
    message = '空页面';
  } else if (pageId && includes(pageCompContextRoot.pageIds, pageId)) {
    message = `页面循环依赖，请检查, Id: ${pageId}`;
  } else if (pageCompContextRoot.inDesigner) {
    message = `页面传送门， Id: ${pageId || '--'}, URL: ${pageUrl || '--'}`;
  }

  if (message) {
    return (
      <WrapperComp
        className={classNames(gzdnBem('empty-block')(), className)}
        ref={innerRef}
        {...rest}
      >
        {message}
      </WrapperComp>
    );
  }

  return (
    <WrapperComp className={className} {...rest}>
      <PageCompPagePortal
        pageKey={key || pageId}
        params={params}
        pageId={pageId}
        pageUrl={pageUrl}
      />
    </WrapperComp>
  );
});
