import React from 'react';
import EngineActionStore from '../engine/EngineActionStore';
import EngineDataStore from '../engine/EngineDataStore';
import EngineEventStore from '../engine/EngineEventStore';
import EngineFormStore from '../engine/EngineFormStore';
import EngineModelStore from '../engine/EngineModelStore';
import EngineRuntimeStore from '../engine/EngineRuntimeStore';
import EngineStore from '../engine/EngineStore';
import DesignerStore from '../stores/DesignerStore';
import LoggerStore from '../stores/LoggerStore';
import MessageStore from '../stores/MessageStore';
import PageStore from '../stores/PageStore';
import PlayerStore from '../stores/PlayerStore';
import SessionStore from '../stores/SessionStore';
import StreamStore from '../stores/StreamStore';

export const BaseStoresContext = React.createContext<{
  streamStore: StreamStore;
  loggerStore: LoggerStore;
  messageStore: MessageStore;
  sessionStore: SessionStore;
  pageStore: PageStore;
  // @ts-ignore
}>({});

// @ts-ignore
export const DesignerStoreContext = React.createContext<DesignerStore>(null);

export const PlayerStoreContext =
  // @ts-ignore
  React.createContext<PlayerStore>(null);

export const EngineStoresContext = React.createContext<{
  engineStore: EngineStore;
  engineActionStore: EngineActionStore;
  engineEventStore: EngineEventStore;
  engineDataStore: EngineDataStore;
  engineFormStore: EngineFormStore;
  engineModelStore: EngineModelStore;
  engineRuntimeStore: EngineRuntimeStore;
  // @ts-ignore
}>({});

export default {};
