import assignWith from 'lodash-es/assignWith';

export function composeSkipNull<T1, T2>(object: T1, source: T2) {
  return assignWith<Record<string, unknown>, T1, T2>(
    {},
    object,
    source,
    (a, b) => (a === undefined ? b : a),
  );
}
