import cloneDeep from 'lodash-es/cloneDeep';
import findIndex from 'lodash-es/findIndex';
import get from 'lodash-es/get';
import set from 'lodash-es/set';
import { v4 as uuidv4 } from 'uuid';
import { TreeNode } from '../types/entities';
import { findTreeNode, walkTree } from './tree';

export function normalizeConfig<T = Record<string, unknown>>(options: {
  config: TreeNode<T>;
  parent?: TreeNode<T>;
  parentId?: string;
  rootConfig?: TreeNode<T>[];
  reserveId?: boolean;
}) {
  const { config, parentId, reserveId = false, rootConfig } = options;

  let { parent } = options;

  if (parent == null) {
    parent = findTreeNode(rootConfig || [], 'id', parentId);
  }

  walkTree([config], (node, p) => {
    const id = reserveId ? node.id : uuidv4();

    // eslint-disable-next-line no-param-reassign
    node.id = id;
    // eslint-disable-next-line no-param-reassign
    node.parentId = p ? p.id : parent?.id;

    let pathname;

    if (p?.pathname) {
      pathname = `${p.pathname},${id}`;
    } else if (parent) {
      pathname = `${parent.pathname},${id}`;
    } else {
      pathname = `${id}`;
    }

    // eslint-disable-next-line no-param-reassign
    node.pathname = pathname;
  });

  return config;
}

/**
 * 规范化 tree node，为期更新 pathname 和 id
 * @param options
 */
export function normalizeTreeNode<T = Record<string, unknown>>(options: {
  config: TreeNode<T>;
  parent?: TreeNode<T>;
  generateId?: boolean;
}) {
  const { config, parent, generateId = false } = options;

  walkTree([config], (node, p) => {
    const id = generateId ? uuidv4() : node.id;

    // eslint-disable-next-line no-param-reassign
    node.id = id;
    // eslint-disable-next-line no-param-reassign
    node.parentId = p ? p.id : parent?.id;

    let pathname;

    if (p?.pathname) {
      pathname = `${p.pathname},${id}`;
    } else if (parent) {
      pathname = `${parent.pathname},${id}`;
    } else {
      pathname = `${id}`;
    }

    // eslint-disable-next-line no-param-reassign
    node.pathname = pathname;
  });

  return config;
}

/**
 * 移动节点，并返回回滚函数队列
 * @param options
 */
export function moveTreeNode<T = Record<string, unknown>>(options: {
  source: TreeNode<T>;
  getTree: () => TreeNode<T>[];
  remove?: boolean;
  insertParentId?: string;
  insertIndex?: number;
}) {
  const {
    getTree,
    remove = false,
    insertParentId,
    insertIndex,
  } = options;

  let { source } = options;

  const rollbacks: (() => void)[] = [];

  const tree = getTree();

  const sourceParent = findTreeNode(tree, 'id', source.parentId);

  const isPeer = insertParentId === sourceParent?.id;

  const sourceIndex = findIndex(sourceParent?.children ?? tree, (n) => n.id === source.id);

  if (remove) {
    const bak = cloneDeep(source);

    if (sourceIndex !== -1) {
      rollbacks.push(() => {
        const p = findTreeNode(getTree(), 'id', bak.parentId);
        if (p && p.children) {
          p.children.splice(
            (isPeer && remove && insertIndex != null && sourceIndex > insertIndex)
              ? sourceIndex + 1 : sourceIndex,
            0,
            bak
          );
        }
      });

      (sourceParent?.children ?? tree)!.splice(sourceIndex, 1);
    }
  }

  if (insertIndex != null) {
    const parent = insertParentId
      ? findTreeNode(tree, 'id', insertParentId)
      : undefined;

    source = normalizeTreeNode({
      parent,
      config: cloneDeep(source),
      generateId: !remove, // 无需移除的场景，意味着需要新的 id
    });

    if (parent && parent.children == null) {
      set(parent, 'children', []);
    }

    rollbacks.push(() => {
      const p = insertParentId
        ? findTreeNode(getTree(), 'id', insertParentId)
        : undefined;

      if (p && p.children) {
        p.children.splice(insertIndex, 1);
      } else {
        getTree().splice(insertIndex, 1);
      }
    });

    const dynamicInsertIndex = (isPeer && remove && sourceIndex < insertIndex)
      ? insertIndex - 1
      : insertIndex;

    (parent?.children ?? tree).splice(dynamicInsertIndex, 0, source);

    source = get(parent?.children ?? tree, `[${dynamicInsertIndex}]`);
  }

  return { rollbacks, result: source };
}
