import dayjs from 'dayjs';
import assign from 'lodash-es/assign';
import compact from 'lodash-es/compact';
import transform from 'lodash-es/transform';

import { Schema, SchemaDataType } from '../types/entities';

export interface SchemaTreeNode {
  code: string;
  pathname: string;
  key: string;
  dataType: SchemaDataType;
  children?: SchemaTreeNode[];
  multiple: boolean;
}

export function buildSchema(
  schemaTreeNode?: SchemaTreeNode,
): Schema | undefined {
  if (schemaTreeNode == null) {
    return undefined;
  }

  const isArray = schemaTreeNode.multiple;

  const dataType = isArray
    ? SchemaDataType.JSON_ARRAY
    : schemaTreeNode.dataType;

  if (isArray) {
    return {
      dataType,
      child: buildSchema({
        ...schemaTreeNode,
        multiple: false,
      }),
    };
  }

  return assign(
    {
      dataType,
    },
    isArray || schemaTreeNode.children == null
      ? undefined
      : {
          properties: transform(
            compact(schemaTreeNode.children),
            (result, value) => {
              const schema = buildSchema(value);

              if (schema) {
                // eslint-disable-next-line no-param-reassign
                result[value.code] = schema;
              }
            },
            {} as Record<string, Schema>,
          ),
        },
  );
}

export function buildSchemaTree(payload: {
  schema: Schema;
  pathname: string;
  key: string;
  multiple?: boolean;
}): SchemaTreeNode | null {
  const { schema, pathname, key, multiple = false } = payload;

  if (schema == null) {
    return null;
  }

  const { dataType, child, properties } = schema;

  if (child) {
    return buildSchemaTree({
      schema: child,
      pathname,
      key,
      multiple: true,
    });
  }

  const paths = pathname.split('.');

  const node: SchemaTreeNode = {
    code: paths.slice(-1)[0],
    pathname,
    dataType,
    multiple,
    key,
  };

  if (properties) {
    node.children = compact(
      Object.entries(properties).map(([code, property], index) =>
        buildSchemaTree({
          schema: property,
          pathname: `${pathname}${multiple ? `[0]` : ''}.${code}`,
          key: `${key}.children[${index}]`,
          multiple: false,
        }),
      ),
    );
  }

  return node;
}

export function buildSchemaSampleData(schema: Schema): any {
  const { dataType, child, properties } = schema;

  if (child) {
    return [buildSchemaSampleData(child)];
  }

  if (properties) {
    return transform(
      properties,
      (result, value, key) => {
        // eslint-disable-next-line no-param-reassign
        result[key] = buildSchemaSampleData(value);
      },
      {} as Record<string, unknown>,
    );
  }

  switch (dataType) {
    case SchemaDataType.BOOLEAN: {
      return false;
    }

    case SchemaDataType.DATE: {
      return dayjs().format('YYYY-MM-DD');
    }

    case SchemaDataType.DECIMAL:
    case SchemaDataType.DOUBLE:
    case SchemaDataType.INTEGER: {
      return 0;
    }

    case SchemaDataType.STRING: {
      return '';
    }

    default: {
      return null;
    }
  }
}
