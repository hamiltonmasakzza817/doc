import concat from 'lodash-es/concat';
import get from 'lodash-es/get';
import includes from 'lodash-es/includes';
import values from 'lodash-es/values';
import rawPropsDesktop, {
  rawPropsDesktopCommon,
} from '../common/raw-props-desktop';
import rawPropsMobile, { rawPropsMobileCommon } from '../common/raw-props-mobile';
import rawPropsPage from '../common/raw-props-page';
import rawPropsTaro, { rawPropsTaroCommon } from '../common/raw-props-taro';
import { CompsAll } from '../types/comps-all';
import { DesktopCompType } from '../types/comps-desktop';
import { MobileCompType } from '../types/comps-mobile';
import { PageCompType } from '../types/comps-page';
import { TaroCompType } from '../types/comps-taro';
import { PagePlatform } from '../types/entities';

export function isPageComp(type: CompsAll) {
  return includes(values(PageCompType), type);
}

export function isDesktopComp(type: CompsAll) {
  return includes(values(DesktopCompType), type);
}

export function isMobileComp(type: CompsAll) {
  return includes(values(MobileCompType), type);
}

export function isTaroComp(type: CompsAll) {
  return includes(values(TaroCompType), type);
}

export function allowCssInJs(platform: PagePlatform) {
  return [PagePlatform.PC, PagePlatform.MOBILE].includes(platform);
}

export function getRawPropsKeys(type: CompsAll) {
  if (isPageComp(type)) {
    return rawPropsPage;
  }

  if (isDesktopComp(type)) {
    return concat(rawPropsDesktopCommon, get(rawPropsDesktop, type) || []);
  }

  if (isMobileComp(type)) {
    return concat(rawPropsMobileCommon, get(rawPropsMobile, type) || []);
  }

  if (isTaroComp(type)) {
    return concat(rawPropsTaroCommon, get(rawPropsTaro, type) || []);
  }

  return [];
}
