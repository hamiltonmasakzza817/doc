import dayjs from 'dayjs';
import jexl from 'jexl';
import assign from 'lodash-es/assign';
import ceil from 'lodash-es/ceil';
import cloneDeep from 'lodash-es/cloneDeep';
import concat from 'lodash-es/concat';
import find from 'lodash-es/find';
import findIndex from 'lodash-es/findIndex';
import floor from 'lodash-es/floor';
import get from 'lodash-es/get';
import includes from 'lodash-es/includes';
import join from 'lodash-es/join';
import map from 'lodash-es/map';
import size from 'lodash-es/size';
import slice from 'lodash-es/slice';
import split from 'lodash-es/split';
import toLower from 'lodash-es/toLower';
import toUpper from 'lodash-es/toUpper';
import sum from 'lodash-es/sum';
import transform from 'lodash-es/transform';

import numeral from 'numeral';
import XRegExp from 'xregexp';
import lodashUtils from '../common/lodash-utils';

import xregexpLookbehind from './xregexpLookbehind2';

xregexpLookbehind(XRegExp);

jexl.addTransform('date', (val, formatter = 'YYYY-MM-DD') =>
  val ? dayjs(val).format(formatter) : dayjs().format(formatter),
);

jexl.addTransform('moment', (val) => dayjs(val));

jexl.addTransform('size', (val) => size(val));
jexl.addTransform('sum', (val) => sum(val));
jexl.addTransform('get', (val, key) => get(val, key));
jexl.addTransform('concat', (val, source) => concat(val, source));
jexl.addTransform('clone', (val) => cloneDeep(val));
jexl.addTransform('ceil', (val, precision = 0) => ceil(val, +precision));
jexl.addTransform('floor', (val, precision = 0) => floor(val, +precision));
jexl.addTransform('upper', (val) => toUpper(val));
jexl.addTransform('lower', (val) => toLower(val));
jexl.addTransform('split', (val, source) => split(val, source));
jexl.addTransform('includes', (val, source) => includes(val, source));

jexl.addTransform('numeral', (val, formatter: '') =>
  numeral(val ?? 0).format(formatter),
);
jexl.addTransform('slice', (val, start, end) => slice(val, start ?? 0, end));
jexl.addTransform('findIndex', (val: any, source: any[], key = null) =>
  findIndex(source, (item) =>
    key == null ? item === val : get(item, key) === val,
  ),
);
jexl.addTransform('find', (val: any, source: any[], key = null) =>
  find(source, (item) => (key == null ? item === val : get(item, key) === val)),
);

jexl.addTransform('jsonStringify', (val) => JSON.stringify(val));
jexl.addTransform('jsonParse', (val) => JSON.parse(val));

jexl.addTransform('test', (val, regExp) => {
  try {
    const r = new RegExp(regExp);
    return r.test(val);
  } catch (e) {
    return false;
  }
});

jexl.addTransform('map', (val, pathname) => map(val, (v) => get(v, pathname)));

jexl.addTransform('join', (val, separator) => join(val, separator));

jexl.addTransform('_', (val, func, ...rest) =>
  get(lodashUtils, func)(val, ...rest),
);

export function parseJexlExpression(expression: string, context: any) {
  if (!expression) {
    return expression;
  }

  if (!/\${|\\}|\$\\{/.test(expression)) {
    return expression;
  }

  let exp = `'${expression}'`.replace(/\${/g, `'+(`);

  // eslint-disable-next-line @typescript-eslint/ban-ts-comment
  // @ts-ignore
  exp = XRegExp.replaceLb(exp, '(?<!\\\\)', /}/g, `)+'`);

  exp = exp
    .replace(/\\}/g, '}')
    .replace(/\$\\{/g, '${')
    .replace(/^''\+|\+''$/g, '');

  let res;

  try {
    res = jexl.evalSync(exp, assign({}, context));
  } catch (e) {
    res = null;
  }

  return res;
}

export function parseJexlExpressionDeep(
  source: any,
  context: Record<string, unknown>,
): any {
  if (!source) {
    return source;
  }

  if (Array.isArray(source)) {
    return transform(
      source,
      (result: any, n) => result.push(parseJexlExpressionDeep(n, context)),
      [],
    );
  }

  if (typeof source === 'object') {
    return transform(
      source,
      (result: any, value, key: string) => {
        // eslint-disable-next-line no-param-reassign
        result[parseJexlExpression(key, context)] = parseJexlExpressionDeep(
          value,
          context,
        );
      },
      {},
    );
  }

  if (typeof source === 'string') {
    return parseJexlExpression(source, context);
  }

  return source;
}
