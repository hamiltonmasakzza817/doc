import forEach from 'lodash-es/forEach';
import get from 'lodash-es/get';
import omit from 'lodash-es/omit';
import set from 'lodash-es/set';
import size from 'lodash-es/size';
import sortBy from 'lodash-es/sortBy';
import unionWith from 'lodash-es/unionWith';
import { IdTreeNode, TreeNode } from '../types/entities';

export function walkTree<T extends { [key: string]: unknown }, P>(
  treeNodes: T[],
  walk: (node: T, parent?: T | null, payload?: P) => P | undefined | void,
  childrenKey = 'children',
  parent: T | null = null,
  payload?: P,
): void {
  if (!Array.isArray(treeNodes)) {
    return;
  }

  for (let i = 0; i < treeNodes.length; i += 1) {
    const node = treeNodes[i];
    const p = walk(node, parent, payload);

    const children = node[childrenKey] as T[];

    if (size(children) > 0) {
      walkTree(children, walk, childrenKey, node, p as P);
    }
  }
}

export function treeToArray<
  T extends { [key: string]: any },
  R extends T & { path: string[]; parentId: string; children: string[] },
>(nodes: T[], key = 'id', childrenKey = 'children', path: string[] = []): R[] {
  if (nodes == null || nodes.length === 0) {
    return [];
  }

  return nodes.reduce((p: R[], treeNode) => {
    const children = (treeNode[childrenKey] as T[]) || [];
    const nodePath = [...path, treeNode[key] as string];

    const r = {
      ...omit(treeNode, [childrenKey]),
      children: children.map((cn) => cn[key] as string),
      path: nodePath,
      parentId: path[path.length - 1],
    } as R;

    const c = treeToArray(children, key, childrenKey, nodePath) as R[];

    return [...p, r, ...c];
  }, []);
}

export function mapTreeNode<
  T extends { [key: string]: any },
  R extends { children?: R[] },
>(
  treeNodes: T[],
  mapper: (node: T, parent: R | null, index: number) => R,
  childrenKey = 'children',
  parent: R | null = null,
): R[] {
  const ps: R[] = [];

  for (let i = 0; i < treeNodes.length; i += 1) {
    const t = treeNodes[i];

    const p = mapper(t, parent, i);

    if (p) {
      const children = t[childrenKey] as T[];

      if (children && children.length > 0) {
        p.children = mapTreeNode(children, mapper, childrenKey, p);
      }
    }

    ps.push(p);
  }

  return ps.filter((s) => s != null);
}

export function filterTree<T extends Record<string, unknown>>(
  treeNodes: T[],
  filter: (node: T) => boolean,
  childrenKey = 'children',
): TreeNode<T>[] {
  const result: TreeNode<T>[] = [];

  forEach(treeNodes, (node) => {
    if (filter(node)) {
      const node1 = omit(node, [childrenKey]);

      const children = get(node, childrenKey) as TreeNode<T>[];

      if (children) {
        set(node1, childrenKey, filterTree(children, filter, childrenKey));
      }

      result.push(node1 as TreeNode<T>);
    }
  });

  return result;
}

export function findTreeNode<T>(
  treeNodes: T[],
  key: keyof T,
  value: unknown,
  childrenKey = 'children',
): T | undefined {
  for (let i = 0; i < treeNodes.length; i += 1) {
    const node = treeNodes[i];

    if (node[key] === value) {
      return node;
    }

    const children = get(node, childrenKey) as T[];

    if (size(children) > 0) {
      const child = findTreeNode(children, key, value, childrenKey);

      if (child) {
        return child;
      }
    }
  }

  return undefined;
}

export function findTreeNodeBy<T extends Record<string, unknown>>(
  treeNodes: T[],
  iteratee: (node: T) => boolean,
  childrenKey = 'children',
): T | null {
  for (let i = 0; i < treeNodes.length; i += 1) {
    const node = treeNodes[i];

    if (iteratee(node)) {
      return node;
    }

    const children = get(node, childrenKey) as T[];

    if (size(children) > 0) {
      const child = findTreeNodeBy(children, iteratee, childrenKey);

      if (child) {
        return child;
      }
    }
  }

  return null;
}

export function idTreeNodeMapToTree(
  rootNodes: IdTreeNode[],
  map: Record<string, TreeNode>,
  key: 'id' | 'pathname' = 'id',
): TreeNode[] {
  return rootNodes.map((idTreeNode) => {
    const node = get(map, idTreeNode[key] as string);

    if (idTreeNode.children) {
      return {
        ...node,
        children: idTreeNodeMapToTree(idTreeNode.children, map, key),
      };
    }
    return node;
  });
}

export function idTreeNodeMapToIdTree(
  rootNodes: IdTreeNode[],
  map: Record<string, IdTreeNode>,
  key: 'id' | 'pathname' = 'id',
): IdTreeNode[] {
  return rootNodes.map((node) => {
    if (node.children) {
      return {
        ...node,
        children: idTreeNodeMapToIdTree(
          node.children.map((c) => map[c[key]!]),
          map,
          key,
        ),
      };
    }
    return node;
  });
}

export function combineIdTreeNode(
  source: IdTreeNode[][],
  key: 'id' | 'pathname' = 'id',
): IdTreeNode[] {
  const map: Record<string, IdTreeNode> = {};

  source.forEach((tree) => {
    walkTree(tree, (node) => {
      const exist = map[node[key]!];

      if (exist) {
        exist.children = unionWith(
          exist.children,
          node.children,
          (a, b) => a[key] === b[key],
        );
      } else {
        map[node[key]!] = { ...node };
      }
    });
  });

  return idTreeNodeMapToIdTree(
    sortBy(
      Object.values(map).filter((node) => node.level === 1),
      ['showOrder'],
    ),
    map,
    key,
  );
}
