import { v4 as uuidv4 } from 'uuid';
import { CompsAll } from '../types/comps-all';
import {
  CompConfig,
  CompFormItem,
  CompFormItemWithOptions,
  TextAlign,
  TimeUnit,
} from '../types/comps-common';
import {
  DesktopCompButtonConfig,
  DesktopCompConfig,
  DesktopCompContainerConfig,
  DesktopCompDatePickerConfig,
  DesktopCompDropdownMenuConfig,
  DesktopCompFormConfig,
  DesktopCompFormItemContainerConfig,
  DesktopCompIconConfig,
  DesktopCompImageConfig,
  DesktopCompMarkdownConfig,
  DesktopCompMenuConfig,
  DesktopCompParagraphConfig,
  DesktopCompSliderConfig,
  DesktopCompStepsConfig,
  DesktopCompTableConfig,
  DesktopCompTabsConfig,
  DesktopCompTagConfig,
  DesktopCompTransferConfig,
  DesktopCompTreeConfig,
  DesktopCompTreeSelectConfig,
  DesktopCompType,
  DesktopCompUploaderConfig,
} from '../types/comps-desktop';
import {
  MobileCompButtonConfig,
  MobileCompConfig,
  MobileCompContainerConfig,
  MobileCompDatePickerConfig,
  MobileCompFormItem,
  MobileCompFormItemConfig,
  MobileCompListItemConfig,
  MobileCompSegmentConfig,
  MobileCompSwiperConfig,
  MobileCompTabPanelConfig,
  MobileCompTabsConfig,
  MobileCompTagConfig,
  MobileCompType,
  MobileCompUploaderConfig,
} from '../types/comps-mobile';
import {
  PageCompBlockConfig,
  PageCompHyperlinkConfig,
  PageCompTextConfig,
  PageCompType,
  PageCompUmdCompConfig,
} from '../types/comps-page';
import {
  TaroCompBooleanItemConfig,
  TaroCompButtonConfig,
  TaroCompConfig,
  TaroCompDatePickerConfig,
  TaroCompFormItem,
  TaroCompListItemConfig,
  TaroCompNavContainerConfig,
  TaroCompSwiperConfig,
  TaroCompType,
} from '../types/comps-taro';
import { PagePlatform } from '../types/entities';
import { isDesktopComp, isMobileComp, isPageComp, isTaroComp } from './comp';

export function createIndelibleContainer(
  parent: CompConfig,
  platform: PagePlatform,
): CompConfig {
  const containerId = uuidv4();

  const containerConfig = {
    id: containerId,
    indelible: true,
    parentId: parent.id,
    pathname: `${parent.pathname},${containerId}`,
  } as CompConfig;

  let container = containerConfig;

  switch (platform) {
    case PagePlatform.PC: {
      // eslint-disable-next-line @typescript-eslint/no-use-before-define
      container = createDesktopComp(DesktopCompType.CONTAINER, {
        ...containerConfig,
        type: DesktopCompType.CONTAINER,
      });
      break;
    }

    case PagePlatform.MOBILE: {
      // eslint-disable-next-line @typescript-eslint/no-use-before-define
      container = createMobileComp(MobileCompType.CONTAINER, {
        ...containerConfig,
        type: MobileCompType.CONTAINER,
      });
      break;
    }

    case PagePlatform.TARO: {
      // eslint-disable-next-line @typescript-eslint/no-use-before-define
      container = createTaroComp(TaroCompType.CONTAINER, {
        ...containerConfig,
        type: TaroCompType.CONTAINER,
      });
      break;
    }

    default: {
      break;
    }
  }

  return container;
}

export function createDesktopComp(
  type: DesktopCompType,
  config: CompConfig,
): DesktopCompConfig {
  const formItemConfig = {
    ...config,
    label: {
      text: '字段',
    },
    value: `\${_pathname}.`,
  } as DesktopCompConfig & CompFormItem;

  switch (type) {
    case DesktopCompType.PARAGRAPH: {
      return {
        ...config,
        text: '段落文字',
      } as DesktopCompParagraphConfig;
    }

    case DesktopCompType.TABLE: {
      return {
        ...config,
        columns: [],
      } as DesktopCompTableConfig;
    }

    case DesktopCompType.BUTTON: {
      return {
        ...config,
        text: '确定',
      } as DesktopCompButtonConfig;
    }

    case DesktopCompType.FORM: {
      return {
        ...config,
        label: {
          align: TextAlign.LEFT,
          width: 80,
        },
      } as DesktopCompFormConfig;
    }

    case DesktopCompType.INPUT:
    case DesktopCompType.TEXT_AREA:
    case DesktopCompType.NUMBER_INPUT:
    case DesktopCompType.RADIO:
    case DesktopCompType.CHECKBOX:
    case DesktopCompType.SWITCH:
    case DesktopCompType.CASCADER:
    case DesktopCompType.SELECT: {
      return formItemConfig;
    }

    case DesktopCompType.SLIDER: {
      return {
        ...formItemConfig,
        max: 100,
        min: 0,
      } as DesktopCompSliderConfig;
    }

    case DesktopCompType.FORM_ITEM_CONTAINER: {
      return {
        ...formItemConfig,
        children: [createIndelibleContainer(config, PagePlatform.PC)],
      } as DesktopCompFormItemContainerConfig;
    }

    case DesktopCompType.DATE_PICKER: {
      return {
        ...formItemConfig,
        timeUnit: TimeUnit.DATE,
      } as DesktopCompDatePickerConfig;
    }

    case DesktopCompType.TREE_SELECT: {
      return {
        ...formItemConfig,
        options: {
          dataSourceType: 'tree',
          childrenKey: 'children',
          name: `$\{_context.name}`,
          value: `$\{_context.id}`,
        },
      } as DesktopCompTreeSelectConfig;
    }

    case DesktopCompType.UPLOADER: {
      const container = createIndelibleContainer(config, PagePlatform.PC);
      const buttonId = uuidv4();

      return {
        ...formItemConfig,
        formatter: `$\{_context.url}`,
        children: [
          {
            ...container,
            children: [
              {
                id: buttonId,
                parentId: container.id,
                pathname: `${container.pathname},${buttonId}`,
                type: DesktopCompType.BUTTON,
                text: '上传',
              } as DesktopCompButtonConfig,
            ],
          } as DesktopCompContainerConfig,
        ],
      } as DesktopCompUploaderConfig;
    }

    case DesktopCompType.TRANSFER: {
      return {
        ...formItemConfig,
        titles: {
          source: '源数据',
          target: '目标数据',
        },
      } as DesktopCompTransferConfig;
    }

    case DesktopCompType.TABS: {
      const container = createIndelibleContainer(config, PagePlatform.PC);

      return {
        ...config,
        children: [
          {
            ...container,
            name: '标签1',
          } as DesktopCompContainerConfig,
        ],
      } as DesktopCompTabsConfig;
    }

    case DesktopCompType.TAG: {
      return {
        ...config,
        text: '标签',
      } as DesktopCompTagConfig;
    }

    case DesktopCompType.IMAGE: {
      return {
        ...config,
        width: 50,
        alt: '图片',
      } as DesktopCompImageConfig;
    }

    case DesktopCompType.TREE: {
      return {
        ...config,
        tree: {
          dataSourceType: 'tree',
          childrenKey: 'children',
          name: `$\{_context.name}`,
          value: `$\{_context.id}`,
        },
      } as DesktopCompTreeConfig;
    }

    case DesktopCompType.ICON: {
      return {
        ...config,
        url: '//at.alicdn.com/t/font_2040307_lr0ir3deu5.js',
        iconType: 'iconplus-circle',
      } as DesktopCompIconConfig;
    }

    case DesktopCompType.MENU: {
      return {
        ...config,
        mode: 'vertical',
        openParent: 1,
        url: `$\{_context.url}`,
        tree: {
          dataSourceType: 'tree',
          childrenKey: 'children',
          name: `$\{_context.name}`,
          value: `$\{_context.id}`,
        },
      } as DesktopCompMenuConfig;
    }

    case DesktopCompType.DROPDOWN_MENU: {
      return {
        ...config,
        dropdownTrigger: 'hover',
        tree: {
          dataSourceType: 'tree',
          childrenKey: 'children',
          name: `$\{_context.name}`,
          value: `$\{_context.value}`,
        },
      } as DesktopCompDropdownMenuConfig;
    }

    case DesktopCompType.STEPS: {
      return {
        ...config,
        title: `$\{_context.title}`,
      } as DesktopCompStepsConfig;
    }

    case DesktopCompType.MARKDOWN: {
      return {
        ...config,
        text: '# 标题',
      } as DesktopCompMarkdownConfig;
    }

    default: {
      return config;
    }
  }
}

export function createMobileComp(
  type: MobileCompType,
  config: MobileCompConfig,
): MobileCompConfig {
  const formItemConfig = {
    ...config,
    label: {
      text: '字段',
    },
    value: `\${_pathname}.`,
  } as MobileCompConfig & CompFormItem;

  switch (type) {
    case MobileCompType.BUTTON: {
      return {
        ...config,
        text: '确定',
      } as MobileCompButtonConfig;
    }

    case MobileCompType.CAPSULE_TABS: {
      return {
        ...config,
        options: {
          label: `\${_context.label}`,
          value: `\${_context.value}`,
        },
      } as MobileCompSegmentConfig;
    }

    case MobileCompType.TAG: {
      return {
        ...config,
        text: '标签',
      } as MobileCompTagConfig;
    }

    case MobileCompType.INPUT:
    case MobileCompType.NUMBER_INPUT:
    case MobileCompType.TEXT_AREA:
    case MobileCompType.SWITCH: {
      return formItemConfig;
    }

    case MobileCompType.DATE_PICKER: {
      return {
        ...formItemConfig,
      } as MobileCompDatePickerConfig;
    }

    case MobileCompType.SELECT:
    case MobileCompType.RADIO:
    case MobileCompType.CHECKBOX: {
      return {
        ...formItemConfig,
        options: {
          name: `$\{_context.label}`,
          value: `$\{_context.value}`,
        },
      } as unknown as MobileCompFormItem & MobileCompConfig;
    }

    case MobileCompType.FORM_ITEM: {
      return {
        ...formItemConfig,
        children: [createIndelibleContainer(config, PagePlatform.MOBILE)],
      } as MobileCompFormItemConfig;
    }

    case MobileCompType.LIST_ITEM: {
      return {
        ...config,
        prefixText: '字段',
      } as MobileCompListItemConfig;
    }

    case MobileCompType.UPLOADER: {
      const container = createIndelibleContainer(config, PagePlatform.MOBILE);
      const buttonId = uuidv4();

      return {
        ...formItemConfig,
        formatter: `$\{_context.url}`,
        children: [
          {
            ...container,
            children: [
              {
                id: buttonId,
                parentId: container.id,
                pathname: `${container.pathname},${buttonId}`,
                type: PageCompType.TEXT,
                textType: 'primary',
                text: '上传',
              } as PageCompTextConfig,
            ],
          } as MobileCompContainerConfig,
        ],
      } as MobileCompUploaderConfig;
    }

    case MobileCompType.SWIPER: {
      return {
        ...config,
        items: {
          dataSource: '',
          imageUrl: `$\{_context.img}`,
        },
      } as MobileCompSwiperConfig;
    }

    case MobileCompType.TABS: {
      const tabPanelId = uuidv4();

      return {
        ...config,
        children: [
          {
            id: tabPanelId,
            type: MobileCompType.TAB_PANEL,
            pathname: `${config.pathname},${tabPanelId}`,
            title: '标签1',
          } as MobileCompTabPanelConfig,
        ],
      } as MobileCompTabsConfig;
    }

    case MobileCompType.IMAGE: {
      return {
        ...config,
        styles: {
          width: 40,
          height: 40,
        },
      };
    }

    default: {
      return config;
    }
  }
}

export function createTaroComp(
  type: TaroCompType,
  config: TaroCompConfig,
): TaroCompConfig {
  const formItemConfig = {
    ...config,
    label: {
      text: '字段',
    },
    value: `\${_pathname}.`,
  } as TaroCompConfig & CompFormItem;

  const formItemConfigWithOptions = {
    ...formItemConfig,
    options: {
      label: `\${_context.label}`,
      value: `\${_context.value}`,
      dataSource: '',
      name: '',
    },
  } as TaroCompConfig & TaroCompFormItem & CompFormItemWithOptions;

  switch (type) {
    case TaroCompType.BUTTON: {
      return {
        ...config,
        buttonType: 'primary',
        text: '确定',
      } as TaroCompButtonConfig;
    }

    case TaroCompType.INPUT:
    case TaroCompType.INPUT_ITEM:
    case TaroCompType.SWITCH:
    case TaroCompType.TEXT_AREA:
    case TaroCompType.CHECKBOX:
    case TaroCompType.SLIDER: {
      return formItemConfig;
    }

    case TaroCompType.RADIO: {
      return formItemConfigWithOptions;
    }

    case TaroCompType.SELECT:
    case TaroCompType.SELECT_ITEM: {
      return {
        ...formItemConfigWithOptions,
        children: [createIndelibleContainer(config, PagePlatform.TARO)],
      };
    }

    case TaroCompType.DATE_PICKER:
    case TaroCompType.DATE_PICKER_ITEM: {
      return {
        ...formItemConfig,
        start: '1970-01-01',
        end: '2099-12-31',
        children: [createIndelibleContainer(config, PagePlatform.TARO)],
      } as TaroCompDatePickerConfig;
    }

    case TaroCompType.CONTAINER:
    case TaroCompType.IMAGE:
    case TaroCompType.FORM:
    case TaroCompType.LIST: {
      return config;
    }

    case TaroCompType.SWIPER: {
      return {
        ...config,
        imageUrl: `\${_context.img}`,
        url: `\${_context.url}`,
      } as TaroCompSwiperConfig;
    }

    case TaroCompType.LIST_ITEM: {
      return {
        ...config,
        headText: '字段',
      } as TaroCompListItemConfig;
    }

    case TaroCompType.BOOLEAN_ITEM: {
      return {
        ...formItemConfig,
        headText: '字段',
        compType: 'switch',
      } as TaroCompBooleanItemConfig;
    }

    case TaroCompType.NAV_CONTAINER: {
      return {
        ...config,
        navigationBarTitleText: '页面标题',
      } as TaroCompNavContainerConfig;
    }

    default: {
      return config;
    }
  }
}

export function createPageComp(
  type: PageCompType,
  config: CompConfig,
  platform: PagePlatform,
) {
  switch (type) {
    case PageCompType.TEXT: {
      return {
        ...config,
        text: '默认文字',
      } as PageCompTextConfig;
    }

    case PageCompType.BLOCK: {
      return {
        ...config,
        css: `
& {
  height: 20px;
  width: 20px;
  background-color: black;
}
`,
      } as PageCompBlockConfig;
    }

    case PageCompType.HYPERLINK: {
      return {
        ...config,
        text: '默认超链接文字',
      } as PageCompHyperlinkConfig;
    }

    case PageCompType.REPEAT: {
      return {
        ...config,
        children: [createIndelibleContainer(config, platform)],
      };
    }

    case PageCompType.UMD_COMP: {
      return {
        ...config,
        memberName: 'default',
      } as PageCompUmdCompConfig;
    }

    default: {
      return config;
    }
  }
}

export function createCompConfig(options: {
  type: CompsAll;
  parent: { id: string; pathname?: string };
  defaultConfig?: Partial<CompConfig>;
  platform?: PagePlatform;
}): CompConfig {
  const { type, platform = PagePlatform.PC, defaultConfig, parent } = options;

  const configId = uuidv4();

  const config = {
    ...(defaultConfig ?? {}),
    id: configId,
    type,
    parentId: parent.id,
    pathname: `${parent.pathname || parent.id},${configId}`,
  } as CompConfig;

  if (isPageComp(type)) {
    return createPageComp(type as PageCompType, config, platform);
  }

  if (isDesktopComp(type)) {
    return createDesktopComp(type as DesktopCompType, config);
  }

  if (isMobileComp(type)) {
    return createMobileComp(type as MobileCompType, config);
  }

  if (isTaroComp(type)) {
    return createTaroComp(type as TaroCompType, config);
  }

  return {
    ...config,
    children: [],
  } as DesktopCompContainerConfig;
}
