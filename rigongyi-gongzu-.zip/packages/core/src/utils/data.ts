import size from 'lodash-es/size';
import { IdTreeNode, TreeNode } from '../types/entities';
import { composeSkipNull } from './object';
import { walkTree } from './tree';

export function mergeEntities<T>(
  object: Record<string, T>,
  source: Record<string, T>,
  key: keyof T,
): void {
  Object.values(source).forEach((o) => {
    const k = `${o[key]}`;
    // eslint-disable-next-line no-param-reassign
    object[k] = composeSkipNull<T, T>(o, object[k]);
  });
}

export function normalizeTree<
  T extends TreeNode,
  P extends {
    children?: P[];
    parentId?: string | null;
    id: string;
  },
>(
  nodes: P[],
  formatter?: (node: P, parent?: T | null) => T,
  idKey: 'id' | 'pathname' = 'id',
  parentId = '1',
  filter: (node: P, parent?: T | null) => boolean = () => true,
): {
  idTree: IdTreeNode[];
  entities: Record<string, T>;
} {
  const idTree: IdTreeNode[] = [];
  const entities: Record<string, T> = {};

  if (size(nodes) > 0) {
    const childrenKey = 'children';

    walkTree<P, IdTreeNode>(
      nodes,
      (node, parent, idTreeNode?: IdTreeNode): IdTreeNode | undefined => {
        const p =
          parent && idTreeNode ? entities[`${idTreeNode[idKey]}`] : null;

        let pathname = '';

        if (p) {
          pathname = `${p.pathname},${node.id}`;
        } else if (node.parentId) {
          pathname = `${node.parentId},${node.id}`;
        } else {
          pathname = `${parentId},${node.id}`;
        }

        const id = {
          pathname,
          id: node.id,
          level: pathname.split(',').length - 1,
        };

        const children = node[childrenKey] as P[];

        if (!filter(node, p)) {
          return undefined;
        }

        const entity = {
          ...(formatter ? formatter(node, p) : node),
          pathname,
          parentId: node.parentId || (parent && parent.id),
        } as P & T;

        delete entity[childrenKey];

        entity.childrenIds = children && children.map((c) => c.id);

        entities[`${entity[idKey]}`] = entity;

        if (idTreeNode) {
          if (Array.isArray(idTreeNode)) {
            idTreeNode.push(id);
          } else if (idTreeNode.children) {
            idTreeNode.children.push(id);
          } else {
            // eslint-disable-next-line no-param-reassign
            idTreeNode.children = [id];
          }
        }

        return id;
      },
      childrenKey,
      null,
      idTree as any,
    );
  }

  return { idTree, entities };
}

type DataValue = string | number;

export function shakeEmptyTreeNode<
  T extends {
    children?: T[];
    data: DataValue[] | { [s: string]: DataValue };
    excluded?: boolean;
    parentExcluded?: boolean;
  },
>(nodes: T[] | null = null): T[] | null {
  if (nodes == null) {
    return null;
  }

  const shaken = nodes
    .map((node) => {
      const children = shakeEmptyTreeNode(node.children);

      const { data } = node;

      let isEmpty = children == null && !node.excluded && !node.parentExcluded;

      if (isEmpty) {
        if (data != null) {
          if (Array.isArray(data)) {
            isEmpty = data.filter((d) => d != null).length === 0;
          } else {
            isEmpty = Object.values(data).every((d) => d == null);
          }
        }
      }

      return {
        ...node,
        children,
        isEmpty,
      };
    })
    .filter(({ isEmpty }) => !isEmpty);

  return shaken.length > 0 ? shaken : null;
}

export function parseJSON(json: any) {
  try {
    return JSON.parse(json);
  } catch (e) {
    return null;
  }
}
