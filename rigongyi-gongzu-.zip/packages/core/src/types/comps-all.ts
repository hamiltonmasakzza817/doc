import { DesktopCompType } from './comps-desktop';
import { MobileCompType } from './comps-mobile';
import { PageCompType } from './comps-page';
import { TaroCompType } from './comps-taro';

export type CompsAll =
  | PageCompType
  | DesktopCompType
  | MobileCompType
  | TaroCompType;
