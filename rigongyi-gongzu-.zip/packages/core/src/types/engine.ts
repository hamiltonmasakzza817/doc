export type CodeInterpreter = (code: string, context: [string, any][]) => any;

export type RouterNavigateMode = 'replace' | 'pushState' | 'open';

export interface Router {
  location?: {
    href: string;
    origin: string;
    pathname: string;
  };
  searchParams: Record<string, any>;
  navigateTo: (url: string, mode?: RouterNavigateMode) => void;
}
