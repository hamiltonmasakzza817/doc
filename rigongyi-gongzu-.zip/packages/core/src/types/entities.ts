import React from 'react';
import { CompConfig } from './comps-common';
import { PageCompCustomConfig } from './comps-page';

export interface LoginData {
  name: string;
  nickname: string;
  roleCodes: string[];
}

export type TreeNode<T = Record<string, unknown>> = T & {
  id: string;
  parentId?: string | null;
  pathname?: string;
  children?: TreeNode<T>[];
  childrenIds?: string[];
  level?: number;
  showOrder?: number;
};

export type IdTreeNode<T = Record<string, unknown>> = T & {
  id: string;
  pathname?: string;
  children?: IdTreeNode<T>[];
  level?: number;
};

export interface DataNode {
  checkable?: boolean;
  children?: DataNode[];
  disabled?: boolean;
  disableCheckbox?: boolean;
  isLeaf?: boolean;
  key: string | number;
  value?: string | number;
  title?: React.ReactNode;
  selectable?: boolean;
  /** Set style of TreeNode. This is not recommend if you don't have any force requirement */
  className?: string;
  style?: React.CSSProperties;
}

export enum PageStatus {
  UNPUBLISHED = 'UNPUBLISHED',
  PUBLISHED = 'PUBLISHED',
  ROLLBACK = 'ROLLBACK',
}

export enum PageModelType {
  DRAFT = 'DRAFT',
  PUBLISHED = 'PUBLISHED',
  BACKUP = 'BACKUP',
}

export enum PageCustomCompTreeNodeType {
  COMPONENT = 'COMPONENT',
  CATEGORY = 'CATEGORY',
}

export enum EventType {
  BPM_SAVE = 'BPM_SAVE',
  BPM_SUBMIT = 'BPM_SUBMIT',
  BPM_REJECT = 'BPM_REJECT',
  BPM_CANCEL = 'BPM_CANCEL',
  BPM_DEL = 'BPM_DEL',
  BPM_WITHDRAW = 'BPM_WITHDRAW',
  DATA_CHANGE = 'DATA_CHANGE',
  INTERVAL = 'INTERVAL',
  DOM_EVENT = 'DOM_EVENT',
  PAGE_EVENT = 'PAGE_EVENT',
  PAGE_LOAD = 'PAGE_LOAD',
}

export type Event = {
  id: string;
  name: string;
  type: EventType;
  actionId?: string;
  params?: string;
  pathname?: string;
  interval: string;
  querySelector?: string;
  // eventName 这里专指 DOM event name，因为后面又加了 event
  eventName?: string;
  pageEventName?: string;
  ignoreBpmWorkflow?: boolean;
  guard?: string;
  take?: number;
};

export interface PageModelData {
  elements: CompConfig[];
  modals: CompConfig[];
  customs: Record<string, PageCompCustomConfig>;
  customTree: TreeNode[];
  actions: Record<string, ActionQueue>;
  datas: Record<string, Data>;
  styles: Record<string, Style>;
  globalStyle?: string;
  events: Event[];
  resources: Resource[];
  version: string;
}

export enum PagePlatform {
  PC = 'PC',
  MOBILE = 'MOBILE',
  TARO = 'TARO',
}

export type Page = TreeNode<{
  id: string;
  name: string;
  model?: {
    modelData?: PageModelData;
    modelKey?: string;
    type: PageModelType;
    md5?: string;
  };
  status: PageStatus;
  platform: PagePlatform;
  url?: string;
  isDrafting?: boolean;
  draftModelMd5?: string;
  publishedModelMd5?: string;
}>;

export enum PageDevice {
  CURRENT = 'CURRENT',
  PC_WIDE = 'PC_WIDE',
  PC = 'PC',
  LAPTOP = 'LAPTOP',
  MOBILE = 'MOBILE',
}

export interface Style {
  id: string;
  name: string;
  style?: string;
}

export enum DataType {
  MANUAL = 'MANUAL',
  URL = 'URL',
}

export interface Data {
  id: string;
  code: string;
  name: string;
  type: DataType;
  params?: any;
  data?: any;
  defaultData?: any;
  autoLoad?: boolean;
  schema?: Schema;
  url?: string;
  method?: 'GET' | 'POST';
  stringifyOptions?: string;
  format: 'form' | 'json';
  ignoreQueryException: boolean;
  formatter?: string;
  ts?: number;
}

export enum ResourceType {
  SCRIPT = 'SCRIPT',
  CSS = 'CSS',
}

export interface Resource {
  id: string;
  name: string;
  type: ResourceType;
  url: string;
}

export enum SchemaDataType {
  NULL = 'Null',
  STRING = 'String',
  DOUBLE = 'Double',
  BOOLEAN = 'Boolean',
  DATE = 'Date',
  DECIMAL = 'Decimal',
  INTEGER = 'Integer',
  JSON_OBJECT = 'JSONObject',
  JSON_ARRAY = 'JSONArray',
}

export interface Schema {
  dataType: SchemaDataType;
  properties?: {
    [code: string]: Schema;
  };
  child?: Schema;
}

export enum ActionType {
  OTHER_ACTION_QUEUE = 'OTHER_ACTION_QUEUE',
  SEND_REQUEST = 'SEND_REQUEST',
  SET_DATA = 'SET_DATA',
  FETCH_DATA = 'FETCH_DATA',
  VALIDATE_FORM = 'VALIDATE_FORM',
  CLEAR_FORM_ERRORS = 'CLEAR_FORM_ERRORS',
  GO = 'GO',
  EXEC_CODE = 'EXEC_CODE',
  CONTROL_MODAL = 'CONTROL_MODAL',
  GUARD = 'GUARD',
  CONTROL_EVENTS = 'CONTROL_EVENTS',
  NOTIFICATION = 'NOTIFICATION',
  START = 'START',
  DISPATCH_PAGE_EVENT = 'DISPATCH_PAGE_EVENT',
  CANCEL_ACTION_QUEUE = 'CANCEL_ACTION_QUEUE',
  DELAY = 'DELAY',
  ACTION_SHEET = 'ACTION_SHEET',
}

// 运行时 Action 彼此传递的数据结构
export type ActionPayload = {
  cancelLater?: boolean;
  params?: Record<string, unknown>;
  context?: Record<string, unknown>;
  contextIndex?: number;
  contextIndexes?: number[];
  contextPathname?: string;
  contextPathnames?: string[];
};

export type Action = {
  type: ActionType;
  params?: Record<string, unknown>;
  // 用于合并上下文解析，并存在于后续 Action 的 _context 中
  context?: Record<string, unknown>;
  parallel?: boolean;
};

export const asyncActions = [
  ActionType.FETCH_DATA,
  ActionType.OTHER_ACTION_QUEUE,
  ActionType.SEND_REQUEST,
];

export const rejectableActions = [ActionType.GUARD, ActionType.VALIDATE_FORM];

export interface ActionRejectable extends Action {
  rejectActionId?: string;
}

export interface ActionAsync extends Action {
  parallelActionId?: string;
}

export interface ActionOtherActionQueue extends ActionAsync {
  type: ActionType.OTHER_ACTION_QUEUE;
  actionId: string;
}

export interface ActionCancelActionQueue extends Action {
  type: ActionType.CANCEL_ACTION_QUEUE;
  actionId: string;
}

export interface ActionFetchData extends ActionAsync {
  dataCode: string;
}

export interface ActionValidateForm extends ActionRejectable {
  type: ActionType.VALIDATE_FORM;
  pathname?: string;
  filter?: string;
  scrollIntoView?: boolean;
}

export interface ActionClearFormErrors extends Action {
  type: ActionType.CLEAR_FORM_ERRORS;
  pathname: string;
}

export interface ActionDelay extends Action {
  type: ActionType.DELAY;
  duration?: number;
}

export interface ActionGo extends Action {
  type: ActionType.GO;
  url: string;
  open: boolean;
  usePushState?: boolean;
  useReplace?: boolean;
}

export interface ActionSendRequest extends ActionAsync {
  url: string;
  method: 'POST' | 'GET' | 'PUT' | 'DELETE';
  format: 'form' | 'json';
  stringifyOptions?: string;
  ignoreException: boolean;
}

export interface ActionControlModal extends Action {
  type: ActionType.CONTROL_MODAL;
  open?: boolean;
  modalId: string;
}

export interface ActionExecCode extends Action {
  type: ActionType.EXEC_CODE;
  code: string;
}

export interface ActionGuard extends ActionRejectable {
  type: ActionType.GUARD;
  code: string;
  confirm?: string;
}

export interface ActionControlEvent extends Action {
  type: ActionType.CONTROL_EVENTS;
  start?: boolean;
  eventId: string;
}

export enum LoggerLevel {
  SUCCESS = 'success',
  INFO = 'info',
  ERROR = 'error',
}

export enum LoggerType {
  NOTIFICATION,
  MESSAGE,
  CONSOLE,
}

export interface Logger {
  message: string;
  level: LoggerLevel;
  type?: LoggerType;
}

export interface ActionNotification extends Action {
  type: ActionType.NOTIFICATION;
  message?: string;
  loggerLevel: LoggerLevel;
  loggerType: LoggerType;
}

export interface ActionStart extends Action {
  type: ActionType.START;
  confirm?: string;
}

export interface ActionDispatchPageEvent extends Action {
  type: ActionType.DISPATCH_PAGE_EVENT;
  pageEventName: string;
}

// Action 队列类型
export enum ActionQueueType {
  GLOBAL = 'GLOBAL', // 主动新增的
  LOCAL = 'LOCAL', // 组件交互、业务事件绑定的
  REJECT = 'REJECT', // 拦截器拒绝的后续分支
  PARALLEL = 'PARALLEL', // 并行执行的分支
}

// 冲突解决，当前有此 Action Queue 处于 pending 状态，如何处理
export enum ActionQueueConflictResolver {
  BOTH = 'BOTH', // 两者均执行【默认】
  EXISTING = 'EXISTING', // 使用当前的，忽略后来的，用于提交表单场景
  COMING = 'COMING', // 使用后来的，用于频繁切换查询条件的异步请求
}

export interface ActionQueue {
  id: string;
  type: ActionQueueType;
  name: string;
  code?: string;
  confirm?: string;
  success?: string;
  context?: Record<string, unknown>;
  actions: Array<Action>;
  conflictResolver?: ActionQueueConflictResolver;
  foreignActionIds?: string[];
  rootActionId?: string;
  ts?: number;
}
