import { ActionBinding, CompClickable, CompConfig } from './comps-common';

export enum PageCompType {
  PAGE = 'PAGE',
  TEXT = 'TEXT',
  HYPERLINK = 'HYPERLINK',
  BLOCK = 'BLOCK',
  IFRAME = 'IFRAME',
  PAGE_PORTAL = 'PAGE_PORTAL',
  UMD_COMP = 'UMD_COMP',
  REPEAT = 'REPEAT',
  CUSTOM = 'CUSTOM',
}

export interface PageCompConfig extends CompConfig {
  type: PageCompType;
}

export interface PageCompTextConfig extends PageCompConfig, CompClickable {
  type: PageCompType.TEXT;
  text: string;
  textType:
    | 'secondary'
    | 'success'
    | 'warning'
    | 'danger'
    | 'primary'
    | 'heading';
  disabled?: string;
}

export interface PageCompPageConfig extends PageCompConfig {
  type: PageCompType.PAGE;
  loading?: string;
  onLoad: ActionBinding;
  onDispose: ActionBinding;
  indelible: true;
  documentTitle?: string;
}

export enum HyperlinkTarget {
  BLANK = 'BLANK',
  DOWNLOAD = 'DOWNLOAD',
}

export interface PageCompHyperlinkConfig extends PageCompConfig {
  type: PageCompType.HYPERLINK;
  text: string;
  url?: string;
  params?: Record<string, unknown>;
  target?: HyperlinkTarget;
  usePushState?: string;
}

export interface PageCompPagePortalConfig extends PageCompConfig {
  type: PageCompType.PAGE_PORTAL;
  pageId?: string;
  pageUrl?: string;
  key?: string;
  params?: Record<string, unknown>;
}

export interface PageCompRepeatConfig extends PageCompConfig {
  type: PageCompType.REPEAT;
  dataSource: string;
  key?: string;
}

export interface PageCompCustomConfig extends PageCompConfig {
  type: PageCompType.CUSTOM;
  loading?: string;
}

export interface PageCompIframeConfig extends PageCompConfig, CompClickable {
  type: PageCompType.IFRAME;
  src: string;
}

export interface PageCompBlockConfig extends PageCompConfig, CompClickable {
  type: PageCompType.BLOCK;
  rawHtml?: string;
}

export interface PageCompUmdCompConfig extends PageCompConfig {
  type: PageCompType.UMD_COMP;
  url?: string;
  moduleName?: string;
  memberName?: string;
  params?: Record<string, unknown>;
}
