import {
  ActionBinding,
  CompClickable,
  CompConfig,
  CompFormItem,
  CompFormItemWithOptions,
  CompUploader,
  TextAlign,
  TimeUnit,
} from './comps-common';

export enum DesktopCompType {
  // 基础组件
  PARAGRAPH = 'PARAGRAPH',
  BUTTON = 'BUTTON',
  ICON = 'ICON',
  IMAGE = 'IMAGE',
  TAG = 'TAG',
  CONTAINER = 'CONTAINER',

  // 表单组件
  FORM = 'FORM',
  FORM_ITEM_CONTAINER = 'FORM_ITEM_CONTAINER',
  INPUT = 'INPUT',
  TEXT_AREA = 'TEXT_AREA',
  NUMBER_INPUT = 'NUMBER_INPUT',
  RADIO = 'RADIO',
  CHECKBOX = 'CHECKBOX',
  SWITCH = 'SWITCH',
  DATE_PICKER = 'DATE_PICKER',
  SELECT = 'SELECT',
  TREE_SELECT = 'TREE_SELECT',
  UPLOADER = 'UPLOADER',
  CASCADER = 'CASCADER',
  SLIDER = 'SLIDER',

  // 高级组件
  TABS = 'TABS',
  TAB_PANE = 'TAB_PANE',
  TABLE = 'TABLE',
  MODAL = 'MODAL',
  TREE = 'TREE',
  PAGINATION = 'PAGINATION',
  MENU = 'MENU',
  PROGRESS = 'PROGRESS',
  DROPDOWN_MENU = 'DROPDOWN_MENU',
  STEPS = 'STEPS',
  MARKDOWN = 'MARKDOWN',
  TRANSFER = 'TRANSFER',
}

export interface DesktopCompConfig extends CompConfig {
  type: DesktopCompType;
  size?: 'small' | 'middle' | 'large';
}

export interface DesktopCompParagraphConfig extends DesktopCompConfig {
  type: DesktopCompType.PARAGRAPH;
  text: string;
}

export interface DesktopCompButtonConfig
  extends DesktopCompConfig,
    CompClickable {
  type: DesktopCompType.BUTTON;
  text: string;
  buttonType?: 'default' | 'primary' | 'ghost' | 'dashed' | 'link' | 'text';
  ghost: boolean;
  disabled?: string;
  renderCompId: string;
}

export interface DesktopCompIconConfig
  extends DesktopCompConfig,
    CompClickable {
  type: DesktopCompType.ICON;
  iconType: string;
  custom?: boolean;
  url?: string;
}

export interface DesktopCompImageConfig
  extends DesktopCompConfig,
    CompClickable {
  type: DesktopCompType.IMAGE;
  url?: string;
  alt?: string;
  altUrl?: string;
  preview?: boolean;
}

export interface DesktopCompTagConfig extends DesktopCompConfig, CompClickable {
  type: DesktopCompType.TAG;
  closable?: boolean;
  text: string;
  color?: string;
  onClose?: ActionBinding;
}

export interface DesktopCompContainerConfig
  extends DesktopCompConfig,
    CompClickable {
  type: DesktopCompType.CONTAINER;
  renderCompId?: string;
  tooltip?: string;
  dropdownCompId?: string;
  dropdownTrigger?: 'hover' | 'click' | 'contextMenu';
  align?:
    | 'topLeft'
    | 'top'
    | 'topRight'
    | 'rightTop'
    | 'right'
    | 'rightBottom'
    | 'bottomRight'
    | 'bottom'
    | 'bottomLeft'
    | 'leftBottom'
    | 'left'
    | 'leftTop';
  onHeightChange?: ActionBinding;
  flexBottom?: string;
  loading?: string;
}

export interface DesktopCompFormConfig extends DesktopCompConfig {
  type: DesktopCompType.FORM;
  value?: string;
  label?: {
    width?: number;
    align: 'left' | 'right';
    span?: number;
  };
}

export interface DesktopCompFormItemContainerConfig
  extends DesktopCompConfig,
    CompFormItem {
  type: DesktopCompType.FORM_ITEM_CONTAINER;
}

export interface DesktopCompInputConfig
  extends DesktopCompConfig,
    CompFormItem {
  type: DesktopCompType.INPUT;
  password?: boolean;
  addonBefore?: string;
  addonAfter?: string;
  onPressEnter?: ActionBinding;
  search?: boolean;
  enterButton?: string;
  onSearch?: ActionBinding;
}

export interface DesktopCompTextAreaConfig
  extends DesktopCompConfig,
    CompFormItem {
  type: DesktopCompType.TEXT_AREA;
  minRows?: number;
  onPressEnter?: ActionBinding;
}

export interface DesktopCompNumberInputConfig
  extends DesktopCompConfig,
    CompFormItem {
  type: DesktopCompType.NUMBER_INPUT;
  max: number;
  min: number;
  precision: number;
  step: number;
  onPressEnter?: ActionBinding;
}

export interface DesktopCompRadioConfig
  extends DesktopCompConfig,
    CompFormItemWithOptions {
  type: DesktopCompType.RADIO;
  radioStyle?: 'vertical' | 'button';
  buttonStyle?: 'outline' | 'solid';
  renderCompId: string;
}

export interface DesktopCompCheckboxConfig
  extends DesktopCompConfig,
    CompFormItemWithOptions {
  type: DesktopCompType.CHECKBOX;
  custom?: boolean;
}

export interface DesktopCompSwitchConfig
  extends DesktopCompConfig,
    CompFormItem {
  type: DesktopCompType.SWITCH;
  checkedText?: string;
  uncheckedText?: string;
  checkedValue?: string;
  uncheckedValue?: string;
}

export interface DesktopCompSelectConfig
  extends DesktopCompConfig,
    CompFormItemWithOptions {
  type: DesktopCompType.SELECT;
  mode: 'tags' | 'multiple';
  labelInValue?: boolean;
  loading?: string;
}

export interface DesktopCompCascaderConfig
  extends DesktopCompConfig,
    CompFormItemWithOptions {
  type: DesktopCompType.CASCADER;
  options?: {
    dataSource: string;
    name: string;
    value: string;
    label?: string;
    disabled?: string;
    childrenKey?: string;
  };
}

export interface DesktopCompSliderConfig
  extends DesktopCompConfig,
    CompFormItem {
  type: DesktopCompType.SLIDER;
  min: number;
  max: number;
  step: number;
}

export interface DesktopCompDatePickerConfig
  extends DesktopCompConfig,
    CompFormItem {
  type: DesktopCompType.DATE_PICKER;
  timeUnit: TimeUnit;
  format?: string;
  isRange?: boolean;
}

export interface DesktopCompTreeDataSource {
  dataSource?: string;
  dataSourceType: 'tree' | 'list';
  parentIdKey?: string;
  childrenKey?: string;
  name?: string;
  value?: string;
  defaultExpandLevel?: number;
  expandedKeys?: string;
  isLeaf?: string;
  asyncLoad?: boolean;
  disabled?: string;
}

export interface DesktopCompTreeSelectConfig
  extends DesktopCompConfig,
    CompFormItem {
  type: DesktopCompType.TREE_SELECT;
  options: DesktopCompTreeDataSource;
  multiple?: boolean;
  labelInValue?: boolean;
  search?: boolean;
  onExpand?: ActionBinding;
  onSearch?: ActionBinding;
}

export interface DesktopCompUploaderConfig
  extends DesktopCompConfig,
    CompFormItem,
    CompUploader {
  type: DesktopCompType.UPLOADER;
}

export interface DesktopCompTransferConfig
  extends DesktopCompConfig,
    CompFormItemWithOptions {
  type: DesktopCompType.TRANSFER;
  titles: {
    source?: string;
    target?: string;
  };
}

export interface DesktopCompTabsConfig extends DesktopCompConfig {
  type: DesktopCompType.TABS;
  activeKey?: string;
  tabsType?: 'line' | 'card' | 'editable-card';
  tabBarExtraContent?: string;
  onChange?: ActionBinding;
}

export interface DesktopCompTableConfig extends DesktopCompConfig {
  type: DesktopCompType.TABLE;
  dataSource?: string;
  defaultExpandLevel?: number;
  pager?: boolean;
  rowKey?: string;
  loading?: string;
  sortKey?: string;
  sortOrder?: string;
  onSort?: ActionBinding;
  onRowClick?: ActionBinding;
  onRowSelectionChange?: ActionBinding;
  childrenKey?: string;
  scrollY?: string;
  rowSelection?: {
    type?: 'checkbox' | 'radio';
    value?: string;
  };
  columnOptions?: unknown[];
  columns: {
    id: string;
    key?: string;
    data?: string;
    title: string;
    width?: number;
    align?: TextAlign;
    fixed?: 'left' | 'right';
    renderCompId?: string;
    sorter?: boolean;
    filtered?: string;
    filteredValue?: string;
    filters?: string;
    params?: Record<string, unknown>;
  }[];
}

export interface DesktopCompModalConfig extends DesktopCompConfig {
  type: DesktopCompType.MODAL;
  displayType?: 'MODAL' | 'DRAWER';
  visible?: string;
  title: string;
  titleRenderCompId?: string;
  onOk?: ActionBinding;
  onCancel?: ActionBinding;
  maskClosable?: boolean;
  footer?: string;
  destroyOnClose?: boolean;
  disableTransition?: boolean;
  centered?: boolean;
}

export interface DesktopCompTreeConfig extends DesktopCompConfig {
  type: DesktopCompType.MODAL;
  tree: DesktopCompTreeDataSource;
  renderCompId?: string;
  onChange?: ActionBinding;
  onExpand?: ActionBinding;
  selectedKeys?: string;
}

export interface DesktopCompPaginationConfig extends DesktopCompConfig {
  type: DesktopCompType.PAGINATION;
  onChange?: ActionBinding;
  page?: string;
  totalPage?: string;
  total?: string;
  pageSize?: string;
}

export interface DesktopCompMenuConfig extends DesktopCompConfig {
  type: DesktopCompType.MENU;
  mode: 'vertical' | 'horizontal' | 'inline';
  openParent?: number;
  theme?: 'light' | 'dark';
  tree?: DesktopCompTreeDataSource;
  url?: string;
  usePushState?: string;
  targetBlank?: string;
  selected?: string;
  onSelect?: ActionBinding;
  triggerSubMenuAction?: 'hover' | 'click';
}

export interface DesktopCompProgressConfig extends DesktopCompConfig {
  type: DesktopCompType.PROGRESS;
  strokeColor?: string;
  trailColor?: string;
  value?: string;
}

export interface DesktopCompDropdownMenuConfig extends DesktopCompConfig {
  type: DesktopCompType.DROPDOWN_MENU;
  dropdownTrigger?: 'hover' | 'click' | 'contextMenu';
  tree?: DesktopCompTreeDataSource;
  onSelect?: ActionBinding;
  placement?:
    | 'topLeft'
    | 'topCenter'
    | 'topRight'
    | 'bottomLeft'
    | 'bottomCenter'
    | 'bottomRight';
}

export interface DesktopCompStepsConfig extends DesktopCompConfig {
  type: DesktopCompType.STEPS;
  dataSource?: string;
  title?: string;
  subTitle?: string;
  description?: string;
  disabled?: string;
  current?: string;
  onChange?: ActionBinding;
}

export interface DesktopCompMarkdownConfig extends DesktopCompConfig {
  type: DesktopCompType.MARKDOWN;
  text?: string;
}
