export interface ActionBinding {
  actionId: string;
  params?: string;
}

export enum TextAlign {
  LEFT = 'left',
  RIGHT = 'right',
  CENTER = 'center',
}

export enum VerticalAlign {
  BASELINE = 'BASELINE',
  TOP = 'TOP',
  CENTER = 'CENTER',
  BOTTOM = 'BOTTOM',
}

export enum TimeUnit {
  DATE = 'DATE',
  WEEK = 'WEEK',
  MONTH = 'MONTH',
  QUARTER = 'QUARTER',
  YEAR = 'YEAR',
}

export type CompTreeNode<T = Record<string, unknown>> = T & {
  id: string;
  name?: string;
  parentId?: string | null;
  pathname?: string;
  children?: CompTreeNode<any>[];
  childrenIds?: string[];
};

export interface PageCompStyles {
  width?: number;
  height?: number;
  span?: number;
  bold?: boolean;
  italic?: boolean;
  underline?: boolean;
  lineThrough?: boolean;
  fontSize?: number;
  fontFamily?: string;
  grid?: number | string;
  gridGap?: string;
  alignSelf?: VerticalAlign;
  backgroundImage?: string;
}

export type CompConfig = CompTreeNode<{
  type: any;
  alias?: string;
  code?: string;
  className?: string;
  css?: string;
  styleIds?: string[];
  styles?: PageCompStyles;
  style?: string;
  indelible?: boolean;
  display?: string;
  rawProps?: Record<string, unknown>;
}>;

export interface CompClickable {
  onClick?: ActionBinding;
}

export interface CompFormItem {
  label?: {
    text?: string;
    width?: number;
    span?: number;
    align: 'left' | 'right';
  };
  value?: string;
  onChange?: ActionBinding;
  onBlur?: ActionBinding;
  disabled?: string;
  readOnly?: string;
  placeholder?: string;
  extra?: string;
  pure?: boolean;
  onWayBinding?: boolean;
  allowClear?: boolean;
  autoFocus?: boolean;
  rule?: {
    required?: boolean;
    requiredExp?: string;
    requiredMsg?: string;
    pattern?: string;
    patternFlag?: string;
    patternMsg?: string;
    validate?: string;
    validateMsg?: string;
    remoteValidate?: {
      url: string;
      method?: 'GET' | 'POST';
      params: string;
    };
    remoteValidateMsg?: string;
    maxLength?: number;
  };
  formItemRawProps?: Record<string, unknown>;
}

export interface CompOptions {
  dataSource: string;
  name: string;
  value: string;
  label?: string;
  disabled?: string;
}

export interface CompOptionAble {
  options?: CompOptions;
}

export interface CompFormItemWithOptions extends CompFormItem, CompOptionAble {
  search?: boolean;
  onSearch?: ActionBinding;
}

export interface CompUploader extends CompFormItem {
  params?: string;
  formatter?: string;
  accept?: string;
  multiple?: boolean;
  url?: string;
  maxSize?: string;
  minSize?: string;
  loading?: string;
}

export interface CodeEditorProps {
  value?: string;
  onChange?: (value?: string) => void;
  language?: string;
  height?: number;
  width?: number;
  readOnly?: boolean;
  editorDidMount?: (editor: any) => void;
  diff?: boolean;
  original?: string;
}
