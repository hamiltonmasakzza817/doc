import {
  ActionBinding,
  CompClickable,
  CompConfig,
  CompFormItem,
  CompFormItemWithOptions,
} from './comps-common';

export enum TaroCompType {
  CONTAINER = 'CONTAINER_T',
  BOTTOM_CONTAINER = 'BOTTOM_CONTAINER_T',
  NAV_CONTAINER = 'NAV_CONTAINER_T',
  FORM = 'FORM_T',
  BUTTON = 'BUTTON_T',
  IMAGE = 'IMAGE_T',
  INPUT = 'INPUT_T',
  INPUT_ITEM = 'INPUT_ITEM_T',
  SELECT = 'SELECT_T',
  SELECT_ITEM = 'SELECT_ITEM_T',
  DATE_PICKER = 'DATE_PICKER_T',
  DATE_PICKER_ITEM = 'DATE_PICKER_ITEM_T',
  RADIO = 'RADIO_T',
  CHECKBOX = 'CHECKBOX_T',
  SWITCH = 'SWITCH_T',
  BOOLEAN_ITEM = 'BOOLEAN_ITEM',
  LIST = 'LIST_T',
  LIST_ITEM = 'LIST_ITEM_T',
  TEXT_AREA = 'TEXT_AREA_T',
  MODAL = 'MODAL_T',
  SLIDER = 'SLIDER_T',
  SWIPER = 'SWIPER_T',
  SCROLL_VIEW = 'SCROLL_VIEW_T',
}

export interface TaroCompConfig extends CompConfig {
  type: TaroCompType;
}

// 列表项、输入项、选择项、开关项等
export interface TaroCompFormItem {
  value?: string;
  rule?: {
    required?: boolean;
    requiredExp?: string;
    requiredMsg?: string;
    pattern?: string;
    patternFlag?: string;
    patternMsg?: string;
    validate?: string;
    validateMsg?: string;
    remoteValidate?: {
      url: string;
      method?: 'GET' | 'POST';
      params: string;
    };
    remoteValidateMsg?: string;
    maxLength?: number;
  };
  useLabel?: boolean;
  headWidth?: number;
  headText?: string;
  head?: string;
  contentText?: string;
  contentAlign?: 'left' | 'center' | 'right';
  arrow?: boolean;
  onClick?: ActionBinding;
}

export interface TaroCompContainerConfig extends TaroCompConfig, CompClickable {
  type: TaroCompType.CONTAINER;
  loading?: string;
  renderCompId?: string;
}

export interface TaroCompNavContainerConfig extends TaroCompConfig {
  type: TaroCompType.NAV_CONTAINER;
  navigationBarTitleText?: string;
}

export interface TaroCompBottomContainerConfig extends TaroCompConfig {
  type: TaroCompType.BOTTOM_CONTAINER;
}

export interface TaroCompButtonConfig extends TaroCompConfig {
  type: TaroCompType.BUTTON;
  buttonType?: 'default' | 'primary' | 'warn';
  size?: 'default' | 'mini';
  openType: 'share' | 'getPhoneNumber';
  plain: boolean;
  disabled: string;
  loading: string;
  text: string;
  border?: boolean;
  onClick?: ActionBinding;
  onGetPhoneNumber?: ActionBinding;
  onShare?: ActionBinding;
}

export interface TaroCompImageConfig extends TaroCompConfig {
  type: TaroCompType.IMAGE;
  src: string;
  mode: 'scaleToFill' | 'aspectFit' | 'aspectFill' | 'widthFix' | 'heightFix';
  lazyLoad?: boolean;
}

export interface TaroCompInput extends TaroCompConfig {
  inputType: 'text' | 'number' | 'idcard' | 'digit';
  password?: boolean;
  maxLength: number;
  footerText?: string;
  footer?: string;
}

export interface TaroCompInputConfig extends TaroCompInput, CompFormItem {
  type: TaroCompType.INPUT;
}

export interface TaroCompInputItemConfig
  extends TaroCompInput,
    TaroCompFormItem {
  type: TaroCompType.INPUT_ITEM;
}

export interface TaroCompSelect
  extends TaroCompConfig,
    CompFormItemWithOptions {}

export interface TaroCompSelectConfig extends TaroCompSelect, CompFormItem {
  type: TaroCompType.SELECT;
}

export interface TaroCompSelectItemConfig
  extends TaroCompSelect,
    TaroCompFormItem {
  type: TaroCompType.SELECT_ITEM;
}

export interface TaroCompDatePicker extends TaroCompConfig {
  mode: 'date' | 'time';
  start: string;
  end: string;
}

export interface TaroCompDatePickerConfig
  extends TaroCompDatePicker,
    CompFormItem {
  type: TaroCompType.DATE_PICKER;
}

export interface TaroCompDatePickerItemConfig
  extends TaroCompDatePicker,
    TaroCompFormItem {
  type: TaroCompType.DATE_PICKER_ITEM;
}

export interface TaroCompRadioConfig
  extends TaroCompConfig,
    TaroCompFormItem,
    CompFormItemWithOptions {
  type: TaroCompType.RADIO;
}

export interface TaroCompCheckboxConfig
  extends TaroCompConfig,
    TaroCompFormItem,
    CompFormItemWithOptions {
  type: TaroCompType.CHECKBOX;
}

export interface TaroCompFormConfig extends TaroCompConfig, CompFormItem {
  type: TaroCompType.FORM;
}

export interface TaroCompSwitchConfig extends TaroCompConfig, CompFormItem {
  type: TaroCompType.SWITCH;
  color?: string;
}

export interface TaroCompBooleanItemConfig
  extends TaroCompConfig,
    TaroCompFormItem,
    CompFormItem {
  type: TaroCompType.BOOLEAN_ITEM;
  switchColor?: string;
  compType: 'switch' | 'check';
}

export interface TaroCompListItemConfig
  extends TaroCompConfig,
    TaroCompFormItem {
  type: TaroCompType.LIST_ITEM;
}

export interface TaroCompListConfig extends TaroCompConfig {
  type: TaroCompType.LIST;
  title?: string;
  card?: boolean;
  error?: string;
  headWidth?: number;
}

export interface TaroCompTextAreaConfig
  extends TaroCompConfig,
    TaroCompFormItem {
  type: TaroCompType.TEXT_AREA;
  maxlength?: number;
}

export interface TaroCompModalConfig extends TaroCompConfig {
  type: TaroCompType.MODAL;
  modalType: 'dialog' | 'half-screen';
  title?: string;
  maskClosable?: boolean;

  noFooter?: boolean;

  onOk?: ActionBinding;
  onCancel?: ActionBinding;

  okText?: string;
  cancelText?: string;
}

export interface TaroCompSliderConfig extends TaroCompConfig, TaroCompFormItem {
  type: TaroCompType.SLIDER;
  min?: number;
  max?: number;
  step?: number;
  disabled?: string;
}

export interface TaroCompSwiperConfig extends TaroCompConfig, TaroCompFormItem {
  type: TaroCompType.SLIDER;
  dataSource?: string;
  imageUrl?: string;
  imageRawProps?: string;
  url?: string;
  current?: string;
  onChange?: ActionBinding;
  autoplay?: boolean;
  element?: string;
}

export interface TaroCompScrollViewConfig extends TaroCompConfig {
  type: TaroCompType.SCROLL_VIEW;
  loading?: string;
  scrollY?: boolean;
  scrollTop?: string;
  scrollX?: boolean;
  hideScrollbar?: boolean;
  flexGrowBottom?: string;
  onScroll?: ActionBinding;
  onRefresherPulling?: ActionBinding;
  refresherEnabled?: boolean;
}
