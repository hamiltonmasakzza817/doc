import {
  ActionBinding,
  CompClickable,
  CompConfig,
  CompFormItem,
  CompOptionAble,
  CompUploader,
} from './comps-common';

export enum MobileCompType {
  BUTTON = 'BUTTON_M',
  CONTAINER = 'CONTAINER_M',
  CAPSULE_TABS = 'CAPSULE_TABS_M',
  TAG = 'TAG_M',
  BADGE = 'BADGE_M',
  LIST = 'LIST_M',
  LIST_ITEM = 'LIST_ITEM_M',
  FORM = 'FORM_M',
  FORM_ITEM = 'FORM_ITEM_M',
  INPUT = 'INPUT_M',
  DATE_PICKER = 'DATE_PICKER_M',
  SELECT = 'SELECT_M',
  SWITCH = 'SWITCH_M',
  CHECKBOX = 'CHECKBOX_M',
  RADIO = 'RADIO_M',
  NUMBER_INPUT = 'NUMBER_INPUT_M',
  SEARCH_BAR = 'SEARCH_BAR_M',
  TEXT_AREA = 'TEXT_AREA_M',
  MODAL = 'MODAL_M',
  UPLOADER = 'UPLOADER_M',
  SWIPER = 'SWIPER_M',
  IMAGE = 'IMAGE_M',
  TABS = 'TABS_M',
  TAB_PANEL = 'TABS_PANEL_M',
  INFINITE_SCROLL = 'INFINITE_SCROLL',
}

export interface MobileCompConfig extends CompConfig {
  type: MobileCompType;
}

export interface MobileCompButtonConfig
  extends MobileCompConfig,
    CompClickable {
  type: MobileCompType.BUTTON;
  color?: 'default' | 'primary' | 'success' | 'warning' | 'danger';
  fill?: 'solid' | 'outline' | 'none';
  size?: 'mini' | 'small' | 'middle' | 'large';
  block?: boolean;
  disabled?: string;
  loading?: string;
  loadingText?: string;
  shape: 'default' | 'rounded' | 'rectangular';
  text?: string;
}

export interface MobileCompContainerConfig
  extends MobileCompConfig,
    CompClickable {
  type: MobileCompType.CONTAINER;
  renderCompId?: string;
  popoverCompId?: string;
  placement?:
    | 'left'
    | 'right'
    | 'top'
    | 'bottom'
    | 'topLeft'
    | 'topRight'
    | 'bottomLeft'
    | 'bottomRight';
  onHeightChange?: ActionBinding;
  flexBottom?: string;
  loading?: string;
}

export interface MobileCompSegmentConfig
  extends MobileCompConfig,
    CompOptionAble {
  type: MobileCompType.CAPSULE_TABS;
  activeKey?: string;
  onChange?: ActionBinding;
}

export interface MobileCompTagConfig extends MobileCompConfig {
  type: MobileCompType.TAG;
  color?: string;
  customColor?: string;
  fill?: 'solid' | 'outline';
  round?: boolean;
  text?: string;
}

export interface MobileCompListConfig extends MobileCompConfig {
  type: MobileCompType.LIST;
  header?: string;
  mode: 'default' | 'card';
}

export interface MobileCompFormItem extends CompFormItem {
  layout: 'vertical' | 'horizontal' | 'none';
}

export interface MobileCompListItemConfig extends MobileCompConfig {
  type: MobileCompType.LIST_ITEM;
  title?: string;
  prefix?: string;
  prefixText?: string;
  description?: string;
  extra?: string;
  arrow: boolean;
  disabled?: string;
  onClick?: ActionBinding;
}

export interface MobileCompFormConfig
  extends MobileCompConfig,
    Pick<MobileCompFormItem, 'layout'>,
    Pick<CompFormItem, 'value'>,
    Pick<MobileCompListConfig, 'mode'> {
  type: MobileCompType.FORM;
}

export interface MobileCompFormItemConfig
  extends MobileCompConfig,
    MobileCompFormItem {
  type: MobileCompType.FORM_ITEM;
}

export interface MobileCompInputConfig
  extends MobileCompConfig,
    MobileCompFormItem {
  type: MobileCompType.INPUT;
  inputType?:
    | 'text'
    | 'bankCard'
    | 'phone'
    | 'password'
    | 'number'
    | 'digit'
    | 'money';
  addonAfter?: string;
}

export interface MobileCompDatePickerConfig
  extends MobileCompConfig,
    MobileCompFormItem {
  type: MobileCompType.DATE_PICKER;
  min?: string;
  max?: string;
  precision:
    | 'year'
    | 'month'
    | 'day'
    | 'hour'
    | 'minute'
    | 'second'
    | 'week'
    | 'week-day';
  format?: string;
}

export interface MobileCompSelectConfig
  extends MobileCompConfig,
    MobileCompFormItem,
    CompOptionAble {
  type: MobileCompType.SELECT;
}

export interface MobileCompSwitchConfig
  extends MobileCompConfig,
    MobileCompFormItem {
  type: MobileCompType.SWITCH;
  checkedValue?: string;
  uncheckedValue?: string;
  checkedText?: string;
  uncheckedText?: string;
}

export interface MobileCompCheckboxConfig
  extends MobileCompConfig,
    MobileCompFormItem,
    CompOptionAble {
  type: MobileCompType.CHECKBOX;
  block?: boolean;
}

export interface MobileCompRadioConfig
  extends MobileCompConfig,
    MobileCompFormItem,
    CompOptionAble {
  type: MobileCompType.RADIO;
  block?: boolean;
}

export interface MobileCompNumberInputConfig
  extends MobileCompConfig,
    MobileCompFormItem {
  type: MobileCompType.NUMBER_INPUT;
  min?: number;
  max?: number;
  step?: number;
}

export interface MobileCompSearchBarConfig extends MobileCompConfig {
  type: MobileCompType.SEARCH_BAR;
  value?: string;
  placeholder?: string;
  clearable?: boolean;
  showCancelButton?: boolean;
  cancelText?: string;
  maxLength?: number;
  onChange?: ActionBinding;
  onSearch?: ActionBinding;
  onBlur?: ActionBinding;
  onFocus?: ActionBinding;
  onClear?: ActionBinding;
}

export interface MobileCompTextAreaConfig
  extends MobileCompConfig,
    MobileCompFormItem {
  type: MobileCompType.TEXT_AREA;
  rows?: number;
  autoSize?: boolean;
  maxLength?: number;
  showCount?: boolean;
}

export interface MobileCompModalConfig extends MobileCompConfig {
  type: MobileCompType.MODAL;
  modalType?: 'dialog' | 'popup';
  visible?: string;
  title?: string;
  noFooter?: boolean;
  position?: 'bottom' | 'top' | 'left' | 'right';

  onOk?: ActionBinding;
  okText?: string;

  onCancel?: ActionBinding;
  cancelText?: string;

  closeOnMaskClick?: boolean;
}

export interface MobileCompUploaderConfig
  extends MobileCompConfig,
    CompUploader,
    CompFormItem {
  type: MobileCompType.UPLOADER;
  loading?: string;
}

export interface MobileCompSwiperConfig extends MobileCompConfig {
  type: MobileCompType.SWIPER;
  autoplay?: boolean;
  autoplayInterval?: number;
  loop?: boolean;
  direction?: 'horizontal' | 'vertical';
  onChange?: ActionBinding;
  slideSize?: number;
  items: {
    dataSource?: string;
    imageUrl?: string;
    element?: string;
  };
}

export interface MobileCompImageConfig extends MobileCompConfig {
  type: MobileCompType.IMAGE;
  src?: string;
  alt?: string;
  fit?: 'contain' | 'cover' | 'fill' | 'none' | 'scale-down';
  placeholder?: string;
  fallback?: string;
  lazy?: boolean;
  onLoad?: ActionBinding;
}

export interface MobileCompTabsConfig extends MobileCompConfig {
  type: MobileCompType.TABS;
  activeKey?: string;
  activeLineMode?: 'auto' | 'full' | 'fixed';
  onChange?: ActionBinding;
  stretch?: boolean;
}

export interface MobileCompTabPanelConfig extends MobileCompConfig {
  type: MobileCompType.TAB_PANEL;
  title?: string;
  disabled?: string;
}

export interface MobileCompInfiniteScrollConfig extends MobileCompConfig {
  type: MobileCompType.INFINITE_SCROLL;
  hasMore?: string;
  onLoadMore?: ActionBinding;
  threshold?: number;
}
