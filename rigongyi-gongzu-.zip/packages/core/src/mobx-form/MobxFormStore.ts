import cloneDeep from 'lodash-es/cloneDeep';
import compact from 'lodash-es/compact';
import forEach from 'lodash-es/forEach';
import get from 'lodash-es/get';
import lodashMap from 'lodash-es/map';
import remove from 'lodash-es/remove';
import set from 'lodash-es/set';
import size from 'lodash-es/size';
import {
  action,
  computed,
  makeObservable,
  observable,
  runInAction,
} from 'mobx';
import { ChangeEvent } from 'react';
import { combineLatest, of } from 'rxjs';
import { map, tap } from 'rxjs/operators';
import { ValuesType } from 'utility-types';
import { BindOptions, ValidateRule } from './types';
import { validate } from './utils';

export interface MobxFormOptions<T> {
  name?: string;
  defaultValues?: T | null;
  setValues?: (values: Record<string, unknown>) => void;
}

type Key<T extends Record<string, unknown>> = keyof T | string;

export default class MobxFormStore<T extends { [key: string]: any }> {
  key = 'FormMobxStore';

  name?: string;

  values: T;

  errors: Record<string, string> = {};

  private defaultValues: T;

  // 一些组件有半受控需求，onChange 不修改 value，onBlur 才修改
  // 这里使用 stashedValues 记录 onChange 时改变
  private stashedValues = observable.map<Key<T>, any>();

  private readonly customSetValues?: ValuesType<
    Pick<MobxFormOptions<T>, 'setValues'>
  >;

  private bindings =
    observable.array<{ key: string; rule: ValidateRule | undefined }>();

  constructor(options: MobxFormOptions<T> = {}) {
    makeObservable(this, {
      name: observable,
      errors: observable,
      updateName: action,
      values: observable,
      dirty: computed,
      setValues: action,
      clearBindings: action,
      reset: action,
      triggerValidation: action,
      unbind: action,
      unbindStartWith: action,
      clearErrors: action,
    });

    const { setValues, defaultValues, name } = options;

    this.name = name;
    this.customSetValues = setValues;

    const values = defaultValues || ({} as T);

    this.defaultValues = cloneDeep(values);
    this.values = values;
  }

  get dirty() {
    // 只检测被 binding 过的
    return Array.from(this.bindings.keys()).some(
      (key) => get(this.values, key) !== get(this.defaultValues, key),
    );
  }

  updateName(name?: string) {
    this.name = name;
  }

  setValues(values: Record<string, unknown>) {
    if (size(values) > 0) {
      if (this.customSetValues) {
        this.customSetValues(values);
      } else {
        Object.entries(values ?? {}).forEach(([key, value]) => {
          set(this.values ?? {}, key, value);
        });
      }
    }
  }

  clearBindings() {
    this.bindings.clear();
    this.clearErrors();
  }

  reset(values?: T) {
    const newValues = values ?? this.defaultValues;

    this.defaultValues = cloneDeep(newValues);
    this.values = newValues;
    this.clearErrors();
  }

  triggerValidation(
    collections: { keys?: string[]; filter?: (key: string) => boolean } = {},
  ) {
    const { keys, filter = () => true } = collections;

    const { bindings, errors } = this;

    const validateKeys = Array.from(keys || bindings.map((b) => b.key));

    if (size(validateKeys) === 0) {
      return of(true);
    }

    return combineLatest(
      lodashMap(validateKeys, (key) => {
        if (filter(key as string)) {
          delete errors[key];

          const binding = bindings.find((b) => b.key === key);

          if (binding != null) {
            const { rule } = binding;

            if (rule) {
              const value = get(this.values, key);

              return validate(value, rule).pipe(
                tap((msg) => {
                  if (msg) {
                    errors[key] = msg;
                  }
                }),
              );
            }
          }
        }

        return of(null);
      }),
    ).pipe(
      map((errs) => compact(errs)),
      tap((errs) => {
        if (size(errs) > 0) {
          // eslint-disable-next-line no-console
          console.log(JSON.stringify(errors));
        }
      }),
      map((errs) => size(errs) === 0),
    );
  }

  bind(
    key: Key<T>,
    options: BindOptions = {},
  ): {
    value: ValuesType<T> | any;
    onChange: (
      valueOrEvent?:
        | any
        | ValuesType<T>
        | boolean
        | ChangeEvent<HTMLInputElement>
        | ChangeEvent<HTMLTextAreaElement>,
    ) => void;
    onBlur?: () => void;
    onFocus?: () => void;
  } {
    const { onBlur = false, ...rule } = options;
    const { stashedValues } = this;

    this.unbind(key);

    this.bindings.push({
      key: key as string,
      rule: size(rule) > 0 ? rule : undefined,
    });

    let value: any;

    if (onBlur && stashedValues.has(key)) {
      value = stashedValues.get(key);
    } else {
      value = get(this.values, key);
    }

    return {
      value,
      onBlur: onBlur
        ? () => {
            this.setValues({ [key]: stashedValues.get(key) });
            runInAction(() => {
              stashedValues.delete(key);
            });
          }
        : undefined,
      onFocus: onBlur
        ? () => {
            runInAction(() => {
              stashedValues.set(key, value);
            });
          }
        : undefined,
      onChange: (valueOrEvent) => {
        const changedValue =
          valueOrEvent != null &&
          typeof valueOrEvent === 'object' &&
          'target' in valueOrEvent
            ? valueOrEvent.target.value
            : valueOrEvent;

        runInAction(() => {
          delete this.errors[key as string];

          if (onBlur) {
            stashedValues.set(key, changedValue);
          } else {
            this.setValues({ [key]: changedValue });
          }
        });

        return changedValue;
      },
    };
  }

  unbind(key: Key<T>) {
    remove(this.bindings, (bind) => bind.key === key);
  }

  unbindStartWith(prefix: string) {
    const keys = this.bindings
      .filter((bind) => bind.key.startsWith(prefix))
      .map((bind) => bind.key);

    keys.forEach((key) => {
      this.unbind(key as any);
    });
  }

  clearErrors(
    options: { keys?: string[]; filter?: (key: string) => boolean } = {},
  ) {
    const { keys, filter = () => true } = options;

    const clearingKeys = Array.from(
      keys || this.bindings.map((bind) => bind.key),
    );

    forEach(clearingKeys, (key) => {
      if (filter(key as string)) {
        delete this.errors[key];
      }
    });
  }

  get bindingKeys() {
    return this.bindings.map((bind) => bind.key);
  }
}
