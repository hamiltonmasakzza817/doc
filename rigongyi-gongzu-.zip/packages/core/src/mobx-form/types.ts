export interface Rules {
  [key: string]: ValidateRule;
}

export interface Errors {
  [key: string]: string;
}

export interface RuleTypeComplex<T> {
  value: T;
  message?: string;
}

export type RuleType<T> = RuleTypeComplex<T> | T;

export interface ValidateRule {
  required?: RuleType<boolean>;
  pattern?: RuleType<RegExp>;
  validate?: RuleType<(value: any) => null | string | Promise<null | string>>;
  remoteValidate?: RuleType<{
    url: string;
    method?: 'GET' | 'POST';
    getParams: (value: any) => Record<string, unknown>;
  }>;
}

export type BindOptions = ValidateRule & {
  onBlur?: boolean;
};
