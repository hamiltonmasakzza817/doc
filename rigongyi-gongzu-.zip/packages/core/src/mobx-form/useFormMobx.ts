import React from 'react';
import MobxFormStore, { MobxFormOptions } from './MobxFormStore';

export default function useFormMobx<T>(options: MobxFormOptions<T> = {}) {
  return React.useMemo(() => new MobxFormStore(options), []);
}
