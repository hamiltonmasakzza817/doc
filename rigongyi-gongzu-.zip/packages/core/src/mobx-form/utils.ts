import isEmpty from 'lodash-es/isEmpty';

import { from, Observable, of } from 'rxjs';
import { map } from 'rxjs/operators';
import { createService } from '../config/service';
import { RuleType, RuleTypeComplex, ValidateRule } from './types';

const defaultErrorMessage: { [key: string]: string } = {
  required: '必填项需填写',
  pattern: '格式不匹配',
  validate: '验证未通过',
  remoteValidate: '远程验证未通过',
};

export function getItemErrorProps(error?: string): {
  validateStatus: '' | 'error' | 'success' | 'warning' | 'validating';
  help?: string;
} {
  return {
    validateStatus: error ? 'error' : '',
    help: error,
  };
}

function formatRuleType<T>(
  ruleType: RuleType<T>,
  name: string,
): RuleTypeComplex<T> {
  if (typeof ruleType === 'object' && 'value' in ruleType) {
    return ruleType as RuleTypeComplex<T>;
  }

  return {
    value: ruleType as T,
    message: defaultErrorMessage[name],
  };
}

export function validate(
  value: any,
  rule: ValidateRule,
): Observable<string | null> {
  if (rule.required) {
    const { value: ruleValue, message } = formatRuleType(
      rule.required,
      'required',
    );
    if (
      ruleValue &&
      (value == null ||
        `${value}` === '' ||
        (Array.isArray(value) && isEmpty(value)))
    ) {
      return of(message || defaultErrorMessage.required);
    }
  }

  if (rule.pattern) {
    const { value: ruleValue, message } = formatRuleType(
      rule.pattern,
      'pattern',
    );

    if (!ruleValue.test(`${value}`)) {
      return of(message || defaultErrorMessage.pattern);
    }
  }

  if (rule.validate) {
    const { value: ruleValue } = formatRuleType(rule.validate, 'validate');
    const validateResult = ruleValue(value);

    if (typeof validateResult === 'string') {
      return of(validateResult);
    }

    if (validateResult instanceof Promise) {
      return from(validateResult);
    }
  }

  if (rule.remoteValidate) {
    const { value: ruleValue, message } = formatRuleType(
      rule.remoteValidate,
      'remoteValidate',
    );

    const method = (ruleValue.method || 'GET').toLowerCase() as 'get' | 'post';
    const params = ruleValue.getParams(value);

    const service = createService();

    return from(
      service[method]<boolean>(
        ruleValue.url,
        method === 'get' ? { params } : params,
      ),
    ).pipe(
      map((isValid) => {
        if (!isValid.data) {
          return message || defaultErrorMessage.remoteValidate;
        }

        return null;
      }),
    );
  }

  return of(null);
}

export function validateJSON(value: any) {
  let isValid: boolean;

  if (value === '' || value == null) {
    return null;
  }

  try {
    JSON.parse(value);
    isValid = true;
  } catch (e) {
    isValid = false;
  }

  return isValid ? null : 'JSON不合法';
}
