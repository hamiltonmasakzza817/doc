export const addingId = 'adding';
export const emptyOption = 'empty';

export const fontFamilyBase = `"PingFangSC-Medium",
"Helvetica Neue","PingFangSC-Regular", "Chinese Quote",-apple-system,BlinkMacSystemFont, 
"Segoe UI","PingFang SC","Hiragino Sans GB","Microsoft YaHei", Helvetica,Arial,sans-serif, 
"Apple Color Emoji","Segoe UI Emoji","Segoe UI Symbol";`;

export const antdIconsUrl = '//at.alicdn.com/t/font_2047187_wlc8k6ivd3.js';

