import LoggerStore from '@gongzu/core/stores/LoggerStore';
import MessageStore from '@gongzu/core/stores/MessageStore';
import PageStore from '@gongzu/core/stores/PageStore';
import SessionStore from '@gongzu/core/stores/SessionStore';
import StreamStore from '@gongzu/core/stores/StreamStore';
import PageManageStore from '../store/PageManageStore';

export const loggerStore = new LoggerStore();
export const messageStore = new MessageStore();
export const streamStore = new StreamStore(loggerStore);
export const pageStore = new PageStore(streamStore);
export const pageManageStore = new PageManageStore(
  pageStore,
  loggerStore,
  streamStore,
);
export const sessionStore = new SessionStore(streamStore);
