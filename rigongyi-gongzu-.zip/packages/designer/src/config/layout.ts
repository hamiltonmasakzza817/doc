import { ColProps } from 'antd/es/col';

export interface FormLayout {
  labelCol?: ColProps;
  wrapperCol: ColProps;
}

export const dialogFormItemLayout: FormLayout = {
  labelCol: {
    xs: { span: 24 },
    sm: { span: 4 },
  },
  wrapperCol: {
    xs: { span: 24 },
    sm: { span: 20 },
  },
};
