import '@gongzu/core/config/global-configs';
import { configService } from '@gongzu/core/config/service';
import { ConfigProvider } from 'antd';
import zhCN from 'antd/lib/locale/zh_CN';
import axios from 'axios';
import React from 'react';
import ReactDOM from 'react-dom';
import Designer from './Designer';

require('@gongzu/core/style.scss');

const portal = document.body;
let root: Element | null;

configService({ axios });

function main() {
  root = portal.querySelector('#gongzu-designer');

  ReactDOM.render(
    <ConfigProvider locale={zhCN}>
      <Designer />
    </ConfigProvider>,
    root,
  );
}

main();
