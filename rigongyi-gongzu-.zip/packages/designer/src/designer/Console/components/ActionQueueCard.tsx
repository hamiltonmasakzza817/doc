import { EditOutlined } from '@ant-design/icons';
import language from '@gongzu/core/config/language';
import { EngineStoresContext } from '@gongzu/core/contexts/store-contexts';
import {
  ActionOtherActionQueue,
  ActionQueue,
  ActionType,
} from '@gongzu/core/types/entities';
import { Card } from 'antd';
import React from 'react';
import ClickableText from '../../../components/ClickableText';

function ActionQueueCard(props: {
  title?: string;
  actionQueue: ActionQueue;
  extra?: JSX.Element;
  onEdit: (event: React.MouseEvent<HTMLDivElement, MouseEvent>) => void;
}) {
  const { actionQueue, title, extra, onEdit } = props;

  const { engineModelStore } = React.useContext(EngineStoresContext);

  return (
    <Card
      title={
        actionQueue
          ? `${actionQueue.name}${
              actionQueue.code ? `（${actionQueue.code}）` : ''
            }`
          : title
      }
      size="small"
      type="inner"
      extra={
        <>
          {extra}

          <ClickableText onClick={onEdit} className="ml-1 text-primary">
            <EditOutlined />
          </ClickableText>
        </>
      }
    >
      {actionQueue.actions?.length > 0 ? (
        <>
          {!!actionQueue.confirm && <div>确认信息：{actionQueue.confirm}</div>}

          {actionQueue.actions.map((action, index) => {
            if (action.type === ActionType.OTHER_ACTION_QUEUE) {
              const queue =
                engineModelStore.actions[
                  (action as ActionOtherActionQueue).actionId
                ];

              if (queue == null) {
                return <></>;
              }

              return (
                <div key={queue.id}>
                  {index + 1}. {queue.name}
                </div>
              );
            }

            return (
              <div key={`${index + 1}`}>
                {index + 1}. {language.pageActionType[action.type]}
              </div>
            );
          })}
        </>
      ) : (
        <div>空</div>
      )}
    </Card>
  );
}

export default ActionQueueCard;
