import { FileOutlined, FolderOutlined } from '@ant-design/icons';
import { EngineStoresContext } from '@gongzu/core/contexts/store-contexts';
import { DataNode, TreeNode } from '@gongzu/core/types/entities';
import { mapTreeNode } from '@gongzu/core/utils/tree';
import { TreeSelect } from 'antd';
import concat from 'lodash-es/concat';
import { observer } from 'mobx-react';
import React from 'react';
import { emptyOption } from '../../../config/constants';

function CustomCompSelect(props: {
  onChange: (value?: string) => void;
  value: string;
  showEmpty?: boolean;
  additionSelections?: DataNode[];
}) {
  const { engineModelStore } = React.useContext(EngineStoresContext);

  const { onChange, value, showEmpty = false, additionSelections = [] } = props;

  const { customs, customTree } = engineModelStore;

  return (
    <TreeSelect<string>
      treeIcon
      allowClear
      treeData={concat(
        additionSelections,
        showEmpty ? { title: '无', key: emptyOption, value: emptyOption } : [],
        mapTreeNode<TreeNode, DataNode>(customTree, (treeNode) => {
          if (treeNode.id === '-1') {
            return {
              title: treeNode.name as string,
              key: treeNode.id,
              value: treeNode.id,
              icon: <FolderOutlined />,
            };
          }

          const config = customs[treeNode.id];

          return {
            title: config.name,
            key: config.id,
            value: config.id,
            icon: <FileOutlined />,
          };
        }),
      )}
      value={value == null && showEmpty ? emptyOption : value}
      onChange={(value1) => {
        if (onChange) {
          onChange(showEmpty && value1 === emptyOption ? undefined : value1);
        }
      }}
    />
  );
}

export default observer(CustomCompSelect);
