import { gzdnBem } from '@gongzu/core/config/constants';
import language from '@gongzu/core/config/language';
import {
  ActionQueue,
  ActionQueueConflictResolver,
} from '@gongzu/core/types/entities';
import { Card, CardProps } from 'antd';
import classNames from 'classnames';
import { observer } from 'mobx-react';
import React from 'react';

export default observer(
  (
    props: Partial<CardProps> & {
      actionQueue: ActionQueue;
    },
  ) => {
    const { className, actionQueue, ...cardProps } = props;
    return (
      <Card
        {...cardProps}
        className={classNames(gzdnBem('action-card')(), className)}
        title={actionQueue.name}
        size="small"
        type="inner"
      >
        <div>编码：{actionQueue.code || '--'}</div>
        <div>二次确认：{actionQueue.confirm || '--'}</div>
        <div>成功提示：{actionQueue.success || '--'}</div>
        <div>
          冲突解决：
          {
            language.pageActionQueueConflictResolver[
              actionQueue.conflictResolver || ActionQueueConflictResolver.BOTH
            ]
          }
        </div>
        <div>
          上下文：
          {actionQueue.context ? JSON.stringify(actionQueue.context) : '--'}
        </div>
      </Card>
    );
  },
);
