import Loading from '@gongzu/core/common/Loading';
import language from '@gongzu/core/config/language';
import { EngineStoresContext } from '@gongzu/core/contexts/store-contexts';
import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { getItemErrorProps, validateJSON } from '@gongzu/core/mobx-form/utils';
import {
  Action,
  ActionControlModal,
  ActionFetchData,
  ActionGo,
  ActionQueue,
  ActionQueueType,
  ActionType,
  EventType,
  LoggerLevel,
  LoggerType,
} from '@gongzu/core/types/entities';
import { Form, Input, InputNumber, Modal, Radio, Select, Switch } from 'antd';
import get from 'lodash-es/get';

import { Observer } from 'mobx-react';
import React from 'react';
import Loadable from 'react-loadable';
import ExpressionInput from '../../../components/ExpressionInput';
import { IPageActionQueueForm } from './type';

const CodeEditor = Loadable({
  loader: () => import('../../../../components/CodeEditor'),
  loading: Loading,
});

const defaultAction = {
  type: ActionType.FETCH_DATA,
} as ActionFetchData;

const defaultCode = `function execAction(state, _params, _context, _index, _pathname, _pathnames, utils) {
}`;

function getActionOptions(
  actions: Record<string, ActionQueue>,
  allowLocal = false,
) {
  return Object.values(actions)
    .filter(
      (ac) => ac.type === ActionQueueType.GLOBAL || (allowLocal && ac.code),
    )
    .map((ac) => (
      <Select.Option key={ac.id} value={ac.id}>
        {ac.type === ActionQueueType.GLOBAL ? ac.name : ac.code}
      </Select.Option>
    ));
}

export default function ActionForm(props: {
  form: MobxFormStore<IPageActionQueueForm>;
  prefix: string;
  visible: boolean;
}) {
  const { form, prefix, visible } = props;

  const { engineModelStore } = React.useContext(EngineStoresContext);

  React.useEffect(
    () => () => {
      form.unbindStartWith(prefix);
    },
    [],
  );

  return (
    <Observer>
      {() => {
        const action = get(form.values, prefix) as Action;

        if (action == null) {
          form.unbindStartWith(prefix);
          return <></>;
        }

        const isCustom = action.type !== ActionType.OTHER_ACTION_QUEUE;

        return (
          <>
            <Form.Item label="自定义">
              <Switch
                checked={isCustom}
                onChange={(checked) => {
                  if (checked) {
                    form.setValues({
                      [prefix]: defaultAction,
                    });
                  } else {
                    form.setValues({
                      [prefix]: {
                        type: ActionType.OTHER_ACTION_QUEUE,
                        params: action.params,
                      },
                    });
                  }
                }}
              />
            </Form.Item>

            {isCustom ? (
              <Observer>
                {() => {
                  form.unbind(`${prefix}.actionId`);

                  return (
                    <>
                      <Form.Item
                        label="类型"
                        required
                        {...getItemErrorProps(form.errors[`${prefix}.type`])}
                      >
                        <Select<ActionType>
                          {...form.bind(`${prefix}.type`, { required: true })}
                          onChange={(value: ActionType) => {
                            let code = get(form.values, `${prefix}.code`);

                            if (
                              value === ActionType.EXEC_CODE &&
                              code == null
                            ) {
                              code = defaultCode;
                            }

                            form.setValues({
                              [`${prefix}.type`]: value,
                              [`${prefix}.code`]: code,
                            });
                          }}
                        >
                          {[
                            ActionType.FETCH_DATA,
                            ActionType.SET_DATA,
                            ActionType.EXEC_CODE,
                            ActionType.CONTROL_MODAL,
                            ActionType.GUARD,
                            ActionType.SEND_REQUEST,
                            ActionType.NOTIFICATION,
                            ActionType.VALIDATE_FORM,
                            ActionType.DISPATCH_PAGE_EVENT,
                            ActionType.CLEAR_FORM_ERRORS,
                            ActionType.DELAY,
                            ActionType.GO,
                            ActionType.ACTION_SHEET,
                            ActionType.CONTROL_EVENTS,
                            ActionType.CANCEL_ACTION_QUEUE,
                          ].map((actionType) => (
                            <Select.Option key={actionType} value={actionType}>
                              {language.pageActionType[actionType]}【
                              {language.pageActionTypeEn[actionType]}】
                            </Select.Option>
                          ))}
                        </Select>
                      </Form.Item>

                      {action.type === ActionType.FETCH_DATA ? (
                        <Form.Item
                          label="数据"
                          required
                          {...getItemErrorProps(
                            form.errors[`${prefix}.dataCode`],
                          )}
                        >
                          <Select
                            {...form.bind(`${prefix}.dataCode`, {
                              required: true,
                            })}
                          >
                            {Object.values(engineModelStore.datas).map(
                              (data) => (
                                <Select.Option
                                  key={data.code}
                                  value={data.code}
                                >
                                  {data.name}
                                </Select.Option>
                              ),
                            )}
                          </Select>
                        </Form.Item>
                      ) : (
                        <>
                          {(() => {
                            form.unbind(`${prefix}.dataCode`);
                          })()}
                        </>
                      )}

                      {action.type === ActionType.DELAY && (
                        <Form.Item label="时间">
                          <InputNumber
                            {...form.bind(`${prefix}.duration`)}
                            precision={0}
                            min={0}
                          />
                          （毫秒）
                        </Form.Item>
                      )}

                      {action.type === ActionType.GO ? (
                        <>
                          <Form.Item
                            label="URL"
                            required
                            {...getItemErrorProps(form.errors[`${prefix}.url`])}
                          >
                            <Input
                              placeholder="http://"
                              {...form.bind(`${prefix}.url`, {
                                required: true,
                              })}
                            />
                          </Form.Item>

                          <Form.Item label="新页面打开">
                            <Switch
                              {...form.bind(`${prefix}.open`)}
                              checked={(action as ActionGo).open}
                            />
                          </Form.Item>

                          <Form.Item label="使用pushState">
                            <Switch
                              {...form.bind(`${prefix}.usePushState`)}
                              checked={(action as ActionGo).usePushState}
                            />
                          </Form.Item>

                          <Form.Item label="使用replace">
                            <Switch
                              {...form.bind(`${prefix}.useReplace`)}
                              checked={(action as ActionGo).useReplace}
                            />
                          </Form.Item>
                        </>
                      ) : (
                        <>
                          {(() => {
                            form.unbind(`${prefix}.url`);
                          })()}
                        </>
                      )}

                      {action.type === ActionType.SEND_REQUEST ? (
                        <>
                          <Form.Item
                            label="URL"
                            required
                            {...getItemErrorProps(form.errors[`${prefix}.url`])}
                          >
                            <Input
                              placeholder="http://"
                              {...form.bind(`${prefix}.url`, {
                                required: true,
                              })}
                            />
                          </Form.Item>

                          <Form.Item label="Method">
                            <Radio.Group
                              {...form.bind(`${prefix}.method`)}
                              defaultValue="GET"
                            >
                              <Radio key="GET" value="GET">
                                Get
                              </Radio>
                              <Radio key="POST" value="POST">
                                POST
                              </Radio>
                              <Radio key="PUT" value="PUT">
                                PUT
                              </Radio>
                              <Radio key="DELETE" value="DELETE">
                                DELETE
                              </Radio>
                            </Radio.Group>
                          </Form.Item>

                          <Form.Item
                            label="Content-Type"
                            {...getItemErrorProps(
                              form.errors[`${prefix}.format`],
                            )}
                          >
                            <Radio.Group
                              {...form.bind(`${prefix}.format`)}
                              defaultValue="form"
                            >
                              <Radio value="form">
                                application/x-www-form-urlencoded
                              </Radio>
                              <Radio value="json">application/json</Radio>
                            </Radio.Group>
                          </Form.Item>

                          <Form.Item
                            label="参数序列化配置"
                            {...getItemErrorProps(
                              form.errors[`${prefix}.stringifyOptions`],
                            )}
                            wrapperCol={{ span: 24 }}
                            labelCol={{ span: 24 }}
                          >
                            <CodeEditor
                              language="json"
                              height={200}
                              width={652}
                              {...form.bind(`${prefix}.stringifyOptions`, {
                                validate: validateJSON,
                              })}
                            />
                          </Form.Item>

                          <Form.Item label="忽略异常">
                            <Switch
                              {...form.bind(`${prefix}.ignoreException`)}
                              checked={get(
                                form.values,
                                `${prefix}.ignoreException`,
                              )}
                            />
                          </Form.Item>
                        </>
                      ) : (
                        <>
                          {(() => {
                            form.unbind(`${prefix}.url`);
                            form.unbind(`${prefix}.method`);
                            form.unbind(`${prefix}.format`);
                          })()}
                        </>
                      )}

                      {action.type === ActionType.CONTROL_MODAL ? (
                        <>
                          <Form.Item
                            label="对话框"
                            required
                            {...getItemErrorProps(
                              form.errors[`${prefix}.modalId`],
                            )}
                          >
                            <Select
                              {...form.bind(`${prefix}.modalId`, {
                                required: true,
                              })}
                            >
                              {engineModelStore.modals.map((modal) => (
                                <Select.Option key={modal.id} value={modal.id}>
                                  {modal.name}
                                </Select.Option>
                              ))}
                            </Select>
                          </Form.Item>

                          <Form.Item label="操作">
                            <Switch
                              {...form.bind(`${prefix}.open`)}
                              checked={(action as ActionControlModal).open}
                              checkedChildren={<span>开启</span>}
                              unCheckedChildren={<span>关闭</span>}
                            />
                          </Form.Item>
                        </>
                      ) : (
                        <>
                          {(() => {
                            form.unbind(`${prefix}.modalId`);
                          })()}
                        </>
                      )}

                      {action.type === ActionType.VALIDATE_FORM ? (
                        <>
                          <Form.Item label="路径">
                            <ExpressionInput
                              {...form.bind(`${prefix}.pathname`)}
                              asPathname
                            />
                          </Form.Item>

                          <Form.Item label="定位错误">
                            <Switch
                              checked={get(
                                form.values,
                                `${prefix}.scrollIntoView`,
                              )}
                              {...form.bind(`${prefix}.scrollIntoView`)}
                            />
                          </Form.Item>
                        </>
                      ) : (
                        <>
                          {(() => {
                            form.unbind(`${prefix}.pathname`);
                          })()}
                        </>
                      )}

                      {action.type === ActionType.CLEAR_FORM_ERRORS ? (
                        <>
                          <Form.Item label="路径" required>
                            <ExpressionInput
                              {...form.bind(`${prefix}.pathname`, {
                                required: true,
                              })}
                              asPathname
                            />
                          </Form.Item>
                        </>
                      ) : (
                        <>
                          {(() => {
                            form.unbind(`${prefix}.pathname`);
                          })()}
                        </>
                      )}

                      {[ActionType.EXEC_CODE, ActionType.GUARD].includes(
                        action.type,
                      ) ? (
                        <>
                          <Form.Item label="代码">
                            <Switch
                              checked={get(action, 'code')}
                              onChange={(check) => {
                                if (!check) {
                                  Modal.confirm({
                                    title: '确认清空代码？',
                                    onOk: () => {
                                      form.setValues({
                                        [`${prefix}.code`]: undefined,
                                      });
                                    },
                                  });
                                } else {
                                  form.setValues({
                                    [`${prefix}.code`]: defaultCode,
                                  });
                                }
                              }}
                            />
                          </Form.Item>

                          {get(action, 'code') && (
                            <Form.Item
                              {...getItemErrorProps(
                                form.errors[`${prefix}.code`],
                              )}
                              wrapperCol={{ span: 24 }}
                              labelCol={{ span: 24 }}
                            >
                              {visible && (
                                <CodeEditor
                                  width={652}
                                  language="javascript"
                                  {...form.bind(`${prefix}.code`)}
                                />
                              )}
                            </Form.Item>
                          )}
                        </>
                      ) : (
                        <>
                          {(() => {
                            form.unbind(`${prefix}.code`);
                          })()}
                        </>
                      )}

                      {action.type === ActionType.GUARD && (
                        <Form.Item label="用户确认">
                          <ExpressionInput
                            {...form.bind(`${prefix}.confirm`)}
                          />
                        </Form.Item>
                      )}

                      {action.type === ActionType.CONTROL_EVENTS ? (
                        <>
                          <Form.Item label="订阅事件">
                            <Switch
                              {...form.bind(`${prefix}.start`)}
                              checked={get(form.values, `${prefix}.start`)}
                              checkedChildren={<span>订阅</span>}
                              unCheckedChildren={<span>取消</span>}
                            />
                          </Form.Item>

                          <Form.Item label="选择事件" required>
                            <Observer>
                              {() => (
                                <Select
                                  allowClear
                                  {...form.bind(`${prefix}.eventId`, {
                                    required: true,
                                  })}
                                >
                                  {engineModelStore.events
                                    .filter((e) =>
                                      [
                                        EventType.INTERVAL,
                                        EventType.DOM_EVENT,
                                        EventType.DATA_CHANGE,
                                      ].includes(e.type),
                                    )
                                    .map((e) => (
                                      <Select key={e.id} value={e.id}>
                                        {e.name}
                                      </Select>
                                    ))}
                                </Select>
                              )}
                            </Observer>
                          </Form.Item>
                        </>
                      ) : (
                        <>
                          {(() => {
                            form.unbind(`${prefix}.eventId`);
                          })()}
                        </>
                      )}

                      {action.type === ActionType.NOTIFICATION ? (
                        <>
                          <Form.Item label="消息" required>
                            <ExpressionInput
                              {...form.bind(`${prefix}.message`, {
                                required: true,
                              })}
                            />
                          </Form.Item>

                          <Form.Item label="消息级别">
                            <Radio.Group
                              {...form.bind(`${prefix}.loggerLevel`)}
                              defaultValue={LoggerLevel.SUCCESS}
                              options={[
                                {
                                  label: '成功',
                                  value: LoggerLevel.SUCCESS,
                                },
                                {
                                  label: '提示',
                                  value: LoggerLevel.INFO,
                                },
                                {
                                  label: '错误',
                                  value: LoggerLevel.ERROR,
                                },
                              ]}
                            />
                          </Form.Item>

                          <Form.Item label="消息类型">
                            <Radio.Group
                              {...form.bind(`${prefix}.loggerType`)}
                              defaultValue={LoggerType.NOTIFICATION}
                              options={[
                                {
                                  label: '通知',
                                  value: LoggerType.NOTIFICATION,
                                },
                                {
                                  label: '消息',
                                  value: LoggerType.MESSAGE,
                                },
                                {
                                  label: '终端',
                                  value: LoggerType.CONSOLE,
                                },
                              ]}
                            />
                          </Form.Item>
                        </>
                      ) : (
                        <>
                          {(() => {
                            form.unbind(`${prefix}.message`);
                          })()}
                        </>
                      )}

                      {action.type === ActionType.DISPATCH_PAGE_EVENT ? (
                        <Form.Item label="页面事件名" required>
                          <Input
                            {...form.bind(`${prefix}.pageEventName`, {
                              required: true,
                            })}
                          />
                        </Form.Item>
                      ) : (
                        <>
                          {(() => {
                            form.unbind(`${prefix}.pageEventName`);
                          })()}
                        </>
                      )}

                      {action.type === ActionType.CANCEL_ACTION_QUEUE ? (
                        <Form.Item label="Action" required>
                          <Select {...form.bind(`${prefix}.actionId`)}>
                            {getActionOptions(engineModelStore.actions, true)}
                          </Select>
                        </Form.Item>
                      ) : (
                        <>
                          {(() => {
                            form.unbind(`${prefix}.actionId`);
                          })()}
                        </>
                      )}
                    </>
                  );
                }}
              </Observer>
            ) : (
              <Observer>
                {() => {
                  form.unbind(`${prefix}.type`);
                  form.unbind(`${prefix}.formCode`);
                  form.unbind(`${prefix}.url`);
                  form.unbind(`${prefix}.dataCode`);
                  form.unbind(`${prefix}.url`);
                  form.unbind(`${prefix}.code`);
                  form.unbind(`${prefix}.interfaceId`);
                  form.unbind(`${prefix}.modalId`);
                  form.unbind(`${prefix}.pageEventName`);

                  return (
                    <Form.Item label="Action" required>
                      <Select {...form.bind(`${prefix}.actionId`)}>
                        {getActionOptions(engineModelStore.actions)}
                      </Select>
                    </Form.Item>
                  );
                }}
              </Observer>
            )}

            <Form.Item label="自定义参数">
              <Switch
                checked={action.params != null}
                onChange={(check) => {
                  if (!check) {
                    Modal.confirm({
                      title: '确认清空自定义参数？',
                      onOk: () => {
                        form.setValues({
                          [`${prefix}.params`]: undefined,
                        });
                      },
                    });
                  } else {
                    form.setValues({
                      [`${prefix}.params`]: '{}',
                    });
                  }
                }}
              />
            </Form.Item>

            {action.params != null ? (
              <Form.Item
                label="参数编辑"
                {...getItemErrorProps(form.errors[`${prefix}.params`])}
                wrapperCol={{ span: 24 }}
                labelCol={{ span: 24 }}
              >
                <CodeEditor
                  language="json"
                  height={200}
                  width={652}
                  {...form.bind(`${prefix}.params`, {
                    validate: validateJSON,
                  })}
                />
              </Form.Item>
            ) : (
              <>
                {(() => {
                  form.unbind(`${prefix}.params`);
                })()}
              </>
            )}

            <Form.Item label="上下文">
              <Switch
                checked={action.context != null}
                onChange={(check) => {
                  if (!check) {
                    Modal.confirm({
                      title: '确认清空上下文？',
                      onOk: () => {
                        form.setValues({
                          [`${prefix}.context`]: undefined,
                        });
                      },
                    });
                  } else {
                    form.setValues({
                      [`${prefix}.context`]: '{}',
                    });
                  }
                }}
              />
            </Form.Item>

            {action.context != null ? (
              <Form.Item
                label="上下文编辑"
                {...getItemErrorProps(form.errors[`${prefix}.context`])}
                wrapperCol={{ span: 24 }}
                labelCol={{ span: 24 }}
              >
                <CodeEditor
                  language="json"
                  height={200}
                  width={652}
                  {...form.bind(`${prefix}.context`, {
                    validate: validateJSON,
                  })}
                />
              </Form.Item>
            ) : (
              <>
                {(() => {
                  form.unbind(`${prefix}.context`);
                })()}
              </>
            )}
          </>
        );
      }}
    </Observer>
  );
}
