import {
  Action,
  ActionQueue,
  asyncActions,
  rejectableActions,
} from '@gongzu/core/types/entities';
import { parseJSON } from '@gongzu/core/utils/data';
import jsonPretty from 'json-stringify-pretty-compact';
import cloneDeep from 'lodash-es/cloneDeep';
import concat from 'lodash-es/concat';
import forEach from 'lodash-es/forEach';
import get from 'lodash-es/get';

export function collectForeignActionIds(
  actionId = '',
  actionQueues: Record<string, ActionQueue> = {},
): string[] {
  if (!actionId) {
    return [];
  }

  const actionQueue = actionQueues[actionId];

  let foreignActionIds = [actionId];

  forEach(actionQueue.actions, (action) => {
    if (concat(asyncActions, rejectableActions).includes(action.type)) {
      const foreignActionId = get(
        action,
        asyncActions.includes(action.type)
          ? 'parallelActionId'
          : 'rejectActionId',
      );

      if (foreignActionId) {
        foreignActionIds = concat(
          foreignActionIds,
          collectForeignActionIds(foreignActionId, actionQueues),
        );
      }
    }
  });

  return foreignActionIds;
}

export function pageActionToForm(action: Action) {
  return {
    ...cloneDeep(action),
    params: action.params
      ? jsonPretty(action.params, {
          maxLength: 0,
        })
      : undefined,
    context: action.context
      ? jsonPretty(action.context, {
          maxLength: 0,
        })
      : undefined,
  };
}

export function pageActionQueueToForm(actionQueue: ActionQueue) {
  return {
    ...cloneDeep(actionQueue),
    context: (actionQueue.context
      ? jsonPretty(actionQueue.context, {
          maxLength: 0,
        })
      : undefined) as any,
    actions: actionQueue.actions.map(pageActionToForm) as any,
  };
}

export function formToPageActionQueue(actionQueueForm: any): ActionQueue {
  return {
    ...actionQueueForm,
    context: actionQueueForm.context
      ? parseJSON(actionQueueForm.context)
      : null,
    actions: actionQueueForm.actions.map((act: any) => ({
      ...act,
      params: act.params ? parseJSON(act.params) : null,
      context: act.context ? parseJSON(act.context) : null,
    })),
  };
}
