import { gzdnBem } from '@gongzu/core/config/constants';
import language from '@gongzu/core/config/language';
import { EngineStoresContext } from '@gongzu/core/contexts/store-contexts';
import {
  Action,
  ActionCancelActionQueue,
  ActionClearFormErrors,
  ActionControlEvent,
  ActionControlModal,
  ActionDelay,
  ActionDispatchPageEvent,
  ActionExecCode,
  ActionFetchData,
  ActionGo,
  ActionGuard,
  ActionNotification,
  ActionOtherActionQueue,
  ActionSendRequest,
  ActionType,
  ActionValidateForm,
} from '@gongzu/core/types/entities';
import { Card, CardProps } from 'antd';
import classNames from 'classnames';
import find from 'lodash-es/find';
import get from 'lodash-es/get';
import { observer } from 'mobx-react';
import React from 'react';

export default observer(
  (
    props: Partial<CardProps> & {
      action: Action;
    },
  ) => {
    const { action, className, ...cardProps } = props;

    const { engineModelStore } = React.useContext(EngineStoresContext);

    return (
      <Card
        {...cardProps}
        className={classNames(
          className,
          gzdnBem('action-card')(),
        )}
        title={language.pageActionType[action.type]}
        size="small"
        type="inner"
      >
        <div>
          参数：
          {action.params ? JSON.stringify(action.params) : '--'}
        </div>
        <div>
          上下文：
          {action.context ? JSON.stringify(action.context) : '--'}
        </div>

        {(() => {
          switch (action.type) {
            case ActionType.OTHER_ACTION_QUEUE: {
              const act = action as ActionOtherActionQueue;

              return (
                <div>
                  执行Action：
                  {get(engineModelStore.actions, `${act.actionId}.name`) ||
                    '--'}
                </div>
              );
            }

            case ActionType.CANCEL_ACTION_QUEUE: {
              const act = action as ActionCancelActionQueue;

              return (
                <div>
                  取消Action：
                  {engineModelStore.actions[act.actionId].name}
                </div>
              );
            }

            case ActionType.CLEAR_FORM_ERRORS: {
              const act = action as ActionClearFormErrors;

              return <div>路径：{act.pathname}</div>;
            }

            case ActionType.CONTROL_EVENTS: {
              const act = action as ActionControlEvent;
              return (
                <div>
                  {act.start ? '注册' : '取消注册'}事件：
                  {get(
                    find(engineModelStore.events, (e) => e.id === act.eventId),
                    'name',
                  ) || '--'}
                </div>
              );
            }

            case ActionType.CONTROL_MODAL: {
              const act = action as ActionControlModal;
              return (
                <div>
                  {act.open ? '开启' : '关闭'}对话框：
                  {get(
                    find(engineModelStore.modals, (e) => e.id === act.modalId),
                    'name',
                  ) || '--'}
                </div>
              );
            }

            case ActionType.DELAY: {
              const act = action as ActionDelay;
              return <div>延迟{act.duration}ms</div>;
            }

            case ActionType.DISPATCH_PAGE_EVENT: {
              const act = action as ActionDispatchPageEvent;
              return <div>事件名：{act.pageEventName}</div>;
            }

            case ActionType.EXEC_CODE: {
              const act = action as ActionExecCode;
              return <div>{act.code}</div>;
            }

            case ActionType.FETCH_DATA: {
              const act = action as ActionFetchData;
              return (
                <div>
                  获取数据：
                  {get(engineModelStore.datas, `${act.dataCode}.name`) || '--'}
                </div>
              );
            }

            case ActionType.GO: {
              const act = action as ActionGo;
              return (
                <>
                  <div>URL：{act.url}</div>
                  <div>新页面打开：{act.open ? '是' : '否'}</div>
                  <div>使用pushState：{act.usePushState ? '是' : '否'}</div>
                </>
              );
            }

            case ActionType.GUARD: {
              const act = action as ActionGuard;
              return (
                <>
                  <div>代码：{act.code || '--'}</div>
                  <div>二次确认：{act.confirm || '--'}</div>
                </>
              );
            }

            case ActionType.NOTIFICATION: {
              const act = action as ActionNotification;
              return <div>消息：{act.message}</div>;
            }

            case ActionType.SEND_REQUEST: {
              const act = action as ActionSendRequest;
              return (
                <>
                  <div>URL：{act.url}</div>
                  <div>方法：{act.method}</div>
                  <div>格式：{act.format}</div>
                </>
              );
            }

            case ActionType.VALIDATE_FORM: {
              const act = action as ActionValidateForm;

              return (
                <>
                  <div>路径：{act.pathname}</div>
                  <div>
                    是否滚动到第一个错误：{act.scrollIntoView ? '是' : '否'}
                  </div>
                </>
              );
            }

            case ActionType.SET_DATA:
            case ActionType.START:
            default:
              return <></>;
          }
        })()}
      </Card>
    );
  },
);
