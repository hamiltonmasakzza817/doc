import { QuestionCircleOutlined } from '@ant-design/icons';
import Loading from '@gongzu/core/common/Loading';
import language from '@gongzu/core/config/language';
import { EngineStoresContext } from '@gongzu/core/contexts/store-contexts';
import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { getItemErrorProps, validateJSON } from '@gongzu/core/mobx-form/utils';
import { ActionQueueConflictResolver } from '@gongzu/core/types/entities';
import { Form, Input, Modal, Select, Switch, Tooltip } from 'antd';
import get from 'lodash-es/get';

import { Observer } from 'mobx-react';
import React from 'react';
import Loadable from 'react-loadable';
import { IPageActionQueueForm } from './type';

const CodeEditor = Loadable({
  loader: () => import('../../../../components/CodeEditor'),
  loading: Loading,
});

export default function ActionQueueForm(props: {
  form: MobxFormStore<IPageActionQueueForm>;
  prefix: string;
  nameFixed?: boolean;
  visible: boolean;
}) {
  const { form, nameFixed = false, visible } = props;

  const { engineModelStore } = React.useContext(EngineStoresContext);

  const prefix = props.prefix.replace(/\.start$/, '');

  return (
    <Observer>
      {() => (
        <>
          <Form.Item
            label="名称"
            required={!nameFixed}
            {...getItemErrorProps(form.errors[`${prefix}.name`])}
          >
            {nameFixed ? (
              <div>{get(form.values, `${prefix}.name`)}</div>
            ) : (
              <Input {...form.bind(`${prefix}.name`, { required: true })} />
            )}
          </Form.Item>

          <Form.Item
            {...getItemErrorProps(form.errors[`${prefix}.code`])}
            label={
              <span>
                代码&nbsp;
                <Tooltip title="若需要访问 pending 状态，请提供唯一代码">
                  <QuestionCircleOutlined />
                </Tooltip>
              </span>
            }
          >
            <Input
              {...form.bind(`${prefix}.code`, {
                validate: (value: string) =>
                  !value ||
                  Object.values(engineModelStore.actions).find(
                    (act) =>
                      act.code === value &&
                      act.id !== get(form.values, `${prefix}.id`),
                  ) == null
                    ? null
                    : '代码不能重复',
              })}
            />
          </Form.Item>

          <Form.Item label="二次确认">
            <Input
              {...form.bind(`${prefix}.confirm`)}
              placeholder="是否执行该操作？"
            />
          </Form.Item>

          <Form.Item
            label={
              <span>
                冲突解决&nbsp;
                <Tooltip title="当前有此 Action Queue 正在执行，需要如何处理">
                  <QuestionCircleOutlined />
                </Tooltip>
              </span>
            }
          >
            <Select
              {...form.bind(`${prefix}.conflictResolver`)}
              defaultValue={ActionQueueConflictResolver.BOTH}
            >
              {[
                ActionQueueConflictResolver.BOTH,
                ActionQueueConflictResolver.EXISTING,
                ActionQueueConflictResolver.COMING,
              ].map((conflictResolver) => (
                <Select.Option value={conflictResolver}>
                  {language.pageActionQueueConflictResolver[conflictResolver]}
                </Select.Option>
              ))}
            </Select>
          </Form.Item>

          <Form.Item label="上下文">
            <Switch
              checked={get(form.values, `${prefix}.context`) != null}
              onChange={(checked) => {
                if (checked) {
                  form.setValues({
                    [`${prefix}.context`]: `{}`,
                  });
                } else {
                  Modal.confirm({
                    title: '确认清空自定义参数？',
                    onOk: () => {
                      form.setValues({
                        context: undefined,
                      });
                    },
                  });
                }
              }}
            />
          </Form.Item>

          {get(form.values, `${prefix}.context`) != null ? (
            <Form.Item
              label="上下文编辑"
              {...getItemErrorProps(form.errors[`${prefix}.context`])}
            >
              {visible && (
                <CodeEditor
                  language="json"
                  height={200}
                  {...form.bind(`${prefix}.context`, {
                    validate: validateJSON,
                  })}
                />
              )}
            </Form.Item>
          ) : (
            <>
              {(() => {
                form.unbind(`${prefix}.context`);
              })()}
            </>
          )}

          <Form.Item label="成功消息">
            <Input
              {...form.bind(`${prefix}.success`)}
              placeholder="该操作已成功执行"
            />
          </Form.Item>
        </>
      )}
    </Observer>
  );
}
