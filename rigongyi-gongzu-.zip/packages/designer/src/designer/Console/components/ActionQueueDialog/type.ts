import { ActionQueue } from '@gongzu/core/types/entities';

export type IPageActionQueueForm = {
  rootActionQueue?: ActionQueue;
  foreignActionQueues: Record<string, ActionQueue>;
};
