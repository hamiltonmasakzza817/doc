import { DeleteOutlined, PlusCircleOutlined } from '@ant-design/icons';
import FlexWrapper from '@gongzu/core/components/FlexWrapper';
import { gzdnBem } from '@gongzu/core/config/constants';
import language from '@gongzu/core/config/language';
import {
  DesignerStoreContext,
  EngineStoresContext,
} from '@gongzu/core/contexts/store-contexts';
import useFormMobx from '@gongzu/core/mobx-form/useFormMobx';
import {
  Action,
  ActionQueue,
  ActionQueueType,
  ActionType,
  asyncActions,
  DataNode,
  rejectableActions,
} from '@gongzu/core/types/entities';
import { treeToArray } from '@gongzu/core/utils/tree';
import { Form, message, Modal, Tooltip, Tree } from 'antd';
import { FormLabelAlign } from 'antd/es/form/interface';
import { ModalProps } from 'antd/es/modal';
import classNames from 'classnames';
import compact from 'lodash-es/compact';
import concat from 'lodash-es/concat';
import difference from 'lodash-es/difference';
import forEach from 'lodash-es/forEach';
import get from 'lodash-es/get';
import map from 'lodash-es/map';
import omit from 'lodash-es/omit';
import transform from 'lodash-es/transform';
import values from 'lodash-es/values';
import { observer, Observer } from 'mobx-react';
import React, { Key } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { dialogFormItemLayout } from '../../../../config/layout';
import ActionCard from './ActionCard';
import ActionForm from './ActionForm';
import ActionQueueForm from './ActionQueueForm';
import ActionStartCard from './ActionStartCard';
import { IPageActionQueueForm } from './type';
import {
  collectForeignActionIds,
  formToPageActionQueue,
  pageActionQueueToForm,
} from './utils';

const actionQueueBem = gzdnBem('action-queue');

const dimensions = {
  height: 154,
  width: 300,
  gap: 48,
};

const formItemLayout = {
  ...dialogFormItemLayout,
  labelAlign: 'left' as FormLabelAlign,
};

export default observer(
  (
    props: ModalProps & {
      actionQueue?: ActionQueue | null;
      nameFixed?: boolean;
      onCancel: () => void;
      onSave?: (actionId: string) => void;
    },
  ) => {
    const {
      actionQueue,
      onCancel,
      onSave,
      nameFixed = false,
      ...modalProps
    } = props;

    const designerStore = React.useContext(DesignerStoreContext);

    const { engineModelStore } = React.useContext(EngineStoresContext);

    const [activeActionKey, setActiveActionKey] = React.useState<string | null>(
      null,
    );

    const [expandedKeys, setExpandedKeys] = React.useState<Key[]>([]);

    const form = useFormMobx<IPageActionQueueForm>({
      defaultValues: null,
    });

    React.useEffect(() => {
      if (actionQueue) {
        form.reset({
          rootActionQueue: pageActionQueueToForm(actionQueue),
          foreignActionQueues: actionQueue.foreignActionIds
            ? transform(
                actionQueue.foreignActionIds,
                (acc, actionId) => {
                  acc[actionId] = pageActionQueueToForm(
                    engineModelStore.actions[actionId],
                  );
                },
                {} as Record<string, ActionQueue>,
              )
            : {},
        });

        setActiveActionKey('rootActionQueue.start');
      } else {
        form.reset({ rootActionQueue: undefined, foreignActionQueues: {} });
        form.clearBindings();
        setActiveActionKey(null);
      }
    }, [actionQueue]);

    const addAction = React.useCallback((index, prefix1: string) => {
      form.triggerValidation().subscribe((isValid) => {
        if (isValid) {
          const actionsPrefix = prefix1.replace(/\.actions\[\d*]$/, '.actions');
          const actions = [...get(form.values, actionsPrefix)];

          actions.splice(index, 0, {
            type: ActionType.FETCH_DATA,
          } as Action);

          form.setValues({
            [actionsPrefix]: actions,
          });

          setActiveActionKey(prefix1);
        } else {
          message.error('Action表单有错误');
        }
      });
    }, []);

    const changeAction = React.useCallback(
      (prefix1) => {
        if (activeActionKey === prefix1) {
          return;
        }

        form.triggerValidation().subscribe((isValid) => {
          if (isValid) {
            setActiveActionKey(prefix1);
          } else {
            message.error('Action表单有错误');
          }
        });
      },
      [activeActionKey],
    );

    const buildActionQueueTreeData = React.useCallback(
      (rootActionQueue: ActionQueue, prefix: string): DataNode[] =>
        concat<DataNode>(
          {
            title: rootActionQueue.name,
            key: `${prefix}.start`,
          },
          map(rootActionQueue.actions, (action, index) => {
            let actionId;

            if (asyncActions.includes(action.type)) {
              actionId = get(action, 'parallelActionId');
            } else if (rejectableActions.includes(action.type)) {
              actionId = get(action, 'rejectActionId');
            }

            return {
              title: language.pageActionType[action.type],
              key: `${prefix}.actions[${index}]`,
              children: actionId
                ? buildActionQueueTreeData(
                    form.values.foreignActionQueues[actionId],
                    `foreignActionQueues['${actionId}']`,
                  )
                : undefined,
            };
          }),
        ),
      [],
    );

    const treeData = React.useRef<DataNode[]>([]);

    React.useEffect(() => {
      let timer: any;

      if (actionQueue) {
        timer = setTimeout(() => {
          setExpandedKeys(treeToArray(treeData.current).map((i) => i.key));
        }, 0);
      }

      return () => {
        if (timer) {
          clearTimeout(timer);
        }
      };
    }, [actionQueue]);

    const titleRender = React.useCallback(
      (node) => {
        if (/start$/.test(`${node.key}`)) {
          const prefix = `${node.key}`.replace('.start', '');

          const actionQueue1 = get(form.values, prefix);

          if (actionQueue1 == null) {
            return null;
          }

          return (
            <div className="relative">
              <ActionStartCard
                className={classNames({
                  [gzdnBem('highlight')()]: activeActionKey === node.key,
                })}
                actionQueue={actionQueue1}
                onClick={() => {
                  changeAction(node.key);
                }}
              />

              <PlusCircleOutlined
                className={actionQueueBem('plus-icon')}
                style={{
                  transform: `translate(
                    ${dimensions.width / 2 - 7}px,
                    ${dimensions.height + 4}px
                  )`,
                }}
                onClick={() => {
                  addAction(0, `${prefix}.actions[0]`);
                }}
              />
            </div>
          );
        }

        const action = get(form.values, node.key) as Action;

        if (action == null) {
          return null;
        }

        const index = +get(`${node.key}`.match(/.actions\[(\d*)]$/), '[1]');
        const prefix = `${node.key}`.replace(/.actions\[\d*]$/, '');

        return (
          <div className="relative">
            <ActionCard
              action={action}
              className={classNames({
                'outline outline-1 outline-primary':
                  activeActionKey === node.key,
              })}
              onClick={() => changeAction(node.key)}
              extra={
                <DeleteOutlined
                  className="text-error cursor-pointer"
                  onClick={(e) => {
                    e.stopPropagation();
                    Modal.confirm({
                      title: '删除确认',
                      content: '是否删除Action',
                      onOk: () => {
                        let foreignActionIdKey;

                        if (asyncActions.includes(action.type)) {
                          foreignActionIdKey = 'parallelActionId';
                        } else if (rejectableActions.includes(action.type)) {
                          foreignActionIdKey = 'rejectActionId';
                        }

                        const foreignActionIds = foreignActionIdKey
                          ? collectForeignActionIds(
                              get(action, foreignActionIdKey),
                              form.values.foreignActionQueues,
                            )
                          : [];

                        const actions = [
                          ...get(form.values, `${prefix}.actions`),
                        ];

                        actions.splice(index, 1);

                        form.setValues({
                          [`${prefix}.actions`]: actions,
                          foreignActionQueues: omit(
                            form.values.foreignActionQueues,
                            foreignActionIds,
                          ),
                        });

                        if (activeActionKey) {
                          form.unbindStartWith(activeActionKey);

                          if (activeActionKey.startsWith(prefix)) {
                            const i = get(
                              activeActionKey.match(
                                new RegExp(`actions\\[(\\d*)]$`),
                              ),
                              '[1]',
                            );

                            if (i != null && i > index) {
                              setActiveActionKey(`${prefix}.actions[${i - 1}]`);
                            }
                          }
                        }
                      },
                    });
                  }}
                />
              }
            />

            <PlusCircleOutlined
              className={actionQueueBem('plus-icon')}
              style={{
                transform: `translate(
                    ${dimensions.width / 2 - 7}px,
                    ${dimensions.height + 4}px
                  )`,
              }}
              onClick={() => {
                addAction(index + 1, `${prefix}.actions[${index + 1}]`);
              }}
            />

            {concat(asyncActions, rejectableActions).includes(action.type) && (
              <Observer>
                {() => {
                  const foreignActionIdKey = asyncActions.includes(action.type)
                    ? 'parallelActionId'
                    : 'rejectActionId';

                  const actionName = asyncActions.includes(action.type)
                    ? '并行执行分支'
                    : '拒绝分支';

                  const iconStyles = {
                    transform: `translate(${dimensions.width + 4}px,${
                      dimensions.height / 2 - 7
                    }px)`,
                  };

                  return (
                    <>
                      {get(action, foreignActionIdKey) ? (
                        <DeleteOutlined
                          className={classNames(
                            actionQueueBem('plus-icon'),
                            'text-error',
                          )}
                          style={iconStyles}
                          onClick={() => {
                            Modal.confirm({
                              title: '删除确认',
                              content: `是否删除${actionName}`,
                              onOk: () => {
                                const foreignActionIds =
                                  collectForeignActionIds(
                                    get(action, foreignActionIdKey),
                                    form.values.foreignActionQueues,
                                  );

                                form.setValues({
                                  [`${node.key}.${foreignActionIdKey}`]:
                                    undefined,
                                  foreignActionQueues: omit(
                                    form.values.foreignActionQueues,
                                    foreignActionIds,
                                  ),
                                });
                              },
                            });
                          }}
                        />
                      ) : (
                        <Tooltip title={`添加${actionName}`}>
                          <PlusCircleOutlined
                            className={actionQueueBem('plus-icon')}
                            style={iconStyles}
                            onClick={() => {
                              const actionId = uuidv4();

                              form.setValues({
                                [`${node.key}.${foreignActionIdKey}`]: actionId,
                                [`foreignActionQueues.${actionId}`]: {
                                  id: actionId,
                                  type: asyncActions.includes(action.type)
                                    ? ActionQueueType.PARALLEL
                                    : ActionQueueType.REJECT,
                                  name: actionName,
                                  actions: [],
                                  rootActionId: form.values.rootActionQueue?.id,
                                } as ActionQueue,
                              });

                              setExpandedKeys(
                                compact(concat(expandedKeys, node.key)),
                              );
                            }}
                          />
                        </Tooltip>
                      )}
                    </>
                  );
                }}
              </Observer>
            )}
          </div>
        );
      },
      [activeActionKey],
    );

    const visible = actionQueue != null;

    return (
      <Modal
        title={`Action编辑 - ${get(form.values, 'rootActionQueue.name')}`}
        {...modalProps}
        style={{ top: 16 }}
        width="100%"
        onCancel={onCancel}
        visible={visible}
        maskClosable={false}
        onOk={() => {
          form.triggerValidation().subscribe((isValid) => {
            if (isValid) {
              const { rootActionQueue, foreignActionQueues } = form.values;

              const foreignActionIds = map(foreignActionQueues, (a) => a.id);

              const foreignActionDeleteIds = difference(
                actionQueue?.foreignActionIds,
                foreignActionIds,
              );

              const rootActionId = designerStore.saveAction({
                ...formToPageActionQueue(rootActionQueue),
                foreignActionIds,
              });

              values(foreignActionQueues).forEach((rejectActionQueue) => {
                designerStore.saveAction(
                  formToPageActionQueue(rejectActionQueue),
                );
              });

              forEach(foreignActionDeleteIds, (actionId) => {
                designerStore.deleteAction(actionId);
              });

              if (onSave) {
                onSave(rootActionId);
              }

              onCancel();
            }
          });
        }}
        keyboard={false}
      >
        <FlexWrapper bottom={101} className="flex">
          <div className="flex-1 overflow-auto relative">
            <Observer>
              {() => {
                if (form.values.rootActionQueue) {
                  treeData.current = buildActionQueueTreeData(
                    form.values.rootActionQueue,
                    'rootActionQueue',
                  );
                }

                return (
                  <>
                    {form.values.rootActionQueue && (
                      <Tree
                        expandedKeys={expandedKeys}
                        onExpand={setExpandedKeys}
                        className={actionQueueBem('tree')}
                        treeData={treeData.current || []}
                        titleRender={titleRender}
                      />
                    )}
                  </>
                );
              }}
            </Observer>
          </div>

          <div className="ml-3 w-px h-full bg-border" />
          <div
            className="px-3 overflow-y-auto"
            style={{
              width: 700,
            }}
          >
            {activeActionKey && (
              <Form
                {...formItemLayout}
                component="div"
                className={actionQueueBem('form')}
              >
                {/\.start$/.test(activeActionKey) ? (
                  <ActionQueueForm
                    visible={visible}
                    form={form}
                    prefix={activeActionKey}
                    nameFixed={
                      nameFixed ||
                      activeActionKey.startsWith('foreignActionQueues')
                    }
                  />
                ) : (
                  <ActionForm
                    visible={visible}
                    form={form}
                    prefix={activeActionKey}
                    key={form.values.rootActionQueue?.id || activeActionKey}
                  />
                )}
              </Form>
            )}
          </div>
        </FlexWrapper>
      </Modal>
    );
  },
);
