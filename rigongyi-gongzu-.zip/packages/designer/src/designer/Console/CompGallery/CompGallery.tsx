import { DesignerStoreContext } from '@gongzu/core/contexts/store-contexts';
import { CompsAll } from '@gongzu/core/types/comps-all';
import { DesktopCompType } from '@gongzu/core/types/comps-desktop';
import { MobileCompType } from '@gongzu/core/types/comps-mobile';
import { PageCompType } from '@gongzu/core/types/comps-page';
import { TaroCompType } from '@gongzu/core/types/comps-taro';
import { PagePlatform } from '@gongzu/core/types/entities';
import {
  isDesktopComp,
  isMobileComp,
  isPageComp,
  isTaroComp,
} from '@gongzu/core/utils/comp';
import { createCompConfig } from '@gongzu/core/utils/comp-creators';
import { observer } from 'mobx-react';
import React from 'react';
import CompDraggable from './CompDraggable';

function filterCompTypes(
  compTypes: CompsAll[],
  platform: PagePlatform = PagePlatform.PC,
) {
  return compTypes.filter((compType) => {
    if (isPageComp(compType)) {
      return true;
    }

    if (platform === PagePlatform.PC) {
      return isDesktopComp(compType);
    }

    if (platform === PagePlatform.MOBILE) {
      return isMobileComp(compType);
    }

    if (platform === PagePlatform.TARO) {
      return isTaroComp(compType);
    }

    return false;
  });
}

export default observer(() => {
  const designerStore = React.useContext(DesignerStoreContext);

  const {
    engineStore: {
      page: { platform },
    },
  } = designerStore;

  const clickComp = React.useCallback((type: CompsAll) => {
    designerStore.paste({
      config: createCompConfig({
        type,
        parent: { id: '' },
        platform: designerStore.engineStore.page.platform,
      }),
      cut: false,
    });
  }, []);

  return (
    <div className="p-2">
      <div className="mb-1 font-bold">基础组件</div>
      <div className="grid grid-cols-2 gap-1">
        {filterCompTypes(
          [
            PageCompType.TEXT,
            DesktopCompType.PARAGRAPH,
            DesktopCompType.BUTTON,
            MobileCompType.BUTTON,
            TaroCompType.BUTTON,
            DesktopCompType.ICON,
            DesktopCompType.IMAGE,
            MobileCompType.IMAGE,
            TaroCompType.IMAGE,
            DesktopCompType.TAG,
            MobileCompType.TAG,
            PageCompType.HYPERLINK,
            DesktopCompType.CONTAINER,
            MobileCompType.CONTAINER,
            TaroCompType.CONTAINER,
            TaroCompType.NAV_CONTAINER,
            TaroCompType.BOTTOM_CONTAINER,
            PageCompType.BLOCK,
            PageCompType.IFRAME,
            TaroCompType.SCROLL_VIEW,
          ],
          platform,
        ).map((type) => (
          <CompDraggable
            pageCompType={type}
            key={type}
            available
            clickable
            onClick={() => clickComp(type)}
          />
        ))}
      </div>

      <div className="mb-1 font-bold mt-2">表单类组件【双向绑定】</div>
      <div className="grid grid-cols-2 gap-1">
        {filterCompTypes(
          [
            DesktopCompType.FORM,
            MobileCompType.FORM,
            TaroCompType.FORM,
            DesktopCompType.FORM_ITEM_CONTAINER,
            MobileCompType.FORM_ITEM,
            DesktopCompType.INPUT,
            MobileCompType.INPUT,
            TaroCompType.INPUT,
            TaroCompType.INPUT_ITEM,
            DesktopCompType.TEXT_AREA,
            MobileCompType.TEXT_AREA,
            TaroCompType.TEXT_AREA,
            DesktopCompType.NUMBER_INPUT,
            MobileCompType.NUMBER_INPUT,
            DesktopCompType.RADIO,
            MobileCompType.RADIO,
            TaroCompType.RADIO,
            DesktopCompType.CHECKBOX,
            TaroCompType.CHECKBOX,
            MobileCompType.CHECKBOX,
            DesktopCompType.SWITCH,
            MobileCompType.SWITCH,
            TaroCompType.SWITCH,
            TaroCompType.BOOLEAN_ITEM,
            DesktopCompType.DATE_PICKER,
            MobileCompType.DATE_PICKER,
            TaroCompType.DATE_PICKER,
            TaroCompType.DATE_PICKER_ITEM,
            DesktopCompType.SELECT,
            MobileCompType.SELECT,
            TaroCompType.SELECT,
            TaroCompType.SELECT_ITEM,
            DesktopCompType.TREE_SELECT,
            DesktopCompType.UPLOADER,
            MobileCompType.UPLOADER,
            DesktopCompType.CASCADER,
            DesktopCompType.TRANSFER,
            DesktopCompType.SLIDER,
            TaroCompType.SLIDER,
            MobileCompType.SEARCH_BAR,
          ],
          platform,
        ).map((type) => (
          <CompDraggable
            pageCompType={type}
            key={type}
            available
            clickable
            onClick={() => clickComp(type)}
          />
        ))}
      </div>

      <div className="mb-1 font-bold mt-2">高级组件</div>
      <div className="grid grid-cols-2 gap-1">
        {filterCompTypes(
          [
            MobileCompType.CAPSULE_TABS,
            MobileCompType.LIST,
            TaroCompType.LIST,
            MobileCompType.LIST_ITEM,
            TaroCompType.LIST_ITEM,
            DesktopCompType.TABS,
            MobileCompType.TABS,
            DesktopCompType.TABLE,
            DesktopCompType.TREE,
            DesktopCompType.PAGINATION,
            DesktopCompType.MENU,
            PageCompType.PAGE_PORTAL,
            PageCompType.UMD_COMP,
            DesktopCompType.PROGRESS,
            DesktopCompType.DROPDOWN_MENU,
            DesktopCompType.STEPS,
            DesktopCompType.MARKDOWN,
            MobileCompType.SWIPER,
            TaroCompType.SWIPER,
            MobileCompType.INFINITE_SCROLL,
          ],
          platform,
        ).map((type) => (
          <CompDraggable
            pageCompType={type}
            key={type}
            available
            clickable
            onClick={() => clickComp(type)}
          />
        ))}
      </div>

      <div className="mb-1 font-bold mt-2">逻辑组件</div>
      <div className="grid grid-cols-2 gap-1">
        {[PageCompType.REPEAT].map((type) => (
          <CompDraggable
            pageCompType={type}
            key={type}
            available
            clickable
            onClick={() => clickComp(type)}
          />
        ))}
      </div>
    </div>
  );
});
