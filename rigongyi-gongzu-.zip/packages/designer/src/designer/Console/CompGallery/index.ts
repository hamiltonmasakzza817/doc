export { default } from './CompGallery';
