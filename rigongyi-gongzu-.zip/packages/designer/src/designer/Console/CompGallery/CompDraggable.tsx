import { gzdnBem } from '@gongzu/core/config/constants';
import language from '@gongzu/core/config/language';
import { DesignerStoreContext } from '@gongzu/core/contexts/store-contexts';
import { CompsAll } from '@gongzu/core/types/comps-all';
import classNames from 'classnames/bind';
import get from 'lodash-es/get';
import React from 'react';

const compGalleryBem = gzdnBem('comp-gallery');

export default function CompDraggable(props: {
  pageCompType: CompsAll;
  label?: string;
  id?: string;
  onClick?: () => void;
  className?: string;
  clickable?: boolean;
  available?: boolean;
}) {
  const {
    pageCompType,
    label,
    id,
    onClick,
    className,
    clickable = false,
    available = false,
  } = props;

  const designerStore = React.useContext(DesignerStoreContext);

  React.useEffect(() => {}, []);

  return (
    <div
      draggable
      onDragStart={() => {
        designerStore.startDragging({
          type: pageCompType,
          id,
        });
      }}
      onDragEnd={() => {
        designerStore.endDragging();
      }}
      className={classNames(
        compGalleryBem('draggable', { click: available && clickable }),
        className,
      )}
      onClick={() => {
        if (onClick && clickable) {
          onClick();
        }
      }}
    >
      <div>{label ?? get(language.compTypes, pageCompType)}</div>
      <div>{get(language.compTypeAlias, pageCompType) || ''}</div>
    </div>
  );
}
