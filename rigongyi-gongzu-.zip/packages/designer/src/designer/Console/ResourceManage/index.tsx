export { default } from './ResourceManage';
