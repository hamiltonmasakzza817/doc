import language from '@gongzu/core/config/language';
import { DesignerStoreContext } from '@gongzu/core/contexts/store-contexts';
import useFormMobx from '@gongzu/core/mobx-form/useFormMobx';
import { getItemErrorProps } from '@gongzu/core/mobx-form/utils';
import { Resource, ResourceType } from '@gongzu/core/types/entities';
import { Form, Input, Modal, Radio } from 'antd';
import { ModalProps } from 'antd/es/modal';
import cloneDeep from 'lodash-es/cloneDeep';

import { Observer } from 'mobx-react';
import React from 'react';
import { addingId } from '../../../config/constants';
import { dialogFormItemLayout } from '../../../config/layout';

export default function ResourceDialog(
  props: Partial<ModalProps> & { pageResource: Resource | null },
) {
  const designerStore = React.useContext(DesignerStoreContext);

  const { pageResource, ...modalProps } = props;

  const form = useFormMobx<Resource>({
    defaultValues: null,
  });

  React.useEffect(() => {
    if (pageResource) {
      form.reset(cloneDeep(pageResource));
    }
  }, [pageResource]);

  return (
    <Modal
      {...modalProps}
      title={pageResource?.id === addingId ? '新建事件' : '编辑事件'}
      visible={pageResource != null}
      width={800}
      maskClosable={false}
      keyboard={false}
      onOk={(e) => {
        form.triggerValidation().subscribe(() => {
          designerStore.saveResource(form.values);

          if (modalProps.onCancel) {
            modalProps.onCancel(e);
          }
        });
      }}
    >
      <Form {...dialogFormItemLayout}>
        <Observer>
          {() => (
            <>
              <Form.Item
                label="名称"
                {...getItemErrorProps(form.errors.name)}
                required
              >
                <Input {...form.bind('name', { required: true })} />
              </Form.Item>

              <Form.Item label="类型">
                <Radio.Group {...form.bind('type')}>
                  {[ResourceType.SCRIPT, ResourceType.CSS].map(
                    (pageResourceType) => (
                      <Radio key={pageResourceType} value={pageResourceType}>
                        {language.pageResourceType[pageResourceType]}
                      </Radio>
                    ),
                  )}
                </Radio.Group>
              </Form.Item>

              <Form.Item
                label="URL"
                {...getItemErrorProps(form.errors.url)}
                required
              >
                <Input {...form.bind('url', { required: true })} />
              </Form.Item>
            </>
          )}
        </Observer>
      </Form>
    </Modal>
  );
}
