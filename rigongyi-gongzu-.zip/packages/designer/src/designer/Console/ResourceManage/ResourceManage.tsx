import { DeleteOutlined, EditOutlined } from '@ant-design/icons';
import language from '@gongzu/core/config/language';
import {
  DesignerStoreContext,
  EngineStoresContext,
} from '@gongzu/core/contexts/store-contexts';
import { Resource, ResourceType } from '@gongzu/core/types/entities';
import { Button, Card, Modal, Tooltip } from 'antd';
import map from 'lodash-es/map';
import size from 'lodash-es/size';
import { observer } from 'mobx-react';
import React from 'react';
import { addingId } from '../../../config/constants';
import ResourceDialog from './ResourceDialog';

export default observer(() => {
  const designerStore = React.useContext(DesignerStoreContext);

  const { engineModelStore } = React.useContext(EngineStoresContext);

  const [pageResourceOpen, setPageResourceOpen] =
    React.useState<Resource | null>(null);

  return (
    <div className="p-2">
      <div>
        <Button
          type="primary"
          size="small"
          onClick={() => {
            setPageResourceOpen({
              id: addingId,
              name: `资源${size(engineModelStore.resources) + 1}`,
              type: ResourceType.SCRIPT,
              url: '',
            });
          }}
        >
          新建
        </Button>
      </div>

      {map(engineModelStore.resources, (resource) => (
        <div className="mt-2" key={resource.id}>
          <Card
            title={resource.name}
            size="small"
            type="inner"
            extra={
              <div className="flex gap-1">
                <Tooltip title="删除">
                  <span
                    className="text-error cursor-pointer"
                    onClick={() => {
                      Modal.confirm({
                        title: '是否删除资源？',
                        content: resource.name,
                        onOk: () => {
                          designerStore.deleteResource(resource);
                        },
                      });
                    }}
                  >
                    <DeleteOutlined />
                  </span>
                </Tooltip>

                <Tooltip title="编辑">
                  <span
                    className="text-primary cursor-pointer"
                    onClick={() => setPageResourceOpen(resource)}
                  >
                    <EditOutlined />
                  </span>
                </Tooltip>
              </div>
            }
          >
            <div>名称：{resource.name}</div>
            <div>类型：{language.pageResourceType[resource.type]}</div>
            <Tooltip title={`URL：${resource.url}`}>
              <div className="whitespace-normal overflow-hidden overflow-ellipsis">
                URL：{resource.url}
              </div>
            </Tooltip>
          </Card>
        </div>
      ))}

      <ResourceDialog
        pageResource={pageResourceOpen}
        onCancel={() => {
          setPageResourceOpen(null);
        }}
      />
    </div>
  );
});
