import { DesignerStoreContext } from '@gongzu/core/contexts/store-contexts';
import useFormMobx from '@gongzu/core/mobx-form/useFormMobx';
import { TreeNode } from '@gongzu/core/types/entities';
import { Form, Input, Modal } from 'antd';
import { Observer } from 'mobx-react';
import React from 'react';
import { dialogFormItemLayout } from '../../../config/layout';
import CustomComponentSelect from '../components/CustomCompSelect';

export default function CustomDialog(props: {
  onCancel: () => void;
  config: TreeNode<{ name: string }> | null;
}) {
  const { config, onCancel } = props;

  const designerStore = React.useContext(DesignerStoreContext);

  const form = useFormMobx<TreeNode<{ name: string }>>({ defaultValues: null });

  React.useEffect(() => {
    if (config) {
      form.reset({ ...config });
    }
  }, [config]);

  return (
    <Modal
      title={config && config.id ? '新建自定义组件' : '修改自定义组件'}
      visible={config != null}
      width={600}
      onOk={() => {
        form.triggerValidation().subscribe((valid) => {
          if (valid) {
            designerStore.saveCustom(form.values);
            onCancel();
          }
        });
      }}
      onCancel={() => {
        onCancel();
      }}
    >
      <Observer>
        {() => (
          <Form {...dialogFormItemLayout}>
            <Form.Item label="名称" required>
              <Input {...form.bind('name', { required: true })} />
            </Form.Item>

            <Form.Item label="父节点">
              <CustomComponentSelect {...form.bind('parentId')} />
            </Form.Item>
          </Form>
        )}
      </Observer>
    </Modal>
  );
}
