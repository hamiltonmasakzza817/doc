import { FileOutlined, FolderOutlined } from '@ant-design/icons';
import { gzdnBem } from '@gongzu/core/config/constants';
import {
  DesignerStoreContext,
  EngineStoresContext,
} from '@gongzu/core/contexts/store-contexts';
import { TreeNode } from '@gongzu/core/types/entities';
import { findTreeNode, mapTreeNode } from '@gongzu/core/utils/tree';
import { Button, Dropdown, Menu, Modal, Tree } from 'antd';
import first from 'lodash-es/first';
import size from 'lodash-es/size';
import { Observer } from 'mobx-react';
import React from 'react';
import { v4 as uuidv4 } from 'uuid';
import CustomDialog from './CustomDialog';

const customManageBem = gzdnBem('custom-manage');
const MenuItem = Menu.Item;

export default function CustomManage() {
  const { engineModelStore } = React.useContext(EngineStoresContext);

  const designerStore = React.useContext(DesignerStoreContext);

  const [customCompConfig, setCustomCompConfig] = React.useState<TreeNode<{
    name: string;
  }> | null>(null);

  return (
    <div className="p-2">
      <div
        className="mb-2 flex"
        onClick={() => {
          setCustomCompConfig({
            id: uuidv4(),
            name: `自定义${size(engineModelStore.customs)}`,
            parentId: '-1',
          });
        }}
      >
        <Button type="primary" size="small">
          新建
        </Button>
      </div>
      <Observer>
        {() => {
          const { customTree, customs } = engineModelStore;

          const {
            editing: { tab: editing },
          } = designerStore;

          return (
            <Tree
              showIcon
              defaultExpandedKeys={['-1']}
              selectedKeys={editing ? [editing.id] : undefined}
              onSelect={(selectedKeys) => {
                const key = first(selectedKeys);

                if (key) {
                  const node = findTreeNode(customTree, 'id', key);
                  if (node) {
                    designerStore.focus(customs[key]);
                  }
                }
              }}
              treeData={mapTreeNode<TreeNode, any>(customTree, (treeNode) => {
                if (treeNode.id === '-1') {
                  return {
                    title: treeNode.name as string,
                    key: treeNode.id,
                    icon: <FolderOutlined />,
                  };
                }

                const config = customs[treeNode.id];

                return {
                  title: (
                    <Dropdown
                      overlay={
                        <Menu
                          className={customManageBem('menu')}
                          onClick={(e) => {
                            e.domEvent.stopPropagation();
                          }}
                        >
                          <MenuItem
                            key="0"
                            onClick={() => {
                              setCustomCompConfig({
                                id: config.id,
                                name: config.name || '',
                                parentId: treeNode.parentId || '',
                              });
                            }}
                          >
                            修改
                          </MenuItem>
                          <MenuItem
                            onClick={() => {
                              Modal.confirm({
                                title: '提示',
                                content: `是否删除自定义：${config.name}${
                                  size(treeNode.children) > 0
                                    ? '，及其自节点'
                                    : ''
                                }`,
                                onOk: () => {
                                  designerStore.deleteCustom(treeNode);
                                },
                              });
                            }}
                          >
                            <span className="text-error">删除</span>
                          </MenuItem>
                        </Menu>
                      }
                      trigger={['contextMenu']}
                    >
                      <span>{config.name}</span>
                    </Dropdown>
                  ),
                  key: config.id,
                  icon: <FileOutlined />,
                };
              })}
            />
          );
        }}
      </Observer>

      <CustomDialog
        onCancel={() => {
          setCustomCompConfig(null);
        }}
        config={customCompConfig}
      />
    </div>
  );
}
