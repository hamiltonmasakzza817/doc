import Loading from '@gongzu/core/common/Loading';
import { gzdnBem } from '@gongzu/core/config/constants';
import language from '@gongzu/core/config/language';
import {
  DesignerStoreContext,
  EngineStoresContext,
} from '@gongzu/core/contexts/store-contexts';
import useFormMobx from '@gongzu/core/mobx-form/useFormMobx';
import { getItemErrorProps, validateJSON } from '@gongzu/core/mobx-form/utils';
import { CompConfig } from '@gongzu/core/types/comps-common';
import { TreeNode } from '@gongzu/core/types/entities';
import { normalizeConfig } from '@gongzu/core/utils/comp-normalizers';
import { parseJSON } from '@gongzu/core/utils/data';
import { findTreeNode, mapTreeNode } from '@gongzu/core/utils/tree';
import { Form, Modal, Tree } from 'antd';
import jsonPretty from 'json-stringify-pretty-compact';
import cloneDeep from 'lodash-es/cloneDeep';
import compact from 'lodash-es/compact';
import concat from 'lodash-es/concat';
import flatten from 'lodash-es/flatten';
import get from 'lodash-es/get';

import { Observer, observer } from 'mobx-react';
import React from 'react';
import Loadable from 'react-loadable';

const CodeEditor = Loadable({
  loader: () => import('../../components/CodeEditor'),
  loading: Loading,
});

function ModelDataDialog() {
  const form = useFormMobx<{
    model: string;
  }>({ defaultValues: null });

  const designerStore = React.useContext(DesignerStoreContext);

  const { engineModelStore } = React.useContext(EngineStoresContext);

  const [expandedKeys, setExpandedKeys] = React.useState<(string | number)[]>(
    [],
  );

  const needSetExpandedKeys = React.useRef<boolean>(true);

  const config = designerStore.modeling;

  React.useEffect(() => {
    if (config) {
      form.reset({
        model: jsonPretty(config, {
          maxLength: 0,
        }),
      });

      if (needSetExpandedKeys.current) {
        needSetExpandedKeys.current = false;
        setExpandedKeys(config.pathname?.split(',') ?? []);
      }
    } else {
      needSetExpandedKeys.current = true;
    }
  }, [config]);

  const onCancel = React.useCallback(() => {
    designerStore.closeModeling();
  }, []);

  const visible = config != null;

  return (
    <Modal
      visible={visible}
      title="组件模型预览"
      width={1000}
      onCancel={() => onCancel()}
      onOk={() => {
        if (config) {
          form.triggerValidation().subscribe((isValid) => {
            if (isValid) {
              const normalized = cloneDeep(parseJSON(form.values.model));

              normalizeConfig({
                config: normalized,
                parentId: config.parentId ?? undefined,
                reserveId: true,
                rootConfig: designerStore.getComponents(),
              });

              designerStore.updateConfig({
                config,
                values: normalized,
                replaceAll: true,
              });

              onCancel();
            }
          });
        }
      }}
    >
      <div className="flex">
        <div className="flex-1 overflow-x-auto">
          <Observer>
            {() => {
              const treeData = mapTreeNode<
                CompConfig,
                TreeNode<{
                  key: string;
                  title: string;
                  node: CompConfig;
                }>
              >(
                flatten(
                  concat(
                    engineModelStore.elements,
                    engineModelStore.modals,
                    Object.values(engineModelStore.customs),
                  ),
                ),
                (node: CompConfig) => ({
                  node,
                  id: node.id,
                  key: node.id,
                  title: `${get(language.compTypes, node.type)}${
                    node.alias ? `(${node.alias})` : ''
                  }`,
                }),
              );

              return (
                <Tree
                  className={gzdnBem('modal-data-dialog')('tree')}
                  treeData={treeData}
                  expandedKeys={expandedKeys}
                  onExpand={setExpandedKeys}
                  selectedKeys={compact([designerStore.focusing?.id])}
                  onSelect={(keys) => {
                    const f = findTreeNode(treeData, 'key', keys[0]);
                    if (f) {
                      designerStore.focus(f.node);
                      designerStore.openModeling(f.node);
                    }
                  }}
                />
              );
            }}
          </Observer>
        </div>
        <div className="ml-3 w-3/4">
          <Form>
            <Form.Item
              label="模型"
              {...getItemErrorProps(form.errors.model)}
            >
              {visible && (
                <CodeEditor
                  language="json"
                  {...form.bind('model', {
                    validate: validateJSON,
                  })}
                />
              )}
            </Form.Item>
          </Form>
        </div>
      </div>
    </Modal>
  );
}

export default observer(ModelDataDialog);
