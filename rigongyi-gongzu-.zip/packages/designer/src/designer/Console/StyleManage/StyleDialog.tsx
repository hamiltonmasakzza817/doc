import Loading from '@gongzu/core/common/Loading';
import { DesignerStoreContext } from '@gongzu/core/contexts/store-contexts';
import useFormMobx from '@gongzu/core/mobx-form/useFormMobx';
import { getItemErrorProps } from '@gongzu/core/mobx-form/utils';
import { Style } from '@gongzu/core/types/entities';
import { Form, Input, Modal } from 'antd';

import { ModalProps } from 'antd/es/modal';
import cloneDeep from 'lodash-es/cloneDeep';

import { toJS } from 'mobx';
import { Observer } from 'mobx-react';
import React from 'react';
import Loadable from 'react-loadable';
import { addingId } from '../../../config/constants';
import { dialogFormItemLayout } from '../../../config/layout';

const CodeEditor = Loadable({
  loader: () => import('../../../components/CodeEditor'),
  loading: Loading,
});

export default function StyleDialog(
  props: Partial<ModalProps> & {
    pageStyle?: Style;
  },
) {
  const designerStore = React.useContext(DesignerStoreContext);

  const { pageStyle, onCancel, ...modalProps } = props;

  const form = useFormMobx<Style>({
    defaultValues: null,
  });

  React.useEffect(() => {
    if (pageStyle) {
      form.reset(cloneDeep(toJS(pageStyle)));
    }
  }, [pageStyle]);

  const visible = pageStyle != null;

  return (
    <Modal
      {...modalProps}
      width={800}
      title={pageStyle?.id === addingId ? '新建样式' : '修改样式'}
      visible={visible}
      onCancel={onCancel}
      maskClosable={false}
      keyboard={false}
      onOk={(e) => {
        form.triggerValidation().subscribe((isValid) => {
          if (isValid) {
            designerStore.saveStyle(form.values);
            if (onCancel) {
              onCancel(e);
            }
          }
        });
      }}
    >
      <Form {...dialogFormItemLayout}>
        <Observer>
          {() => (
            <>
              <Form.Item
                label="名称"
                required
                {...getItemErrorProps(form.errors.name)}
              >
                {form.values.id === 'global' ? (
                  '全局'
                ) : (
                  <Input {...form.bind('name', { required: true })} />
                )}
              </Form.Item>

              <Form.Item label="样式">
                {visible && (
                  <CodeEditor language="less" {...form.bind('style')} />
                )}
              </Form.Item>
            </>
          )}
        </Observer>
      </Form>
    </Modal>
  );
}
