import { DeleteOutlined, EditOutlined } from '@ant-design/icons';
import Loading from '@gongzu/core/common/Loading';
import { gzdnBem } from '@gongzu/core/config/constants';
import {
  DesignerStoreContext,
  EngineStoresContext,
} from '@gongzu/core/contexts/store-contexts';
import { Style } from '@gongzu/core/types/entities';
import { allowCssInJs } from '@gongzu/core/utils/comp';
import { Button, Card, Modal, Spin, Tooltip } from 'antd';
import classNames from 'classnames';
import size from 'lodash-es/size';
import { observer, useLocalObservable } from 'mobx-react';
import React from 'react';
import Loadable from 'react-loadable';
import ClickableText from '../../../components/ClickableText';
import { addingId } from '../../../config/constants';
import StyleDialog from './StyleDialog';

const CodeEditor = Loadable({
  loader: () => import('../../../components/CodeEditor'),
  loading: () => (
    <Loading>
      <Spin />
    </Loading>
  ),
});

export default observer(() => {
  const designerStore = React.useContext(DesignerStoreContext);

  const {
    engineModelStore,
    engineStore: {
      page: { platform },
    },
  } = React.useContext(EngineStoresContext);

  const state = useLocalObservable<{
    pageStyleOpen?: Style;
    showCode: boolean;
  }>(() => ({
    showCode: false,
  }));

  return (
    <>
      <div className="p-2">
        {allowCssInJs(platform) && (
          <div>
            <Button
              type="primary"
              size="small"
              onClick={() => {
                state.pageStyleOpen = {
                  id: addingId,
                  name: `样式${size(engineModelStore.styles) + 1}`,
                };
              }}
            >
              新建
            </Button>
          </div>
        )}

        <div className="mt-2">
          <Card
            size="small"
            type="inner"
            title="全局"
            className={classNames('mb-2', gzdnBem('code-card'))}
            extra={
              <div className="flex gap-1">
                <Tooltip title="删除">
                  <span
                    className="text-error cursor-pointer"
                    onClick={() =>
                      Modal.confirm({
                        title: '是否删除全局样式',
                        onOk: () => {
                          designerStore.deleteGlobalStyle();
                        },
                      })
                    }
                  >
                    <DeleteOutlined />
                  </span>
                </Tooltip>

                <Tooltip title="编辑">
                  <span
                    className="ml-1 text-primary cursor-pointer"
                    onClick={() => {
                      state.pageStyleOpen = {
                        id: 'global',
                        name: '全局',
                        style: engineModelStore.globalStyle,
                      };
                    }}
                  >
                    <EditOutlined />
                  </span>
                </Tooltip>
              </div>
            }
          >
            <div
              onClick={() => {
                state.showCode = !state.showCode;
              }}
              className="text-primary cursor-pointer"
            >
              {state.showCode ? '收起' : '展开'}
            </div>

            {state.showCode && (
              <div className="mt-2">
                <CodeEditor
                  height={150}
                  language="less"
                  readOnly
                  value={engineModelStore.globalStyle}
                />
              </div>
            )}
          </Card>
        </div>

        {allowCssInJs(platform) &&
          Object.values(engineModelStore.styles).map((pageStyle) => (
            <div className="mt-2" key={pageStyle.id}>
              <Card
                size="small"
                type="inner"
                title={pageStyle.name}
                className={gzdnBem('code-card')}
                extra={
                  <>
                    <Tooltip title="删除">
                      <ClickableText
                        className="text-error"
                        onClick={() =>
                          Modal.confirm({
                            title: '是否删除',
                            content: pageStyle.name,
                            onOk: () => {
                              designerStore.deleteStyle(pageStyle.id);
                            },
                          })
                        }
                      >
                        <DeleteOutlined />
                      </ClickableText>
                    </Tooltip>

                    <Tooltip title="编辑">
                      <ClickableText
                        className="ml-1 text-primary"
                        onClick={() => {
                          state.pageStyleOpen = pageStyle;
                        }}
                      >
                        <EditOutlined />
                      </ClickableText>
                    </Tooltip>
                  </>
                }
              >
                <div>
                  <span
                    onClick={() => {
                      state.showCode = !state.showCode;
                    }}
                    className="text-primary cursor-pointer"
                  >
                    {state.showCode ? '收起' : '展开'}
                  </span>
                </div>

                {state.showCode && (
                  <div className="mt-2">
                    <CodeEditor
                      height={150}
                      language="less"
                      readOnly
                      value={pageStyle.style}
                    />
                  </div>
                )}
              </Card>
            </div>
          ))}
      </div>

      <StyleDialog
        pageStyle={state.pageStyleOpen}
        onCancel={() => {
          state.pageStyleOpen = undefined;
        }}
      />
    </>
  );
});
