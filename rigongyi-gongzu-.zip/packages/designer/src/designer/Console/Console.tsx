import { css } from '@emotion/css';
import ToolsHotKeys from '@gongzu/core/common/ToolsHotKeys';
import FlexWrapper from '@gongzu/core/components/FlexWrapper';
import { gzdnBem } from '@gongzu/core/config/constants';
import { DesignerStoreContext } from '@gongzu/core/contexts/store-contexts';
import { ToolModule } from '@gongzu/core/stores/DesignerStore';
import { observer } from 'mobx-react';
import React, { useEffect, useRef } from 'react';
import { useBeforeUnload } from 'react-use';
import ErrorBoundaryDesktop from '../../components/ErrorBoundary';
import Docks from '../components/Docks';
import Header from '../components/Header';
import ToolWindow from '../components/ToolWindow';
import ActionManage from './ActionManage';
import PageDesignerCanvas from './Canvas';
import CompGallery from './CompGallery';
import PageDesignerHeader from './ConsoleHeader/ConsoleHeader';
import CustomManage from './CustomManage';
import DataManage from './DataManage';
import PageElementNavigator from './ElementNavigator';
import EventManage from './EventManage';
import ModalManage from './ModalManage';
import ModelingDialog from './ModelDataDialog';
import PageManage from './PageManage';
import ResourceManage from './ResourceManage';
import PageCompSettings from './Settings';
import StyleManage from './StyleManage';

const consoleBem = gzdnBem('console');

const toolModuleComponents = {
  [ToolModule.DATAS]: DataManage,
  [ToolModule.NAVIGATOR]: PageElementNavigator,
  [ToolModule.STYLES]: StyleManage,
  [ToolModule.COMPONENTS]: CompGallery,
  [ToolModule.PAGES]: PageManage,
  [ToolModule.SETTINGS]: PageCompSettings,
  [ToolModule.ACTIONS]: ActionManage,
  [ToolModule.EVENTS]: EventManage,
  [ToolModule.RESOURCES]: ResourceManage,
  [ToolModule.MODALS]: ModalManage,
  [ToolModule.CUSTOM]: CustomManage,
};

const leftToolModules = [
  ToolModule.COMPONENTS,
  ToolModule.MODALS,
  ToolModule.CUSTOM,
  ToolModule.NAVIGATOR,
  ToolModule.STYLES,
  ToolModule.ACTIONS,
  ToolModule.DATAS,
  ToolModule.EVENTS,
  ToolModule.RESOURCES,
];

const rightToolModules = [ToolModule.SETTINGS, ToolModule.PAGES];

const DirtyWatcher = observer(() => {
  const designerStore = React.useContext(DesignerStoreContext);

  useBeforeUnload(designerStore.dirty, '需要保存');

  return <></>;
});

export interface PageDesignerProps {
  pageId: string;
}

export default observer(() => {
  const designerStore = React.useContext(DesignerStoreContext);
  useEffect(() => {
    window.scrollTo(0, 0);
    window.dispatchEvent(new Event('resize'));
  }, []);

  const canvasRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (canvasRef.current) {
      canvasRef.current.scrollTop = 0;
      window.dispatchEvent(new Event('resize'));
    }
  }, [designerStore.env.isPreview]);

  const { env, leftDock, rightDock } = designerStore;

  return (
    <>
      <Header>
        <PageDesignerHeader />
      </Header>

      <FlexWrapper className={consoleBem('container')}>
        <ErrorBoundaryDesktop>
          <DirtyWatcher />

          <div className="flex bg-white h-full">
            <ToolsHotKeys />

            {env.isPreview ? null : (
              <>
                <Docks
                  className={css`
                    border-right: 1px solid #d9d9d9;
                  `}
                  toolModules={leftToolModules}
                  activeToolModule={leftDock}
                  onChange={(toolModule) =>
                    designerStore.updateLeftDock(toolModule)
                  }
                />

                {leftToolModules.map((toolModule) => {
                  const tool = toolModuleComponents[toolModule];

                  return (
                    <ToolWindow
                      key={`${toolModule}`}
                      className="border-border border-r"
                      toolModule={toolModule}
                      active={leftDock === toolModule}
                      onClose={() => designerStore.updateLeftDock(undefined)}
                    >
                      {tool ? React.createElement(tool) : <></>}
                    </ToolWindow>
                  );
                })}
              </>
            )}

            <div className="flex-1 relative overflow-auto" ref={canvasRef}>
              <PageDesignerCanvas />
            </div>

            {env.isPreview ? null : (
              <>
                <>
                  {rightToolModules.map((toolModule) => {
                    const tool = toolModuleComponents[toolModule];

                    return tool == null ? (
                      <></>
                    ) : (
                      <ToolWindow
                        key={`${toolModule}`}
                        className="border-border border-l"
                        toolModule={toolModule}
                        active={rightDock === toolModule}
                        onClose={() => designerStore.updateRightDock(undefined)}
                      >
                        {React.createElement(tool)}
                      </ToolWindow>
                    );
                  })}

                  <Docks
                    className={css`
                      border-left: 1px solid #d9d9d9;
                    `}
                    toolModules={rightToolModules}
                    activeToolModule={rightDock}
                    onChange={(toolModule) => {
                      designerStore.updateRightDock(toolModule);
                    }}
                  />
                </>
              </>
            )}
          </div>

          <ModelingDialog />
        </ErrorBoundaryDesktop>
      </FlexWrapper>
    </>
  );
});
