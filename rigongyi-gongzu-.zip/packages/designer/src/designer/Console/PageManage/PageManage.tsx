import { getHistory } from '@gongzu/core/config/history';
import {
  BaseStoresContext,
  DesignerStoreContext,
} from '@gongzu/core/contexts/store-contexts';
import { Page, PagePlatform, PageStatus } from '@gongzu/core/types/entities';
import { mapTreeNode } from '@gongzu/core/utils/tree';
import { Dropdown, Menu, Modal, Tooltip, Tree } from 'antd';
import size from 'lodash-es/size';

import { Observer } from 'mobx-react';
import React from 'react';
import { addingId } from '../../../config/constants';
import PageDialog from '../../components/PageDialog';
import PageModelDialog from '../../components/PageModelDialog';
import { PageManageStoreContext } from '../../contexts';

const MenuItem = Menu.Item;

export default function PageManage() {
  const { pageStore } = React.useContext(BaseStoresContext);

  const pageManageStore = React.useContext(PageManageStoreContext);

  const designerStore = React.useContext(DesignerStoreContext);

  const history = getHistory();

  React.useEffect(() => {
    pageManageStore.init();
  }, []);

  const openPage = React.useCallback((page: Page) => {
    pageManageStore.openPage(page);
  }, []);

  return (
    <>
      <Observer>
        {() => {
          const { dirty } = designerStore;

          const treeData = mapTreeNode(pageManageStore.idTree, (n) => {
            const node = pageStore.pages[n.id];

            return (
              node && {
                key: n.id,
                title: (
                  <Dropdown
                    overlay={
                      <Menu style={{ minWidth: 150 }}>
                        <MenuItem
                          key="0"
                          onClick={() => {
                            if (dirty) {
                              Modal.confirm({
                                title: '尚未保存，是否放弃修改直接跳转？',
                                onOk: () => {
                                  history.push(
                                    `${window.location.pathname}?pageId=${node.id}`,
                                  );
                                },
                              });
                            } else {
                              history.push(
                                `${window.location.pathname}?pageId=${node.id}`,
                              );
                            }
                          }}
                        >
                          设计
                        </MenuItem>

                        <MenuItem
                          key="1.1"
                          onClick={() => {
                            openPage(node);
                          }}
                        >
                          修改
                        </MenuItem>

                        <MenuItem
                          key="1"
                          onClick={() => {
                            openPage({
                              id: addingId,
                              name: `页面${size(pageStore.pages) + 1}`,
                              status: PageStatus.UNPUBLISHED,
                              parentId: node.id,
                              platform: PagePlatform.PC,
                            });
                          }}
                        >
                          新建
                        </MenuItem>

                        <MenuItem
                          key="2"
                          onClick={() => pageManageStore.openPageModel(node)}
                        >
                          模型
                        </MenuItem>
                        <MenuItem
                          key="3"
                          className="text-error"
                          onClick={() => {
                            Modal.confirm({
                              title: '是否删除该页面',
                              content: node.name,
                              onOk: () => {
                                pageManageStore.deletePage(node.id);
                              },
                            });
                          }}
                        >
                          删除
                        </MenuItem>
                      </Menu>
                    }
                    trigger={['contextMenu']}
                  >
                    <Tooltip title={node.id}>
                      <span
                        style={{
                          userSelect: 'none',
                        }}
                        onDoubleClick={() => openPage(node)}
                      >
                        {node?.name ?? '-'}
                      </span>
                    </Tooltip>
                  </Dropdown>
                ),
                children: [],
              }
            );
          });

          return (
            <div className="p-2">
              <Tree
                expandedKeys={pageManageStore.expandedRowKeys}
                onExpand={(expandedKeys) =>
                  pageManageStore.updateExpandedRowKeys(
                    expandedKeys.map((k) => k.toString()),
                  )
                }
                treeData={treeData}
              />
            </div>
          );
        }}
      </Observer>

      <PageDialog />

      <Observer>
        {() => (
          <PageModelDialog
            pageModel={pageManageStore.pageModelOpen}
            onCancel={() => pageManageStore.closePageModel()}
            onSave={(model) => {
              if (pageManageStore.pageModelOpen) {
                pageStore
                  .savePageModel(pageManageStore.pageModelOpen.id, model)
                  .subscribe();
              }
            }}
          />
        )}
      </Observer>
    </>
  );
}
