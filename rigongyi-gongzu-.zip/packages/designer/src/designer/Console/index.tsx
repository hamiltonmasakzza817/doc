import Loading from '@gongzu/core/common/Loading';
import FlexWrapper from '@gongzu/core/components/FlexWrapper';
import {
  BaseStoresContext,
  DesignerStoreContext,
  EngineStoresContext,
} from '@gongzu/core/contexts/store-contexts';
import EngineStore from '@gongzu/core/engine/EngineStore';
import DesignerStore from '@gongzu/core/stores/DesignerStore';
import LoggerStore from '@gongzu/core/stores/LoggerStore';
import MessageStore from '@gongzu/core/stores/MessageStore';
import { observer } from 'mobx-react';
import React from 'react';
import { mergeMap, tap } from "rxjs/operators";
import { loggerStore, pageStore } from '../../config/container';
import codeInterpreter from '../../utils/codeInterpreter';
import router from '../../utils/router';
import Header from '../components/Header';
import Console, { PageDesignerProps } from './Console';

export default observer((props: PageDesignerProps) => {
  const { pageId } = props;

  const { streamStore } = React.useContext(BaseStoresContext);

  const [designerStore, setDesignerStore] =
    React.useState<DesignerStore | null>(null);

  React.useEffect(() => {
    streamStore
      .fromStream(
        pageStore.fetchPage({ id: pageId }, 'draft').pipe(
          mergeMap((page) => {
            const engineStore1 = new EngineStore(
              {
                page,
                portal: document.body,
                inDesigner: true,
              },
              new LoggerStore(),
              new MessageStore(),
              codeInterpreter,
              router,
            );

            const store = new DesignerStore(
              loggerStore,
              streamStore,
              engineStore1,
            );

            setDesignerStore(store);

            document.title = `${engineStore1.page.name} - 设计`;

            return store.init();
          }),
        ),
        'pageDesigner/init',
      )
      .subscribe();
  }, [pageId]);

  if (streamStore.getPending('pageDesigner/init')) {
    return (
      <>
        <Header>
          <div className="text-center">加载中...</div>
        </Header>

        <FlexWrapper>
          <Loading />
        </FlexWrapper>
      </>
    );
  }

  if (designerStore == null) {
    return (
      <FlexWrapper>
        <Loading>模型未加载</Loading>
      </FlexWrapper>
    );
  }

  const { engineStore } = designerStore;

  const {
    engineModelStore,
    engineRuntimeStore,
    engineActionStore,
    engineDataStore,
    engineEventStore,
    engineFormStore,
  } = engineStore;

  return (
    <DesignerStoreContext.Provider value={designerStore}>
      <EngineStoresContext.Provider
        value={{
          engineStore,
          engineModelStore,
          engineRuntimeStore,
          engineActionStore,
          engineDataStore,
          engineEventStore,
          engineFormStore,
        }}
      >
        <Console />
      </EngineStoresContext.Provider>
    </DesignerStoreContext.Provider>
  );
});
