import { fixedChildPageCompTypes } from '@gongzu/core/config/comps';
import { gzdnBem } from '@gongzu/core/config/constants';
import language from '@gongzu/core/config/language';
import {
  BaseStoresContext,
  DesignerStoreContext,
} from '@gongzu/core/contexts/store-contexts';
import { CompConfig } from '@gongzu/core/types/comps-common';
import { TreeNode } from '@gongzu/core/types/entities';
import { findTreeNode, mapTreeNode, walkTree } from '@gongzu/core/utils/tree';
import { Tree } from 'antd';
import compact from 'lodash-es/compact';
import concat from 'lodash-es/concat';
import get from 'lodash-es/get';
import includes from 'lodash-es/includes';
import uniq from 'lodash-es/uniq';
import { observer } from 'mobx-react';
import React from 'react';

export default observer(() => {
  const { loggerStore } = React.useContext(BaseStoresContext);

  const designerStore = React.useContext(DesignerStoreContext);

  const [expandedKeys, setExpandedKeys] = React.useState<string[]>();

  const { focusing } = designerStore;

  React.useEffect(() => {
    if (focusing) {
      const ids = focusing.pathname?.split(',') ?? [];
      ids.pop();
      setExpandedKeys(uniq(concat(ids, expandedKeys ?? [])));
    }
  }, [focusing]);

  const treeData = mapTreeNode<
    CompConfig,
    TreeNode<{
      node: CompConfig;
      key: string;
      title: string;
    }>
  >(designerStore.getComponents(), (node: CompConfig) => {
    const typeName = get(language.compTypes, node.type);

    const name = node.name || node.alias;

    return {
      node,
      id: node.id,
      key: node.id,
      title: name ? `${name}(${typeName})` : typeName,
    };
  });

  return (
    <div className="p-2">
      <Tree
        className={gzdnBem('element-navigator')('tree')}
        treeData={treeData}
        expandedKeys={expandedKeys}
        onExpand={(expandedKeys1) => setExpandedKeys(expandedKeys1 as string[])}
        selectedKeys={compact([focusing?.id])}
        onSelect={(keys) => {
          const f = findTreeNode(treeData, 'key', keys[0]);
          if (f) {
            designerStore.focus(f.node);
          }
        }}
        draggable
        onDrop={(info) => {
          const dragKey = info.dragNode.key;
          const dropKey = info.node.key;

          let dragging: CompConfig | undefined;
          let dropping: CompConfig | undefined;

          let draggingParent: CompConfig | undefined;
          let droppingParent: CompConfig | undefined;

          walkTree(treeData, (node) => {
            if (node.key === dragKey) {
              dragging = node.node;
            }

            if (node.key === dropKey) {
              dropping = node.node;
            }
          });

          walkTree(treeData, (node) => {
            if (node.key === dragging?.parentId) {
              draggingParent = node.node;
            }

            if (node.key === dropping?.parentId) {
              droppingParent = node.node;
            }
          });

          if (dragging && dropping && draggingParent && droppingParent) {
            const draggingConfig = dragging as CompConfig;
            const droppingConfig = dropping as CompConfig;
            const draggingParentConfig = draggingParent as CompConfig;

            if (includes(fixedChildPageCompTypes, draggingParentConfig.type)) {
              loggerStore.error('此元素不允许移动');
              return;
            }

            if (
              (info.dropPosition === 0 &&
                includes(fixedChildPageCompTypes, droppingConfig.type)) ||
              includes(fixedChildPageCompTypes, draggingParentConfig.type)
            ) {
              loggerStore.error('该区域不允许接收元素');
              return;
            }

            designerStore.drop({
              dragging: draggingConfig,
              dropping: {
                config: info.dropToGap
                  ? droppingConfig
                  : (get(droppingConfig.children, 0) as CompConfig),
                position: info.dropToGap ? 'rear' : 'front',
              },
            });
          } else {
            loggerStore.error('未找到元素');
          }
        }}
      />
    </div>
  );
});
