import CompContext from '@gongzu/core/common/CompContext';
import usePageCompTools from '@gongzu/core/common/usePageCompTools';
import { DesignerStoreContext } from '@gongzu/core/contexts/store-contexts';
import { PageDevice, PagePlatform } from '@gongzu/core/types/entities';
import classNames from 'classnames';
import { observer, useLocalObservable } from 'mobx-react';
import React from 'react';
import { useWindowSize } from 'react-use';

const deviceWidths = {
  [PageDevice.PC_WIDE]: 2560,
  [PageDevice.PC]: 1920,
  [PageDevice.LAPTOP]: 1366,
  [PageDevice.MOBILE]: 375,
};

export default observer((props: { visible: boolean; height?: number }) => {
  const { visible } = props;

  const localState = useLocalObservable<{
    width: string | number;
    height: number | string;
  }>(() => ({
    width: 0,
    height: 0,
  }));

  const frame = React.useRef<HTMLIFrameElement>(null);

  const pageCompTools = usePageCompTools();

  const designerStore = React.useContext(DesignerStoreContext);

  const {
    engineStore: { page },
  } = designerStore;

  const compContext = React.useContext(CompContext);

  const { device, isPreview } = designerStore.env;

  const windowSize = useWindowSize();

  React.useEffect(() => {
    let width: number | string;

    if (device === PageDevice.CURRENT) {
      if (isPreview) {
        width = '100%';
      } else {
        // 减去设计画布容器的 padding 和工具窗 Dock 的宽度
        width = windowSize.width;
      }
    } else {
      width = deviceWidths[device];
    }

    localState.width = width;
  }, [windowSize.width, device]);

  React.useEffect(() => {
    window.addEventListener('designer/save', () => {
      pageCompTools.saveModel();
    });
  }, []);

  const init = React.useCallback(() => {
    if (frame.current?.contentWindow) {
      frame.current.contentWindow.dispatchEvent(
        new CustomEvent('canvas/init', {
          detail: {
            designerStore,
            compContext,
          },
        }),
      );
    }
  }, []);

  const onViewportChange = React.useCallback((e: Event) => {
    const event = e as unknown as {
      detail: DOMRectReadOnly;
    };

    localState.height = event.detail.height;
  }, []);

  React.useEffect(() => {
    if (visible) {
      window.addEventListener('designer/ready', init);
      window.addEventListener('designer/viewport-change', onViewportChange);
    } else {
      window.removeEventListener('designer/ready', init);
      window.removeEventListener('designer/viewport-change', onViewportChange);
    }
  }, [visible]);

  let { height } = localState;

  let minHeight;

  const isMobile = device === PageDevice.MOBILE;
  if (isMobile) {
    height = '100%';
  } else if (props.height) {
    // 非移动端必然有滚动条，故需要减去滚动条的高度
    minHeight = props.height - 21;
  }

  return (
    <iframe
      title="designer-canvas"
      width={localState.width}
      height={height}
      src={page.platform === PagePlatform.TARO ? '/taro' : '/web'}
      className={classNames('border-0', {
        'w-full h-full overflow-auto': isMobile,
        'overflow-hidden': !isMobile,
      })}
      style={{
        visibility: visible ? 'visible' : 'hidden',
        minHeight,
        outlineOffset: -1,
        outline: '1px dashed purple'
      }}
      ref={frame}
    />
  );
});
