import { actionBindingKeys } from '@gongzu/core/config/comps';
import { gzdnBem } from '@gongzu/core/config/constants';
import language from '@gongzu/core/config/language';
import { DesignerStoreContext } from '@gongzu/core/contexts/store-contexts';
import { CompConfig } from '@gongzu/core/types/comps-common';
import { walkTree } from '@gongzu/core/utils/tree';
import { Tooltip } from 'antd';
import classNames from 'classnames';
import get from 'lodash-es/get';
import size from 'lodash-es/size';
import split from 'lodash-es/split';
import { observer } from 'mobx-react';
import React from 'react';
import Dot from '../../../components/Dot';

const nodeCrumbBem = gzdnBem('node-crumb');

export default observer(() => {
  const designerStore = React.useContext(DesignerStoreContext);

  const { focusing } = designerStore;

  if (!focusing) {
    return (
      <span
        style={{
          lineHeight: '40px',
        }}
      >
        无选中节点
      </span>
    );
  }

  const pathnames = split(focusing.pathname ?? focusing.id, ',');

  const nodes: CompConfig[] = [];

  const components = designerStore.getEditingComponents();

  walkTree(components, (node) => {
    if (pathnames.includes(node.id)) {
      nodes.push(node);
    }
  });

  return (
    <div className={nodeCrumbBem('container')}>
      {nodes.map((node, index) => {
        const { alias } = node;

        const typeName = get(language.compTypes, node.type);

        const hasAction = actionBindingKeys.some(
          (key) => get(node, `${key}.actionId`) != null,
        );

        const hasStyle = size(node.css) > 0 || size(node.styleIds) > 0;

        return (
          <div key={node.id} className="relative">
            <span
              onClick={() => designerStore.focus(node)}
              className={classNames('cursor-pointer', {
                'font-bold text-primary': focusing === node,
              })}
            >
              {alias ? `${alias}(${typeName})` : typeName}
            </span>

            <div className={nodeCrumbBem('node')}>
              {hasAction && (
                <Tooltip title="有Action">
                  <Dot size={4} className="bg-success" />
                </Tooltip>
              )}

              {hasStyle && (
                <Tooltip title="有样式">
                  <Dot size={4} className="bg-error" />
                </Tooltip>
              )}
            </div>

            {index !== size(nodes) - 1 ? ' > ' : ''}
          </div>
        );
      })}
    </div>
  );
});
