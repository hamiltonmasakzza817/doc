import Central from '@gongzu/core/common/Central';
import PageCompContext, { ICompContext } from '@gongzu/core/common/CompContext';
import FlexWrapper from '@gongzu/core/components/FlexWrapper';
import { gzdnBem } from '@gongzu/core/config/constants';
import language from '@gongzu/core/config/language';
import {
  DesignerStoreContext,
  EngineStoresContext,
} from '@gongzu/core/contexts/store-contexts';
import { PageCompType } from '@gongzu/core/types/comps-page';
import { PageDevice } from '@gongzu/core/types/entities';
import { Tabs } from 'antd';
import classNames from 'classnames';
import compact from 'lodash-es/compact';
import find from 'lodash-es/find';
import get from 'lodash-es/get';
import { observer, Observer, useLocalObservable } from 'mobx-react';
import React from 'react';

import CanvasLoader from './CanvasLoader';
import NodeCrumb from './NodeCrumb';
import PreviewLoader from './PreviewLoader';

const iPhoneXImage = require('../../../resource/iPhone13.png');

const CanvasWrapper = observer(
  (props: {
    children: JSX.Element | JSX.Element[];
    id?: string;
    isPreview: boolean;
  }) => {
    const designerStore = React.useContext(DesignerStoreContext);

    const { children, id, isPreview } = props;

    const { device } = designerStore.env;

    const isMobile = device === PageDevice.MOBILE;

    const localState = useLocalObservable<{
      height: number | string;
    }>(() => ({
      height: 0,
    }));

    const canvas = (
      <Observer>
        {() => {
          if (isMobile) {
            return (
              <div
                className={gzdnBem('canvas')('mobile')}
                style={{
                  backgroundImage: `url('${iPhoneXImage.default}')`,
                }}
              >
                <div data-viewport={id} className="overflow-y-auto">
                  {children}
                </div>
              </div>
            );
          }

          return (
            <>
              {React.cloneElement(React.Children.only(children), {
                height: localState.height,
              })}
            </>
          );
        }}
      </Observer>
    );

    if (isPreview) {
      return <FlexWrapper>{canvas}</FlexWrapper>;
    }

    return (
      <FlexWrapper
        className="w-full relative overflow-auto"
        data-viewport={id}
        bottom={55}
        onMouseLeave={(e) => {
          e.stopPropagation();
          e.preventDefault();
          designerStore.clearHover();
        }}
        onHeightChange={(height) => {
          localState.height = height;
        }}
      >
        {canvas}
      </FlexWrapper>
    );
  },
);

export default observer(() => {
  const designerStore = React.useContext(DesignerStoreContext);

  const { engineModelStore, engineRuntimeStore } =
    React.useContext(EngineStoresContext);

  const pageCompContext = React.useContext(PageCompContext);

  const { elements } = engineModelStore;

  const {
    editing: { tabs, tab },
    env: { isPreview },
  } = designerStore;

  const active = find(tabs, (c) => c.id === tab?.id);

  const canvasPageComContext = React.useMemo<ICompContext>(
    () => ({
      ...pageCompContext,
      pageIds: compact([designerStore.pageId]),
      state: engineRuntimeStore.state,
      containerQuerySelector: active
        ? `[data-container="${active.id}"]`
        : undefined,
      viewportQuerySelector: active
        ? `[data-viewport="${active.id}"]`
        : undefined,
      inMobile: designerStore.env.device === PageDevice.MOBILE,
      inDesigner: true,
    }),
    [pageCompContext],
  );

  return (
    <div>
      {elements != null ? (
        <>
          <div className={classNames('px-3 pt-3', { hidden: isPreview })}>
            <Tabs
              hideAdd
              type="editable-card"
              activeKey={tab?.id}
              onChange={(activeKey) => {
                const focus = tabs.find((t) => t.id === activeKey);
                if (focus) {
                  designerStore.focus(focus);
                } else {
                  designerStore.blur();
                }
              }}
              onEdit={(targetKey, action) => {
                if (action === 'remove') {
                  designerStore.discardEditing(
                    tabs.find((t) => t.id === targetKey),
                  );
                }
              }}
            >
              {compact(tabs).map((comp) => (
                <Tabs.TabPane
                  tab={`${get(language.compTypes, comp.type)}${
                    comp.name ? `（${comp.name}）` : ''
                  }`}
                  key={comp.id}
                  closable={comp.type !== PageCompType.PAGE}
                >
                  <></>
                </Tabs.TabPane>
              ))}
            </Tabs>

            <PageCompContext.Provider value={canvasPageComContext}>
              <CanvasWrapper id={active?.id} isPreview={false}>
                <CanvasLoader visible={!isPreview} />
              </CanvasWrapper>
            </PageCompContext.Provider>

            <NodeCrumb />
          </div>

          {isPreview && (
            <PageCompContext.Provider
              value={{
                ...pageCompContext,
                inDesigner: false,
                pageIds: compact([designerStore.pageId]),
                containerQuerySelector: `[data-container="${engineModelStore.pageId}"]`,
                viewportQuerySelector: `[data-viewport="${engineModelStore.pageId}"]`,
              }}
            >
              <CanvasWrapper id={engineModelStore.pageId} isPreview>
                <PreviewLoader />
              </CanvasWrapper>
            </PageCompContext.Provider>
          )}
        </>
      ) : (
        <Central>
          <div>无权限或未加载到数据</div>
        </Central>
      )}
    </div>
  );
});
