import { EngineStoresContext } from '@gongzu/core/contexts/store-contexts';
import { PagePlatform } from '@gongzu/core/types/entities';
import cloneDeep from 'lodash-es/cloneDeep';
import omit from 'lodash-es/omit';

import { observer } from 'mobx-react';
import React from 'react';

export default observer(() => {
  const frame = React.useRef<HTMLIFrameElement>(null);

  const { engineStore, engineModelStore, engineRuntimeStore } =
    React.useContext(EngineStoresContext);

  const { page } = engineStore;

  React.useEffect(() => {
    const init = () => {
      if (frame.current?.contentWindow) {
        const {
          actions,
          datas,
          events,
          elements,
          modals,
          styles,
          resources,
          customTree,
          customs,
          globalStyle,
        } = engineModelStore;

        frame.current.contentWindow.dispatchEvent(
          new CustomEvent('preview/init', {
            detail: {
              mode: 'preview',
              page: cloneDeep(engineStore.page),
              modelData: JSON.stringify({
                elements,
                modals,
                customs,
                customTree,
                actions,
                datas: omit(datas, ['_system']),
                styles,
                events,
                version: engineStore.version,
                globalStyle,
                resources,
              }),
              state: cloneDeep(engineRuntimeStore.state),
            },
          }),
        );
      }
    };

    window.addEventListener('designer/ready', init);

    return () => {
      window.removeEventListener('designer/ready', init);
    };
  }, []);

  return (
    <>
      <iframe
        id="designer-canvas"
        title="designer-canvas"
        src={page.platform === PagePlatform.TARO ? '/taro' : '/web'}
        className="w-full h-full border-0 overflow-auto"
        ref={frame}
      />
    </>
  );
});
