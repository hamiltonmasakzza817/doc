import { DeleteOutlined, EditOutlined } from '@ant-design/icons';
import language from '@gongzu/core/config/language';
import {
  DesignerStoreContext,
  EngineStoresContext,
} from '@gongzu/core/contexts/store-contexts';
import {
  ActionQueue,
  ActionQueueType,
  Event,
  EventType,
} from '@gongzu/core/types/entities';
import { Button, Card, Modal, Tooltip } from 'antd';
import assign from 'lodash-es/assign';
import find from 'lodash-es/find';
import { observer } from 'mobx-react';
import React from 'react';
import { addingId } from '../../../config/constants';
import ActionQueueDialog from '../components/ActionQueueDialog';
import EventDialog from './EventDialog';

export default observer(() => {
  const designerStore = React.useContext(DesignerStoreContext);

  const { engineModelStore } = React.useContext(EngineStoresContext);

  const [pageEventOpen, setPageEventOpen] = React.useState<Event | null>(null);

  const [actionQueueOpen, setActionQueueOpen] = React.useState<{
    actionQueue: ActionQueue;
    eventId: string;
  } | null>(null);

  return (
    <div className="p-2">
      <div>
        <Button
          type="primary"
          size="small"
          onClick={() => {
            const { length } = engineModelStore.events;

            setPageEventOpen({
              id: addingId,
              name: `事件${length + 1}`,
              type: EventType.DATA_CHANGE,
              interval: '1000',
            });
          }}
        >
          新建
        </Button>
      </div>

      {engineModelStore.events.map((event) => (
        <div className="mt-2">
          <Card
            key={event.id}
            title={event.name}
            className="mb-3"
            size="small"
            type="inner"
            extra={
              <div className="flex gap-1">
                <Tooltip title="删除">
                  <span
                    className="text-error cursor-pointer"
                    onClick={() => {
                      Modal.confirm({
                        title: '是否删除事件？',
                        content: event.name,
                        onOk: () => {
                          designerStore.deleteEvent(event);
                        },
                      });
                    }}
                  >
                    <DeleteOutlined />
                  </span>
                </Tooltip>

                <Tooltip title="编辑">
                  <span
                    className="text-primary cursor-pointer"
                    onClick={() => setPageEventOpen(event)}
                  >
                    <EditOutlined />
                  </span>
                </Tooltip>
              </div>
            }
          >
            <div>名称：{event.name}</div>
            <div>类型：{language.pageEventType[event.type]}</div>
            <div>
              <span
                className="text-primary cursor-pointer"
                onClick={() => {
                  if (event.actionId) {
                    setActionQueueOpen({
                      eventId: event.id,
                      actionQueue: assign(
                        {},
                        engineModelStore.actions[event.actionId],
                        { name: event.name },
                      ),
                    });
                  } else {
                    setActionQueueOpen({
                      eventId: event.id,
                      actionQueue: {
                        id: addingId,
                        name: event.name,
                        actions: [],
                        type: ActionQueueType.LOCAL,
                      },
                    });
                  }
                }}
              >
                编辑Action
              </span>
            </div>
          </Card>
        </div>
      ))}

      <EventDialog
        pageEvent={pageEventOpen}
        onCancel={() => setPageEventOpen(null)}
      />

      <ActionQueueDialog
        actionQueue={actionQueueOpen?.actionQueue}
        onCancel={() => setActionQueueOpen(null)}
        onSave={(actionId) => {
          if (actionQueueOpen) {
            designerStore.saveEvent(
              assign(
                {},
                find(
                  engineModelStore.events,
                  (e) => e.id === actionQueueOpen.eventId,
                ),
                { actionId },
              ),
            );
          }
        }}
        nameFixed
      />
    </div>
  );
});
