import language from '@gongzu/core/config/language';
import { DesignerStoreContext } from '@gongzu/core/contexts/store-contexts';
import useFormMobx from '@gongzu/core/mobx-form/useFormMobx';
import { getItemErrorProps } from '@gongzu/core/mobx-form/utils';
import { Event, EventType } from '@gongzu/core/types/entities';
import { Form, Input, InputNumber, Modal, Select } from 'antd';
import { ModalProps } from 'antd/es/modal';
import cloneDeep from 'lodash-es/cloneDeep';
import { Observer } from 'mobx-react';
import React from 'react';
import { addingId } from '../../../config/constants';
import { dialogFormItemLayout } from '../../../config/layout';
import ExpressionInput from '../../components/ExpressionInput';

export default function EventDialog(
  props: Partial<ModalProps> & { pageEvent: Event | null },
) {
  const { pageEvent, ...modalProps } = props;

  const designerStore = React.useContext(DesignerStoreContext);

  const form = useFormMobx<Event>({
    defaultValues: null,
  });

  React.useEffect(() => {
    if (pageEvent) {
      form.reset(cloneDeep(pageEvent));
    }
  }, [pageEvent]);

  return (
    <Modal
      {...modalProps}
      title={pageEvent?.id === addingId ? '新建事件' : '编辑事件'}
      visible={pageEvent != null}
      width={600}
      maskClosable={false}
      keyboard={false}
      onOk={(e) => {
        form.triggerValidation().subscribe((isValid) => {
          if (isValid) {
            designerStore.saveEvent(form.values);
          }
        });

        if (modalProps.onCancel) {
          modalProps.onCancel(e);
        }
      }}
    >
      <Form {...dialogFormItemLayout}>
        <Observer>
          {() => (
            <>
              <Form.Item
                label="名称"
                {...getItemErrorProps(form.errors.name)}
                required
              >
                <Input {...form.bind('name', { required: true })} />
              </Form.Item>

              <Form.Item
                label="类型"
                {...getItemErrorProps(form.errors.type)}
                required
              >
                <Select {...form.bind('type', { required: true })}>
                  {[
                    EventType.PAGE_LOAD,
                    EventType.DATA_CHANGE,
                    EventType.INTERVAL,
                    EventType.DOM_EVENT,
                    EventType.PAGE_EVENT,
                  ].map((t) => (
                    <Select.Option key={t} value={t}>
                      {language.pageEventType[t]}
                    </Select.Option>
                  ))}
                </Select>
              </Form.Item>

              <Form.Item label="默认注册">
                <ExpressionInput {...form.bind('guard')} />
              </Form.Item>

              <Form.Item label="take">
                <InputNumber precision={0} step={1} {...form.bind('take')} />
              </Form.Item>

              {form.values.type === EventType.INTERVAL ? (
                <Form.Item
                  label="间隔"
                  required
                  {...getItemErrorProps(form.errors.interval)}
                >
                  <ExpressionInput
                    {...form.bind('interval', { required: true })}
                  />
                  （毫秒）
                </Form.Item>
              ) : (
                <>
                  {(() => {
                    form.unbind('interval');
                  })()}
                </>
              )}

              {form.values.type === EventType.DATA_CHANGE ? (
                <Form.Item
                  label="pathname"
                  required
                  {...getItemErrorProps(form.errors.pathname)}
                >
                  <ExpressionInput
                    asPathname
                    {...form.bind('pathname', { required: true })}
                  />
                </Form.Item>
              ) : (
                <>
                  {(() => {
                    form.unbind('pathname');
                  })()}
                </>
              )}

              {form.values.type === EventType.DOM_EVENT ? (
                <>
                  <Form.Item
                    label="CSS选择器"
                    required
                    {...getItemErrorProps(form.errors.querySelector)}
                  >
                    <ExpressionInput
                      {...form.bind('querySelector', { required: true })}
                    />
                  </Form.Item>

                  <Form.Item
                    label="DOM事件名"
                    required
                    {...getItemErrorProps(form.errors.eventName)}
                  >
                    <ExpressionInput
                      {...form.bind('eventName', { required: true })}
                    />
                  </Form.Item>
                </>
              ) : (
                <>
                  {(() => {
                    form.unbind('querySelector');
                    form.unbind('eventName');
                  })()}
                </>
              )}

              {form.values.type === EventType.PAGE_EVENT ? (
                <Form.Item
                  label="页面事件名"
                  required
                  {...getItemErrorProps(form.errors.pageEventName)}
                >
                  <Input {...form.bind('pageEventName', { required: true })} />
                </Form.Item>
              ) : (
                <>
                  {(() => {
                    form.unbind('pageEventName');
                  })()}
                </>
              )}
            </>
          )}
        </Observer>
      </Form>
    </Modal>
  );
}
