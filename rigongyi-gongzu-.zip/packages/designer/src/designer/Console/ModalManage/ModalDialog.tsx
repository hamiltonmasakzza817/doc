import { DesignerStoreContext } from '@gongzu/core/contexts/store-contexts';
import useFormMobx from '@gongzu/core/mobx-form/useFormMobx';
import { getItemErrorProps } from '@gongzu/core/mobx-form/utils';
import {
  DesktopCompModalConfig,
  DesktopCompType,
} from '@gongzu/core/types/comps-desktop';
import { Form, Input, Modal, ModalProps } from 'antd';
import find from 'lodash-es/find';
import omit from 'lodash-es/omit';

import { Observer } from 'mobx-react';
import React from 'react';
import { dialogFormItemLayout } from '../../../config/layout';

export default function ModalDialog(
  props: ModalProps & { modal: Partial<DesktopCompModalConfig> | null },
) {
  const { onCancel, modal } = props;

  const designerStore = React.useContext(DesignerStoreContext);

  const form = useFormMobx<{ name: string }>({
    defaultValues: null,
  });

  React.useEffect(() => {
    if (modal) {
      form.reset({
        name: modal.name || '',
      });
    }
  }, [modal]);

  return (
    <Modal
      {...omit(props, 'modal')}
      title="新建对话框"
      onOk={(e) => {
        form.triggerValidation().subscribe((isValid) => {
          if (isValid) {
            if (modal && modal.id) {
              const config = find(
                designerStore.getComponents(DesktopCompType.MODAL),
                (n) => n.id === modal.id,
              );
              designerStore.updateConfig({
                config,
                values: form.values,
              });
            } else {
              designerStore.saveModal({
                ...form.values,
              });
            }

            if (onCancel) {
              onCancel(e);
            }
          }
        });
      }}
    >
      <Form {...dialogFormItemLayout}>
        <Observer>
          {() => (
            <>
              <Form.Item
                label="组件名"
                required
                {...getItemErrorProps(form.errors.name)}
              >
                <Input {...form.bind('name', { required: true })} />
              </Form.Item>
            </>
          )}
        </Observer>
      </Form>
    </Modal>
  );
}
