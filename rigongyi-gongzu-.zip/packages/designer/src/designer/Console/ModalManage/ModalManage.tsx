import { DeleteOutlined, EditOutlined } from '@ant-design/icons';
import { DesignerStoreContext } from '@gongzu/core/contexts/store-contexts';
import {
  DesktopCompModalConfig,
  DesktopCompType,
} from '@gongzu/core/types/comps-desktop';
import { Button, Card, Modal, Tooltip } from 'antd';
import classNames from 'classnames';
import fill from 'lodash-es/fill';
import get from 'lodash-es/get';
import size from 'lodash-es/size';
import slice from 'lodash-es/slice';
import { observer } from 'mobx-react';
import React from 'react';
import { DragDropContext, Draggable, Droppable } from 'react-beautiful-dnd';
import ModalDialog from './ModalDialog';

export default observer(() => {
  const designerStore = React.useContext(DesignerStoreContext);

  const [modalEditing, setModalEditing] = React.useState<{
    id?: string;
    name: string;
  } | null>(null);

  const modals = designerStore.getComponents(
    DesktopCompType.MODAL,
  ) as DesktopCompModalConfig[];

  const {
    editing: { tab: editing },
  } = designerStore;

  return (
    <>
      <div className="p-2">
        <div>
          <Button
            type="primary"
            size="small"
            onClick={() => {
              setModalEditing({
                name: `对话框${size(modals) + 1}`,
              });
            }}
          >
            新建
          </Button>
        </div>

        <DragDropContext
          onDragEnd={(result) => {
            if (result.destination && result.source) {
              const resorted = slice(modals);

              fill(
                resorted,
                get(modals, result.destination.index),
                result.source.index,
                result.source.index + 1,
              );

              fill(
                resorted,
                get(modals, result.source.index),
                result.destination.index,
                result.destination.index + 1,
              );

              designerStore.updateModals(resorted);
            }
          }}
        >
          <Droppable droppableId="droppable">
            {(provided) => (
              <div {...provided.droppableProps} ref={provided.innerRef}>
                {modals.map((config, index) => (
                  <Draggable
                    key={`${index + 1}`}
                    draggableId={config.id}
                    index={index}
                  >
                    {(provided1) => (
                      <div
                        ref={provided1.innerRef}
                        className={classNames('mt-2', {
                          'outline outline-1 outline-primary':
                            config === editing,
                        })}
                        {...provided1.draggableProps}
                        {...provided1.dragHandleProps}
                      >
                        <Card
                          size="small"
                          type="inner"
                          title={config.name}
                          onClick={() => {
                            designerStore.focus(config);
                          }}
                          extra={
                            <div className="flex gap-1">
                              <Tooltip title="删除">
                                <span
                                  className="text-error cursor-pointer"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    e.preventDefault();
                                    Modal.confirm({
                                      title: '提示',
                                      content: `是否删除对话框：${config.name}`,
                                      onOk: () => {
                                        designerStore.deleteModal(config);
                                      },
                                    });
                                  }}
                                >
                                  <DeleteOutlined />
                                </span>
                              </Tooltip>
                              <Tooltip title="编辑">
                                <span
                                  className="text-primary cursor-pointer"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    e.preventDefault();

                                    setModalEditing({
                                      name: config.name || '',
                                      id: config.id,
                                    });
                                  }}
                                >
                                  <EditOutlined />
                                </span>
                              </Tooltip>
                            </div>
                          }
                        >
                          <div>名称： {config.name}</div>
                          <div>类型：{config.displayType}</div>
                        </Card>
                      </div>
                    )}
                  </Draggable>
                ))}
              </div>
            )}
          </Droppable>
        </DragDropContext>
      </div>

      <ModalDialog
        visible={modalEditing != null}
        onCancel={() => setModalEditing(null)}
        modal={modalEditing}
      />
    </>
  );
});
