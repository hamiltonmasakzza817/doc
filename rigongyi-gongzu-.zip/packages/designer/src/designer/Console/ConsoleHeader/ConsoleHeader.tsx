import {
  CaretDownOutlined,
  DatabaseOutlined,
  DownOutlined,
  MenuOutlined,
  SettingOutlined,
} from '@ant-design/icons';
import { gzdnBem } from '@gongzu/core/config/constants';
import language from '@gongzu/core/config/language';
import {
  BaseStoresContext,
  DesignerStoreContext,
  EngineStoresContext,
} from '@gongzu/core/contexts/store-contexts';
import {
  Page,
  PageDevice,
  PagePlatform,
  PageStatus,
} from '@gongzu/core/types/entities';
import { Button, Dropdown, Menu, Modal, Tooltip } from 'antd';
import classNames from 'classnames';
import get from 'lodash-es/get';
import omit from 'lodash-es/omit';
import size from 'lodash-es/size';
import { observer } from 'mobx-react';
import React, { MouseEventHandler } from 'react';
import { mergeMap } from 'rxjs/operators';
import ClickableText from '../../../components/ClickableText';
import Dot from '../../../components/Dot';
import PageDialog from '../../components/PageDialog';
import PageModelDialog from '../../components/PageModelDialog';
import { PageManageStoreContext } from '../../contexts';
import PageNavTree from './PageNavTree';

const headerBem = gzdnBem('console-header');

export default observer((props: { className?: string }) => {
  const { className } = props;

  const { pageStore } = React.useContext(BaseStoresContext);

  const pageManageStore = React.useContext(PageManageStoreContext);

  const designerStore = React.useContext(DesignerStoreContext);

  const {
    engineModelStore,
    engineStore: {
      page: { platform },
    },
  } = React.useContext(EngineStoresContext);

  const [modelOpen, setModelOpen] = React.useState<Page | null>(null);
  const [pageMenuOpen, setPageMenuOpen] = React.useState<boolean>(false);

  const preventMouseEvent = React.useCallback<MouseEventHandler>((event) => {
    event.preventDefault();
    event.stopPropagation();
  }, []);

  React.useEffect(() => {
    pageManageStore.fetchPageTree().subscribe();
  }, []);

  const [modal, contextHolder] = Modal.useModal();

  const page = get(pageStore.pages, designerStore.pageId);

  const pageStatus = page?.status;

  const pageStatusText = pageStatus ? language.pageStatus[pageStatus] : '--';

  return (
    <>
      <div
        className={classNames(
          'ml-3 flex items-center justify-between',
          className,
        )}
      >
        <div className="flex items-center">
          <Dropdown
            visible={pageMenuOpen}
            onVisibleChange={setPageMenuOpen}
            mouseLeaveDelay={0.2}
            overlay={
              <div
                className={headerBem('menu-dropdown')}
                onClick={preventMouseEvent}
                onMouseDown={preventMouseEvent}
              >
                <PageNavTree />
              </div>
            }
          >
            <div className="font-bold cursor-pointer flex gap-1 items-center">
              <MenuOutlined
                style={{
                  color: '#999',
                }}
              />
              {page?.name ?? '--'}
            </div>
          </Dropdown>

          <div className="ml-2">
            <>
              {pageStatus !== PageStatus.UNPUBLISHED ? (
                <Tooltip title="去发布页">
                  <a
                    href={`/${
                      platform === PagePlatform.TARO ? 'taro' : 'web'
                    }?pageId=${page?.id}`}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    页面{pageStatusText}
                  </a>
                </Tooltip>
              ) : (
                <span>页面{pageStatusText}</span>
              )}

              <Dot
                className={classNames(
                  'ml-0.5',
                  pageStatus !== PageStatus.UNPUBLISHED
                    ? 'bg-success'
                    : 'bg-disabled',
                )}
              />
            </>
          </div>

          <div className="ml-3">
            <>
              <span>草稿{page?.isDrafting ? '编辑中' : '已发布'}</span>

              <Dot
                className={classNames(
                  'ml-0.5',
                  !page?.isDrafting ? 'bg-success' : 'bg-disabled',
                )}
              />
            </>
          </div>

          <Button
            size="small"
            type="primary"
            className="ml-2"
            onClick={() => {
              Modal.confirm({
                title: '是否发布',
                onOk: () => {
                  designerStore
                    .publishPage()
                    .pipe(
                      mergeMap(() =>
                        pageStore.fetchPage({ id: page.id }, 'draft'),
                      ),
                    )
                    .subscribe();
                },
              });
            }}
          >
            发布
          </Button>

          {page.status === PageStatus.PUBLISHED && (
            <Button
              size="small"
              className="ml-2"
              type="ghost"
              onClick={() => {
                Modal.confirm({
                  title: '是否回滚',
                  onOk: () => {
                    designerStore.rollbackPage().subscribe();
                  },
                });
              }}
            >
              回滚
            </Button>
          )}
        </div>

        <div className="flex items-center gap-2 mr-1">
          <div>
            平台：
            {
              language.pagePlatform[
                designerStore.engineStore.page.platform || PagePlatform.PC
              ]
            }
          </div>

          <div>
            {size(designerStore.rollbacks) > 0 ? (
              <div>
                <Tooltip title="ctrl(⌘)+z">
                  <ClickableText onClick={() => designerStore.rollback()}>
                    回滚
                  </ClickableText>
                </Tooltip>
              </div>
            ) : (
              <></>
            )}
          </div>

          <Dropdown
            overlay={
              <Menu selectedKeys={[designerStore.env.device]}>
                {[
                  PageDevice.CURRENT,
                  PageDevice.PC_WIDE,
                  PageDevice.PC,
                  PageDevice.LAPTOP,
                  PageDevice.MOBILE,
                ].map((device) => (
                  <Menu.Item
                    key={device}
                    onClick={() => {
                      designerStore.updateEnv({
                        device,
                      });
                    }}
                  >
                    {language.pageDevice[device]}
                  </Menu.Item>
                ))}
              </Menu>
            }
          >
            <div className="mr-1 flex items-center">
              {language.pageDevice[designerStore.env.device]}
              &nbsp;
              <CaretDownOutlined />
            </div>
          </Dropdown>

          <ClickableText
            onClick={() => {
              const {
                actions,
                datas,
                events,
                elements,
                modals,
                styles,
                resources,
                customs,
                customTree,
                version,
              } = engineModelStore;

              const page1 = {
                ...page,
                modelData: {
                  elements,
                  modals,
                  customs,
                  customTree,
                  actions,
                  datas: omit(datas, ['_system']),
                  styles,
                  events,
                  resources,
                  version,
                },
              };

              setModelOpen(page1);
            }}
            className="ml-1 text-primary"
            style={{ lineHeight: 0 }}
          >
            <Tooltip title="页面模型">
              <DatabaseOutlined />
            </Tooltip>
          </ClickableText>

          <ClickableText
            className="text-primary"
            onClick={() => {
              designerStore.updateEnv({
                isPreview: !designerStore.env.isPreview,
              });
            }}
            style={{
              lineHeight: 0,
            }}
          >
            {designerStore.env.isPreview ? '设计' : '预览'}
          </ClickableText>

          <Tooltip title="基础设置">
            <ClickableText
              onClick={() => {
                pageManageStore
                  .openPage(pageStore.pages[designerStore.pageId])
                  .subscribe();
              }}
              className="text-primary"
              style={{
                lineHeight: 0,
              }}
            >
              <SettingOutlined />
            </ClickableText>
          </Tooltip>

          <Tooltip title="ctrl(⌘)+s">
            <Button
              size="small"
              type="primary"
              ghost
              onClick={() => {
                designerStore
                  .savePage()
                  .pipe(mergeMap((id) => pageStore.fetchPage({ id }, 'draft')))
                  .subscribe();
              }}
              disabled={!designerStore.dirty}
            >
              保存
            </Button>
          </Tooltip>

          <Dropdown
            overlay={
              <Menu>
                <Menu.Item
                  onClick={() => {
                    designerStore.clearUnusedActions();
                  }}
                >
                  清除无效Action
                </Menu.Item>
                <Menu.Item
                  onClick={() => {
                    modal.info({
                      title: '版本',
                      // @ts-ignore
                      content: VERSION,
                    });
                  }}
                >
                  关于
                </Menu.Item>
              </Menu>
            }
          >
            <Button size="small">
              更多
              <DownOutlined
                style={{
                  fontSize: 9,
                  margin: '-1px 0px 0px 2px',
                  verticalAlign: 'middle',
                }}
              />
            </Button>
          </Dropdown>
        </div>
      </div>

      <PageModelDialog
        onSave={(model) => {
          pageStore.savePageModel(designerStore.pageId, model).subscribe(() => {
            window.location.reload();
          });
        }}
        pageModel={modelOpen}
        onCancel={() => setModelOpen(null)}
      />

      <PageDialog />

      {contextHolder}
    </>
  );
});
