import { getHistory } from '@gongzu/core/config/history';
import {
  BaseStoresContext,
  DesignerStoreContext,
  EngineStoresContext,
} from '@gongzu/core/contexts/store-contexts';
import { mapTreeNode } from '@gongzu/core/utils/tree';
import { Modal, Tree } from 'antd';
import { observer } from 'mobx-react';
import React from 'react';
import { PageManageStoreContext } from '../../contexts';

export default observer(() => {
  const { pageStore } = React.useContext(BaseStoresContext);

  const pageManageStore = React.useContext(PageManageStoreContext);

  const designerStore = React.useContext(DesignerStoreContext);

  const { engineModelStore } = React.useContext(EngineStoresContext);

  const history = getHistory();

  const { dirty } = designerStore;

  return (
    <Tree
      expandedKeys={pageManageStore.expandedRowKeys}
      onExpand={(expandedKeys) =>
        pageManageStore.updateExpandedRowKeys(
          expandedKeys as unknown as string[],
        )
      }
      selectedKeys={[engineModelStore.pageId]}
      treeData={mapTreeNode(pageManageStore.idTree || [], (n) => {
        const node = pageStore.pages[n.id];
        return (
          node && {
            key: n.id,
            value: n.id,
            title: (
              <span
                className="hover:text-primary"
                onClick={() => {
                  if (dirty) {
                    Modal.confirm({
                      title: '尚未保存，是否放弃修改直接跳转？',
                      onOk: () => {
                        history.push(
                          `${window.location.pathname}?pageId=${n.id}`,
                        );
                      },
                    });
                  } else {
                    history.push(`${window.location.pathname}?pageId=${n.id}`);
                  }
                }}
              >
                {node.name || '--'}
              </span>
            ),
            children: [],
          }
        );
      })}
    />
  );
});
