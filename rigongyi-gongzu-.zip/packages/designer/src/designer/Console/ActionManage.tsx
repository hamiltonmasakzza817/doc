import { DeleteOutlined } from '@ant-design/icons';
import {
  DesignerStoreContext,
  EngineStoresContext,
} from '@gongzu/core/contexts/store-contexts';
import { ActionQueue, ActionQueueType } from '@gongzu/core/types/entities';
import { Button, Modal } from 'antd';
import sortBy from 'lodash-es/sortBy';

import { observer } from 'mobx-react';
import React from 'react';
import ClickableText from '../../components/ClickableText';
import { addingId } from '../../config/constants';
import ActionQueueCard from './components/ActionQueueCard';
import ActionQueueDialog from './components/ActionQueueDialog';

export default observer(() => {
  const designerStore = React.useContext(DesignerStoreContext);

  const { engineModelStore } = React.useContext(EngineStoresContext);

  const [actionQueueOpen, setActionQueueOpen] =
    React.useState<ActionQueue | null>(null);

  return (
    <div className="p-2">
      <div>
        <Button
          type="primary"
          size="small"
          onClick={() => {
            const { length } = Object.keys(engineModelStore.actions);

            setActionQueueOpen({
              id: addingId,
              name: `Action${length + 1}`,
              actions: [],
              type: ActionQueueType.GLOBAL,
            });
          }}
        >
          新建
        </Button>
      </div>

      {sortBy(Object.values(engineModelStore.actions), (d) => d.ts || 0)
        .reverse()
        .filter((actionQueue) => actionQueue.type === ActionQueueType.GLOBAL)
        .map((actionQueue) => (
          <div key={actionQueue.id} className="mt-2">
            <ActionQueueCard
              actionQueue={actionQueue}
              onEdit={() => setActionQueueOpen(actionQueue)}
              extra={
                <ClickableText
                  className="ml-1 text-error"
                  onClick={() => {
                    Modal.confirm({
                      title: '是否删除该Action？',
                      content: actionQueue.name,
                      onOk: () => {
                        designerStore.deleteAction(actionQueue.id);
                      },
                    });
                  }}
                >
                  <DeleteOutlined />
                </ClickableText>
              }
            />
          </div>
        ))}

      <ActionQueueDialog
        actionQueue={actionQueueOpen}
        onCancel={() => setActionQueueOpen(null)}
      />
    </div>
  );
});
