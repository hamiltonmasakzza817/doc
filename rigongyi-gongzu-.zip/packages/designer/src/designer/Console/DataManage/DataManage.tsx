import { DeleteOutlined, EditOutlined } from '@ant-design/icons';
import Loading from '@gongzu/core/common/Loading';
import { gzdnBem } from '@gongzu/core/config/constants';
import language from '@gongzu/core/config/language';
import {
  DesignerStoreContext,
  EngineStoresContext,
} from '@gongzu/core/contexts/store-contexts';
import { Data, DataType } from '@gongzu/core/types/entities';
import { Button, Card, Modal, Spin, Tooltip } from 'antd';
import classNames from 'classnames';
import jsonPretty from 'json-stringify-pretty-compact';
import concat from 'lodash-es/concat';
import get from 'lodash-es/get';
import includes from 'lodash-es/includes';
import size from 'lodash-es/size';
import sortBy from 'lodash-es/sortBy';
import without from 'lodash-es/without';
import { observer } from 'mobx-react';
import React from 'react';
import Loadable from 'react-loadable';
import ClickableText from '../../../components/ClickableText';
import { addingId } from '../../../config/constants';
import DataDialog from './DataDialog';

const CodeEditor = Loadable({
  loader: () => import('../../../components/CodeEditor'),
  loading: () => (
    <Loading>
      <Spin />
    </Loading>
  ),
});

export default observer(() => {
  const { engineModelStore, engineRuntimeStore } =
    React.useContext(EngineStoresContext);

  const designerStore = React.useContext(DesignerStoreContext);

  const [pageDataOpen, setPageDataOpen] = React.useState<Data | null>(null);

  return (
    <div className="p-2">
      <div>
        <Button
          type="primary"
          size="small"
          onClick={() => {
            const length = size(engineModelStore.datas);

            setPageDataOpen({
              id: addingId,
              code: `data${length + 1}`,
              name: `数据${length + 1}`,
              type: DataType.URL,
              autoLoad: true,
              format: 'form',
              ignoreQueryException: false,
            });
          }}
        >
          新建
        </Button>
      </div>

      {sortBy(Object.values(engineModelStore.datas), (d) => d.ts || 0)
        .reverse()
        .map((pageData, index) => {
          const expendedKeys = get(designerStore.expendedKeys, 'pageData');

          const expended = includes(expendedKeys, pageData.id);

          return (
            <div
              key={`${index + 1}`}
              className={classNames('mt-2', {
                'outline outline-1 outline-primary': expended,
              })}
            >
              <Card
                size="small"
                type="inner"
                title={`${pageData.code}（${pageData.name}）`}
                className={gzdnBem('code-card')}
                extra={
                  <div className="flex gap-1">
                    <Tooltip title="删除">
                      <span
                        className="text-error cursor-pointer"
                        onClick={() => {
                          Modal.confirm({
                            title: '是否删除数据？',
                            content: pageData.name,
                            onOk: () => {
                              designerStore.deleteData(pageData.code);
                            },
                          });
                        }}
                      >
                        <DeleteOutlined />
                      </span>
                    </Tooltip>

                    <Tooltip title="编辑">
                      <span
                        className="text-primary cursor-pointer"
                        onClick={() => setPageDataOpen(pageData)}
                      >
                        <EditOutlined />
                      </span>
                    </Tooltip>
                  </div>
                }
              >
                <div className="flex justify-between relative">
                  <div>类型：{language.pageDataType[pageData.type]}</div>

                  <div className="text-primary">
                    {expended ? (
                      <span
                        className="cursor-pointer"
                        onClick={() => {
                          designerStore.updateExpendedKeys(
                            'pageData',
                            without(expendedKeys, pageData.id),
                          );
                        }}
                      >
                        收起
                      </span>
                    ) : (
                      <span
                        className="cursor-pointer"
                        onClick={() =>
                          designerStore.updateExpendedKeys(
                            'pageData',
                            concat(expendedKeys, pageData.id),
                          )
                        }
                      >
                        展开
                      </span>
                    )}
                  </div>
                </div>

                {expended && (
                  <div className="mt-2">
                    <CodeEditor
                      readOnly
                      language="json"
                      value={jsonPretty(
                        engineRuntimeStore.state[pageData.code],
                        {
                          maxLength: 0,
                        },
                      )}
                    />
                  </div>
                )}
              </Card>
            </div>
          );
        })}

      <DataDialog
        pageData={pageDataOpen}
        onCancel={() => setPageDataOpen(null)}
      />
    </div>
  );
});
