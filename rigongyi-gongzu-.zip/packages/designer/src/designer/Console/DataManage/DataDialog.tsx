import Loading from "@gongzu/core/common/Loading";
import lodashUtils from "@gongzu/core/common/lodash-utils";
import language from "@gongzu/core/config/language";
import { createService, formAxiosOptions } from "@gongzu/core/config/service";
import {
  BaseStoresContext,
  DesignerStoreContext,
  EngineStoresContext
} from "@gongzu/core/contexts/store-contexts";
import useFormMobx from "@gongzu/core/mobx-form/useFormMobx";
import { getItemErrorProps, validateJSON } from "@gongzu/core/mobx-form/utils";
import { Data, DataType } from "@gongzu/core/types/entities";
import { parseJSON } from "@gongzu/core/utils/data";
import {
  parseJexlExpression,
  parseJexlExpressionDeep
} from "@gongzu/core/utils/jexl";
import { buildSchemaSampleData } from "@gongzu/core/utils/schema";
import {
  filterTree,
  findTreeNode,
  findTreeNodeBy,
  mapTreeNode,
  walkTree
} from "@gongzu/core/utils/tree";
import { Button, Form, Input, Modal, Radio, Select, Switch } from "antd";
import { ModalProps } from "antd/es/modal";
import dayjs from "dayjs";
import jsonPretty from "json-stringify-pretty-compact";
import assign from "lodash-es/assign";
import cloneDeep from "lodash-es/cloneDeep";
import omit from "lodash-es/omit";
import set from "lodash-es/set";

import { observer, Observer } from "mobx-react";
import qs from "qs";
import React from "react";
import Loadable from "react-loadable";
import { EMPTY, from, of } from "rxjs";
import { map, mergeMap, tap } from "rxjs/operators";
import { addingId } from "../../../config/constants";
import { dialogFormItemLayout } from "../../../config/layout";
import codeInterpreter from "../../../utils/codeInterpreter";
import SchemaTable from "../../components/SchemaTable/SchemaTable";

const CodeEditor = Loadable({
  loader: () => import("../../../components/CodeEditor"),
  loading: Loading
});

export default observer(
  (props: Partial<ModalProps> & { pageData: Data | null }) => {
    const { pageData, onCancel, ...modalProps } = props;

    const { streamStore } = React.useContext(BaseStoresContext);

    const designerStore = React.useContext(DesignerStoreContext);

    const { engineRuntimeStore, engineModelStore } =
      React.useContext(EngineStoresContext);

    const form = useFormMobx<Data>({
      defaultValues: null
    });

    React.useEffect(() => {
      if (pageData) {
        const pd = cloneDeep(pageData);

        pd.params = pd.params
          ? jsonPretty(pd.params, {
            maxLength: 0
          })
          : null;

        pd.data = pd.data
          ? jsonPretty(pd.data, {
            maxLength: 0
          })
          : null;

        pd.defaultData = pd.defaultData
          ? jsonPretty(pd.defaultData, {
            maxLength: 0
          })
          : null;

        form.reset(pd);
      }
    }, [pageData]);

    const onSync = () => {
      const { type, method = "GET", format } = form.values;

      let { url } = form.values;

      return streamStore.fromStream(
        form.triggerValidation().pipe(
          mergeMap((isValid) => {
            if (isValid) {
              const params = parseJexlExpressionDeep(
                parseJSON(form.values.params),
                engineRuntimeStore.state
              );

              const stringifyOptions = parseJexlExpressionDeep(
                parseJSON(form.values.stringifyOptions),
                engineRuntimeStore.state
              );

              const service =
                format === "form"
                  ? createService(formAxiosOptions)
                  : createService();

              url = parseJexlExpression(url ?? "", engineRuntimeStore.state);

              if (type === DataType.URL && url) {
                if (method === "GET") {
                  return from(
                    service.get(url, {
                      params,
                      paramsSerializer: stringifyOptions
                        ? (p) => qs.stringify(p, stringifyOptions) : undefined,
                    })
                  );
                }

                return from(service.post(url, params));
              }

              return of(parseJSON(form.values.data));
            }

            return from(EMPTY);
          }),
          map((data) => {
            if (form.values.formatter) {
              try {
                return codeInterpreter(form.values.formatter, [
                  ["result", cloneDeep(data)],
                  ["state", cloneDeep(engineRuntimeStore.state)],
                  ["params", {}],
                  [
                    "utils",
                    {
                      ...lodashUtils,
                      walkTree,
                      findTreeNode,
                      findTreeNodeBy,
                      mapTreeNode,
                      filterTree,
                      moment: dayjs
                    }
                  ]
                ]);
              } catch (e) {
                return data;
              }
            }

            return data;
          }),
          mergeMap((data) => designerStore.analysisSchema(data)),
          tap((schema) => {
            set(form.values || {}, "schema", schema);
          })
        ),
        "pageDataSync"
      );
    };

    const visible = pageData != null;

    return (
      <Modal
        {...modalProps}
        title={pageData?.id === addingId ? "新建数据" : "修改数据"}
        visible={visible}
        onCancel={onCancel}
        width={1000}
        maskClosable={false}
        keyboard={false}
        footer={
          <Observer>
            {() => {
              const getData = () =>
                assign(
                  omit(form.values, ["params", "data"]),
                  form.values.type === DataType.MANUAL
                    ? {
                      data: form.values.data
                        ? parseJSON(form.values.data)
                        : null
                    }
                    : {
                      params: form.values.params
                        ? parseJSON(form.values.params)
                        : null,
                      defaultData: form.values.defaultData
                        ? parseJSON(form.values.defaultData)
                        : null
                    }
                );

              return (
                <>
                  <Button onClick={onCancel}>取消</Button>

                  <Button
                    type="primary"
                    ghost
                    onClick={(e) => {
                      designerStore.saveData(getData()).subscribe(() => {
                        if (onCancel) {
                          onCancel(e);
                        }
                      });
                    }}
                  >
                    保存
                  </Button>

                  <Button
                    type="primary"
                    onClick={(e) => {
                      designerStore.saveData(getData(), true).subscribe(() => {
                        if (onCancel) {
                          onCancel(e);
                        }
                      });
                    }}
                  >
                    保存并同步
                  </Button>
                </>
              );
            }}
          </Observer>
        }
      >
        <Form {...dialogFormItemLayout}>
          <Form.Item
            label="名称"
            required
            {...getItemErrorProps(form.errors.name)}
          >
            <Input {...form.bind("name", { required: true })} />
          </Form.Item>

          <Form.Item
            label="编码"
            required
            {...getItemErrorProps(form.errors.code)}
          >
            {pageData?.id === addingId ? (
              <Input
                {...form.bind("code", {
                  required: true,
                  validate: (value) =>
                    value in engineModelStore.datas ? "此编码已存在" : null
                })}
              />
            ) : (
              <Observer>
                {() => {
                  form.unbind("code");
                  return <div>{form.values.code}</div>;
                }}
              </Observer>
            )}
          </Form.Item>

          <Form.Item label="类型">
            <Select {...form.bind("type")}>
              {[DataType.URL, DataType.MANUAL].map((t) => (
                <Select.Option key={t} value={t}>
                  {language.pageDataType[t]}
                </Select.Option>
              ))}
            </Select>
          </Form.Item>

          {form.values.type === DataType.MANUAL ? (
            <>
              <Form.Item label="数据" {...getItemErrorProps(form.errors.data)}>
                {form.values.schema != null && (
                  <div
                    style={{
                      lineHeight: "32px"
                    }}
                  >
                    <Button
                      size="small"
                      type="link"
                      onClick={() => {
                        if (form.values.schema) {
                          form.setValues({
                            data: jsonPretty(
                              buildSchemaSampleData(form.values.schema),
                              {
                                maxLength: 0
                              }
                            )
                          });
                        }
                      }}
                    >
                      使用 schema 生成样例数据
                    </Button>
                  </div>
                )}

                {visible && (
                  <CodeEditor
                    language="json"
                    height={200}
                    {...form.bind("data", {
                      validate: validateJSON
                    })}
                  />
                )}
              </Form.Item>
            </>
          ) : (
            <>
              {(() => {
                form.unbind("data");
              })()}
            </>
          )}

          {form.values.type === DataType.URL ? (
            <>
              <Form.Item
                label="URL"
                required
                {...getItemErrorProps(form.errors.url)}
              >
                <Input {...form.bind("url", { required: true })} />
              </Form.Item>

              <Form.Item
                label="Method"
                {...getItemErrorProps(form.errors.method)}
              >
                <Radio.Group {...form.bind("method")} defaultValue="GET">
                  <Radio key="GET" value="GET">
                    Get
                  </Radio>

                  <Radio key="POST" value="POST">
                    POST
                  </Radio>
                </Radio.Group>
              </Form.Item>

              <Form.Item label="Content-Type">
                <Radio.Group {...form.bind("format")} defaultValue="json">
                  <Radio value="form">application/x-www-form-urlencoded</Radio>
                  <Radio value="json">application/json</Radio>
                </Radio.Group>
              </Form.Item>

              {form.values.method === "GET" ||
                (form.values.format === "form" && (
                  <Form.Item
                    label="参数序列化配置"
                    {...getItemErrorProps(form.errors.params)}
                  >
                    <CodeEditor
                      language="json"
                      height={200}
                      {...form.bind("stringifyOptions", {
                        validate: validateJSON
                      })}
                    />
                  </Form.Item>
                ))}

              <Form.Item label="忽略异常">
                <Switch
                  {...form.bind("ignoreQueryException")}
                  checked={form.values.ignoreQueryException}
                  defaultChecked={false}
                />
              </Form.Item>
            </>
          ) : (
            <>
              {(() => {
                form.unbind("url");
                form.unbind("method");
                form.unbind("format");
                form.unbind("stringifyOptions");
              })()}
            </>
          )}

          {[DataType.URL].includes(form.values.type) ? (
            <>
              <Form.Item
                label="默认参数"
                {...getItemErrorProps(form.errors.params)}
              >
                <CodeEditor
                  language="json"
                  height={200}
                  {...form.bind("params", {
                    validate: validateJSON
                  })}
                />
              </Form.Item>

              <Form.Item
                label="默认数据"
                {...getItemErrorProps(form.errors.defaultData)}
              >
                <CodeEditor
                  language="json"
                  height={200}
                  {...form.bind("defaultData", {
                    validate: validateJSON
                  })}
                />
              </Form.Item>

              <Form.Item label="默认加载">
                <Switch
                  {...form.bind("autoLoad")}
                  checked={form.values.autoLoad}
                />
              </Form.Item>
            </>
          ) : (
            <>
              {(() => {
                form.unbind("params");
                form.unbind("defaultData");
              })()}
            </>
          )}

          <Form.Item label="格式化函数">
            <div
              className="mb-1"
              style={{
                lineHeight: "32px"
              }}
            >
              <Switch
                checked={form.values.formatter != null}
                onChange={(checked) => {
                  if (checked) {
                    form.setValues({
                      formatter: `function formatter(result, state, params, utils) {
}
                              `
                    });
                  } else {
                    Modal.confirm({
                      title: "是否清空格式化函数？",
                      onOk: () => {
                        form.setValues({
                          formatter: null
                        });
                      }
                    });
                  }
                }}
              />
            </div>

            {form.values.formatter != null && (
              <CodeEditor language="javascript" {...form.bind("formatter")} />
            )}
          </Form.Item>

          {[DataType.MANUAL, DataType.URL].includes(form.values.type) && (
            <Form.Item label="Schema">
              <SchemaTable
                schema={form.values.schema}
                loading={streamStore.pending.get("schemaAnalyzing")}
                editable={[DataType.URL, DataType.MANUAL].includes(
                  form.values.type
                )}
                deduce={form.values.type === DataType.URL}
                onChange={(schema) => form.setValues({ schema })}
                onSync={onSync}
                autoSync
              />
            </Form.Item>
          )}
        </Form>
      </Modal>
    );
  }
);
