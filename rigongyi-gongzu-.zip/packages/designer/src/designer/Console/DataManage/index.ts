export { default } from './DataManage';
