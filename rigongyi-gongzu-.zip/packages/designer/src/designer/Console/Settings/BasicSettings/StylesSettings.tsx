import {
  BoldOutlined,
  ItalicOutlined,
  StrikethroughOutlined,
  UnderlineOutlined,
} from '@ant-design/icons';
import { containablePageCompTypes } from '@gongzu/core/config/comps';
import { gzdnBem } from '@gongzu/core/config/constants';
import language from '@gongzu/core/config/language';
import { VerticalAlign } from '@gongzu/core/types/comps-common';
import { Form, InputNumber, Radio, Select } from 'antd';
import assign from 'lodash-es/assign';
import get from 'lodash-es/get';
import includes from 'lodash-es/includes';
import range from 'lodash-es/range';
import { Observer } from 'mobx-react';
import React from 'react';
import ClickableText from '../../../../components/ClickableText';
import { fontFamilyBase } from '../../../../config/constants';
import ExpressionInput from '../../../components/ExpressionInput/ExpressionInput';
import ImageUploader from '../../../components/ImageUploader';
import SettingsFormContext from '../context/SettingsFormContext';

const fontFamilies = [
  ['宋体', `Georgia, SimSun, "宋体", serif`],
  [
    '微软雅黑',
    `Arial, "Microsoft YaHei", "微软雅黑", Heiti, "黑体", sans-serif`,
  ],
  [
    '华文细黑',
    `Helvetica, Tahoma, Arial, STXihei, "华文细黑", "Microsoft YaHei", "微软雅黑", Heiti, "黑体", sans-serif`,
  ],
];

const fontSizes = [
  ['小号', 12],
  ['正文', 14],
  ['大号', 16],
  ['标题', 24],
  ['标题2', 18],
];

const textFormats = [
  ['bold', <BoldOutlined />],
  ['italic', <ItalicOutlined />],
  ['underline', <UnderlineOutlined />],
  ['lineThrough', <StrikethroughOutlined />],
];

const settingsBem = gzdnBem('settings');

export default function StylesSettings() {
  const form = React.useContext(SettingsFormContext);

  return (
    <Observer>
      {() => (
        <>
          <Form.Item label="文本格式">
            <div className={settingsBem('text-settings')}>
              {textFormats.map((f) => {
                const checked = get(form.values, `styles.${f[0]}`);

                return (
                  <ClickableText
                    onClick={() => {
                      const relate: Record<string, boolean> = {};

                      if (!checked) {
                        if (f[0] === 'underline') {
                          relate['styles.lineThrough'] = false;
                        } else if (f[0] === 'lineThrough') {
                          relate['styles.underline'] = false;
                        }
                      }

                      form.setValues(
                        assign(relate, {
                          [`styles.${f[0]}`]: !checked,
                        }),
                      );
                    }}
                    key={f[0] as string}
                    className={settingsBem('text-settings-icon', { checked })}
                  >
                    {f[1]}
                  </ClickableText>
                );
              })}
            </div>
          </Form.Item>

          <Form.Item label="字号">
            <Select
              allowClear
              {...form.bind('styles.fontSize')}
              optionLabelProp="label"
            >
              {fontSizes.map((f) => (
                <Select.Option key={f[1]} value={f[1]} label={f[0]}>
                  <span
                    style={{
                      fontSize: f[1] ? f[1] : 'inherit',
                    }}
                  >
                    {f[0]}
                  </span>
                </Select.Option>
              ))}
            </Select>
          </Form.Item>

          <Form.Item label="字体">
            <Select
              allowClear
              {...form.bind('styles.fontFamily')}
              optionLabelProp="label"
            >
              {fontFamilies.map((f) => (
                <Select.Option key={f[1]} value={f[1]} label={f[0]}>
                  <span
                    style={{
                      fontFamily: `${f[1]}, ${fontFamilyBase}`,
                    }}
                  >
                    {f[0]}
                  </span>
                </Select.Option>
              ))}
            </Select>
          </Form.Item>

          <Form.Item label="宽度单位">
            <Select
              allowClear
              {...form.bind('styles.span')}
              options={range(1, 13).map((n) => ({
                label: `${n}个单元`,
                value: n,
              }))}
            />
          </Form.Item>

          <Form.Item label="宽度">
            <InputNumber {...form.bind('styles.width')} precision={0} min={0} />
          </Form.Item>

          <Form.Item label="高度">
            <InputNumber
              {...form.bind('styles.height')}
              precision={0}
              min={0}
            />
          </Form.Item>

          {includes(containablePageCompTypes, form.values.type) && (
            <>
              <Form.Item label="栅格">
                <Radio.Group
                  {...form.bind('styles.grid')}
                  defaultValue={null}
                  buttonStyle="solid"
                >
                  <Radio.Button value={null} key="null">
                    无
                  </Radio.Button>
                  <Radio.Button value="12" key="12">
                    12单元
                  </Radio.Button>
                  <Radio.Button value="flex" key="flex">
                    flex
                  </Radio.Button>
                </Radio.Group>
              </Form.Item>

              <Form.Item label="间隔">
                <Select
                  allowClear
                  {...form.bind('styles.gridGap')}
                  options={[
                    [0.5, '4px'],
                    [1, '8px'],
                    [2, '16px'],
                    [3, '24px'],
                    [4, '32px'],
                    [5, '40px'],
                    [6, '48px'],
                    [8, '64px'],
                  ].map(([v, k]) => ({ label: k, value: v }))}
                />
              </Form.Item>

              <Form.Item label="垂直对齐">
                <Select {...form.bind('styles.alignSelf')} allowClear>
                  {[
                    VerticalAlign.TOP,
                    VerticalAlign.CENTER,
                    VerticalAlign.BASELINE,
                    VerticalAlign.BOTTOM,
                  ].map((va) => (
                    <Select.Option key={va} value={va}>
                      {language.verticalAlign[va]}
                    </Select.Option>
                  ))}
                </Select>
              </Form.Item>
            </>
          )}

          <Form.Item label="背景图">
            <ExpressionInput
              {...form.bind('styles.backgroundImage', { onBlur: true })}
              leafOnly
            />
          </Form.Item>

          <Form.Item label="图片上传">
            <ImageUploader
              url={get(form.values, 'styles.backgroundImage')}
              onChange={({ url }) => {
                form.setValues({ 'styles.backgroundImage': url });
              }}
            />
          </Form.Item>
        </>
      )}
    </Observer>
  );
}
