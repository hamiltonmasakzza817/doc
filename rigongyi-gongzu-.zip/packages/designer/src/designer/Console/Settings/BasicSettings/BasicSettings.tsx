import { DeleteOutlined, QuestionCircleOutlined } from '@ant-design/icons';
import usePageCompTools from '@gongzu/core/common/usePageCompTools';
import {
  indeliblePageCompTypes,
  rootPageCompTypes,
} from '@gongzu/core/config/comps';
import language from '@gongzu/core/config/language';
import { EngineStoresContext } from '@gongzu/core/contexts/store-contexts';
import { allowCssInJs } from '@gongzu/core/utils/comp';
import { Form, Input, Modal, Tooltip } from 'antd';
import get from 'lodash-es/get';
import includes from 'lodash-es/includes';
import { observer } from 'mobx-react';
import React from 'react';
import ClickableText from '../../../../components/ClickableText';
import CodeEditorCard from '../../../components/CodeEditorCard';
import ExpressionInput from '../../../components/ExpressionInput/ExpressionInput';
import StyleGrid from '../../../components/StyleGrid';
import SettingsFormContext from '../context/SettingsFormContext';
import StylesSettings from './StylesSettings';

export default observer(() => {
  const form = React.useContext(SettingsFormContext);

  const pageCompTool = usePageCompTools();

  const {
    engineStore: {
      page: { platform },
    },
  } = React.useContext(EngineStoresContext);

  return (
    <>
      <Form.Item label="操作">
        <div className="flex items-center">
          {!includes(rootPageCompTypes, form.values.type) && (
            <>
              <ClickableText onClick={pageCompTool.copy} className="mr-1">
                复制
              </ClickableText>

              <ClickableText
                onClick={pageCompTool.cut}
                className="mr-1 text-warning"
              >
                剪切
              </ClickableText>
            </>
          )}

          <ClickableText
            onClick={pageCompTool.paste}
            className="mr-1 text-primary"
          >
            粘贴
          </ClickableText>

          {!includes(indeliblePageCompTypes, form.values.type) &&
            !form.values.indelible && (
              <ClickableText
                className="text-error mr-1"
                onClick={pageCompTool.delete}
              >
                删除
              </ClickableText>
            )}

          <ClickableText onClick={pageCompTool.model} className="text-primary">
            模型
          </ClickableText>
        </div>
      </Form.Item>

      <Form.Item label="组件名">
        <div>{get(language.compTypes, form.values.type)}</div>
      </Form.Item>

      <Form.Item label="别名">
        <Input {...form.bind('name', { onBlur: true })} />
      </Form.Item>

      <StylesSettings key={form.values.id} />

      <Form.Item
        label={
          <span>
            类名&nbsp;
            <Tooltip
              title={
                <div>
                  <div>
                    工具类css使用方法请参考{' '}
                    <a
                      href="https://tailwindcss.com/docs/padding"
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      tailwindcss
                    </a>
                  </div>

                  <div>
                    目前已支持模块： padding
                    <br />
                    margin
                    <br />
                    textAlign
                    <br />
                    textColor
                    <br />
                    backgroundColor
                    <br />
                    width
                    <br />
                    height
                    <br />
                    borderRadius
                    <br />
                    cursor
                    <br />
                    display
                    <br />
                    flex
                    <br />
                    flexWrap
                    <br />
                    flexDirection
                    <br />
                    justifyContent
                    <br />
                    justifyItems
                    <br />
                    justifySelf
                    <br />
                  </div>
                </div>
              }
            >
              <QuestionCircleOutlined />
            </Tooltip>
          </span>
        }
      >
        <ExpressionInput
          rows={2}
          {...form.bind('className', { onBlur: true })}
        />
      </Form.Item>

      {allowCssInJs(platform) ? (
        <>
          <Form.Item label="继承样式">
            <StyleGrid form={form} />
          </Form.Item>

          <Form.Item className="block">
            <CodeEditorCard
              title="自定义样式（css语法）"
              height={150}
              language="less"
              defaultValue={`& {
}`}
              extra={
                <ClickableText
                  className="ml-1 text-error"
                  onClick={() => {
                    Modal.confirm({
                      title: '提示',
                      content: '是否清空自定义样式？',
                      onOk: () => {
                        form.setValues({ css: undefined });
                      },
                    });
                  }}
                >
                  <DeleteOutlined />
                </ClickableText>
              }
              {...form.bind('css')}
            />
          </Form.Item>
        </>
      ) : (
        <>
          <Form.Item className="block">
            <CodeEditorCard
              title="自定义样式（style语法）"
              height={150}
              language="json"
              defaultValue="{}"
              extra={
                <ClickableText
                  className="ml-1 text-error"
                  onClick={() => {
                    Modal.confirm({
                      title: '提示',
                      content: '是否清空自定义样式？',
                      onOk: () => {
                        form.setValues({ style: undefined });
                      },
                    });
                  }}
                >
                  <DeleteOutlined />
                </ClickableText>
              }
              {...form.bind('style')}
            />
          </Form.Item>
        </>
      )}
    </>
  );
});
