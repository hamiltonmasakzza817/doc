import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { PageCompBlockConfig } from '@gongzu/core/types/comps-page';
import { Form } from 'antd';
import TextArea from 'antd/es/input/TextArea';
import { Observer } from 'mobx-react';
import React from 'react';
import SettingsFormContext from '../context/SettingsFormContext';

export default function PageCompBlockSettings() {
  const form = React.useContext(
    SettingsFormContext,
  ) as unknown as MobxFormStore<PageCompBlockConfig>;

  return (
    <Observer>
      {() => (
        <>
          <Form.Item label="HTML">
            <TextArea {...form.bind('rawHtml', { onBlur: true })} />
          </Form.Item>
        </>
      )}
    </Observer>
  );
}
