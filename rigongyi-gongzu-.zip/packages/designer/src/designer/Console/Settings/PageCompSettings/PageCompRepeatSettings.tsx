import { QuestionCircleOutlined } from '@ant-design/icons';
import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { PageCompRepeatConfig } from '@gongzu/core/types/comps-page';
import { Form, Tooltip } from 'antd';
import { Observer } from 'mobx-react';
import React from 'react';
import ExpressionInput from '../../../components/ExpressionInput';
import SettingsFormContext from '../context/SettingsFormContext';

export default function PageCompRepeatSettings() {
  const form = React.useContext(
    SettingsFormContext,
  ) as unknown as MobxFormStore<PageCompRepeatConfig>;

  return (
    <Observer>
      {() => (
        <>
          <Form.Item label="数据源">
            <ExpressionInput
              {...form.bind('dataSource', { onBlur: true })}
              asPathname
            />
          </Form.Item>

          <Form.Item
            label={
              <span>
                Key&nbsp;
                <Tooltip title="被循环项的唯一识别码，用于区别相邻元素。若不指定，则是循环下标，当元素变更时，有被React渲染优化的风险，导致错位">
                  <QuestionCircleOutlined />
                </Tooltip>
              </span>
            }
          >
            <ExpressionInput leafOnly {...form.bind('key', { onBlur: true })} />
          </Form.Item>
        </>
      )}
    </Observer>
  );
}
