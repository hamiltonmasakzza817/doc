import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { PageCompPageConfig } from '@gongzu/core/types/comps-page';
import { Form } from 'antd';
import { observer } from 'mobx-react';
import React from 'react';
import ExpressionInput from '../../../components/ExpressionInput';
import SettingsFormContext from '../context/SettingsFormContext';

export default observer(() => {
  const form = React.useContext(
    SettingsFormContext,
  ) as unknown as MobxFormStore<PageCompPageConfig>;

  return (
    <>
      <Form.Item label="文档标题">
        <ExpressionInput {...form.bind('documentTitle', { onBlur: true })} />
      </Form.Item>
      <Form.Item label="Loading">
        <ExpressionInput {...form.bind('loading', { onBlur: true })} />
      </Form.Item>
    </>
  );
});
