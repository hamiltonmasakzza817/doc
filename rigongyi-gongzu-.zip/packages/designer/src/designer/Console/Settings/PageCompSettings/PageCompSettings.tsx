import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { PageCompConfig, PageCompType } from '@gongzu/core/types/comps-page';
import { observer } from 'mobx-react';
import React from 'react';
import SettingsFormContext from '../context/SettingsFormContext';
import PageCompBlockSettings from './PageCompBlockSettings';
import PageCompHyperlinkSettings from './PageCompHyperlinkSettings';
import PageCompIframeSettings from './PageCompIframeSettings';
import PageCompPagePortalSettings from './PageCompPagePortalSettings';
import PageCompPageSettings from './PageCompPageSettings';
import PageCompRepeatSettings from './PageCompRepeatSettings';
import PageCompTextSettings from './PageCompTextSettings';
import PageCompUmdCompSettings from './PageCompUmdCompSettings';

function PageCompSettings() {
  const form = React.useContext(
    SettingsFormContext,
  ) as MobxFormStore<PageCompConfig>;

  switch (form.values.type) {
    case PageCompType.PAGE: {
      return <PageCompPageSettings />;
    }

    case PageCompType.TEXT: {
      return <PageCompTextSettings />;
    }

    case PageCompType.REPEAT: {
      return <PageCompRepeatSettings />;
    }

    case PageCompType.HYPERLINK: {
      return <PageCompHyperlinkSettings />;
    }

    case PageCompType.PAGE_PORTAL: {
      return <PageCompPagePortalSettings />;
    }

    case PageCompType.IFRAME: {
      return <PageCompIframeSettings />;
    }

    case PageCompType.BLOCK: {
      return <PageCompBlockSettings />;
    }

    case PageCompType.UMD_COMP: {
      return <PageCompUmdCompSettings />;
    }

    default: {
      return <></>;
    }
  }
}

export default observer(PageCompSettings);
