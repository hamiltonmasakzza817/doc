import { QuestionCircleOutlined } from '@ant-design/icons';
import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { PageCompPagePortalConfig } from '@gongzu/core/types/comps-page';
import { Form, Tooltip } from 'antd';
import { observer } from 'mobx-react';
import React from 'react';
import CodeEditorCard from '../../../components/CodeEditorCard';
import ExpressionInput from '../../../components/ExpressionInput';
import SettingsFormContext from '../context/SettingsFormContext';

export default observer(() => {
  const form = React.useContext(
    SettingsFormContext,
  ) as unknown as MobxFormStore<PageCompPagePortalConfig>;

  return (
    <>
      <Form.Item label="页面Id">
        <ExpressionInput leafOnly {...form.bind('pageId', { onBlur: true })} />
      </Form.Item>

      <Form.Item label="页面URL">
        <ExpressionInput leafOnly {...form.bind('pageUrl', { onBlur: true })} />
      </Form.Item>

      <Form.Item
        label={
          <span>
            Key&nbsp;
            <Tooltip title="页面唯一识别码，用于区别相同页面之间跳转，以期重新加载">
              <QuestionCircleOutlined />
            </Tooltip>
          </span>
        }
      >
        <ExpressionInput leafOnly {...form.bind('key', { onBlur: true })} />
      </Form.Item>

      <Form.Item className="block">
        <CodeEditorCard
          title="参数"
          language="json"
          height={150}
          {...form.bind('params')}
        />
      </Form.Item>
    </>
  );
});
