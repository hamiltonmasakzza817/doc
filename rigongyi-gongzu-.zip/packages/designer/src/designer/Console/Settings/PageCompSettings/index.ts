export { default } from './PageCompSettings';
