import language from '@gongzu/core/config/language';
import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { PageCompTextConfig } from '@gongzu/core/types/comps-page';
import { Form, Select } from 'antd';
import get from 'lodash-es/get';

import { observer } from 'mobx-react';
import React from 'react';
import ExpressionInput from '../../../components/ExpressionInput';
import SettingsFormContext from '../context/SettingsFormContext';

export default observer(() => {
  const form = React.useContext(
    SettingsFormContext,
  ) as unknown as MobxFormStore<PageCompTextConfig>;

  return (
    <>
      <Form.Item label="文字">
        <ExpressionInput {...form.bind('text', { onBlur: true })} />
      </Form.Item>

      <Form.Item label="样式类型">
        <Select allowClear {...form.bind('textType')}>
          {['primary', 'secondary', 'success', 'warning', 'danger'].map((t) => (
            <Select.Option value={t} key={t}>
              {get(language.textType, t)}
            </Select.Option>
          ))}
        </Select>
      </Form.Item>

      <Form.Item label="禁用">
        <ExpressionInput {...form.bind('disabled', { onBlur: true })} />
      </Form.Item>
    </>
  );
});
