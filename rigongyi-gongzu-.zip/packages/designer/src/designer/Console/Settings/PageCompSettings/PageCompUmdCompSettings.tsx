import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { PageCompUmdCompConfig } from '@gongzu/core/types/comps-page';
import { Form } from 'antd';
import { observer } from 'mobx-react';
import React from 'react';
import CodeEditorCard from '../../../components/CodeEditorCard';
import ExpressionInput from '../../../components/ExpressionInput';
import SettingsFormContext from '../context/SettingsFormContext';

export default observer(() => {
  const form = React.useContext(
    SettingsFormContext,
  ) as MobxFormStore<PageCompUmdCompConfig>;

  return (
    <>
      <Form.Item label="URL">
        <ExpressionInput {...form.bind('url', { onBlur: true })} />
      </Form.Item>

      <Form.Item label="模块名">
        <ExpressionInput {...form.bind('moduleName', { onBlur: true })} />
      </Form.Item>

      <Form.Item label="属性名">
        <ExpressionInput
          defaultValue="default"
          {...form.bind('memberName', { onBlur: true })}
        />
      </Form.Item>

      <Form.Item className="block">
        <CodeEditorCard
          title="参数"
          language="json"
          height={150}
          {...form.bind('params')}
        />
      </Form.Item>
    </>
  );
});
