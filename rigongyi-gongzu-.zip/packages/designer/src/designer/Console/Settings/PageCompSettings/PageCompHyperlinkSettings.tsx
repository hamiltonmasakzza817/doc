import { DeleteOutlined } from '@ant-design/icons';
import language from '@gongzu/core/config/language';
import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import {
  HyperlinkTarget,
  PageCompHyperlinkConfig,
} from '@gongzu/core/types/comps-page';
import { Form, Modal, Select } from 'antd';

import { Observer } from 'mobx-react';
import React from 'react';
import ClickableText from '../../../../components/ClickableText';
import CodeEditorCard from '../../../components/CodeEditorCard';
import ExpressionInput from '../../../components/ExpressionInput/ExpressionInput';
import SettingsFormContext from '../context/SettingsFormContext';

export default function PageCompHyperlinkSettings() {
  const form = React.useContext(
    SettingsFormContext,
  ) as unknown as MobxFormStore<PageCompHyperlinkConfig>;

  return (
    <Observer>
      {() => (
        <>
          <Form.Item label="显示文字">
            <ExpressionInput {...form.bind('text', { onBlur: true })} />
          </Form.Item>

          <Form.Item label="URL">
            <ExpressionInput {...form.bind('url', { onBlur: true })} />
          </Form.Item>

          <Form.Item label="使用PushState">
            <ExpressionInput
              leafOnly
              {...form.bind('usePushState', { onBlur: true })}
            />
          </Form.Item>

          <Form.Item label="目标">
            <Select allowClear {...form.bind('target')}>
              {[HyperlinkTarget.BLANK, HyperlinkTarget.DOWNLOAD].map((t) => (
                <Select.Option key={t} value={t}>
                  {language.hyperlinkTarget[t]}
                </Select.Option>
              ))}
            </Select>
          </Form.Item>

          <Form.Item className="block">
            <CodeEditorCard
              title="覆盖属性"
              language="json"
              height={150}
              extra={
                <ClickableText
                  onClick={() => {
                    Modal.confirm({
                      title: '删除提示',
                      content: '是否删除参数',
                      onOk: () => {
                        form.setValues({
                          params: undefined,
                        });
                      },
                    });
                  }}
                >
                  <DeleteOutlined className="ml-1 text-error" />
                </ClickableText>
              }
              {...form.bind('params')}
            />
          </Form.Item>
        </>
      )}
    </Observer>
  );
}
