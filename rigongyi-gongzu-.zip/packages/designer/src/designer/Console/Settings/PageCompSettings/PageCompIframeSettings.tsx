import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { PageCompTextConfig } from '@gongzu/core/types/comps-page';
import { Form } from 'antd';

import { observer, Observer } from 'mobx-react';
import React from 'react';
import ExpressionInput from '../../../components/ExpressionInput';
import SettingsFormContext from '../context/SettingsFormContext';

export default observer(() => {
  const form = React.useContext(
    SettingsFormContext,
  ) as unknown as MobxFormStore<PageCompTextConfig>;

  return (
    <Observer>
      {() => (
        <>
          <Form.Item label="网页地址">
            <ExpressionInput {...form.bind('src', { onBlur: true })} />
          </Form.Item>
        </>
      )}
    </Observer>
  );
});
