import { DeleteOutlined } from '@ant-design/icons';
import Central from '@gongzu/core/common/Central';
import { gzdnBem } from '@gongzu/core/config/constants';
import { DesignerStoreContext } from '@gongzu/core/contexts/store-contexts';
import useFormMobx from '@gongzu/core/mobx-form/useFormMobx';
import { CompConfig } from '@gongzu/core/types/comps-common';
import { PageCompType } from '@gongzu/core/types/comps-page';
import {
  isDesktopComp,
  isMobileComp,
  isPageComp,
  isTaroComp,
} from '@gongzu/core/utils/comp';
import { Form, Modal, Radio } from 'antd';
import classNames from 'classnames';
import entries from 'lodash-es/entries';
import get from 'lodash-es/get';
import { observer } from 'mobx-react';
import React from 'react';
import ClickableText from '../../../components/ClickableText';
import CodeEditorCard from '../../components/CodeEditorCard';
import ExpressionInput from '../../components/ExpressionInput';
import ActionSettings from './ActionSettings';
import BasicSettings from './BasicSettings';
import SettingsFormContext from './context/SettingsFormContext';
import DesktopCompSettings from './DesktopCompSettings';
import MobileCompSettings from './MobileCompSettings';
import PageCompSettings from './PageCompSettings';
import TaroCompSettings from './TaroCompSettings';

const settingsBem = gzdnBem('settings');

export default observer(() => {
  const designerStore = React.useContext(DesignerStoreContext);

  const { focusing } = designerStore;

  const form = useFormMobx<CompConfig>({
    name: 'pageCompSettings',
    defaultValues: {
      id: '',
      type: PageCompType.PAGE,
    },
    setValues: (values) => {
      if (
        entries(values).some(
          ([key, value]) => get(designerStore.focusing, key) !== value,
        )
      ) {
        designerStore.updateConfig({
          config: designerStore.focusing,
          values,
        });
      }
    },
  });

  React.useEffect(() => {
    if (focusing) {
      form.reset(focusing);
    }
  }, [focusing]);

  const [tab, setTab] = React.useState('style');

  const compType = form.values.type;

  if (focusing) {
    return (
      <div className={settingsBem('container')}>
        <SettingsFormContext.Provider value={form}>
          <Form>
            <div className="p-2">
              <div className={classNames('mb-2', settingsBem('form'))}>
                <Radio.Group
                  options={[
                    { label: '基础', value: 'style' },
                    { label: '组件&数据', value: 'data' },
                    { label: '交互', value: 'event' },
                  ]}
                  optionType="button"
                  buttonStyle="solid"
                  value={tab}
                  onChange={(e) => {
                    setTab(e.target.value);
                  }}
                />
              </div>

              {tab === 'style' && <BasicSettings />}

              {tab === 'data' && (
                <>
                  <Form.Item className="block">
                    <CodeEditorCard
                      title="覆盖属性"
                      language="json"
                      height={150}
                      extra={
                        <ClickableText
                          onClick={() => {
                            Modal.confirm({
                              title: '删除提示',
                              content: '是否删除覆盖属性',
                              onOk: () => {
                                form.setValues({
                                  rawProps: undefined,
                                });
                              },
                            });
                          }}
                        >
                          <DeleteOutlined className="ml-1 text-error" />
                        </ClickableText>
                      }
                      {...form.bind('rawProps')}
                    />
                  </Form.Item>

                  <Form.Item label="条件显示">
                    <ExpressionInput
                      leafOnly
                      {...form.bind('display', {
                        onBlur: true,
                      })}
                    />
                  </Form.Item>

                  {isPageComp(compType) && <PageCompSettings />}

                  {isDesktopComp(compType) && <DesktopCompSettings />}

                  {isMobileComp(compType) && <MobileCompSettings />}

                  {isTaroComp(compType) && <TaroCompSettings />}
                </>
              )}

              {tab === 'event' && <ActionSettings />}
            </div>
          </Form>
        </SettingsFormContext.Provider>
      </div>
    );
  }

  return (
    <Central>
      <div>未选择</div>
    </Central>
  );
});
