import { formItemCompTypes } from '@gongzu/core/config/comps';
import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import {
  MobileCompConfig,
  MobileCompType,
} from '@gongzu/core/types/comps-mobile';
import { Form, Radio } from 'antd';
import { observer } from 'mobx-react';
import React from 'react';
import ExpressionInput from '../../../components/ExpressionInput/ExpressionInput';
import SettingsFormContext from '../context/SettingsFormContext';
import MobileCompButtonSettings from './MobileCompButtonSettings';
import MobileCompCapsuleTabsSettings from './MobileCompCapsuleTabsSettings';
import MobileCompContainerSettings from './MobileCompContainerSettings';
import MobileCompFormItemSettings from './MobileCompFormItemSettings';
import MobileCompFormSettings from './MobileCompFormSettings';
import MobileCompImageSettings from './MobileCompImageSettings';
import MobileCompInfiniteScroll from './MobileCompInfiniteScrollSettings';
import MobileCompListItemSettings from './MobileCompListItemSettings';
import MobileCompListSettings from './MobileCompListSettings';
import MobileCompModalSettings from './MobileCompModalSettings';
import MobileCompSearchBarSettings from './MobileCompSearchBarSettings';
import MobileCompSwiperSettings from './MobileCompSwiperSettings';
import MobileCompTabPanelSettings from './MobileCompTabPanelSettings';
import MobileCompTabsSettings from './MobileCompTabsSettings';
import MobileCompTagSettings from './MobileCompTagSettings';

export default observer(() => {
  const form = React.useContext(
    SettingsFormContext,
  ) as MobxFormStore<MobileCompConfig>;

  if (
    formItemCompTypes.includes(form.values.type) ||
    form.values.type === MobileCompType.FORM
  ) {
    return (
      <>
        <Form.Item label="值绑定地址">
          <ExpressionInput
            {...form.bind('value', { onBlur: true })}
            asPathname
          />
        </Form.Item>

        <Form.Item label="布局">
          <Radio.Group
            {...form.bind('layout')}
            optionType="button"
            buttonStyle="solid"
            defaultValue="vertical"
            options={[
              { label: '垂直', value: 'vertical' },
              { label: '水平', value: 'horizontal' },
              { label: '继承', value: 'none' },
            ]}
          />
        </Form.Item>

        {formItemCompTypes.includes(form.values.type) ? (
          <MobileCompFormItemSettings />
        ) : (
          <MobileCompFormSettings />
        )}
      </>
    );
  }

  switch (form.values.type) {
    case MobileCompType.BUTTON: {
      return <MobileCompButtonSettings />;
    }

    case MobileCompType.CONTAINER: {
      return <MobileCompContainerSettings />;
    }

    case MobileCompType.CAPSULE_TABS: {
      return <MobileCompCapsuleTabsSettings />;
    }

    case MobileCompType.TAG: {
      return <MobileCompTagSettings />;
    }

    case MobileCompType.SEARCH_BAR: {
      return <MobileCompSearchBarSettings />;
    }

    case MobileCompType.LIST: {
      return <MobileCompListSettings />;
    }

    case MobileCompType.MODAL: {
      return <MobileCompModalSettings />;
    }

    case MobileCompType.SWIPER: {
      return <MobileCompSwiperSettings />;
    }

    case MobileCompType.IMAGE: {
      return <MobileCompImageSettings />;
    }

    case MobileCompType.TABS: {
      return <MobileCompTabsSettings />;
    }

    case MobileCompType.TAB_PANEL: {
      return <MobileCompTabPanelSettings />;
    }

    case MobileCompType.LIST_ITEM: {
      return <MobileCompListItemSettings />;
    }

    case MobileCompType.INFINITE_SCROLL: {
      return <MobileCompInfiniteScroll />;
    }

    default: {
      return <></>;
    }
  }
});
