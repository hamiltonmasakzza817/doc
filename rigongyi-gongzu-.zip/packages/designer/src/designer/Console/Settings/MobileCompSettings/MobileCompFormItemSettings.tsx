import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import {
  MobileCompConfig,
  MobileCompFormItem,
  MobileCompType,
} from '@gongzu/core/types/comps-mobile';
import { Form } from 'antd';
import { Observer, observer } from 'mobx-react';
import React from 'react';
import ExpressionInput from '../../../components/ExpressionInput';
import CompUploaderSettings from '../common/CompUploaderSettings';
import FormItemSettings from '../common/FormItemSettings';
import { SectionHeading } from '../common/SectionHeading';
import SettingsFormContext from '../context/SettingsFormContext';
import MobileCompCheckboxSettings from './MobileCompCheckboxSettings';
import MobileCompDatePickerSettings from './MobileCompDatePickerSettings';
import MobileCompFormSettings from './MobileCompFormSettings';
import MobileCompInputSettings from './MobileCompInputSettings';
import MobileCompListItemSettings from './MobileCompListItemSettings';
import MobileCompNumberInputSettings from './MobileCompNumberInputSettings';
import MobileCompSwitchSettings from './MobileCompSwitchSettings';
import MobileCompTextAreaSettings from './MobileCompTextAreaSettings';

export default observer(() => {
  const form = React.useContext(
    SettingsFormContext,
  ) as unknown as MobxFormStore<MobileCompConfig & MobileCompFormItem>;

  return (
    <>
      <FormItemSettings />

      <Observer>
        {() => {
          switch (form.values.type) {
            case MobileCompType.INPUT: {
              return <MobileCompInputSettings />;
            }

            case MobileCompType.DATE_PICKER: {
              return <MobileCompDatePickerSettings />;
            }

            case MobileCompType.SWITCH: {
              return <MobileCompSwitchSettings />;
            }

            case MobileCompType.NUMBER_INPUT: {
              return <MobileCompNumberInputSettings />;
            }

            case MobileCompType.TEXT_AREA: {
              return <MobileCompTextAreaSettings />;
            }

            case MobileCompType.UPLOADER: {
              return <CompUploaderSettings />;
            }

            case MobileCompType.LIST_ITEM: {
              return <MobileCompListItemSettings />;
            }

            case MobileCompType.CHECKBOX:
            case MobileCompType.RADIO: {
              return <MobileCompCheckboxSettings />;
            }

            case MobileCompType.FORM: {
              return <MobileCompFormSettings />;
            }

            default: {
              return <></>;
            }
          }
        }}
      </Observer>

      {[
        MobileCompType.SELECT,
        MobileCompType.CHECKBOX,
        MobileCompType.RADIO,
      ].includes(form.values.type) && (
        <>
          <SectionHeading caption="备选项" />

          <Form.Item label="数据源">
            <ExpressionInput
              asPathname
              nonLeafOnly
              {...form.bind('options.dataSource', { onBlur: true })}
            />
          </Form.Item>

          <Form.Item label="标题">
            <ExpressionInput {...form.bind('options.name', { onBlur: true })} />
          </Form.Item>

          <Form.Item label="值">
            <ExpressionInput
              {...form.bind('options.value', { onBlur: true })}
            />
          </Form.Item>
        </>
      )}
    </>
  );
});
