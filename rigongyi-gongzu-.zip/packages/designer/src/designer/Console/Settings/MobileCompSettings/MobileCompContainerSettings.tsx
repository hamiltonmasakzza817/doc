import { QuestionCircleOutlined } from '@ant-design/icons';
import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { MobileCompContainerConfig } from '@gongzu/core/types/comps-mobile';
import { Form, Input, Select, Tooltip } from 'antd';
import { observer } from 'mobx-react';
import React from 'react';
import ExpressionInput from '../../../components/ExpressionInput';
import CustomComponentSelect from '../../components/CustomCompSelect';
import SettingsFormContext from '../context/SettingsFormContext';

export default observer(() => {
  const form = React.useContext(
    SettingsFormContext,
  ) as unknown as MobxFormStore<MobileCompContainerConfig>;

  return (
    <>
      <Form.Item label="Loading">
        <ExpressionInput
          leafOnly
          {...form.bind('loading', {
            onBlur: true,
          })}
        />
      </Form.Item>

      <Form.Item
        label={
          <span>
            代码&nbsp;
            <Tooltip title="用于多标签页索引">
              <QuestionCircleOutlined />
            </Tooltip>
          </span>
        }
      >
        <Input {...form.bind('code', { onBlur: true })} />
      </Form.Item>

      <Form.Item label="自定义组件">
        <CustomComponentSelect {...form.bind('renderCompId')} showEmpty />
      </Form.Item>

      <Form.Item label="弹出组件">
        <CustomComponentSelect {...form.bind('popoverCompId')} showEmpty />
      </Form.Item>

      {form.values.popoverCompId != null && (
        <Form.Item label="弹出位置">
          <Select
            {...form.bind('placement')}
            options={[
              'left',
              'right',
              'top',
              'bottom',
              'topLeft',
              'topRight',
              'bottomLeft',
              'bottomRight',
            ].map((i) => ({ label: i, value: i }))}
          />
        </Form.Item>
      )}

      <Form.Item
        label={
          <span>
            延展至底部
            <Tooltip title="填写距离视口底部的距离，会使容器获得动态的高度">
              <QuestionCircleOutlined />
            </Tooltip>
          </span>
        }
      >
        <ExpressionInput {...form.bind('flexBottom', { onBlur: true })} />
      </Form.Item>
    </>
  );
});
