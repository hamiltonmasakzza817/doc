import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { MobileCompInfiniteScrollConfig } from '@gongzu/core/types/comps-mobile';
import { Form, InputNumber } from 'antd';
import { observer } from 'mobx-react';
import React from 'react';
import ExpressionInput from '../../../components/ExpressionInput';
import SettingsFormContext from '../context/SettingsFormContext';

export default observer(() => {
  const form = React.useContext(
    SettingsFormContext,
  ) as unknown as MobxFormStore<MobileCompInfiniteScrollConfig>;

  return (
    <>
      <Form.Item label="还有更多">
        <ExpressionInput {...form.bind('hasMore')} />
      </Form.Item>

      <Form.Item label="触底阈值">
        <InputNumber
          defaultValue={250}
          precision={0}
          min={0}
          {...form.bind('threshold')}
        />
      </Form.Item>
    </>
  );
});
