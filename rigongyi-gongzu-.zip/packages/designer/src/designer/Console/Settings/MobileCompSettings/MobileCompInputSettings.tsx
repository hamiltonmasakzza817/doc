import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { MobileCompInputConfig } from '@gongzu/core/types/comps-mobile';
import { Form, Select } from 'antd';
import { observer } from 'mobx-react';
import React from 'react';
import ExpressionInput from '../../../components/ExpressionInput';
import SettingsFormContext from '../context/SettingsFormContext';

export default observer(() => {
  const form = React.useContext(
    SettingsFormContext,
  ) as unknown as MobxFormStore<MobileCompInputConfig>;

  return (
    <>
      <Form.Item label="输入类型">
        <Select
          {...form.bind('inputType')}
          defaultValue="text"
          options={[
            { label: '文本', value: 'text' },
            { label: '银行卡', value: 'bankCard' },
            { label: '手机号', value: 'phone' },
            { label: '密码', value: 'password' },
            { label: '数字', value: 'number' },
            { label: 'digit', value: 'digit' },
            { label: '金额', value: 'money' },
          ]}
        />
      </Form.Item>

      <Form.Item label="后缀">
        <ExpressionInput {...form.bind('addonAfter', { onBlur: true })} />
      </Form.Item>
    </>
  );
});
