import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { MobileCompSwitchConfig } from '@gongzu/core/types/comps-mobile';
import { Form } from 'antd';
import { observer } from 'mobx-react';
import React from 'react';
import ExpressionInput from '../../../components/ExpressionInput';
import SettingsFormContext from '../context/SettingsFormContext';

export default observer(() => {
  const form = React.useContext(
    SettingsFormContext,
  ) as unknown as MobxFormStore<MobileCompSwitchConfig>;

  return (
    <>
      <Form.Item label="真值值">
        <ExpressionInput
          defaultValue={`$\{true}`}
          {...form.bind('checkedValue', { onBlur: true })}
        />
      </Form.Item>

      <Form.Item label="假值值">
        <ExpressionInput
          defaultValue={`$\{false}`}
          {...form.bind('uncheckedValue', { onBlur: true })}
        />
      </Form.Item>

      <Form.Item label="真值文字">
        <ExpressionInput {...form.bind('checkedText', { onBlur: true })} />
      </Form.Item>

      <Form.Item label="假值文字">
        <ExpressionInput {...form.bind('uncheckedValue', { onBlur: true })} />
      </Form.Item>
    </>
  );
});
