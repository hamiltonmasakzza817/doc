import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { MobileCompSegmentConfig } from '@gongzu/core/types/comps-mobile';
import { Form } from 'antd';
import { observer } from 'mobx-react';
import React from 'react';
import ExpressionInput from '../../../components/ExpressionInput';
import { SectionHeading } from '../common/SectionHeading';
import SettingsFormContext from '../context/SettingsFormContext';

export default observer(() => {
  const form = React.useContext(
    SettingsFormContext,
  ) as MobxFormStore<MobileCompSegmentConfig>;

  return (
    <>
      <Form.Item label="选中值">
        <ExpressionInput {...form.bind('activeKey')} />
      </Form.Item>

      <SectionHeading caption="备选项" />

      <Form.Item label="数据源">
        <ExpressionInput
          asPathname
          nonLeafOnly
          {...form.bind('options.dataSource', { onBlur: true })}
        />
      </Form.Item>

      <Form.Item label="标题">
        <ExpressionInput {...form.bind('options.label', { onBlur: true })} />
      </Form.Item>

      <Form.Item label="值">
        <ExpressionInput {...form.bind('options.value', { onBlur: true })} />
      </Form.Item>

      <Form.Item label="禁用">
        <ExpressionInput {...form.bind('options.disabled', { onBlur: true })} />
      </Form.Item>
    </>
  );
});
