import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { MobileCompSwiperConfig } from '@gongzu/core/types/comps-mobile';
import { Form, InputNumber, Radio, Switch } from 'antd';
import { observer } from 'mobx-react';
import React from 'react';
import ExpressionInput from '../../../components/ExpressionInput';
import CustomCompSelect from '../../components/CustomCompSelect';
import { SectionHeading } from '../common/SectionHeading';
import SettingsFormContext from '../context/SettingsFormContext';

export default observer(() => {
  const form = React.useContext(
    SettingsFormContext,
  ) as unknown as MobxFormStore<MobileCompSwiperConfig>;

  const key = form.values.id;

  return (
    <>
      <Form.Item label="自动播放">
        <Switch
          key={key}
          {...form.bind('autoplay')}
          checked={Boolean(form.values.autoplay)}
        />
      </Form.Item>

      <Form.Item label="播放间隔">
        <InputNumber
          key={key}
          {...form.bind('autoplayInterval')}
          defaultValue={3000}
        />
      </Form.Item>

      <Form.Item label="方向">
        <Radio.Group
          optionType="button"
          buttonStyle="solid"
          {...form.bind('direction')}
          key={key}
          defaultValue="horizontal"
          options={[
            { label: '水平', value: 'horizontal' },
            { label: '垂直', value: 'vertical' },
          ]}
        />
      </Form.Item>

      <Form.Item label="无限滚动">
        <Switch {...form.bind('loop')} checked={form.values.loop} />
      </Form.Item>

      <Form.Item label="宽度百分比">
        <InputNumber
          {...form.bind('slideWidth')}
          min={0}
          max={100}
          step={10}
          precision={0}
          defaultValue={100}
          key={key}
        />
      </Form.Item>

      <SectionHeading caption="元素配置" />

      <Form.Item label="数据源">
        <ExpressionInput
          asPathname
          {...form.bind('items.dataSource', { onBlur: true })}
        />
      </Form.Item>

      <Form.Item label="图片URL">
        <ExpressionInput
          asPathname
          {...form.bind('items.imageUrl', { onBlur: true })}
        />
      </Form.Item>

      <Form.Item label="自定义">
        <CustomCompSelect {...form.bind('items.element')} />
      </Form.Item>
    </>
  );
});
