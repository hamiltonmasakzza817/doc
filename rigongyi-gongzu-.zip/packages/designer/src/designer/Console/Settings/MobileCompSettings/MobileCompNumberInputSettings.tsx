import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { MobileCompInputConfig } from '@gongzu/core/types/comps-mobile';
import { Form, InputNumber } from 'antd';
import { observer } from 'mobx-react';
import React from 'react';
import SettingsFormContext from '../context/SettingsFormContext';

export default observer(() => {
  const form = React.useContext(
    SettingsFormContext,
  ) as unknown as MobxFormStore<MobileCompInputConfig>;

  return (
    <>
      <Form.Item label="最小值">
        <InputNumber {...form.bind('min')} />
      </Form.Item>

      <Form.Item label="最大值">
        <InputNumber {...form.bind('max')} />
      </Form.Item>

      <Form.Item label="步长">
        <InputNumber precision={0} min={0} {...form.bind('step')} />
      </Form.Item>

      <Form.Item label="小数位数">
        <InputNumber precision={0} min={0} {...form.bind('digits')} />
      </Form.Item>
    </>
  );
});
