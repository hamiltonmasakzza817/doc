import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { MobileCompDatePickerConfig } from '@gongzu/core/types/comps-mobile';
import { Form, Select } from 'antd';
import { observer } from 'mobx-react';
import React from 'react';
import ExpressionInput from '../../../components/ExpressionInput';
import SettingsFormContext from '../context/SettingsFormContext';

export default observer(() => {
  const form = React.useContext(
    SettingsFormContext,
  ) as unknown as MobxFormStore<MobileCompDatePickerConfig>;

  const key = form.values.id;

  return (
    <>
      <Form.Item label="精度">
        <Select
          key={key}
          defaultValue="day"
          options={[
            { value: 'year', label: '年份' },
            { value: 'month', label: '月份' },
            { value: 'day', label: '日期' },
            { value: 'hour', label: '小时' },
            { value: 'minute', label: '分钟' },
            { value: 'second', label: '秒' },
            { value: 'week', label: '周' },
            { value: 'week-day', label: '周天' },
          ]}
          {...form.bind('precision')}
        />
      </Form.Item>

      <Form.Item label="最小值">
        <ExpressionInput {...form.bind('min', { onBlur: true })} />
      </Form.Item>

      <Form.Item label="最大值">
        <ExpressionInput {...form.bind('max', { onBlur: true })} />
      </Form.Item>

      <Form.Item label="格式化">
        <ExpressionInput {...form.bind('format', { onBlur: true })} />
      </Form.Item>
    </>
  );
});
