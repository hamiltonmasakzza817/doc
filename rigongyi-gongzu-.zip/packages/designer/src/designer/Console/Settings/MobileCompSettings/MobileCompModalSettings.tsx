import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { MobileCompModalConfig } from '@gongzu/core/types/comps-mobile';
import { Form, Radio, Switch } from 'antd';
import { observer } from 'mobx-react';
import React from 'react';
import ExpressionInput from '../../../components/ExpressionInput';
import SettingsFormContext from '../context/SettingsFormContext';

export default observer(() => {
  const form = React.useContext(
    SettingsFormContext,
  ) as MobxFormStore<MobileCompModalConfig>;

  return (
    <>
      <Form.Item label="对话框类型">
        <Radio.Group
          optionType="button"
          buttonStyle="solid"
          defaultValue="dialog"
          options={[
            { label: '标准', value: 'dialog' },
            { label: '弹出层', value: 'popup' },
          ]}
          {...form.bind('modalType')}
        />
      </Form.Item>

      <Form.Item label="蒙层关闭">
        <Switch
          {...form.bind('closeOnMaskClick')}
          checked={Boolean(form.values.closeOnMaskClick)}
        />
      </Form.Item>

      {form.values.modalType === 'popup' && (
        <>
          <Form.Item label="弹出位置">
            <Radio.Group
              optionType="button"
              buttonStyle="solid"
              defaultValue="bottom"
              options={[
                { label: '底', value: 'bottom' },
                { label: '顶', value: 'top' },
                { label: '左', value: 'left' },
                { label: '右', value: 'right' }
              ]}
              {...form.bind('position')}
            />
          </Form.Item>
        </>
      )}

      {form.values.modalType !== 'popup' && (
        <>
          <Form.Item label="标题">
            <ExpressionInput {...form.bind('title')} />
          </Form.Item>

          <Form.Item label="隐藏Footer">
            <Switch checked={form.values.noFooter} {...form.bind('noFooter')} />
          </Form.Item>

          {!form.values.noFooter && (
            <>
              <Form.Item label="确定文本">
                <ExpressionInput {...form.bind('okText')} />
              </Form.Item>

              <Form.Item label="关闭文本">
                <ExpressionInput {...form.bind('cancelText')} />
              </Form.Item>
            </>
          )}
        </>
      )}
    </>
  );
});
