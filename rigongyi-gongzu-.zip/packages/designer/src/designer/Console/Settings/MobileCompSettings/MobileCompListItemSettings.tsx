import MobxFormStore from '@gongzu/core/src/mobx-form/MobxFormStore';
import { MobileCompListItemConfig } from '@gongzu/core/src/types/comps-mobile';
import { Form, Switch } from 'antd';
import { observer } from 'mobx-react';
import React from 'react';
import ExpressionInput from '../../../components/ExpressionInput';
import CustomCompSelect from '../../components/CustomCompSelect';
import SettingsFormContext from '../context/SettingsFormContext';

export default observer(() => {
  const form = React.useContext(
    SettingsFormContext,
  ) as unknown as MobxFormStore<MobileCompListItemConfig>;

  const key = form.values.id;

  return (
    <>
      <Form.Item label="标题">
        <ExpressionInput {...form.bind('title', { onBlur: true })} />
      </Form.Item>

      <Form.Item label="前缀文字">
        <ExpressionInput {...form.bind('prefixText', { onBlur: true })} />
      </Form.Item>

      <Form.Item label="前缀">
        <CustomCompSelect {...form.bind('prefix')} />
      </Form.Item>

      <Form.Item label="描述">
        <ExpressionInput {...form.bind('description', { onBlur: true })} />
      </Form.Item>

      <Form.Item label="后缀文字">
        <ExpressionInput {...form.bind('extra', { onBlur: true })} />
      </Form.Item>

      <Form.Item label="箭头">
        <Switch
          {...form.bind('arrow')}
          key={key}
          checked={form.values.arrow}
          defaultChecked
        />
      </Form.Item>
    </>
  );
});
