import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { MobileCompImageConfig } from '@gongzu/core/types/comps-mobile';
import { Form, Select, Switch } from 'antd';
import { observer } from 'mobx-react';
import React from 'react';
import ExpressionInput from '../../../components/ExpressionInput';
import ImageUploader from '../../../components/ImageUploader';
import CustomCompSelect from '../../components/CustomCompSelect';
import SettingsFormContext from '../context/SettingsFormContext';

export default observer(() => {
  const form = React.useContext(
    SettingsFormContext,
  ) as MobxFormStore<MobileCompImageConfig>;

  const key = form.values.id;

  return (
    <>
      <Form.Item label="URL">
        <ExpressionInput {...form.bind('src', { onBlur: true })} leafOnly />
      </Form.Item>

      <Form.Item label="图片上传">
        <ImageUploader
          url={form.values.src}
          onChange={({ url }) => {
            form.setValues({ src: url });
          }}
        />
      </Form.Item>

      <Form.Item label="代替文字">
        <ExpressionInput {...form.bind('alt', { onBlur: true })} leafOnly />
      </Form.Item>

      <Form.Item label="填充模式">
        <Select
          key={key}
          {...form.bind('fit')}
          defaultValue="fill"
          options={[
            { label: '拉伸', value: 'fill' },
            { label: '内裁切', value: 'contain' },
            { label: '外裁切', value: 'cover' },
            { label: '原始尺寸', value: 'none' },
            { label: 'scale-down', value: 'scale-down' },
          ]}
        />
      </Form.Item>

      <Form.Item label="加载占位">
        <CustomCompSelect {...form.bind('placeholder')} />
      </Form.Item>

      <Form.Item label="失败占位">
        <CustomCompSelect {...form.bind('fallback')} />
      </Form.Item>

      <Form.Item label="懒加载">
        <Switch {...form.bind('lazy')} checked={form.values.lazy} />
      </Form.Item>
    </>
  );
});
