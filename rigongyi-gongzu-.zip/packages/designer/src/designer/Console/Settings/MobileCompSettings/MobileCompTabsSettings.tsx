import { PlusCircleOutlined } from '@ant-design/icons';
import { gzdnBem } from '@gongzu/core/config/constants';
import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import {
  MobileCompTabPanelConfig,
  MobileCompTabsConfig,
  MobileCompType,
} from '@gongzu/core/types/comps-mobile';
import { Form, Radio, Switch } from 'antd';
import size from 'lodash-es/size';
import { observer } from 'mobx-react';
import React from 'react';
import { v4 as uuidv4 } from 'uuid';
import ClickableText from '../../../../components/ClickableText';
import ExpressionInput from '../../../components/ExpressionInput';
import SettingsFormContext from '../context/SettingsFormContext';

export default observer(() => {
  const form = React.useContext(
    SettingsFormContext,
  ) as MobxFormStore<MobileCompTabsConfig>;

  const key = form.values.id;

  return (
    <>
      <Form.Item label="当前页">
        <ExpressionInput {...form.bind('activeKey', { onBlur: true })} />
      </Form.Item>

      <Form.Item label="下划线模式">
        <Radio.Group
          key={key}
          optionType="button"
          buttonStyle="solid"
          {...form.bind('activeLineMode')}
          defaultValue="auto"
          options={[
            { label: '自动', value: 'auto' },
            { label: '占满', value: 'full' },
            { label: '固定', value: 'fixed' },
          ]}
        />
      </Form.Item>

      <Form.Item label="选项卡拉伸">
        <Switch
          {...form.bind('stretch')}
          checked={form.values.stretch}
          key={key}
          defaultChecked
        />
      </Form.Item>

      <Form.Item label="增加页签">
        <ClickableText
          onClick={() => {
            const id = uuidv4();

            const seq = size(form.values.children) + 1;

            form.setValues({
              children: [
                ...(form.values.children ?? []),
                {
                  id,
                  pathname: `${form.values.pathname},${id}`,
                  parentId: `${form.values.id}`,
                  type: MobileCompType.TAB_PANEL,
                  title: `标签${seq}`,
                  code: `tab${seq}`,
                } as MobileCompTabPanelConfig,
              ],
            });
          }}
          className={gzdnBem('clickable-icon')}
        >
          <PlusCircleOutlined />
        </ClickableText>
      </Form.Item>
    </>
  );
});
