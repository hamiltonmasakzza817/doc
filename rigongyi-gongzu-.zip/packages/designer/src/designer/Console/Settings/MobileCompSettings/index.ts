export { default } from './MobileCompSettings';
