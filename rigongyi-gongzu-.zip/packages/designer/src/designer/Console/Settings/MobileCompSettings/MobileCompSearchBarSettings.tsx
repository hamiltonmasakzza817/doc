import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { MobileCompSearchBarConfig } from '@gongzu/core/types/comps-mobile';
import { Form, Input, InputNumber, Switch } from 'antd';
import { observer } from 'mobx-react';
import React from 'react';
import ExpressionInput from '../../../components/ExpressionInput';
import SettingsFormContext from '../context/SettingsFormContext';

export default observer(() => {
  const form = React.useContext(
    SettingsFormContext,
  ) as MobxFormStore<MobileCompSearchBarConfig>;

  const key = form.values.id;

  return (
    <>
      <Form.Item label="绑定地址">
        <ExpressionInput {...form.bind('value', { onBlur: true })} />
      </Form.Item>

      <Form.Item label="占位符">
        <ExpressionInput {...form.bind('placeholder', { onBlur: true })} />
      </Form.Item>

      <Form.Item label="取消按钮">
        <Switch
          {...form.bind('showCancelButton')}
          checked={form.values.showCancelButton}
        />
      </Form.Item>

      {form.values.showCancelButton && (
        <Form.Item label="取消文字">
          <Input
            key={key}
            {...form.bind('cancelText', { onBlur: true })}
            defaultValue="取消"
          />
        </Form.Item>
      )}

      <Form.Item label="最大长度">
        <InputNumber {...form.bind('maxLength')} />
      </Form.Item>
    </>
  );
});
