import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { MobileCompButtonConfig } from '@gongzu/core/types/comps-mobile';
import { Form, Radio, Select, Switch } from 'antd';
import { observer } from 'mobx-react';
import React from 'react';
import ExpressionInput from '../../../components/ExpressionInput';
import SettingsFormContext from '../context/SettingsFormContext';

export default observer(() => {
  const form = React.useContext(
    SettingsFormContext,
  ) as unknown as MobxFormStore<MobileCompButtonConfig>;

  const { id } = form.values;

  return (
    <>
      <Form.Item label="尺寸">
        <Radio.Group
          key={id}
          {...form.bind('size')}
          defaultValue="middle"
          optionType="button"
          buttonStyle="solid"
          options={[
            { value: 'mini', label: '迷你' },
            { value: 'small', label: '小' },
            { value: 'middle', label: '默认' },
            { value: 'large', label: '大' },
          ]}
        />
      </Form.Item>

      <Form.Item label="文本">
        <ExpressionInput {...form.bind('text', { onBlur: true })} />
      </Form.Item>

      <Form.Item label="按钮颜色">
        <Select
          key={id}
          {...form.bind('color')}
          defaultValue="primary"
          options={[
            { label: '默认', value: 'default' },
            { label: '主色', value: 'primary' },
            { label: '成功', value: 'success' },
            { label: '警告', value: 'warning' },
            { label: '危险', value: 'danger' },
          ]}
        />
      </Form.Item>

      <Form.Item label="填充模式">
        <Radio.Group
          key={id}
          defaultValue="solid"
          optionType="button"
          buttonStyle="solid"
          {...form.bind('fill')}
          options={[
            { label: '实色', value: 'solid' },
            { label: '大纲', value: 'outline' },
            { label: '无', value: 'none' },
          ]}
        />
      </Form.Item>
      <Form.Item label="占满整行">
        <Switch {...form.bind('block')} checked={form.values.block} />
      </Form.Item>
      <Form.Item label="禁用">
        <ExpressionInput {...form.bind('disabled', { onBlur: true })} />
      </Form.Item>
      <Form.Item label="Loading">
        <ExpressionInput {...form.bind('loading', { onBlur: true })} />
      </Form.Item>
      <Form.Item label="Loading文字">
        <ExpressionInput {...form.bind('loadingText', { onBlur: true })} />
      </Form.Item>
      <Form.Item label="形状">
        <Radio.Group
          key={id}
          defaultValue="default"
          optionType="button"
          buttonStyle="solid"
          {...form.bind('shape')}
          options={[
            { label: '默认', value: 'default' },
            { label: '圆角', value: 'rounded' },
            { label: '直角', value: 'rectangular' },
          ]}
        />
      </Form.Item>
    </>
  );
});
