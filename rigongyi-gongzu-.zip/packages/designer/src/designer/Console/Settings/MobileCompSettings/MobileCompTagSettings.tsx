import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { MobileCompTagConfig } from '@gongzu/core/types/comps-mobile';
import { Form, Radio, Select, Switch } from 'antd';
import { observer } from 'mobx-react';
import React from 'react';
import ExpressionInput from '../../../components/ExpressionInput';
import SettingsFormContext from '../context/SettingsFormContext';

export default observer(() => {
  const form = React.useContext(
    SettingsFormContext,
  ) as unknown as MobxFormStore<MobileCompTagConfig>;

  const key = form.values.id;

  return (
    <>
      <Form.Item label="颜色">
        <Select
          key={key}
          {...form.bind('color')}
          defaultValue="default"
          options={[
            { value: 'default', label: '默认' },
            { value: 'primary', label: '主色' },
            { value: 'success', label: '成功' },
            { value: 'warning', label: '警告' },
            { value: 'danger', label: '危险' },
            { value: 'custom', label: '自定义' },
          ]}
        />
      </Form.Item>

      {form.values.color === 'custom' && (
        <Form.Item label="自定义颜色">
          <ExpressionInput {...form.bind('customColor', { onBlur: true })} />
        </Form.Item>
      )}

      <Form.Item label="填充模式">
        <Radio.Group
          key={key}
          {...form.bind('fill')}
          optionType="button"
          buttonStyle="solid"
          defaultValue="solid"
          options={[
            { value: 'solid', label: '实体' },
            { value: 'outline', label: '大纲' },
          ]}
        />
      </Form.Item>

      <Form.Item label="圆角">
        <Switch {...form.bind('round')} checked={form.values.round} />
      </Form.Item>

      <Form.Item label="文字">
        <ExpressionInput {...form.bind('text', { onBlur: true })} />
      </Form.Item>
    </>
  );
});
