import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { MobileCompTextAreaConfig } from '@gongzu/core/types/comps-mobile';
import { Form, InputNumber, Switch } from 'antd';
import { observer } from 'mobx-react';
import React from 'react';
import SettingsFormContext from '../context/SettingsFormContext';

export default observer(() => {
  const form = React.useContext(
    SettingsFormContext,
  ) as unknown as MobxFormStore<MobileCompTextAreaConfig>;

  return (
    <>
      <Form.Item label="行数">
        <InputNumber
          {...form.bind('rows', { onBlur: true })}
          min={0}
          max={20}
          step={1}
          precision={0}
        />
      </Form.Item>

      <Form.Item label="自动高度">
        <Switch {...form.bind('autoSize')} checked={form.values.autoSize} />
      </Form.Item>

      <Form.Item label="最大字符数">
        <InputNumber
          {...form.bind('maxLength', { onBlur: true })}
          min={0}
          step={1}
          precision={0}
        />
      </Form.Item>

      <Form.Item label="显示数字">
        <Switch {...form.bind('showCount')} checked={form.values.showCount} />
      </Form.Item>
    </>
  );
});
