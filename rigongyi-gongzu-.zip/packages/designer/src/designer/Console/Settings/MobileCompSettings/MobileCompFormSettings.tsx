import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { MobileCompFormConfig } from '@gongzu/core/src/types/comps-mobile';
import { Form, Radio } from 'antd';
import { observer } from 'mobx-react';
import React from 'react';
import SettingsFormContext from '../context/SettingsFormContext';

export default observer(() => {
  const form = React.useContext(
    SettingsFormContext,
  ) as unknown as MobxFormStore<MobileCompFormConfig>;

  const key = form.values.id;

  return (
    <>
      <Form.Item label="模式">
        <Radio.Group
          optionType="button"
          buttonStyle="solid"
          key={key}
          defaultValue="default"
          options={[
            { label: '默认', value: 'default' },
            { label: '卡片', value: 'card' },
          ]}
          {...form.bind('mode')}
        />
      </Form.Item>
    </>
  );
});
