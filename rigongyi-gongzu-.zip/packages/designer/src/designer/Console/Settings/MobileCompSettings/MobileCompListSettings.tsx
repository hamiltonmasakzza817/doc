import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { MobileCompListConfig } from '@gongzu/core/types/comps-mobile';
import { Form, Radio } from 'antd';
import { observer } from 'mobx-react';
import React from 'react';
import ExpressionInput from '../../../components/ExpressionInput';
import SettingsFormContext from '../context/SettingsFormContext';

export default observer(() => {
  const form = React.useContext(
    SettingsFormContext,
  ) as unknown as MobxFormStore<MobileCompListConfig>;

  const key = form.values.id;

  return (
    <>
      <Form.Item label="列表头">
        <ExpressionInput {...form.bind('header')} />
      </Form.Item>

      <Form.Item label="模式">
        <Radio.Group
          optionType="button"
          buttonStyle="solid"
          key={key}
          defaultValue="default"
          options={[
            { label: '默认', value: 'default' },
            { label: '卡片', value: 'card' },
          ]}
          {...form.bind('mode')}
        />
      </Form.Item>
    </>
  );
});
