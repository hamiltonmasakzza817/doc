import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { MobileCompCheckboxConfig } from '@gongzu/core/src/types/comps-mobile';
import { Form, Switch } from 'antd';
import { observer } from 'mobx-react';
import React from 'react';
import ExpressionInput from '../../../components/ExpressionInput';
import SettingsFormContext from '../context/SettingsFormContext';

export default observer(() => {
  const form = React.useContext(
    SettingsFormContext,
  ) as unknown as MobxFormStore<MobileCompCheckboxConfig>;

  return (
    <>
      <Form.Item label="独占一行">
        <Switch {...form.bind('block')} checked={form.values.block} />
      </Form.Item>

      <Form.Item label="元素禁用">
        <ExpressionInput {...form.bind('itemDisabled', { onBlur: true })} />
      </Form.Item>
    </>
  );
});
