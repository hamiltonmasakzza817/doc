import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { MobileCompTabPanelConfig } from '@gongzu/core/types/comps-mobile';
import { Form } from 'antd';
import { observer } from 'mobx-react';
import React from 'react';
import ExpressionInput from '../../../components/ExpressionInput';
import SettingsFormContext from '../context/SettingsFormContext';

export default observer(() => {
  const form = React.useContext(
    SettingsFormContext,
  ) as MobxFormStore<MobileCompTabPanelConfig>;

  return (
    <>
      <Form.Item label="标题">
        <ExpressionInput {...form.bind('title', { onBlur: true })} />
      </Form.Item>

      <Form.Item label="禁用">
        <ExpressionInput {...form.bind('disabled', { onBlur: true })} />
      </Form.Item>
    </>
  );
});
