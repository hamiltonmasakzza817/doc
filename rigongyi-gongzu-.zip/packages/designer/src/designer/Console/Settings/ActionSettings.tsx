import {
  blurPageCompTypes,
  changeablePageCompTypes,
  clickableCompTypes,
  loadableCompTypes,
} from '@gongzu/core/config/comps';
import { DesktopCompType } from '@gongzu/core/types/comps-desktop';
import { MobileCompType } from '@gongzu/core/types/comps-mobile';
import { PageCompType } from '@gongzu/core/types/comps-page';
import { TaroCompType } from '@gongzu/core/types/comps-taro';
import concat from 'lodash-es/concat';
import get from 'lodash-es/get';
import includes from 'lodash-es/includes';

import { observer } from 'mobx-react';
import React from 'react';
import ActionBindingForm from './common/ActionBindingForm';
import SettingsFormContext from './context/SettingsFormContext';

const pageCompTypeActions = {
  [DesktopCompType.CONTAINER]: {
    prefix: 'onHeightChange',
    name: '高度变更',
  },
  [DesktopCompType.TAG]: {
    prefix: 'onClose',
    name: '关闭',
  },
  [DesktopCompType.MODAL]: [
    {
      prefix: 'onOk',
      name: '确定',
    },
    {
      prefix: 'onCancel',
      name: '取消',
    },
  ],
  [MobileCompType.MODAL]: [
    {
      prefix: 'onOk',
      name: '确定',
    },
    {
      prefix: 'onCancel',
      name: '取消',
    },
  ],
  [TaroCompType.MODAL]: [
    {
      prefix: 'onOk',
      name: '确定',
    },
    {
      prefix: 'onCancel',
      name: '取消',
    },
  ],
  [DesktopCompType.TABLE]: [
    {
      prefix: 'onSort',
      name: '排序&过滤变更',
    },
    {
      prefix: 'onRowClick',
      name: '点击行',
    },
    {
      prefix: 'onRowSelectionChange',
      name: '行选变更',
    },
  ],
  [DesktopCompType.SELECT]: {
    prefix: 'onSearch',
    name: '搜索',
  },
  [DesktopCompType.DROPDOWN_MENU]: {
    prefix: 'onSelect',
    name: '选择菜单',
  },
  [DesktopCompType.MENU]: {
    prefix: 'onSelect',
    name: '选择菜单',
  },
  [DesktopCompType.INPUT]: [
    {
      prefix: 'onPressEnter',
      name: '按回车',
    },
    {
      prefix: 'onSearch',
      name: '搜索',
    },
  ],
  [DesktopCompType.NUMBER_INPUT]: {
    prefix: 'onPressEnter',
    name: '按回车',
  },
  [DesktopCompType.TEXT_AREA]: {
    prefix: 'onPressEnter',
    name: '按回车',
  },
  [DesktopCompType.TREE_SELECT]: [
    {
      prefix: 'onExpand',
      name: '展开',
    },
    {
      prefix: 'onSearch',
      name: '搜索',
    },
  ],
  [DesktopCompType.TREE]: {
    prefix: 'onExpand',
    name: '展开',
  },
  [MobileCompType.SEARCH_BAR]: [
    {
      prefix: 'onSearch',
      name: '查询确认',
    },
    {
      prefix: 'onFocus',
      name: '聚焦',
    },
    {
      prefix: 'onClear',
      name: '清空',
    },
  ],
  [MobileCompType.INFINITE_SCROLL]: {
    prefix: 'onLoadMore',
    name: '加载更多',
  },
  [TaroCompType.SCROLL_VIEW]: [
    {
      prefix: 'onScroll',
      name: '滚动',
    },
    {
      prefix: 'onRefresherPulling',
      name: '下拉刷新',
    },
  ],
  [PageCompType.PAGE]: {
    prefix: 'onDispose',
    name: '页面销毁',
  },
  [TaroCompType.BUTTON]: [
    {
      prefix: 'onGetPhoneNumber',
      name: '获取手机号',
    },
  ],
};

export default observer(() => {
  const form = React.useContext(SettingsFormContext);

  return (
    <div className="flex flex-col gap-2">
      {includes(loadableCompTypes, form.values.type) && (
        <ActionBindingForm prefix="onLoad" name="加载完成" />
      )}

      {includes(clickableCompTypes, form.values.type) && (
        <ActionBindingForm prefix="onClick" name="点击" />
      )}

      {includes(blurPageCompTypes, form.values.type) && (
        <ActionBindingForm prefix="onBlur" name="失去焦点" />
      )}

      {includes(changeablePageCompTypes, form.values.type) && (
        <ActionBindingForm prefix="onChange" name="值变更" />
      )}

      {form.values.type in pageCompTypeActions &&
        concat(get(pageCompTypeActions, form.values.type)).map((action) => (
          <ActionBindingForm key={action.prefix} {...action} />
        ))}
    </div>
  );
});
