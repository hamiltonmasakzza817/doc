import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { TaroCompScrollViewConfig } from '@gongzu/core/types/comps-taro';
import { Form, Switch } from 'antd';
import { observer } from 'mobx-react';
import React from 'react';
import ExpressionInput from '../../../components/ExpressionInput/ExpressionInput';
import SettingsFormContext from '../context/SettingsFormContext';

export default observer(() => {
  const form = React.useContext(
    SettingsFormContext,
  ) as unknown as MobxFormStore<TaroCompScrollViewConfig>;

  return (
    <>
      <Form.Item label="Loading">
        <ExpressionInput
          leafOnly
          {...form.bind('loading', {
            onBlur: true,
          })}
        />
      </Form.Item>

      <Form.Item label="纵向滚动">
        <Switch {...form.bind('scrollY')} checked={form.values.scrollY} />
      </Form.Item>

      {form.values.scrollY === true && (
        <Form.Item label="纵向滚动位置">
          <ExpressionInput {...form.bind('scrollTop')} />
        </Form.Item>
      )}

      <Form.Item label="横向滚动">
        <Switch {...form.bind('scrollX')} checked={form.values.scrollX} />
      </Form.Item>

      <Form.Item label="隐藏滚动条">
        <Switch
          {...form.bind('hideScrollbar')}
          checked={form.values.hideScrollbar}
        />
      </Form.Item>

      <Form.Item label="开启下拉刷新">
        <Switch
          {...form.bind('refresherEnabled')}
          checked={form.values.refresherEnabled}
          defaultChecked={false}
        />
      </Form.Item>

      <Form.Item label="延展至底部">
        <ExpressionInput {...form.bind('flexGrowBottom')} />
      </Form.Item>
    </>
  );
});
