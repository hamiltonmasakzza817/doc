import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { TaroCompType } from '@gongzu/core/types/comps-taro';
import { Form } from 'antd';
import { observer } from 'mobx-react';
import React from 'react';
import ExpressionInput from '../../../components/ExpressionInput/ExpressionInput';
import { SectionHeading } from '../common/SectionHeading';
import SettingsFormContext from '../context/SettingsFormContext';

export default observer(() => {
  const form = React.useContext(
    SettingsFormContext,
  ) as unknown as MobxFormStore<{
    id: string;
    type: TaroCompType;
    options?: {
      dataSource: string;
      name: string;
      value: string;
    };
    border?: boolean;
  }>;

  return (
    <>
      <SectionHeading caption="备选项" />

      <Form.Item label="数据源">
        <ExpressionInput
          asPathname
          nonLeafOnly
          {...form.bind('options.dataSource', { onBlur: true })}
        />
      </Form.Item>

      <Form.Item label="标题">
        <ExpressionInput {...form.bind('options.label', { onBlur: true })} />
      </Form.Item>

      <Form.Item label="值">
        <ExpressionInput {...form.bind('options.value', { onBlur: true })} />
      </Form.Item>
    </>
  );
});
