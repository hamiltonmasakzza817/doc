import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { TaroCompButtonConfig } from '@gongzu/core/types/comps-taro';
import { Form, Radio, Select, Switch } from 'antd';
import { observer } from 'mobx-react';
import React from 'react';
import ExpressionInput from '../../../components/ExpressionInput';
import SettingsFormContext from '../context/SettingsFormContext';

export default observer(() => {
  const form = React.useContext(
    SettingsFormContext,
  ) as unknown as MobxFormStore<TaroCompButtonConfig>;

  return (
    <>
      <Form.Item label="尺寸">
        <Radio.Group
          key={form.values.id}
          defaultValue="default"
          {...form.bind('size')}
          buttonStyle="solid"
        >
          <Radio.Button value="default">默认</Radio.Button>
          <Radio.Button value="mini">小</Radio.Button>
        </Radio.Group>
      </Form.Item>

      <Form.Item label="按钮类型">
        <Select
          key={form.values.id}
          {...form.bind('buttonType')}
          defaultValue="default"
          options={[
            ['default', '默认'],
            ['primary', '主色'],
            ['warn', '警告'],
          ].map(([value, label]) => ({ label, value }))}
        />
      </Form.Item>

      <Form.Item label="开放能力">
        <Select
          allowClear
          key={form.values.id}
          {...form.bind('openType')}
          options={[
            ['share', '分享'],
            ['getPhoneNumber', '获取手机号'],
          ].map(([value, label]) => ({ label, value }))}
        />
      </Form.Item>

      <Form.Item label="边框">
        <Switch
          checked={form.values.border}
          {...form.bind('border')}
          defaultChecked
        />
      </Form.Item>

      <Form.Item label="禁用">
        <ExpressionInput {...form.bind('disabled', { onBlur: true })} />
      </Form.Item>

      <Form.Item label="文本">
        <ExpressionInput {...form.bind('text', { onBlur: true })} />
      </Form.Item>

      <Form.Item label="Loading">
        <ExpressionInput {...form.bind('loading', { onBlur: true })} />
      </Form.Item>
    </>
  );
});
