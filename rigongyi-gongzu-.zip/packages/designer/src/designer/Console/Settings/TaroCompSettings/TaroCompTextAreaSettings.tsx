import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { TaroCompTextAreaConfig } from '@gongzu/core/types/comps-taro';
import { Form, InputNumber } from 'antd';
import { observer } from 'mobx-react';
import React from 'react';
import SettingsFormContext from '../context/SettingsFormContext';
import TaroCompFormControlSettings from './TaroCompFormControlSettings';

export default observer(() => {
  const form = React.useContext(
    SettingsFormContext,
  ) as unknown as MobxFormStore<TaroCompTextAreaConfig>;

  return (
    <>
      <TaroCompFormControlSettings />

      <Form.Item label="最大长度">
        <InputNumber key={form.values.id} {...form.bind('maxlength')} />
      </Form.Item>
    </>
  );
});
