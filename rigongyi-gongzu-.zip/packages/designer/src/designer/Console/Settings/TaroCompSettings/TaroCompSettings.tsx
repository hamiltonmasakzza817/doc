import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { TaroCompConfig, TaroCompType } from '@gongzu/core/types/comps-taro';
import { observer } from 'mobx-react';
import React from 'react';
import SettingsFormContext from '../context/SettingsFormContext';
import TaroCompBooleanItemSettings from './TaroCompBooleanItemSettings';
import TaroCompButtonSettings from './TaroCompButtonSettings';
import TaroCompCheckboxSettings from './TaroCompCheckboxSettings';
import TaroCompContainerSettings from './TaroCompContainerSettings';
import TaroCompDatePickerItemSettings from './TaroCompDatePickerItemSettings';
import TaroCompDatePickerSettings from './TaroCompDatePickerSettings';
import TaroCompFormSettings from './TaroCompFormSettings';
import TaroCompImageSettings from './TaroCompImageSettings';
import TaroCompInputItemSettings from './TaroCompInputItemSettings';
import TaroCompInputSettings from './TaroCompInputSettings';
import TaroCompListItemSettings from './TaroCompListItemSettings';
import TaroCompListSettings from './TaroCompListSettings';
import TaroCompModalSettings from './TaroCompModalSettings';
import TaroCompNavContainerSettings from './TaroCompNavContainerSettings';
import TaroCompRadioSettings from './TaroCompRadioSettings';
import TaroCompScrollViewSettings from './TaroCompScrollViewSettings';
import TaroCompSelectItemSettings from './TaroCompSelectItemSettings';
import TaroCompSelectSettings from './TaroCompSelectSettings';
import TaroCompSliderSettings from './TaroCompSliderSettings';
import TaroCompSwiperSettings from './TaroCompSwiperSettings';
import TaroCompSwitchSettings from './TaroCompSwitchSettings';
import TaroCompTextAreaSettings from './TaroCompTextAreaSettings';

export default observer(() => {
  const form = React.useContext(
    SettingsFormContext,
  ) as MobxFormStore<TaroCompConfig>;

  switch (form.values.type) {
    case TaroCompType.BUTTON: {
      return <TaroCompButtonSettings />;
    }

    case TaroCompType.CONTAINER: {
      return <TaroCompContainerSettings />;
    }

    case TaroCompType.IMAGE: {
      return <TaroCompImageSettings />;
    }

    case TaroCompType.INPUT: {
      return <TaroCompInputSettings />;
    }

    case TaroCompType.INPUT_ITEM: {
      return <TaroCompInputItemSettings />;
    }

    case TaroCompType.DATE_PICKER: {
      return <TaroCompDatePickerSettings />;
    }

    case TaroCompType.DATE_PICKER_ITEM: {
      return <TaroCompDatePickerItemSettings />;
    }

    case TaroCompType.LIST_ITEM: {
      return <TaroCompListItemSettings />;
    }

    case TaroCompType.LIST: {
      return <TaroCompListSettings />;
    }

    case TaroCompType.TEXT_AREA: {
      return <TaroCompTextAreaSettings />;
    }

    case TaroCompType.MODAL: {
      return <TaroCompModalSettings />;
    }

    case TaroCompType.SLIDER: {
      return <TaroCompSliderSettings />;
    }

    case TaroCompType.SWIPER: {
      return <TaroCompSwiperSettings />;
    }

    case TaroCompType.SCROLL_VIEW: {
      return <TaroCompScrollViewSettings />;
    }

    case TaroCompType.SWITCH: {
      return <TaroCompSwitchSettings />;
    }

    case TaroCompType.SELECT: {
      return <TaroCompSelectSettings />;
    }

    case TaroCompType.SELECT_ITEM: {
      return <TaroCompSelectItemSettings />;
    }

    case TaroCompType.BOOLEAN_ITEM: {
      return <TaroCompBooleanItemSettings />;
    }

    case TaroCompType.RADIO: {
      return <TaroCompRadioSettings />;
    }

    case TaroCompType.CHECKBOX: {
      return <TaroCompCheckboxSettings />;
    }

    case TaroCompType.FORM: {
      return <TaroCompFormSettings />;
    }

    case TaroCompType.NAV_CONTAINER: {
      return <TaroCompNavContainerSettings />;
    }

    default: {
      return <></>;
    }
  }
});
