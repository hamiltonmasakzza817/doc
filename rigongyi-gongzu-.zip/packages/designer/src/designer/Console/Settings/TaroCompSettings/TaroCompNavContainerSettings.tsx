import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { TaroCompNavContainerConfig } from '@gongzu/core/types/comps-taro';
import { Form } from 'antd';
import { observer } from 'mobx-react';
import React from 'react';
import { useContext } from 'react';
import ExpressionInput from '../../../components/ExpressionInput';
import SettingsFormContext from '../context/SettingsFormContext';

export default observer(() => {
  const form = useContext(
    SettingsFormContext,
  ) as unknown as MobxFormStore<TaroCompNavContainerConfig>;

  return (
    <>
      <Form.Item label="标题文字">
        <ExpressionInput
          {...form.bind('navigationBarTitleText', { onBlur: true })}
        />
      </Form.Item>
    </>
  );
});
