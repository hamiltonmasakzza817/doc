import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { TaroCompListItemConfig } from '@gongzu/core/types/comps-taro';
import { Form, Switch } from 'antd';
import { observer } from 'mobx-react';
import React from 'react';
import ExpressionInput from '../../../components/ExpressionInput';
import FormItemRulesSettings from '../common/FormItemRulesSettings/FormItemRulesSettings';
import SettingsFormContext from '../context/SettingsFormContext';
import TaroCompFormItemSettings from './TaroCompFormItemSettings';

export default observer(() => {
  const form = React.useContext(
    SettingsFormContext,
  ) as unknown as MobxFormStore<TaroCompListItemConfig>;

  return (
    <>
      <FormItemRulesSettings />

      <Form.Item label="值绑定地址">
        <ExpressionInput {...form.bind('value', { onBlur: true })} asPathname />
      </Form.Item>

      <Form.Item label="右箭头">
        <Switch {...form.bind('arrow')} checked={form.values.arrow} />
      </Form.Item>

      <Form.Item label="使用Label">
        <Switch {...form.bind('useLabel')} checked={form.values.useLabel} />
      </Form.Item>

      <Form.Item label="内容文字">
        <ExpressionInput {...form.bind('contentText', { onBlur: true })} />
      </Form.Item>

      <TaroCompFormItemSettings />
    </>
  );
});
