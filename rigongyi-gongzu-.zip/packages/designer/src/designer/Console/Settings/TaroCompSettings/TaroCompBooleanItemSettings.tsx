import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { TaroCompBooleanItemConfig } from '@gongzu/core/types/comps-taro';
import { Form, Radio } from 'antd';
import { observer } from 'mobx-react';
import React, { useContext } from 'react';
import ExpressionInput from '../../../components/ExpressionInput';
import SettingsFormContext from '../context/SettingsFormContext';
import TaroCompFormControlSettings from './TaroCompFormControlSettings';
import TaroCompFormItemSettings from './TaroCompFormItemSettings';

export default observer(() => {
  const form = useContext(
    SettingsFormContext,
  ) as unknown as MobxFormStore<TaroCompBooleanItemConfig>;

  return (
    <>
      <TaroCompFormControlSettings />

      <Form.Item label="类型">
        <Radio.Group
          {...form.bind('compType')}
          options={[
            ['switch', '开关'],
            ['check', '对钩'],
          ].map(([value, label]) => ({
            value,
            label,
          }))}
          defaultValue="switch"
          optionType="button"
          buttonStyle="solid"
        />
      </Form.Item>

      {(form.values.compType == null || form.values.compType === 'switch') && (
        <Form.Item label="Switch颜色">
          <ExpressionInput {...form.bind('switchColor', { onBlur: true })} />
        </Form.Item>
      )}

      <TaroCompFormItemSettings />
    </>
  );
});
