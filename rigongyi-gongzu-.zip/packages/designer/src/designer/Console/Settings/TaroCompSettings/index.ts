export { default } from './TaroCompSettings';
