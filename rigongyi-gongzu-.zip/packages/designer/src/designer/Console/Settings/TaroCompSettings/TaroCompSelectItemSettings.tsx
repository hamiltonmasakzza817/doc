import React from 'react';
import TaroCompFormItemSettings from './TaroCompFormItemSettings';
import TaroCompSelectSettings from './TaroCompSelectSettings';

export default () => {
  return (
    <>
      <TaroCompSelectSettings />
      <TaroCompFormItemSettings />
    </>
  );
};
