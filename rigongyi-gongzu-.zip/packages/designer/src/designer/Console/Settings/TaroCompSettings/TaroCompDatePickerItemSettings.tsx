import React from 'react';
import TaroCompDatePickerSettings from './TaroCompDatePickerSettings';
import TaroCompFormItemSettings from './TaroCompFormItemSettings';

export default () => (
  <>
    <TaroCompDatePickerSettings />
    <TaroCompFormItemSettings />
  </>
);
