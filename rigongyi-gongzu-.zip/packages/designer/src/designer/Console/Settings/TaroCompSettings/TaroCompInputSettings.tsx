import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { TaroCompInputConfig } from '@gongzu/core/types/comps-taro';
import { Form, Radio, Select, Switch } from 'antd';
import { observer } from 'mobx-react';
import React from 'react';
import SettingsFormContext from '../context/SettingsFormContext';
import TaroCompFormControlSettings from './TaroCompFormControlSettings';

export default observer(() => {
  const form = React.useContext(
    SettingsFormContext,
  ) as unknown as MobxFormStore<TaroCompInputConfig>;

  return (
    <>
      <TaroCompFormControlSettings />

      <Form.Item label="输入框类型">
        <Select
          {...form.bind('inputType')}
          defaultValue="text"
          options={[
            ['text', '文本'],
            ['number', '数字'],
            ['phone', '手机号'],
            ['digit', '小数点数字'],
          ].map(([value, label]) => ({
            label,
            value,
          }))}
        />
      </Form.Item>

      <Form.Item label="密码">
        <Switch {...form.bind('password')} checked={form.values.password} />
      </Form.Item>


    </>
  );
});
