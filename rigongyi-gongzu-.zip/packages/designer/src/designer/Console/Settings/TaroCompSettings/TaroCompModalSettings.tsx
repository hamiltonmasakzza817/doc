import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { TaroCompModalConfig } from '@gongzu/core/types/comps-taro';
import { Form, Radio, Switch } from 'antd';
import { observer } from 'mobx-react';
import React from 'react';
import ExpressionInput from '../../../components/ExpressionInput';
import SettingsFormContext from '../context/SettingsFormContext';

export default observer(() => {
  const form = React.useContext(
    SettingsFormContext,
  ) as unknown as MobxFormStore<TaroCompModalConfig>;

  return (
    <>
      <Form.Item label="对话框类型">
        <Radio.Group
          optionType="button"
          buttonStyle="solid"
          defaultValue="dialog"
          options={[
            { label: '标准', value: 'dialog' },
            { label: '半屏', value: 'half-screen' },
          ]}
          {...form.bind('modalType')}
        />
      </Form.Item>

      <Form.Item label="蒙层关闭">
        <Switch
          {...form.bind('maskClosable')}
          checked={form.values.maskClosable}
        />
      </Form.Item>

      <Form.Item label="标题文字">
        <ExpressionInput {...form.bind('title', { onBlur: true })} />
      </Form.Item>

      <Form.Item label="隐藏Footer">
        <Switch checked={form.values.noFooter} {...form.bind('noFooter')} />
      </Form.Item>

      {!form.values.noFooter && (
        <>
          <Form.Item label="确定文字">
            <ExpressionInput {...form.bind('okText', { onBlur: true })} />
          </Form.Item>

          <Form.Item label="取消文字">
            <ExpressionInput {...form.bind('cancelText', { onBlur: true })} />
          </Form.Item>
        </>
      )}
    </>
  );
});
