import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { TaroCompFormItem } from '@gongzu/core/types/comps-taro';
import { Form, InputNumber, Radio } from 'antd';
import { observer } from 'mobx-react';
import React from 'react';
import ExpressionInput from '../../../components/ExpressionInput';
import CustomComponentSelect from '../../components/CustomCompSelect';
import SettingsFormContext from '../context/SettingsFormContext';

export default observer(() => {
  const form = React.useContext(
    SettingsFormContext,
  ) as unknown as MobxFormStore<TaroCompFormItem>;

  return (
    <>
      <Form.Item label="内容对齐">
        <Radio.Group
          optionType="button"
          buttonStyle="solid"
          options={[
            ['left', '左'],
            ['center', '居中'],
            ['right', '右'],
          ].map(([value, label]) => ({ label, value }))}
          defaultValue="center"
          {...form.bind('contentAlign')}
        />
      </Form.Item>

      <Form.Item label="头部宽度">
        <InputNumber
          {...form.bind('headWidth')}
          precision={0}
          min={0}
          step={1}
        />
      </Form.Item>

      <Form.Item label="头部文字">
        <ExpressionInput {...form.bind('headText', { onBlur: true })} />
      </Form.Item>

      <Form.Item label="头部组件">
        <CustomComponentSelect {...form.bind('head')} showEmpty />
      </Form.Item>
    </>
  );
});
