import { DeleteOutlined } from '@ant-design/icons';
import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { TaroCompSwiperConfig } from '@gongzu/core/types/comps-taro';
import { Form, Modal, Switch } from 'antd';
import { observer } from 'mobx-react';
import React from 'react';
import ClickableText from '../../../../components/ClickableText';
import CodeEditorCard from '../../../components/CodeEditorCard';
import ExpressionInput from '../../../components/ExpressionInput';
import CustomCompSelect from '../../components/CustomCompSelect';
import { SectionHeading } from '../common/SectionHeading';
import SettingsFormContext from '../context/SettingsFormContext';

export default observer(() => {
  const form = React.useContext(
    SettingsFormContext,
  ) as unknown as MobxFormStore<TaroCompSwiperConfig>;

  return (
    <>
      <Form.Item label="当前序号">
        <ExpressionInput {...form.bind('current', { onBlur: true })} />
      </Form.Item>

      <Form.Item label="自动播放">
        <Switch {...form.bind('autoplay')} checked={form.values.autoplay} />
      </Form.Item>

      <Form.Item className="block">
        <CodeEditorCard
          title="覆盖图片属性"
          language="json"
          height={150}
          extra={
            <ClickableText
              onClick={() => {
                Modal.confirm({
                  title: '删除提示',
                  content: '是否删除图片覆盖属性',
                  onOk: () => {
                    form.setValues({
                      imageRawProps: undefined,
                    });
                  },
                });
              }}
            >
              <DeleteOutlined className="ml-1 text-error" />
            </ClickableText>
          }
          {...form.bind('imageRawProps')}
        />
      </Form.Item>

      <SectionHeading caption="数据源" />

      <Form.Item label="数据源地址">
        <ExpressionInput
          asPathname
          {...form.bind('dataSource', { onBlur: true })}
        />
      </Form.Item>

      <Form.Item label="图片URL">
        <ExpressionInput {...form.bind('imageUrl', { onBlur: true })} />
      </Form.Item>

      <Form.Item label="跳转URL">
        <ExpressionInput {...form.bind('url', { onBlur: true })} />
      </Form.Item>

      <Form.Item label="自定义">
        <CustomCompSelect {...form.bind('element')} />
      </Form.Item>
    </>
  );
});
