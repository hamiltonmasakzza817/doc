import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { TaroCompFormConfig } from '@gongzu/core/types/comps-taro';
import { Form } from 'antd';
import React, { useContext } from 'react';
import ExpressionInput from '../../../components/ExpressionInput/ExpressionInput';
import SettingsFormContext from '../context/SettingsFormContext';

export default () => {
  const form = useContext(
    SettingsFormContext,
  ) as unknown as MobxFormStore<TaroCompFormConfig>;

  return (
    <>
      <Form.Item label="值绑定地址">
        <ExpressionInput {...form.bind('value', { onBlur: true })} asPathname />
      </Form.Item>
    </>
  );
};
