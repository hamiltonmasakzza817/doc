import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { TaroCompImageConfig } from '@gongzu/core/types/comps-taro';
import { Form, Select, Switch } from 'antd';
import { observer } from 'mobx-react';
import React from 'react';
import ExpressionInput from '../../../components/ExpressionInput';
import ImageUploader from '../../../components/ImageUploader';
import SettingsFormContext from '../context/SettingsFormContext';

export default observer(() => {
  const form = React.useContext(
    SettingsFormContext,
  ) as unknown as MobxFormStore<TaroCompImageConfig>;

  return (
    <>
      <Form.Item label="图片地址">
        <ExpressionInput {...form.bind('src', { onBlur: true })} />
      </Form.Item>

      <Form.Item label="图片上传">
        <ImageUploader
          url={form.values.src}
          onChange={({ url }) => {
            form.setValues({ src: url });
          }}
        />
      </Form.Item>

      <Form.Item label="自适应">
        <Select
          {...form.bind('mode')}
          defaultValue="scaleToFill"
          options={[
            ['scaleToFill', '拉伸'],
            ['aspectFit', '等宽高比适应最小轴'],
            ['aspectFill', '等宽高比使用最大轴'],
            ['widthFix', '适应宽度'],
            ['heightFix', '适应高度'],
          ].map(([value, label]) => ({ label, value }))}
        />
      </Form.Item>

      <Form.Item label="懒加载">
        <Switch {...form.bind('lazyLoad')} checked={form.values.lazyLoad} />
      </Form.Item>
    </>
  );
});
