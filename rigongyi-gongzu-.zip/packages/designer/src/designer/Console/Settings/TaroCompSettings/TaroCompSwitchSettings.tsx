import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { TaroCompSwitchConfig } from '@gongzu/core/types/comps-taro';
import { Form } from 'antd';
import { observer } from 'mobx-react';
import React, { useContext } from 'react';
import ExpressionInput from '../../../components/ExpressionInput';
import SettingsFormContext from '../context/SettingsFormContext';
import TaroCompFormControlSettings from './TaroCompFormControlSettings';

export default observer(() => {
  const form = useContext(
    SettingsFormContext,
  ) as unknown as MobxFormStore<TaroCompSwitchConfig>;

  return (
    <>
      <TaroCompFormControlSettings />

      <Form.Item label="颜色">
        <ExpressionInput {...form.bind('color', { onBlur: true })} />
      </Form.Item>
    </>
  );
});
