import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { TaroCompButtonConfig } from '@gongzu/core/types/comps-taro';
import { Form } from 'antd';
import { observer } from 'mobx-react';
import React from 'react';
import ExpressionInput from '../../../components/ExpressionInput/ExpressionInput';
import CustomComponentSelect from '../../components/CustomCompSelect';
import SettingsFormContext from '../context/SettingsFormContext';

export default observer(() => {
  const form = React.useContext(
    SettingsFormContext,
  ) as unknown as MobxFormStore<TaroCompButtonConfig>;

  return (
    <>
      <Form.Item label="Loading">
        <ExpressionInput
          leafOnly
          {...form.bind('loading', {
            onBlur: true,
          })}
        />
      </Form.Item>

      <Form.Item label="自定义组件">
        <CustomComponentSelect {...form.bind('renderCompId')} showEmpty />
      </Form.Item>
    </>
  );
});
