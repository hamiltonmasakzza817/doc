import React from 'react';
import TaroCompFormItemSettings from './TaroCompFormItemSettings';
import TaroCompInputSettings from './TaroCompInputSettings';

export default () => {
  return (
    <>
      <TaroCompInputSettings />
      <TaroCompFormItemSettings />
    </>
  );
};
