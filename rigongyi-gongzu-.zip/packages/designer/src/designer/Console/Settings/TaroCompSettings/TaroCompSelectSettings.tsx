import React from 'react';
import OptionsSettings from './OptionsSettings';
import TaroCompFormControlSettings from './TaroCompFormControlSettings';

export default () => {
  return (
    <>
      <TaroCompFormControlSettings />
      <OptionsSettings />
    </>
  );
};
