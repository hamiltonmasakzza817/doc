import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { TaroCompDatePickerConfig } from '@gongzu/core/types/comps-taro';
import { Form, Radio } from 'antd';
import { observer } from 'mobx-react';
import React from 'react';
import ExpressionInput from '../../../components/ExpressionInput';
import SettingsFormContext from '../context/SettingsFormContext';
import TaroCompFormControlSettings from './TaroCompFormControlSettings';

export default observer(() => {
  const form = React.useContext(
    SettingsFormContext,
  ) as unknown as MobxFormStore<TaroCompDatePickerConfig>;

  const suffix = form.values.mode === 'time' ? '时间' : '日期';

  return (
    <>
      <TaroCompFormControlSettings />

      <Form.Item label="模式">
        <Radio.Group
          buttonStyle="solid"
          optionType="button"
          defaultValue="date"
          options={[
            ['date', '日期'],
            ['time', '时间'],
          ].map(([value, label]) => ({
            label,
            value,
          }))}
          key={form.values.id}
          {...form.bind('mode')}
        />
      </Form.Item>

      {form.values.mode !== 'time' && (
        <>
          {' '}
          <Form.Item label={`最小${suffix}`}>
            <ExpressionInput {...form.bind('start', { onBlur: true })} />
          </Form.Item>
          <Form.Item label={`最大${suffix}`}>
            <ExpressionInput {...form.bind('end', { onBlur: true })} />
          </Form.Item>
        </>
      )}
    </>
  );
});
