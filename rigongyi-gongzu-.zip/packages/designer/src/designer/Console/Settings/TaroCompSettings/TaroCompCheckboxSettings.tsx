import { observer } from 'mobx-react';
import React from 'react';
import OptionsSettings from './OptionsSettings';
import TaroCompFormControlSettings from './TaroCompFormControlSettings';

export default observer(() => (
  <>
    <TaroCompFormControlSettings />
    <OptionsSettings />
  </>
));
