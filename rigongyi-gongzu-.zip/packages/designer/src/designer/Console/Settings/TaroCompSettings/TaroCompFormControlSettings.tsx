import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { CompFormItem } from '@gongzu/core/types/comps-common';
import { Form, Switch } from 'antd';
import { observer } from 'mobx-react';
import React from 'react';
import ExpressionInput from '../../../components/ExpressionInput/ExpressionInput';
import FormItemRulesSettings from '../common/FormItemRulesSettings';
import SettingsFormContext from '../context/SettingsFormContext';

export default observer(() => {
  const form = React.useContext(
    SettingsFormContext,
  ) as unknown as MobxFormStore<CompFormItem>;

  return (
    <>
      <FormItemRulesSettings />

      <Form.Item label="值绑定地址">
        <ExpressionInput {...form.bind('value', { onBlur: true })} asPathname />
      </Form.Item>

      <Form.Item label="单向绑定">
        <Switch
          {...form.bind('onWayBinding')}
          checked={form.values.onWayBinding}
        />
      </Form.Item>

      <Form.Item label="禁用">
        <ExpressionInput {...form.bind('disabled', { onBlur: true })} />
      </Form.Item>

      <Form.Item label="只读">
        <ExpressionInput {...form.bind('readOnly', { onBlur: true })} />
      </Form.Item>

      <Form.Item label="占位符">
        <ExpressionInput {...form.bind('placeholder', { onBlur: true })} />
      </Form.Item>
    </>
  );
});
