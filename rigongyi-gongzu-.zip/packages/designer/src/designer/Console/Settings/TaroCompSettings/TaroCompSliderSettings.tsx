import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { TaroCompSliderConfig } from '@gongzu/core/types/comps-taro';
import { Form, InputNumber } from 'antd';
import { observer } from 'mobx-react';
import React from 'react';
import SettingsFormContext from '../context/SettingsFormContext';

export default observer(() => {
  const form = React.useContext(
    SettingsFormContext,
  ) as unknown as MobxFormStore<TaroCompSliderConfig>;

  return (
    <>
      <Form.Item label="最小值">
        <InputNumber
          {...form.bind('min')}
          defaultValue={0}
          key={form.values.id}
        />
      </Form.Item>

      <Form.Item label="最大值">
        <InputNumber
          {...form.bind('max')}
          defaultValue={100}
          key={form.values.id}
        />
      </Form.Item>

      <Form.Item label="步长">
        <InputNumber
          {...form.bind('step')}
          defaultValue={10}
          key={form.values.id}
        />
      </Form.Item>
    </>
  );
});
