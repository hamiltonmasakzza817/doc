import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { TaroCompListConfig } from '@gongzu/core/types/comps-taro';
import { Form, InputNumber, Switch } from "antd";
import { observer } from 'mobx-react';
import React from 'react';
import ExpressionInput from '../../../components/ExpressionInput';
import SettingsFormContext from '../context/SettingsFormContext';

export default observer(() => {
  const form = React.useContext(
    SettingsFormContext,
  ) as unknown as MobxFormStore<TaroCompListConfig>;

  return (
    <>
      <Form.Item label="标题">
        <ExpressionInput {...form.bind('title')} />
      </Form.Item>

      <Form.Item label="卡片">
        <Switch {...form.bind('card')} checked={form.values.card} />
      </Form.Item>

      <Form.Item label="头部宽度">
        <InputNumber
          {...form.bind('headWidth')}
          precision={0}
          min={0}
          step={1}
        />
      </Form.Item>
    </>
  );
});
