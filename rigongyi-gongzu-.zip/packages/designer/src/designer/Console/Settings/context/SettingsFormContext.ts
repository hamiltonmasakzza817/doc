import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { CompConfig } from '@gongzu/core/types/comps-common';
import React from 'react';

export default React.createContext<MobxFormStore<CompConfig>>(
  new MobxFormStore<CompConfig>(),
);
