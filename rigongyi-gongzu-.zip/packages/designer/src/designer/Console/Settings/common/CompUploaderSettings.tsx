import { DeleteOutlined, QuestionCircleOutlined } from '@ant-design/icons';
import api from '@gongzu/core/config/api';
import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { DesktopCompUploaderConfig } from '@gongzu/core/types/comps-desktop';
import { Form, Input, Modal, Switch, Tooltip } from 'antd';
import { Observer, observer } from 'mobx-react';
import React from 'react';
import ClickableText from '../../../../components/ClickableText';
import CodeEditorCard from '../../../components/CodeEditorCard';
import ExpressionInput from '../../../components/ExpressionInput';
import SettingsFormContext from '../context/SettingsFormContext';

export default observer(() => {
  const form = React.useContext(
    SettingsFormContext,
  ) as unknown as MobxFormStore<DesktopCompUploaderConfig>;

  return (
    <>
      <Form.Item
        label={
          <span>
            上传地址&nbsp;
            <Tooltip title={`默认地址为：${api.file.upload}`}>
              <QuestionCircleOutlined />
            </Tooltip>
          </span>
        }
      >
        <ExpressionInput {...form.bind('url', { onBlur: true })} />
      </Form.Item>

      <Form.Item label="loading地址">
        <ExpressionInput
          asPathname
          {...form.bind('loading', { onBlur: true })}
        />
      </Form.Item>

      <Form.Item className="block">
        <Observer>
          {() => (
            <CodeEditorCard
              title="自定义参数"
              height={150}
              language="json"
              extra={
                form.values.params ? (
                  <ClickableText
                    className="ml-1 text-error"
                    onClick={() => {
                      Modal.confirm({
                        title: '提示',
                        content: '是否清空自定义参数？',
                        onOk: () => {
                          form.setValues({ params: undefined });
                        },
                      });
                    }}
                  >
                    <DeleteOutlined />
                  </ClickableText>
                ) : (
                  <></>
                )
              }
              {...form.bind('params')}
            />
          )}
        </Observer>
      </Form.Item>

      <Form.Item label="结果格式化">
        <Input
          placeholder="格式化表达式"
          {...form.bind('formatter', { onBlur: true })}
        />
      </Form.Item>

      <Form.Item label="文件格式">
        <Input
          placeholder=".pdf,.doc,.docx,.xls,.xlsx,.msg,.png,.jpg"
          {...form.bind('accept', { onBlur: true })}
        />
      </Form.Item>

      <Form.Item label="最大尺寸MB">
        <ExpressionInput {...form.bind('maxSize', { onBlur: true })} />
      </Form.Item>

      <Form.Item label="最小尺寸MB">
        <ExpressionInput {...form.bind('minSize', { onBlur: true })} />
      </Form.Item>

      <Form.Item label="多选">
        <Switch {...form.bind('multiple')} checked={form.values.multiple} />
      </Form.Item>
    </>
  );
});
