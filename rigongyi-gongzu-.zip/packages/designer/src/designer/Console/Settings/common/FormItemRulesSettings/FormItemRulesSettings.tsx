import { EditOutlined } from '@ant-design/icons';
import Loading from '@gongzu/core/common/Loading';
import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { CompFormItem } from '@gongzu/core/types/comps-common';
import { Card } from 'antd';
import jsonPretty from 'json-stringify-pretty-compact';
import { observer } from 'mobx-react';
import React from 'react';
import Loadable from 'react-loadable';
import ClickableText from '../../../../../components/ClickableText';
import SettingsFormContext from '../../context/SettingsFormContext';
import DesktopCompFormItemRuleDialog from './FormItemRuleDialog';
import { Rule } from './types';

const CodeEditor = Loadable({
  loader: () => import('../../../../../components/CodeEditor'),
  loading: Loading,
});

export default observer(() => {
  const [ruleEditing, setRuleEditing] = React.useState<Rule | null>(null);

  const form = React.useContext(
    SettingsFormContext,
  ) as unknown as MobxFormStore<CompFormItem>;

  const { rule } = form.values;

  return (
    <>
      <Card
        size="small"
        type="inner"
        title="校验规则"
        className="mb-1"
        extra={
          <ClickableText
            className="text-primary"
            onClick={() => setRuleEditing(rule ?? {})}
          >
            <EditOutlined />
          </ClickableText>
        }
      >
        {rule ? (
          <div className="break-all">
            <div>必填：{rule.required ? '是' : '否'}</div>

            {rule.requiredExp != null && (
              <div>必填表达式：{rule.requiredExp}</div>
            )}

            {rule.requiredMsg != null && (
              <div>必填校验错误信息：{rule.requiredMsg}</div>
            )}

            {rule.pattern != null && (
              <>
                <div>正则：{rule.pattern}</div>
                {rule.patternMsg != null && (
                  <div>正则校验错误信息：{rule.patternMsg}</div>
                )}
              </>
            )}

            {rule.validate != null && (
              <>
                <div>自定义函数：</div>

                {ruleEditing != null && (
                  <CodeEditor readOnly value={rule.validate} height={200} />
                )}

                {rule.validateMsg != null && (
                  <div>自定义校验错误信息：{rule.validateMsg}</div>
                )}
              </>
            )}

            {rule.remoteValidate != null && (
              <>
                <div>远程校验：</div>
                <div>URL: {rule.remoteValidate.url}</div>
                <CodeEditor
                  readOnly
                  value={jsonPretty(rule.remoteValidate.params, {
                    maxLength: 0,
                  })}
                  height={200}
                />
                {rule.validateMsg != null && (
                  <div>远程校验错误信息：{rule.validateMsg}</div>
                )}
              </>
            )}

            {rule.maxLength != null && <div>最大长度{rule.maxLength}</div>}
          </div>
        ) : (
          <div>无</div>
        )}
      </Card>

      <DesktopCompFormItemRuleDialog
        rule={ruleEditing}
        onSave={(rule1) => {
          form.setValues({ rule: rule1 });
        }}
        onCancel={() => setRuleEditing(null)}
      />
    </>
  );
});
