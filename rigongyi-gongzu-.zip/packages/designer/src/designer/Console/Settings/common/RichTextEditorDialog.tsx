import FlexWrapper from '@gongzu/core/components/FlexWrapper';
import { gzdnBem } from '@gongzu/core/config/constants';
import { Input, Modal } from 'antd';
import { ModalProps } from 'antd/es/modal';
import React from 'react';

const settingsBem = gzdnBem('settings');

export default function RichTextDialog(
  props: ModalProps & {
    text?: string;
    onSave: (value?: string) => void;
  },
) {
  const { text, onSave, ...modalProps } = props;

  const [value, setValue] = React.useState<string | undefined>();

  React.useEffect(() => {
    if (text) {
      setValue(text);
    }
  }, [text]);

  return (
    <Modal
      visible={text != null}
      className={settingsBem('rich-text-settings-modal')}
      title="编辑文字"
      onOk={() => {
        onSave(value);
      }}
      {...modalProps}
    >
      <FlexWrapper bottom={53 + 24 * 2}>
        <Input.TextArea
          value={value}
          onChange={(e) => {
            setValue(e.target.value);
          }}
        />
      </FlexWrapper>
    </Modal>
  );
}
