import Loading from '@gongzu/core/common/Loading';
import useFormMobx from '@gongzu/core/mobx-form/useFormMobx';
import { getItemErrorProps, validateJSON } from '@gongzu/core/mobx-form/utils';
import { parseJSON } from '@gongzu/core/utils/data';
import { Divider, Form, Input, InputNumber, Modal, Radio, Switch } from 'antd';
import { ModalProps } from 'antd/es/modal';
import jsonPretty from 'json-stringify-pretty-compact';
import cloneDeep from 'lodash-es/cloneDeep';

import { observer } from 'mobx-react';
import React from 'react';
import Loadable from 'react-loadable';

import { dialogFormItemLayout } from '../../../../../config/layout';
import ExpressionInput from '../../../../components/ExpressionInput';
import { Rule } from './types';

const CodeEditor = Loadable({
  loader: () => import('../../../../../components/CodeEditor'),
  loading: Loading,
});

const defaultValidator = `function execAction(value, state, _index, _pathname, _pathnames, utils) {
  return true;
}`;

export default observer(
  (
    props: Pick<ModalProps, 'onCancel'> & {
      rule: Rule | null;
      onSave: (rule: Rule) => void;
    },
  ) => {
    const { rule, onSave, onCancel } = props;

    const form = useFormMobx<Rule>({ defaultValues: null });

    React.useEffect(() => {
      if (rule) {
        const clone = cloneDeep(rule);

        if (clone.remoteValidate?.params) {
          clone.remoteValidate.params = jsonPretty(
            clone.remoteValidate.params,
            {
              maxLength: 0,
            },
          );
        }

        form.reset(clone);
      }
    }, [rule]);

    const visible = rule != null;

    return (
      <Modal
        title="编辑校验规则"
        visible={visible}
        width={800}
        onCancel={onCancel}
        onOk={(e) => {
          form.triggerValidation().subscribe((isValid) => {
            if (isValid) {
              const clone = cloneDeep(form.values);

              if (clone.remoteValidate?.params) {
                clone.remoteValidate.params = parseJSON(
                  clone.remoteValidate.params,
                );
              }

              onSave(clone);

              if (onCancel) {
                onCancel(e);
              }
            }
          });
        }}
      >
        <Form {...dialogFormItemLayout}>
          <Form.Item label="必填">
            <Switch {...form.bind('required')} checked={form.values.required} />
          </Form.Item>

          <Form.Item label="必填表达式">
            <ExpressionInput {...form.bind('requiredExp', { onBlur: true })} />
          </Form.Item>

          <Form.Item label="错误信息">
            <Input
              {...form.bind('requiredMsg', { onBlur: true })}
              placeholder="必填项需填写"
            />
          </Form.Item>

          <Divider />

          <Form.Item label="正则">
            <Switch
              checked={form.values.pattern != null}
              onChange={(checked) =>
                form.setValues({ pattern: checked ? '' : null })
              }
            />
          </Form.Item>

          {form.values.pattern != null && (
            <>
              <Form.Item label="正则">
                <Input {...form.bind('pattern', { onBlur: true })} />
              </Form.Item>

              <Form.Item label="正则Flag">
                <Input {...form.bind('patternFlag', { onBlur: true })} />
              </Form.Item>

              <Form.Item label="错误信息">
                <Input
                  {...form.bind('patternMsg', { onBlur: true })}
                  placeholder="格式不匹配"
                />
              </Form.Item>
            </>
          )}

          <Divider />

          <Form.Item label="自定义校验">
            <Switch
              checked={form.values.validate != null}
              onChange={(checked) =>
                form.setValues({
                  validate: checked ? defaultValidator : null,
                })
              }
            />
          </Form.Item>

          {form.values.validate != null && (
            <>
              <Form.Item label="代码">
                {visible && (
                  <CodeEditor
                    language="javascript"
                    height={200}
                    {...form.bind('validate')}
                  />
                )}
              </Form.Item>

              <Form.Item label="错误信息">
                <Input {...form.bind('validateMsg')} placeholder="验证未通过" />
              </Form.Item>
            </>
          )}

          <Divider />

          <Form.Item label="远程校验">
            <Switch
              checked={form.values.remoteValidate != null}
              onChange={(checked) =>
                form.setValues({ remoteValidate: checked ? {} : null })
              }
            />
          </Form.Item>

          {form.values.remoteValidate != null && (
            <>
              <Form.Item label="远程校验URL">
                <Input {...form.bind('remoteValidate.url')} />
              </Form.Item>

              <Form.Item label="方法">
                <Radio.Group
                  {...form.bind('remoteValidate.method')}
                  defaultValue="GET"
                >
                  <Radio key="GET" value="GET">
                    Get
                  </Radio>
                  <Radio key="POST" value="POST">
                    POST
                  </Radio>
                </Radio.Group>
              </Form.Item>

              <Form.Item
                label="远程校验参数"
                {...getItemErrorProps(form.errors['remoteValidate.params'])}
              >
                {visible && (
                  <CodeEditor
                    language="json"
                    height={200}
                    {...form.bind('remoteValidate.params', {
                      validate: validateJSON,
                    })}
                  />
                )}
              </Form.Item>

              <Form.Item label="错误信息">
                <Input
                  {...form.bind('remoteValidateMsg')}
                  placeholder="远程验证未通过"
                />
              </Form.Item>
            </>
          )}

          <Divider />

          <Form.Item label="最大长度">
            <InputNumber precision={0} min={1} {...form.bind('maxLength')} />
          </Form.Item>
        </Form>
      </Modal>
    );
  },
);
