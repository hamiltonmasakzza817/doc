import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { CompConfig } from '@gongzu/core/types/comps-common';
import { Form, InputNumber, Switch } from 'antd';
import get from 'lodash-es/get';

import { Observer } from 'mobx-react';
import React from 'react';

import ExpressionInput from '../../../components/ExpressionInput/ExpressionInput';

export default function TreeDataSourceForm(props: {
  form: MobxFormStore<CompConfig>;
  prefix: string;
}) {
  const { form, prefix } = props;

  return (
    <Observer>
      {() => (
        <>
          <Form.Item label="数据源">
            <ExpressionInput
              asPathname
              nonLeafOnly
              {...form.bind(`${prefix}.dataSource`, { onBlur: true })}
            />
          </Form.Item>

          <Form.Item label="异步加载">
            <Switch
              {...form.bind(`${prefix}.asyncLoad`)}
              checked={get(form.values, `${prefix}.asyncLoad`) === true}
            />
          </Form.Item>

          <Form.Item label="Children属性">
            <ExpressionInput
              asPathname
              arrayOnly
              {...form.bind(`${prefix}.childrenKey`, { onBlur: true })}
            />
          </Form.Item>

          <Form.Item label="是否叶子">
            <ExpressionInput
              {...form.bind(`${prefix}.isLeaf`, { onBlur: true })}
            />
          </Form.Item>

          <Form.Item label="值">
            <ExpressionInput
              leafOnly
              {...form.bind(`${prefix}.value`, { onBlur: true })}
            />
          </Form.Item>

          <Form.Item label="标题">
            <ExpressionInput
              {...form.bind(`${prefix}.name`, { onBlur: true })}
            />
          </Form.Item>

          <Form.Item label="展开节点">
            <ExpressionInput
              {...form.bind(`${prefix}.expandedKeys`, { onBlur: true })}
            />
          </Form.Item>

          <Form.Item label="默认展开">
            <InputNumber
              {...form.bind(`${prefix}.defaultExpandLevel`)}
              min={0}
              precision={0}
              placeholder="1"
            />
          </Form.Item>
        </>
      )}
    </Observer>
  );
}
