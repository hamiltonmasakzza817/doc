import { CompFormItem } from '@gongzu/core/types/comps-common';
import { NonUndefined, ValuesType } from 'utility-types';

export type Rule = NonUndefined<ValuesType<Pick<CompFormItem, 'rule'>>>;
