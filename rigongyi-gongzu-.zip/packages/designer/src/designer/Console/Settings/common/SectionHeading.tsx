import { Divider } from 'antd';
import React from 'react';

export function SectionHeading(props: { caption: string }) {
  const { caption } = props;

  return (
    <Divider>
      <div className="font-bold">{caption}</div>
    </Divider>
  );
}
