import { DeleteOutlined, PlusCircleOutlined } from '@ant-design/icons';
import {
  DesignerStoreContext,
  EngineStoresContext,
} from '@gongzu/core/contexts/store-contexts';
import { ActionBinding } from '@gongzu/core/types/comps-common';
import { ActionQueue, ActionQueueType } from '@gongzu/core/types/entities';
import { Modal } from 'antd';
import compact from 'lodash-es/compact';
import get from 'lodash-es/get';
import map from 'lodash-es/map';
import size from 'lodash-es/size';
import slice from 'lodash-es/slice';
import { observer } from 'mobx-react';
import React from 'react';
import ClickableText from '../../../../components/ClickableText';
import { addingId } from '../../../../config/constants';
import ActionQueueCard from '../../components/ActionQueueCard';
import ActionQueueDialog from '../../components/ActionQueueDialog';
import SettingsFormContext from '../context/SettingsFormContext';

export default observer(
  (props: { prefix: string; name: string; multiple?: boolean }) => {
    const { prefix, name, multiple = false } = props;

    const [actionQueueOpen, setActionQueueOpen] =
      React.useState<ActionQueue | null>(null);

    const actionQueueOpenIndex = React.useRef<number>(0);

    const form = React.useContext(SettingsFormContext);

    const designerStore = React.useContext(DesignerStoreContext);

    const { engineModelStore } = React.useContext(EngineStoresContext);

    if (!multiple) {
      let actionQueue = get(
        engineModelStore.actions,
        get(form.values, `${prefix}.actionId`),
      );

      if (actionQueue == null || actionQueue.type === ActionQueueType.GLOBAL) {
        actionQueue = {
          id: addingId,
          name,
          type: ActionQueueType.LOCAL,
          actions: [],
        };
      }

      return (
        <>
          <ActionQueueCard
            title={name}
            onEdit={() => setActionQueueOpen(actionQueue)}
            actionQueue={actionQueue}
            extra={
              actionQueue.id && actionQueue.id !== addingId ? (
                <ClickableText
                  className="ml-1 text-error"
                  onClick={() => {
                    Modal.confirm({
                      title: '是否删除该Action？',
                      content: actionQueue.name,
                      onOk: () => {
                        designerStore.deleteAction(actionQueue.id);
                        form.setValues({
                          [prefix]: null,
                        });
                      },
                    });
                  }}
                >
                  <DeleteOutlined />
                </ClickableText>
              ) : (
                <></>
              )
            }
          />

          <ActionQueueDialog
            actionQueue={actionQueueOpen}
            onCancel={() => setActionQueueOpen(null)}
            onSave={(id) => {
              form.setValues({
                [`${prefix}.actionId`]: id,
              });
            }}
          />
        </>
      );
    }

    let actionQueues = compact(
      map(get(form.values, prefix) as ActionBinding[], (actionBinding) =>
        get(engineModelStore.actions, actionBinding.actionId),
      ),
    );

    if (actionQueues.length === 0) {
      actionQueues = [
        {
          id: addingId,
          name: `${name}1`,
          type: ActionQueueType.LOCAL,
          actions: [],
        },
      ];
    }

    return (
      <>
        {actionQueues.map((actionQueue, index) => (
          <ActionQueueCard
            title={actionQueue.name}
            onEdit={() => {
              actionQueueOpenIndex.current = index;
              setActionQueueOpen(actionQueue);
            }}
            actionQueue={actionQueue}
            extra={
              actionQueue.id === addingId ? (
                <></>
              ) : (
                <>
                  <ClickableText
                    className="text-error"
                    onClick={() => {
                      Modal.confirm({
                        title: '是否删除该Action？',
                        content: actionQueue.name,
                        onOk: () => {
                          const aq = slice(get(form.values, prefix));
                          aq.splice(index, 1);
                          form.setValues({
                            [prefix]: aq,
                          });
                          designerStore.deleteAction(actionQueue.id);
                        },
                      });
                    }}
                  >
                    <DeleteOutlined />
                  </ClickableText>

                  <ClickableText
                    className="ml-1 text-error"
                    onClick={() => {
                      actionQueueOpenIndex.current = size(actionQueues);
                      setActionQueueOpen({
                        id: addingId,
                        name: `${name}${size(actionQueues) + 1}`,
                        type: ActionQueueType.LOCAL,
                        actions: [],
                      });
                    }}
                  >
                    <PlusCircleOutlined />
                  </ClickableText>
                </>
              )
            }
          />
        ))}

        <ActionQueueDialog
          actionQueue={actionQueueOpen}
          onCancel={() => setActionQueueOpen(null)}
          onSave={(id) => {
            form.setValues({
              [`${prefix}[${actionQueueOpenIndex.current}].actionId`]: id,
            });
          }}
        />
      </>
    );
  },
);
