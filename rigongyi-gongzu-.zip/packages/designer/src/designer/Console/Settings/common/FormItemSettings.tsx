import { DeleteOutlined } from '@ant-design/icons';
import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { CompConfig, CompFormItem } from '@gongzu/core/types/comps-common';
import { Form, Modal, Switch } from 'antd';
import { observer } from 'mobx-react';
import React from 'react';
import ClickableText from '../../../../components/ClickableText';
import CodeEditorCard from '../../../components/CodeEditorCard';
import ExpressionInput from '../../../components/ExpressionInput';
import SettingsFormContext from '../context/SettingsFormContext';
import FormItemRulesSettings from './FormItemRulesSettings/FormItemRulesSettings';

export default observer((props: {
  alwaysPure?: boolean
}) => {
  const { alwaysPure = false } = props;

  const form = React.useContext(SettingsFormContext) as MobxFormStore<
    CompConfig & CompFormItem
  >;

  return (
    <>
      {!alwaysPure && (
        <Form.Item className="block">
          <CodeEditorCard
            title="覆盖表单项属性"
            language="json"
            height={150}
            extra={
              <ClickableText
                onClick={() => {
                  Modal.confirm({
                    title: '删除提示',
                    content: '是否删除表单项覆盖属性',
                    onOk: () => {
                      form.setValues({
                        formItemRawProps: undefined,
                      });
                    },
                  });
                }}
              >
                <DeleteOutlined className="ml-1 text-error" />
              </ClickableText>
            }
            {...form.bind('formItemRawProps')}
          />
        </Form.Item>
      )}

      <FormItemRulesSettings />

      <Form.Item label="允许清空">
        <Switch checked={form.values.allowClear} {...form.bind('allowClear')} />
      </Form.Item>

      <Form.Item label="自动Focus">
        <Switch checked={form.values.autoFocus} {...form.bind('autoFocus')} />
      </Form.Item>

      {!alwaysPure && (
        <Form.Item label="纯录入组件">
          <Switch {...form.bind('pure')} checked={form.values.pure} />
        </Form.Item>
      )}

      <Form.Item label="单向绑定">
        <Switch
          {...form.bind('onWayBinding')}
          checked={form.values.onWayBinding}
        />
      </Form.Item>

      {!alwaysPure && !form.values.pure && (
        <>
          <Form.Item label="标签">
            <ExpressionInput {...form.bind('label.text', { onBlur: true })} />
          </Form.Item>

          <Form.Item label="备注">
            <ExpressionInput {...form.bind('extra', { onBlur: true })} />
          </Form.Item>
        </>
      )}

      <Form.Item label="禁用">
        <ExpressionInput {...form.bind('disabled', { onBlur: true })} />
      </Form.Item>

      <Form.Item label="只读">
        <ExpressionInput {...form.bind('readOnly', { onBlur: true })} />
      </Form.Item>

      <Form.Item label="占位符">
        <ExpressionInput {...form.bind('placeholder', { onBlur: true })} />
      </Form.Item>
    </>
  );
});
