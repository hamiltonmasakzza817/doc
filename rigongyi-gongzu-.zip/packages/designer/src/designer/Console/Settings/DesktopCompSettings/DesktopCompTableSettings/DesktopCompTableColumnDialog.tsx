import language from '@gongzu/core/config/language';
import useFormMobx from '@gongzu/core/mobx-form/useFormMobx';
import { getItemErrorProps } from '@gongzu/core/mobx-form/utils';
import { TextAlign } from '@gongzu/core/types/comps-common';
import { Form, Input, InputNumber, Modal, Radio, Switch } from 'antd';
import { ModalProps } from 'antd/es/modal';
import cloneDeep from 'lodash-es/cloneDeep';
import { observer } from 'mobx-react';
import React from 'react';
import { addingId } from '../../../../../config/constants';
import { dialogFormItemLayout } from '../../../../../config/layout';
import ExpressionInput from '../../../../components/ExpressionInput';
import CustomComponentSelect from '../../../components/CustomCompSelect';
import { TableColumn } from './types';

export default observer(
  (
    props: Pick<ModalProps, 'onCancel'> & {
      column: TableColumn | null;
      onSave: (column: TableColumn) => void;
    },
  ) => {
    const { onCancel, column, onSave } = props;

    const form = useFormMobx<TableColumn>({
      defaultValues: null,
    });

    React.useEffect(() => {
      if (column) {
        form.reset(cloneDeep(column));
      }
    }, [column]);

    return (
      <Modal
        title={form.values.id === addingId ? '新增栏目' : '修改栏目'}
        visible={column != null}
        onCancel={onCancel}
        onOk={(e) => {
          form.triggerValidation().subscribe((isValid) => {
            if (isValid) {
              onSave(form.values);

              if (onCancel) {
                onCancel(e);
              }
            }
          });
        }}
      >
        <Form {...dialogFormItemLayout}>
          <Form.Item
            label="标题"
            required
            {...getItemErrorProps(form.errors.title)}
          >
            <Input {...form.bind('title', { required: true, onBlur: true })} />
          </Form.Item>

          <Form.Item label="Key">
            <Input {...form.bind('key')} />
          </Form.Item>

          <Form.Item label="文字">
            <ExpressionInput {...form.bind('data', { onBlur: true })} />
          </Form.Item>

          <Form.Item label="自定义组件">
            <CustomComponentSelect {...form.bind('renderCompId')} showEmpty />
          </Form.Item>

          <Form.Item label="宽度">
            <InputNumber {...form.bind('width')} precision={0} min={0} />
          </Form.Item>

          <Form.Item label="对齐">
            <Radio.Group
              {...form.bind('align')}
              buttonStyle="solid"
              defaultValue={TextAlign.LEFT}
            >
              {[TextAlign.LEFT, TextAlign.CENTER, TextAlign.RIGHT].map(
                (align) => (
                  <Radio.Button key={align} value={align}>
                    {language.textAlign[align]}
                  </Radio.Button>
                ),
              )}
            </Radio.Group>
          </Form.Item>

          <Form.Item label="固定">
            <Radio.Group {...form.bind('fixed')} buttonStyle="solid">
              <Radio.Button value={undefined} key={0}>
                不固定
              </Radio.Button>
              <Radio.Button value="left" key={1}>
                左侧
              </Radio.Button>
              <Radio.Button value="right" key={2}>
                右侧
              </Radio.Button>
            </Radio.Group>
          </Form.Item>

          <Form.Item label="排序">
            <Switch {...form.bind('sorter')} checked={form.values.sorter} />
          </Form.Item>

          <Form.Item label="筛选">
            <ExpressionInput {...form.bind('filtered')} />
          </Form.Item>

          <Form.Item label="筛选值">
            <ExpressionInput {...form.bind('filteredValue')} />
          </Form.Item>

          <Form.Item label="筛选备选">
            <ExpressionInput {...form.bind('filters')} />
          </Form.Item>
        </Form>
      </Modal>
    );
  },
);
