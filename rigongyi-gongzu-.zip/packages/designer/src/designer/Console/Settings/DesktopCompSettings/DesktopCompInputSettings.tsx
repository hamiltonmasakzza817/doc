import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { DesktopCompInputConfig } from '@gongzu/core/types/comps-desktop';
import { Form, Input, Switch } from 'antd';
import { observer } from 'mobx-react';
import React from 'react';
import ExpressionInput from '../../../components/ExpressionInput';
import SettingsFormContext from '../context/SettingsFormContext';

export default observer(() => {
  const form = React.useContext(
    SettingsFormContext,
  ) as unknown as MobxFormStore<DesktopCompInputConfig>;

  return (
    <>
      <Form.Item label="搜索">
        <Switch {...form.bind('search')} checked={form.values.search} />
      </Form.Item>

      {form.values.search && (
        <Form.Item label="搜索按钮文字">
          <ExpressionInput {...form.bind('enterButton', { onBlur: true })} />
        </Form.Item>
      )}

      <Form.Item label="前缀">
        <Input {...form.bind('addonBefore', { onBlur: true })} />
      </Form.Item>

      <Form.Item label="后缀">
        <Input {...form.bind('addonAfter', { onBlur: true })} />
      </Form.Item>

      <Form.Item label="密码">
        <Switch {...form.bind('password')} checked={form.values.password} />
      </Form.Item>
    </>
  );
});
