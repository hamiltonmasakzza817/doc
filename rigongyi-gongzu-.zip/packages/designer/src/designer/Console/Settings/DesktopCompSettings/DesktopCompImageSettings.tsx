import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { DesktopCompImageConfig } from '@gongzu/core/types/comps-desktop';
import { Form, Switch } from 'antd';

import { observer } from 'mobx-react';
import React from 'react';
import ExpressionInput from '../../../components/ExpressionInput';
import ImageUploader from '../../../components/ImageUploader';
import SettingsFormContext from '../context/SettingsFormContext';

export default observer(() => {
  const form = React.useContext(
    SettingsFormContext,
  ) as unknown as MobxFormStore<DesktopCompImageConfig>;

  return (
    <>
      <Form.Item label="URL">
        <ExpressionInput {...form.bind('url', { onBlur: true })} leafOnly />
      </Form.Item>

      <Form.Item label="点击查看大图">
        <Switch {...form.bind('preview')} checked={form.values.preview} />
      </Form.Item>

      <Form.Item label="图片上传">
        <ImageUploader
          url={form.values.url}
          onChange={({ url }) => {
            form.setValues({ url });
          }}
        />
      </Form.Item>

      <Form.Item label="代替文字">
        <ExpressionInput {...form.bind('alt', { onBlur: true })} leafOnly />
      </Form.Item>

      <Form.Item label="默认图片">
        <ExpressionInput {...form.bind('altUrl', { onBlur: true })} leafOnly />
      </Form.Item>
    </>
  );
});
