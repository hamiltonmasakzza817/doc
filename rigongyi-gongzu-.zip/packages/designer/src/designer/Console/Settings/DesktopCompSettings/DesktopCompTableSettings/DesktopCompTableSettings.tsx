import { QuestionCircleOutlined } from '@ant-design/icons';
import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { DesktopCompTableConfig } from '@gongzu/core/types/comps-desktop';
import {
  Button,
  Form,
  Input,
  InputNumber,
  Modal,
  Radio,
  Switch,
  Tooltip,
} from 'antd';
import assign from 'lodash-es/assign';
import concat from 'lodash-es/concat';
import findIndex from 'lodash-es/findIndex';
import size from 'lodash-es/size';
import slice from 'lodash-es/slice';
import without from 'lodash-es/without';
import { observer } from 'mobx-react';
import React from 'react';
import { DragDropContext, Draggable, Droppable } from 'react-beautiful-dnd';
import { v4 as uuidv4 } from 'uuid';
import { addingId } from '../../../../../config/constants';
import CodeEditorCard from '../../../../components/CodeEditorCard';
import ExpressionInput from '../../../../components/ExpressionInput';
import { SectionHeading } from '../../common/SectionHeading';
import SettingsFormContext from '../../context/SettingsFormContext';
import DesktopCompTableColumnCard from './DesktopCompTableColumnCard';
import DesktopCompTableColumnDialog from './DesktopCompTableColumnDialog';
import { TableColumn } from './types';

export default observer(() => {
  const form = React.useContext(
    SettingsFormContext,
  ) as unknown as MobxFormStore<DesktopCompTableConfig>;

  const [columnEditing, setColumnEditing] = React.useState<TableColumn | null>(
    null,
  );

  return (
    <>
      <Form.Item label="数据源">
        <ExpressionInput
          {...form.bind('dataSource', { onBlur: true })}
          asPathname
        />
      </Form.Item>

      <Form.Item label="表体高度">
        <ExpressionInput {...form.bind('scrollY', { onBlur: true })} />
      </Form.Item>

      <Form.Item label="默认展开">
        <InputNumber
          {...form.bind('defaultExpandLevel')}
          min={0}
          precision={0}
          placeholder="1"
        />
      </Form.Item>

      <Form.Item label="主键" required>
        <Input {...form.bind('rowKey', { onBlur: true })} />
      </Form.Item>

      <Form.Item label="childrenKey" required>
        <Input {...form.bind('childrenKey', { onBlur: true })} />
      </Form.Item>

      <Form.Item label="Loading">
        <ExpressionInput {...form.bind('loading', { onBlur: true })} />
      </Form.Item>

      <Form.Item label="排序列">
        <ExpressionInput {...form.bind('sortKey', { onBlur: true })} />
      </Form.Item>

      <Form.Item label="排序方向">
        <ExpressionInput {...form.bind('sortOrder', { onBlur: true })} />
      </Form.Item>

      <SectionHeading caption="行选择" />

      <Form.Item label="类型">
        <Radio.Group {...form.bind('rowSelection.type')}>
          <Radio value="radio" key="radio">
            单选
          </Radio>
          <Radio value="checkbox" key="checkbox">
            多选
          </Radio>
        </Radio.Group>
      </Form.Item>

      <Form.Item label="值绑定地址">
        <ExpressionInput {...form.bind('rowSelection.value')} asPathname />
      </Form.Item>

      <SectionHeading caption="栏目" />

      <Form.Item label="使用配置">
        <Switch
          checked={form.values.columnOptions != null}
          onChange={(checked) => {
            if (checked) {
              form.setValues({
                columnOptions: {},
              });
            } else {
              Modal.confirm({
                title: '确认',
                content: '是否清空当前配置',
                onOk: () => {
                  form.setValues({
                    columnOptions: undefined,
                  });
                },
              });
            }
          }}
        />
      </Form.Item>

      {form.values.columnOptions != null ? (
        <>
          <CodeEditorCard
            title="栏目配置"
            language="json"
            height={150}
            {...form.bind('columnOptions')}
          />
        </>
      ) : (
        <>
          <div className="mb-2 break-all">
            <Button
              type="primary"
              onClick={() =>
                setColumnEditing({
                  id: addingId,
                  title: `栏目${size(form.values.columns) + 1}`,
                })
              }
              size="small"
            >
              新建
            </Button>

            {size(form.values.columns) > 1 && (
              <Tooltip title="拖动卡片进行排序">
                <QuestionCircleOutlined />
              </Tooltip>
            )}
          </div>

          <DragDropContext
            onDragEnd={(result) => {
              if (result.destination && result.source) {
                const columns = slice(form.values.columns);
                const fromIndex = result.source.index;
                const from = columns[fromIndex];
                const toIndex = result.destination.index;
                columns.splice(fromIndex, 1);
                columns.splice(toIndex, 0, from);
                form.setValues({ columns });
              }
            }}
          >
            <Droppable droppableId="droppable">
              {(provided) => (
                <div {...provided.droppableProps} ref={provided.innerRef}>
                  {form.values.columns?.map((column, index) => (
                    <Draggable
                      key={column.id}
                      draggableId={column.id}
                      index={index}
                    >
                      {(provided1) => (
                        <div
                          ref={provided1.innerRef}
                          {...provided1.draggableProps}
                          {...provided1.dragHandleProps}
                        >
                          <DesktopCompTableColumnCard
                            column={column}
                            index={index + 1}
                            onEdit={() => setColumnEditing(column)}
                            onDelete={() => {
                              Modal.confirm({
                                title: '是否删除栏目？',
                                content: column.title,
                                onOk: () => {
                                  form.setValues({
                                    columns: without(
                                      form.values.columns,
                                      column,
                                    ),
                                  });
                                },
                              });
                            }}
                            className="mb-3"
                            key={column.id}
                          />
                        </div>
                      )}
                    </Draggable>
                  ))}

                  {provided.placeholder}
                </div>
              )}
            </Droppable>
          </DragDropContext>
        </>
      )}

      <DesktopCompTableColumnDialog
        column={columnEditing}
        onCancel={() => setColumnEditing(null)}
        onSave={(column) => {
          if (column.id === addingId) {
            form.setValues({
              columns: concat(
                form.values.columns,
                assign({}, column, { id: uuidv4() }),
              ),
            });
          } else {
            const columns = [...form.values.columns];

            const index = findIndex(columns, (c) => c.id === column.id);

            columns.splice(index, 1, column);

            form.setValues({
              columns,
            });
          }
        }}
      />
    </>
  );
});
