import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { DesktopCompCheckboxConfig } from '@gongzu/core/types/comps-desktop';
import { Form, Switch } from 'antd';
import { observer } from 'mobx-react';
import React from 'react';
import SettingsFormContext from '../context/SettingsFormContext';

export default observer(() => {
  const form = React.useContext(
    SettingsFormContext,
  ) as unknown as MobxFormStore<DesktopCompCheckboxConfig>;

  return (
    <Form.Item label="自定义选项">
      <Switch {...form.bind('custom')} checked={form.values.custom} />
    </Form.Item>
  );
});
