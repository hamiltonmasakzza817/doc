import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { CompConfig } from '@gongzu/core/types/comps-common';
import { DesktopCompTreeConfig } from '@gongzu/core/types/comps-desktop';
import { Form } from 'antd';
import { observer } from 'mobx-react';
import React from 'react';
import ExpressionInput from '../../../components/ExpressionInput';
import CustomComponentSelect from '../../components/CustomCompSelect';
import TreeDataSourceForm from '../common/TreeDataSourceForm';
import SettingsFormContext from '../context/SettingsFormContext';

export default observer(() => {
  const form = React.useContext(
    SettingsFormContext,
  ) as unknown as MobxFormStore<DesktopCompTreeConfig>;

  return (
    <>
      <TreeDataSourceForm
        form={form as unknown as MobxFormStore<CompConfig>}
        prefix="tree"
      />

      <Form.Item label="自定义组件">
        <CustomComponentSelect {...form.bind('renderCompId')} showEmpty />
      </Form.Item>

      <Form.Item label="选中值">
        <ExpressionInput {...form.bind('selectedKeys', { onBlur: true })} />
      </Form.Item>
    </>
  );
});
