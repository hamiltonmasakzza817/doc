import { EditOutlined } from '@ant-design/icons';
import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { DesktopCompParagraphConfig } from '@gongzu/core/types/comps-desktop';
import { Card } from 'antd';
import DOMPurify from 'dompurify';
import { observer } from 'mobx-react';
import React from 'react';
import ClickableText from '../../../../components/ClickableText';
import RichTextDialog from '../common/RichTextEditorDialog';
import SettingsFormContext from '../context/SettingsFormContext';

export default observer(() => {
  const form = React.useContext(
    SettingsFormContext,
  ) as unknown as MobxFormStore<DesktopCompParagraphConfig>;

  const [showText, setShowText] = React.useState<string | undefined>();

  return (
    <>
      <Card
        size="small"
        type="inner"
        title="文字"
        extra={
          <ClickableText
            className="text-primary"
            onClick={() => setShowText(form.values.text)}
          >
            <EditOutlined />
          </ClickableText>
        }
      >
        <div
          className="overflow-x-auto"
          dangerouslySetInnerHTML={{
            __html: DOMPurify.sanitize(form.values.text || '--'),
          }}
        />
      </Card>

      <RichTextDialog
        text={showText}
        onCancel={() => {
          setShowText(undefined);
        }}
        onSave={(value) => {
          form.setValues({ text: value });
          setShowText(undefined);
        }}
      />
    </>
  );
});
