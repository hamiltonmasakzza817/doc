export { default } from './DesktopCompSettings';
