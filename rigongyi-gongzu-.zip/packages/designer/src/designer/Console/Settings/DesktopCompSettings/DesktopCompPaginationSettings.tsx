import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { DesktopCompPaginationConfig } from '@gongzu/core/types/comps-desktop';
import { Form } from 'antd';
import { observer } from 'mobx-react';
import React from 'react';
import ExpressionInput from '../../../components/ExpressionInput';
import SettingsFormContext from '../context/SettingsFormContext';

export default observer(() => {
  const form = React.useContext(
    SettingsFormContext,
  ) as unknown as MobxFormStore<DesktopCompPaginationConfig>;

  return (
    <>
      <Form.Item label="页码">
        <ExpressionInput {...form.bind('page', { onBlur: true })} />
      </Form.Item>

      <Form.Item label="总页数">
        <ExpressionInput {...form.bind('totalPage', { onBlur: true })} />
      </Form.Item>

      <Form.Item label="总数量">
        <ExpressionInput {...form.bind('total', { onBlur: true })} />
      </Form.Item>

      <Form.Item label="每页数量">
        <ExpressionInput {...form.bind('pageSize', { onBlur: true })} />
      </Form.Item>
    </>
  );
});
