import { formItemCompTypes } from '@gongzu/core/config/comps';
import language from '@gongzu/core/config/language';
import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { TextAlign } from '@gongzu/core/types/comps-common';
import {
  DesktopCompConfig,
  DesktopCompType,
} from '@gongzu/core/types/comps-desktop';
import { Form, Input, Select } from 'antd';
import range from 'lodash-es/range';
import { observer } from 'mobx-react';
import React from 'react';
import ExpressionInput from '../../../components/ExpressionInput/ExpressionInput';
import SettingsFormContext from '../context/SettingsFormContext';
import DesktopCompButtonSettings from './DesktopCompButtonSettings';
import DesktopCompContainerSettings from './DesktopCompContainerSettings';
import DesktopCompDropdownMenuSettings from './DesktopCompDropdownMenuSettings';
import DesktopCompFormItemSettings from './DesktopCompFormItemSettings';
import DesktopCompIconSettings from './DesktopCompIconSettings';
import DesktopCompImageSettings from './DesktopCompImageSettings';
import DesktopCompMarkdownSettings from './DesktopCompMarkdownSettings';
import DesktopCompMenuSettings from './DesktopCompMenuSettings';
import DesktopCompModalSettings from './DesktopCompModalSettings';
import DesktopCompPaginationSettings from './DesktopCompPaginationSettings';
import DesktopCompParagraphSettings from './DesktopCompParagraphSettings';
import DesktopCompProgressSettings from './DesktopCompProgressSettings';
import DesktopCompStepsSettings from './DesktopCompStepsSettings';
import DesktopCompTableSettings from './DesktopCompTableSettings';
import DesktopCompTabsSettings from './DesktopCompTabsSettings';
import DesktopCompTagSettings from './DesktopCompTagSettings';
import DesktopCompTreeSettings from './DesktopCompTreeSettings';

export default observer(() => {
  const form = React.useContext(
    SettingsFormContext,
  ) as MobxFormStore<DesktopCompConfig>;

  if (
    formItemCompTypes.includes(form.values.type) ||
    form.values.type === DesktopCompType.FORM
  ) {
    return (
      <>
        <Form.Item label="表单名">
          <Input {...form.bind('name', { onBlur: true })} />
        </Form.Item>

        <Form.Item label="标签宽度">
          <Select
            allowClear
            {...form.bind('label.span')}
            options={range(1, 25).map((n) => ({
              label: `${n}/24个单元`,
              value: n,
            }))}
          />
        </Form.Item>

        <Form.Item label="标签对齐">
          <Select
            {...form.bind('label.align')}
            defaultValue={TextAlign.LEFT}
            options={[TextAlign.LEFT, TextAlign.RIGHT].map((align) => ({
              label: language.textAlign[align],
              value: align,
            }))}
          />
        </Form.Item>

        <Form.Item label="值绑定地址">
          <ExpressionInput
            {...form.bind('value', { onBlur: true })}
            asPathname
          />
        </Form.Item>

        {formItemCompTypes.includes(form.values.type) && (
          <DesktopCompFormItemSettings />
        )}
      </>
    );
  }

  switch (form.values.type) {
    case DesktopCompType.CONTAINER: {
      return <DesktopCompContainerSettings />;
    }

    case DesktopCompType.BUTTON: {
      return <DesktopCompButtonSettings />;
    }

    case DesktopCompType.PARAGRAPH: {
      return <DesktopCompParagraphSettings />;
    }

    case DesktopCompType.TABLE: {
      return <DesktopCompTableSettings />;
    }

    case DesktopCompType.MODAL: {
      return <DesktopCompModalSettings />;
    }

    case DesktopCompType.PAGINATION: {
      return <DesktopCompPaginationSettings />;
    }

    case DesktopCompType.TABS: {
      return <DesktopCompTabsSettings />;
    }

    case DesktopCompType.IMAGE: {
      return <DesktopCompImageSettings />;
    }

    case DesktopCompType.TREE: {
      return <DesktopCompTreeSettings />;
    }

    case DesktopCompType.ICON: {
      return <DesktopCompIconSettings />;
    }

    case DesktopCompType.TAG: {
      return <DesktopCompTagSettings />;
    }

    case DesktopCompType.MENU: {
      return <DesktopCompMenuSettings />;
    }

    case DesktopCompType.PROGRESS: {
      return <DesktopCompProgressSettings />;
    }

    case DesktopCompType.DROPDOWN_MENU: {
      return <DesktopCompDropdownMenuSettings />;
    }

    case DesktopCompType.STEPS: {
      return <DesktopCompStepsSettings />;
    }

    case DesktopCompType.MARKDOWN: {
      return <DesktopCompMarkdownSettings />;
    }

    default: {
      return <></>;
    }
  }
});
