export { default } from './DesktopCompTableSettings';
