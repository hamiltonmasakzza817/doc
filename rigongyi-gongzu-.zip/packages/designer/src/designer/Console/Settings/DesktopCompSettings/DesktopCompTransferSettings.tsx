import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { DesktopCompTransferConfig } from '@gongzu/core/types/comps-desktop';
import { Form } from 'antd';
import { observer } from 'mobx-react';
import React from 'react';
import ExpressionInput from '../../../components/ExpressionInput';
import SettingsFormContext from '../context/SettingsFormContext';

export default observer(() => {
  const form = React.useContext(
    SettingsFormContext,
  ) as unknown as MobxFormStore<DesktopCompTransferConfig>;

  return (
    <>
      <Form.Item label="原标题">
        <ExpressionInput {...form.bind('titles.source')} />
      </Form.Item>

      <Form.Item label="目标标题">
        <ExpressionInput {...form.bind('titles.target')} />
      </Form.Item>
    </>
  );
});
