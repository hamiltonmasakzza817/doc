import language from '@gongzu/core/config/language';
import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { TimeUnit } from '@gongzu/core/types/comps-common';
import { DesktopCompDatePickerConfig } from '@gongzu/core/types/comps-desktop';
import { Form, Input, Select, Switch } from 'antd';

import { observer } from 'mobx-react';
import React from 'react';
import SettingsFormContext from '../context/SettingsFormContext';

export default observer(() => {
  const form = React.useContext(
    SettingsFormContext,
  ) as unknown as MobxFormStore<DesktopCompDatePickerConfig>;

  return (
    <>
      <Form.Item label="时间单位">
        <Select {...form.bind('timeUnit')}>
          {[
            TimeUnit.DATE,
            TimeUnit.WEEK,
            TimeUnit.MONTH,
            TimeUnit.QUARTER,
            TimeUnit.YEAR,
          ].map((tu) => (
            <Select.Option key={tu} value={tu}>
              {language.timeUnit[tu]}
            </Select.Option>
          ))}
        </Select>
      </Form.Item>

      <Form.Item label="使用区间">
        <Switch {...form.bind('isRange')} checked={form.values.isRange} />
      </Form.Item>

      <Form.Item label="格式化">
        <Input {...form.bind('format', { onBlur: true })} />
      </Form.Item>
    </>
  );
});
