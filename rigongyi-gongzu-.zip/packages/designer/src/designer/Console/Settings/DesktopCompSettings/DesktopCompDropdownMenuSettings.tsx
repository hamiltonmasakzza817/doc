import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { CompConfig } from '@gongzu/core/types/comps-common';
import { DesktopCompDropdownMenuConfig } from '@gongzu/core/types/comps-desktop';
import { Form, Select } from 'antd';
import { observer } from 'mobx-react';
import React from 'react';
import TreeDataSourceForm from '../common/TreeDataSourceForm';
import SettingsFormContext from '../context/SettingsFormContext';

export default observer(() => {
  const form = React.useContext(
    SettingsFormContext,
  ) as unknown as MobxFormStore<DesktopCompDropdownMenuConfig>;

  return (
    <>
      <Form.Item label="下拉触发方式">
        <Select allowClear {...form.bind('dropdownTrigger')}>
          {[
            ['hover', '滑过'],
            ['click', '点击'],
            ['contextMenu', '右键'],
          ].map((trigger) => (
            <Select.Option key={trigger[0]} value={trigger[0]}>
              {trigger[1]}
            </Select.Option>
          ))}
        </Select>
      </Form.Item>

      <Form.Item label="定位">
        <Select allowClear {...form.bind('placement')}>
          {[
            'bottomLeft',
            'bottomCenter',
            'bottomRight',
            'topLeft',
            'topCenter',
            'topCenter',
          ].map((placement) => (
            <Select.Option key={placement} value={placement}>
              {placement}
            </Select.Option>
          ))}
        </Select>
      </Form.Item>

      <TreeDataSourceForm
        form={form as MobxFormStore<CompConfig>}
        prefix="tree"
      />
    </>
  );
});
