import { PlusCircleOutlined } from '@ant-design/icons';
import { gzdnBem } from '@gongzu/core/config/constants';
import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import {
  DesktopCompContainerConfig,
  DesktopCompTabsConfig,
  DesktopCompType,
} from '@gongzu/core/types/comps-desktop';
import { Form, Select } from 'antd';
import size from 'lodash-es/size';
import { observer } from 'mobx-react';
import React from 'react';
import { v4 as uuidv4 } from 'uuid';
import ClickableText from '../../../../components/ClickableText';
import ExpressionInput from '../../../components/ExpressionInput';
import CustomComponentSelect from '../../components/CustomCompSelect';
import SettingsFormContext from '../context/SettingsFormContext';

export default observer(() => {
  const form = React.useContext(
    SettingsFormContext,
  ) as unknown as MobxFormStore<DesktopCompTabsConfig>;

  return (
    <>
      <Form.Item label="当前页">
        <ExpressionInput {...form.bind('activeKey')} leafOnly />
      </Form.Item>

      <Form.Item label="标签组类型">
        <Select allowClear {...form.bind('tabsType')}>
          {['line', 'card'].map((t) => (
            <Select.Option key={t} value={t}>
              {t}
            </Select.Option>
          ))}
        </Select>
      </Form.Item>

      <Form.Item label="TabBar额外">
        <CustomComponentSelect {...form.bind('tabBarExtraContent')} showEmpty />
      </Form.Item>

      <Form.Item label="增加页签">
        <ClickableText
          onClick={() => {
            const id = uuidv4();
            form.setValues({
              children: [
                ...(form.values.children ?? []),
                {
                  id,
                  pathname: `${form.values.pathname},${id}`,
                  parentId: `${form.values.id}`,
                  type: DesktopCompType.CONTAINER,
                  name: `标签${size(form.values.children) + 1}`,
                } as DesktopCompContainerConfig,
              ],
            });
          }}
          className={gzdnBem('clickable-icon')}
        >
          <PlusCircleOutlined />
        </ClickableText>
      </Form.Item>
    </>
  );
});
