import { QuestionCircleOutlined } from '@ant-design/icons';
import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import {
  DesktopCompSelectConfig,
  DesktopCompTreeSelectConfig,
} from '@gongzu/core/types/comps-desktop';
import { Form, Select, Switch, Tooltip } from 'antd';
import { observer } from 'mobx-react';
import React from 'react';
import SettingsFormContext from '../context/SettingsFormContext';

export default observer(() => {
  const form = React.useContext(
    SettingsFormContext,
  ) as unknown as MobxFormStore<
    DesktopCompSelectConfig | DesktopCompTreeSelectConfig
  >;

  return (
    <>
      <Form.Item
        label={
          <span>
            labelInValue&nbsp;
            <Tooltip title="是否把每个选项的 label 包装到 value 中，其绑定数据格式必须为 { value: string, label: string }">
              <QuestionCircleOutlined />
            </Tooltip>
          </span>
        }
      >
        <Switch
          {...form.bind('labelInValue')}
          checked={form.values.labelInValue}
        />
      </Form.Item>

      <Form.Item label="模式">
        <Select allowClear {...form.bind('mode')}>
          {[
            ['multiple', '多选'],
            ['tags', 'tags'],
          ].map((opt) => (
            <Select.Option key={opt[0]} value={opt[0]}>
              {opt[1]}
            </Select.Option>
          ))}
        </Select>
      </Form.Item>
    </>
  );
});
