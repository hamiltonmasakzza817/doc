import { DeleteOutlined, EditOutlined } from '@ant-design/icons';
import language from '@gongzu/core/config/language';
import { EngineStoresContext } from '@gongzu/core/contexts/store-contexts';
import { Card } from 'antd';
import { observer, Observer } from 'mobx-react';
import React from 'react';
import ClickableText from '../../../../../components/ClickableText';
import { TableColumn } from './types';

export default observer(
  (props: {
    column: TableColumn;
    onEdit: () => void;
    onDelete: () => void;
    index: number;
    className?: string;
  }) => {
    const { column, onEdit, onDelete, className, index } = props;

    const { engineModelStore } = React.useContext(EngineStoresContext);

    return (
      <Card
        size="small"
        type="inner"
        title={`${index}. ${column.title}`}
        className={className}
        extra={
          <>
            <ClickableText className="text-primary" onClick={onEdit}>
              <EditOutlined />
            </ClickableText>

            <ClickableText className="ml-1 text-error" onClick={onDelete}>
              <DeleteOutlined />
            </ClickableText>
          </>
        }
      >
        <div>标题：{column.title || '--'}</div>

        {column.key && <div>Key: {column.key}</div>}

        <div className="break-all">文字：{column.data || '无'}</div>

        {column.renderCompId != null && (
          <Observer>
            {() => {
              const component = engineModelStore.customs[column.renderCompId!];
              return <div>自定义组件：{component?.name}</div>;
            }}
          </Observer>
        )}

        {column.width != null && <div>宽度：{column.width}</div>}

        {column.align != null && (
          <div>对齐：{language.textAlign[column.align]}</div>
        )}

        {column.sorter && <div>参与排序</div>}
      </Card>
    );
  },
);
