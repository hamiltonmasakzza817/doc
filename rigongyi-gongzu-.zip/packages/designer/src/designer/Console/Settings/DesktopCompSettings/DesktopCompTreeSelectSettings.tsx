import { QuestionCircleOutlined } from '@ant-design/icons';
import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { DesktopCompTreeSelectConfig } from '@gongzu/core/types/comps-desktop';
import { Form, Switch, Tooltip } from 'antd';
import get from 'lodash-es/get';

import { observer } from 'mobx-react';
import React from 'react';
import SettingsFormContext from '../context/SettingsFormContext';

export default observer(() => {
  const form = React.useContext(
    SettingsFormContext,
  ) as unknown as MobxFormStore<DesktopCompTreeSelectConfig>;

  return (
    <>
      <Form.Item
        label={
          <span>
            labelInValue&nbsp;
            <Tooltip title="是否把每个选项的 label 包装到 value 中，其绑定数据格式必须为 { value: string, label: string }">
              <QuestionCircleOutlined />
            </Tooltip>
          </span>
        }
      >
        <Switch
          {...form.bind('labelInValue')}
          checked={form.values.labelInValue}
        />
      </Form.Item>

      <Form.Item label="多选">
        <Switch
          {...form.bind('multiple')}
          checked={get(form.values, 'multiple')}
        />
      </Form.Item>
    </>
  );
});
