import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { DesktopCompProgressConfig } from '@gongzu/core/types/comps-desktop';
import { Form, Input } from 'antd';
import { observer } from 'mobx-react';
import React from 'react';
import ExpressionInput from '../../../components/ExpressionInput';
import SettingsFormContext from '../context/SettingsFormContext';

export default observer(() => {
  const form = React.useContext(
    SettingsFormContext,
  ) as unknown as MobxFormStore<DesktopCompProgressConfig>;

  return (
    <>
      <Form.Item label="值">
        <ExpressionInput {...form.bind('value', { onBlur: true })} />
      </Form.Item>

      <Form.Item label="填充颜色">
        <Input {...form.bind('strokeColor', { onBlur: true })} />
      </Form.Item>

      <Form.Item label="尾部颜色">
        <Input {...form.bind('trailColor', { onBlur: true })} />
      </Form.Item>
    </>
  );
});
