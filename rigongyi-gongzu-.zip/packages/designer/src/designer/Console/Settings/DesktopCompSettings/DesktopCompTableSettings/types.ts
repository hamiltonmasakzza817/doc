import { DesktopCompTableConfig } from '@gongzu/core/types/comps-desktop';
import { ValuesType } from 'utility-types';

export type TableColumn = ValuesType<
  ValuesType<Pick<DesktopCompTableConfig, 'columns'>>
>;
