import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { DesktopCompButtonConfig } from '@gongzu/core/types/comps-desktop';
import { Form, Select, Switch } from 'antd';
import { ButtonType } from 'antd/es/button';
import { observer } from 'mobx-react';
import React from 'react';
import ExpressionInput from '../../../components/ExpressionInput';
import CustomComponentSelect from '../../components/CustomCompSelect';
import SettingsFormContext from '../context/SettingsFormContext';

export default observer(() => {
  const form = React.useContext(
    SettingsFormContext,
  ) as unknown as MobxFormStore<DesktopCompButtonConfig>;

  return (
    <>
      <Form.Item label="文本">
        <ExpressionInput {...form.bind('text', { onBlur: true })} />
      </Form.Item>

      <Form.Item label="自定义组件">
        <CustomComponentSelect {...form.bind('renderCompId')} showEmpty />
      </Form.Item>

      <Form.Item label="按钮类型">
        <Select {...form.bind('buttonType')}>
          {(
            [
              'default',
              'primary',
              'danger',
              'dashed',
              'link',
              'text',
            ] as ButtonType[]
          ).map((buttonType) => (
            <Select.Option key={buttonType} value={buttonType}>
              {buttonType}
            </Select.Option>
          ))}
        </Select>
      </Form.Item>

      <Form.Item label="镂空">
        <Switch
          checked={form.values.ghost}
          onChange={(checked) => form.setValues({ ghost: checked })}
        />
      </Form.Item>

      <Form.Item label="禁用">
        <ExpressionInput
          leafOnly
          {...form.bind('disabled', { onBlur: true })}
        />
      </Form.Item>
    </>
  );
});
