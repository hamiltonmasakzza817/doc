import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { DesktopCompModalConfig } from '@gongzu/core/types/comps-desktop';
import { Form, Radio, Switch } from 'antd';
import { observer } from 'mobx-react';
import React from 'react';
import { emptyOption } from '../../../../config/constants';
import ExpressionInput from '../../../components/ExpressionInput';
import CustomComponentSelect from '../../components/CustomCompSelect';
import SettingsFormContext from '../context/SettingsFormContext';

export default observer(() => {
  const form = React.useContext(
    SettingsFormContext,
  ) as unknown as MobxFormStore<DesktopCompModalConfig>;

  return (
    <>
      <Form.Item label="类型">
        <Radio.Group
          defaultValue="MODAL"
          options={['MODAL', 'DRAWER'].map((k) => ({
            value: k,
            label: k,
          }))}
          {...form.bind('displayType')}
        />
      </Form.Item>

      <Form.Item label="标题">
        <ExpressionInput {...form.bind('title')} />
      </Form.Item>

      <Form.Item label="蒙层关闭">
        <Switch
          {...form.bind('maskClosable')}
          checked={form.values.maskClosable !== false}
        />
      </Form.Item>

      <Form.Item label="关闭页面后销毁">
        <Switch
          {...form.bind('destroyOnClose')}
          checked={form.values.destroyOnClose}
        />
      </Form.Item>

      <Form.Item label="自定义标题">
        <CustomComponentSelect {...form.bind('titleRenderCompId')} showEmpty />
      </Form.Item>

      <Form.Item label="垂直居中">
        <Switch {...form.bind('centered')} checked={form.values.centered} />
      </Form.Item>

      <Form.Item label="关闭动画">
        <Switch
          {...form.bind('disableTransition')}
          checked={form.values.disableTransition}
        />
      </Form.Item>

      <Form.Item label="Footer">
        <CustomComponentSelect
          {...form.bind('footer')}
          additionSelections={[
            { title: '不渲染Footer', key: emptyOption, value: emptyOption },
          ]}
        />
      </Form.Item>
    </>
  );
});
