import { QuestionCircleOutlined } from '@ant-design/icons';
import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { CompConfig } from '@gongzu/core/types/comps-common';
import { DesktopCompMenuConfig } from '@gongzu/core/types/comps-desktop';
import { Form, Select, Tooltip } from 'antd';
import { observer } from 'mobx-react';
import React from 'react';
import ExpressionInput from '../../../components/ExpressionInput';
import TreeDataSourceForm from '../common/TreeDataSourceForm';
import SettingsFormContext from '../context/SettingsFormContext';

export default observer(() => {
  const form = React.useContext(
    SettingsFormContext,
  ) as unknown as MobxFormStore<DesktopCompMenuConfig>;

  return (
    <>
      <TreeDataSourceForm
        form={form as unknown as MobxFormStore<CompConfig>}
        prefix="tree"
      />

      <Form.Item label="URL">
        <ExpressionInput leafOnly {...form.bind('url', { onBlur: true })} />
      </Form.Item>

      <Form.Item label="使用PushState">
        <ExpressionInput
          leafOnly
          {...form.bind('usePushState', { onBlur: true })}
        />
      </Form.Item>

      <Form.Item label="新窗口打开">
        <ExpressionInput
          leafOnly
          {...form.bind('targetBlank', { onBlur: true })}
        />
      </Form.Item>

      <Form.Item label="是否选中">
        <ExpressionInput
          leafOnly
          {...form.bind('selected', { onBlur: true })}
        />
      </Form.Item>

      <Form.Item label="模式">
        <Select {...form.bind('mode')}>
          {['vertical', 'inline', 'horizontal'].map((m) => (
            <Select.Option key={m} value={m}>
              {m}
            </Select.Option>
          ))}
        </Select>
      </Form.Item>

      <Form.Item
        label={
          <span>
            父级默认模式&nbsp;
            <Tooltip
              title={
                <div>
                  当默认选中子菜单时，父级菜单是否默认展开。一般当模式为“inline”时推荐默认展开
                </div>
              }
            >
              <QuestionCircleOutlined />
            </Tooltip>
          </span>
        }
      >
        <Select {...form.bind('openParent')}>
          {[
            { value: 1, label: '展开' },
            { value: 0, label: '关闭' },
          ].map((m) => (
            <Select.Option key={m.value} value={m.value}>
              {m.label}
            </Select.Option>
          ))}
        </Select>
      </Form.Item>

      <Form.Item label="主题">
        <Select {...form.bind('theme')}>
          {['dark', 'light'].map((m) => (
            <Select.Option key={m} value={m}>
              {m}
            </Select.Option>
          ))}
        </Select>
      </Form.Item>

      <Form.Item label="子菜单触发方式">
        <Select {...form.bind('triggerSubMenuAction')}>
          {[
            {
              value: 'hover',
              label: '悬浮',
            },
            {
              value: 'click',
              label: '点击',
            },
          ].map((m) => (
            <Select.Option key={m.value} value={m.value}>
              {m.label}
            </Select.Option>
          ))}
        </Select>
      </Form.Item>
    </>
  );
});
