import { QuestionCircleOutlined } from '@ant-design/icons';
import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { CompFormItem } from '@gongzu/core/types/comps-common';
import {
  DesktopCompConfig,
  DesktopCompType,
} from '@gongzu/core/types/comps-desktop';
import { Form, Switch, Tooltip } from 'antd';
import get from 'lodash-es/get';

import { observer, Observer } from 'mobx-react';
import React from 'react';
import ExpressionInput from '../../../components/ExpressionInput/ExpressionInput';
import UploaderSettingsForm from '../common/CompUploaderSettings';
import FormItemSettings from '../common/FormItemSettings';
import { SectionHeading } from '../common/SectionHeading';
import TreeDataSourceForm from '../common/TreeDataSourceForm';
import SettingsFormContext from '../context/SettingsFormContext';
import DesktopCompCheckboxSettings from './DesktopCompCheckboxSettings';
import DesktopCompDatePickerSettings from './DesktopCompDatePickerSettings';
import DesktopCompInputSettings from './DesktopCompInputSettings';
import DesktopCompNumberInputSettings from './DesktopCompNumberInputSettings';
import DesktopCompRadioSettings from './DesktopCompRadioSettings';
import DesktopCompSelectSettings from './DesktopCompSelectSettings';
import DesktopCompSliderSettings from './DesktopCompSliderSettings';
import DesktopCompSwitchSettings from './DesktopCompSwitchSettings';
import DesktopCompTransferSettings from './DesktopCompTransferSettings';
import DesktopCompTreeSelectSettings from './DesktopCompTreeSelectSettings';

export default observer(() => {
  const form = React.useContext(
    SettingsFormContext,
  ) as unknown as MobxFormStore<DesktopCompConfig & CompFormItem>;

  return (
    <>
      <FormItemSettings />

      <Observer>
        {() => {
          switch (form.values.type) {
            case DesktopCompType.INPUT:
              return <DesktopCompInputSettings />;

            case DesktopCompType.NUMBER_INPUT:
              return <DesktopCompNumberInputSettings />;

            case DesktopCompType.SELECT:
              return <DesktopCompSelectSettings />;

            case DesktopCompType.TREE_SELECT:
              return <DesktopCompTreeSelectSettings />;

            case DesktopCompType.DATE_PICKER:
              return <DesktopCompDatePickerSettings />;

            case DesktopCompType.CHECKBOX:
              return <DesktopCompCheckboxSettings />;

            case DesktopCompType.RADIO:
              return <DesktopCompRadioSettings />;

            case DesktopCompType.UPLOADER:
              return <UploaderSettingsForm />;

            case DesktopCompType.TRANSFER:
              return <DesktopCompTransferSettings />;

            case DesktopCompType.SWITCH:
              return <DesktopCompSwitchSettings />;

            case DesktopCompType.SLIDER:
              return <DesktopCompSliderSettings />;

            default:
              return <></>;
          }
        }}
      </Observer>

      {/* 有备选项的组件 */}
      {[
        DesktopCompType.CHECKBOX,
        DesktopCompType.SELECT,
        DesktopCompType.RADIO,
        DesktopCompType.TREE_SELECT,
        DesktopCompType.CASCADER,
        DesktopCompType.TRANSFER,
      ].includes(form.values.type as DesktopCompType) && (
        <>
          <SectionHeading caption="备选项" />

          {/* 数组备选项 */}
          {[
            DesktopCompType.CHECKBOX,
            DesktopCompType.SELECT,
            DesktopCompType.RADIO,
            DesktopCompType.TRANSFER,
          ].includes(form.values.type as DesktopCompType) && (
            <>
              <Form.Item label="数据源">
                <ExpressionInput
                  asPathname
                  nonLeafOnly
                  {...form.bind('options.dataSource', { onBlur: true })}
                />
              </Form.Item>

              <Form.Item label="标题">
                <ExpressionInput
                  {...form.bind('options.name', { onBlur: true })}
                />
              </Form.Item>

              {form.values.type === DesktopCompType.SELECT && (
                <Form.Item
                  label={
                    <span>
                      选中标题&nbsp;
                      <Tooltip title="若不填，则显示标题">
                        <QuestionCircleOutlined />
                      </Tooltip>
                    </span>
                  }
                >
                  <ExpressionInput
                    {...form.bind('options.label', { onBlur: true })}
                  />
                </Form.Item>
              )}

              <Form.Item label="值">
                <ExpressionInput
                  {...form.bind('options.value', { onBlur: true })}
                />
              </Form.Item>
            </>
          )}

          {/* 树备选项 */}
          {[DesktopCompType.TREE_SELECT, DesktopCompType.CASCADER].includes(
            form.values.type as DesktopCompType,
          ) && <TreeDataSourceForm form={form} prefix="options" />}

          <Form.Item label="禁用">
            <ExpressionInput
              {...form.bind('options.disabled', { onBlur: true })}
            />
          </Form.Item>

          {/* 备选项搜索 */}
          {[DesktopCompType.SELECT, DesktopCompType.TREE_SELECT].includes(
            form.values.type as DesktopCompType,
          ) && (
            <>
              <Form.Item label="本地过滤">
                <Switch
                  {...form.bind('search')}
                  checked={get(form.values, 'search') !== false}
                />
              </Form.Item>

              <Form.Item label="搜索loading">
                <ExpressionInput {...form.bind('loading', { onBlur: true })} />
              </Form.Item>
            </>
          )}
        </>
      )}
    </>
  );
});
