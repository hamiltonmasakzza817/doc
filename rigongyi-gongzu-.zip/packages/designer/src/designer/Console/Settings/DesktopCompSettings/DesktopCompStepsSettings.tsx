import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { DesktopCompStepsConfig } from '@gongzu/core/types/comps-desktop';
import { Form } from 'antd';
import { observer } from 'mobx-react';
import React from 'react';
import ExpressionInput from '../../../components/ExpressionInput';
import SettingsFormContext from '../context/SettingsFormContext';

export default observer(() => {
  const form = React.useContext(
    SettingsFormContext,
  ) as unknown as MobxFormStore<DesktopCompStepsConfig>;

  return (
    <>
      <Form.Item label="数据源">
        <ExpressionInput
          asPathname
          arrayOnly
          {...form.bind('dataSource', { onBlur: true })}
        />
      </Form.Item>

      <Form.Item label="当前步骤">
        <ExpressionInput {...form.bind('current', { onBlur: true })} />
      </Form.Item>

      <Form.Item label="标题">
        <ExpressionInput {...form.bind('title', { onBlur: true })} />
      </Form.Item>

      <Form.Item label="副标题">
        <ExpressionInput {...form.bind('subTitle', { onBlur: true })} />
      </Form.Item>

      <Form.Item label="描述">
        <ExpressionInput {...form.bind('description', { onBlur: true })} />
      </Form.Item>

      <Form.Item label="节点禁用">
        <ExpressionInput {...form.bind('disabled', { onBlur: true })} />
      </Form.Item>
    </>
  );
});
