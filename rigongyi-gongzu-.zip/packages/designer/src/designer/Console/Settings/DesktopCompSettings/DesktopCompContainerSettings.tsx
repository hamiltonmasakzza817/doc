import { QuestionCircleOutlined } from '@ant-design/icons';
import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { DesktopCompContainerConfig } from '@gongzu/core/types/comps-desktop';
import { Form, Input, Select, Tooltip } from 'antd';
import { observer } from 'mobx-react';
import React from 'react';
import ExpressionInput from '../../../components/ExpressionInput';
import CustomComponentSelect from '../../components/CustomCompSelect';
import SettingsFormContext from '../context/SettingsFormContext';

export default observer(() => {
  const form = React.useContext(
    SettingsFormContext,
  ) as unknown as MobxFormStore<DesktopCompContainerConfig>;

  return (
    <>
      <Form.Item label="Loading">
        <ExpressionInput
          leafOnly
          {...form.bind('loading', {
            onBlur: true,
          })}
        />
      </Form.Item>

      <Form.Item label="文字提示">
        <ExpressionInput {...form.bind('tooltip', { onBlur: true })} />
      </Form.Item>

      <Form.Item
        label={
          <span>
            代码&nbsp;
            <Tooltip title="用于多标签页索引">
              <QuestionCircleOutlined />
            </Tooltip>
          </span>
        }
      >
        <Input {...form.bind('code', { onBlur: true })} />
      </Form.Item>

      <Form.Item label="自定义组件">
        <CustomComponentSelect {...form.bind('renderCompId')} showEmpty />
      </Form.Item>

      <Form.Item label="下拉组件">
        <CustomComponentSelect {...form.bind('dropdownCompId')} showEmpty />
      </Form.Item>

      {form.values.dropdownCompId != null && (
        <>
          <Form.Item label="下拉触发方式">
            <Select allowClear {...form.bind('dropdownTrigger')}>
              {[
                ['hover', '滑过'],
                ['click', '点击'],
                ['contextMenu', '右键'],
              ].map((trigger) => (
                <Select.Option key={trigger[0]} value={trigger[0]}>
                  {trigger[1]}
                </Select.Option>
              ))}
            </Select>
          </Form.Item>
          <Form.Item label="对齐">
            <Select
              {...form.bind('align')}
              defaultValue="bottomLeft"
              options={[
                'topLeft',
                'top',
                'topRight',
                'rightTop',
                'right',
                'rightBottom',
                'bottomRight',
                'bottom',
                'bottomLeft',
                'leftBottom',
                'left',
                'leftTop',
              ].map((k) => ({ label: k, value: k }))}
            />
          </Form.Item>
        </>
      )}

      <Form.Item
        label={
          <span>
            延展至底部
            <Tooltip title="填写距离视口底部的距离，会使容器获得动态的高度">
              <QuestionCircleOutlined />
            </Tooltip>
          </span>
        }
      >
        <ExpressionInput {...form.bind('flexBottom', { onBlur: true })} />
      </Form.Item>
    </>
  );
});
