import { EditOutlined } from '@ant-design/icons';
import Loading from '@gongzu/core/common/Loading';
import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import useFormMobx from '@gongzu/core/mobx-form/useFormMobx';
import { DesktopCompMarkdownConfig } from '@gongzu/core/types/comps-desktop';
import { Card, Modal } from 'antd';
import { ModalProps } from 'antd/es/modal';
import { observer } from 'mobx-react';
import React from 'react';
import Loadable from 'react-loadable';
import ClickableText from '../../../../components/ClickableText';
import SettingsFormContext from '../context/SettingsFormContext';

const CodeEditor = Loadable({
  loader: () => import('../../../../components/CodeEditor'),
  loading: Loading,
});

const MarkdownEditorDialog = observer(
  (
    props: ModalProps & {
      markdown?: string;
      onSave: (value: string) => void;
    },
  ) => {
    const { markdown, onSave, ...modalProps } = props;

    const form = useFormMobx<{
      markdown: string;
    }>({
      defaultValues: null,
    });

    React.useEffect(() => {
      if (markdown) {
        form.reset({ markdown });
      }
    }, [markdown]);

    return (
      <Modal
        title="Markdown编辑"
        width={1000}
        {...modalProps}
        onOk={() => {
          onSave(form.values.markdown);
        }}
      >
        {modalProps.visible && (
          <CodeEditor
            language="markdown"
            height={600}
            {...form.bind('markdown')}
          />
        )}
      </Modal>
    );
  },
);

export default observer(() => {
  const form = React.useContext(
    SettingsFormContext,
  ) as unknown as MobxFormStore<DesktopCompMarkdownConfig>;

  const [showText, setShowText] = React.useState<boolean>(false);

  return (
    <>
      <Card
        size="small"
        type="inner"
        title="文本"
        extra={
          <ClickableText
            className="text-primary"
            onClick={() => setShowText(true)}
          >
            <EditOutlined />
          </ClickableText>
        }
      >
        <div
          className="overflow-auto"
          style={{
            height: 200,
          }}
        >
          {form.values.text}
        </div>
      </Card>

      <MarkdownEditorDialog
        visible={showText}
        markdown={form.values.text}
        onCancel={() => setShowText(false)}
        onSave={(value) => {
          form.setValues({
            text: value,
          });
          setShowText(false);
        }}
      />
    </>
  );
});
