import { QuestionCircleOutlined } from '@ant-design/icons';
import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { DesktopCompTagConfig } from '@gongzu/core/types/comps-desktop';
import { Form, Switch, Tooltip } from 'antd';
import { observer } from 'mobx-react';
import React from 'react';
import ExpressionInput from '../../../components/ExpressionInput';
import SettingsFormContext from '../context/SettingsFormContext';

export default observer(() => {
  const form = React.useContext(
    SettingsFormContext,
  ) as unknown as MobxFormStore<DesktopCompTagConfig>;

  return (
    <>
      <Form.Item label="文本">
        <ExpressionInput leafOnly {...form.bind('text', { onBlur: true })} />
      </Form.Item>

      <Form.Item
        label={
          <span>
            颜色&nbsp;
            <Tooltip
              title={
                <div>
                  pink
                  <br />
                  red
                  <br />
                  yellow
                  <br />
                  orange
                  <br />
                  cyan
                  <br />
                  green
                  <br />
                  blue
                  <br />
                  purple
                  <br />
                  geekblue
                  <br />
                  magenta
                  <br />
                  volcano
                  <br />
                  gold
                  <br />
                  lime
                  <br />
                  success
                  <br />
                  processing
                  <br />
                  error
                  <br />
                  default
                  <br />
                  warning
                </div>
              }
            >
              <QuestionCircleOutlined />
            </Tooltip>
          </span>
        }
      >
        <ExpressionInput {...form.bind('color', { onBlur: true })} />
      </Form.Item>

      <Form.Item label="可以关闭">
        <Switch {...form.bind('closable')} checked={form.values.closable} />
      </Form.Item>
    </>
  );
});
