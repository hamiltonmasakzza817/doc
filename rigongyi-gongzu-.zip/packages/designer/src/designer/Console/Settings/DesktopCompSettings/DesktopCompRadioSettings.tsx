import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { DesktopCompRadioConfig } from '@gongzu/core/types/comps-desktop';
import { Form, Radio, Select } from 'antd';
import { observer } from 'mobx-react';
import React from 'react';
import CustomComponentSelect from '../../components/CustomCompSelect';
import SettingsFormContext from '../context/SettingsFormContext';

export default observer(() => {
  const form = React.useContext(
    SettingsFormContext,
  ) as unknown as MobxFormStore<DesktopCompRadioConfig>;

  return (
    <>
      <Form.Item label="风格">
        <Select allowClear {...form.bind('radioStyle')}>
          <Select.Option key="vertical" value="vertical">
            垂直分布
          </Select.Option>
          <Select.Option key="button" value="button">
            按钮型
          </Select.Option>
        </Select>
      </Form.Item>

      <Form.Item label="自定义组件">
        <CustomComponentSelect {...form.bind('renderCompId')} showEmpty />
      </Form.Item>

      {form.values.radioStyle === 'button' && (
        <Form.Item label="按钮风格" {...form.bind('buttonStyle')}>
          <Radio.Group defaultValue="outline">
            <Radio key="outline" value="outline">
              Outline
            </Radio>
            <Radio key="solid" value="solid">
              Solid
            </Radio>
          </Radio.Group>
        </Form.Item>
      )}
    </>
  );
});
