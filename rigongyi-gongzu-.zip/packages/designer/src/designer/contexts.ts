import React from 'react';
import PageManageStore from '../store/PageManageStore';

export const PageManageStoreContext =
  // @ts-ignore
  React.createContext<PageManageStore>(null);
