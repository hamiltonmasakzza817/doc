import { DeleteOutlined, PlusCircleOutlined } from '@ant-design/icons';
import { gzdnBem } from '@gongzu/core/config/constants';
import { EngineStoresContext } from '@gongzu/core/contexts/store-contexts';
import MobxFormStore from '@gongzu/core/mobx-form/MobxFormStore';
import { CompConfig } from '@gongzu/core/types/comps-common';
import { Select } from 'antd';
import concat from 'lodash-es/concat';
import { observer } from 'mobx-react';
import React from 'react';
import ClickableText from '../../components/ClickableText';

const styleGridBem = gzdnBem('style-grid');

export default observer((props: { form: MobxFormStore<CompConfig> }) => {
  const { form } = props;

  const { engineModelStore } = React.useContext(EngineStoresContext);

  return (
    <div className={styleGridBem('container')}>
      {form.values.styleIds?.map((styleId, index) => (
        <React.Fragment key={styleId}>
          <Select allowClear {...form.bind(`styleIds[${index}]`)}>
            {Object.values(engineModelStore.styles).map((s) => (
              <Select.Option key={s.id} value={s.id}>
                {s.name}
              </Select.Option>
            ))}
          </Select>

          <ClickableText
            onClick={() => {
              const styleIds = concat(form.values.styleIds);

              styleIds.splice(index, 1);

              form.setValues({
                styleIds,
              });
            }}
            className="text-error"
          >
            <DeleteOutlined />
          </ClickableText>
        </React.Fragment>
      ))}

      <div className="grid-cols-2">
        <ClickableText
          onClick={() => {
            form.setValues({
              styleIds: [...(form.values.styleIds ?? []), ''],
            });
          }}
          className={gzdnBem('clickable-icon')}
        >
          <PlusCircleOutlined />
        </ClickableText>
      </div>
    </div>
  );
});
