import Loading from '@gongzu/core/common/Loading';
import { Page } from '@gongzu/core/types/entities';
import { Button, Modal } from 'antd';
import { ModalProps } from 'antd/es/modal';
import jsonPretty from 'json-stringify-pretty-compact';
import { observer } from 'mobx-react';
import React from 'react';
import Loadable from 'react-loadable';

const CodeEditor = Loadable({
  loader: () => import('../../components/CodeEditor'),
  loading: Loading,
});

export default observer(
  (
    props: Pick<ModalProps, 'onCancel'> & {
      pageModel?: Page | null;
      onSave: (model: string) => void;
    },
  ) => {
    const { pageModel, onCancel, onSave } = props;

    const [model, setModel] = React.useState<string>('');

    React.useEffect(() => {
      if (pageModel) {
        setModel(
          jsonPretty(pageModel.model?.modelData, {
            maxLength: 0,
          }),
        );
      }
    }, [pageModel]);

    const visible = pageModel != null;

    return (
      <Modal
        title={`${pageModel?.name}模型`}
        visible={visible}
        width={800}
        style={{
          top: 24,
        }}
        maskClosable={false}
        keyboard={false}
        onCancel={onCancel}
        footer={
          <>
            <Button onClick={onCancel}>关闭</Button>

            <Button
              type="primary"
              onClick={() => {
                onSave(model);
              }}
            >
              保存
            </Button>
          </>
        }
      >
        {visible && (
          <CodeEditor
            language="json"
            height={500}
            value={model}
            onChange={(value1) => setModel(value1 || '')}
          />
        )}
      </Modal>
    );
  },
);
