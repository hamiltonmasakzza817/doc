import language from '@gongzu/core/config/language';
import { BaseStoresContext } from '@gongzu/core/contexts/store-contexts';
import useFormMobx from '@gongzu/core/mobx-form/useFormMobx';
import { getItemErrorProps } from '@gongzu/core/mobx-form/utils';
import { IdTreeNode, Page, PagePlatform } from '@gongzu/core/types/entities';
import { mapTreeNode } from '@gongzu/core/utils/tree';
import { Button, Form, Input, Modal, Radio, TreeSelect } from 'antd';
import cloneDeep from 'lodash-es/cloneDeep';

import { Observer, observer } from 'mobx-react';
import React from 'react';
import { EMPTY, from } from 'rxjs';
import { mergeMap } from 'rxjs/operators';
import { addingId } from '../../config/constants';
import { dialogFormItemLayout } from '../../config/layout';
import { PageManageStoreContext } from '../contexts';

function PageDialog() {
  const pageManageStore = React.useContext(PageManageStoreContext);

  const { streamStore, pageStore } = React.useContext(BaseStoresContext);

  const page = pageManageStore.pageOpen;

  const form = useFormMobx<Page>({
    defaultValues: null,
  });

  React.useEffect(() => {
    if (page) {
      form.reset(cloneDeep(page));
    }
  }, [page]);

  // React.useEffect(() => {
  //   const { parentId } = form.values;
  //
  //   let parentUrl: string | null = null;
  //   let parentChildrenSize = 0;
  //
  //   if (parentId === '-1') {
  //     parentUrl = '/';
  //     parentChildrenSize = size(
  //       values(pageStore.pages).filter((i) => i.parentId === '-1'),
  //     );
  //   } else {
  //     const parent = parentId ? get(pageStore.pages, parentId) : null;
  //     if (parent) {
  //       parentUrl = parent.url ? `${parent.url}/` : null;
  //       parentChildrenSize = size(parent.children);
  //     }
  //   }
  //
  //   if (parentUrl) {
  //     if (
  //       parentUrl &&
  //       (form.values.url == null || !form.values.url.startsWith(parentUrl))
  //     ) {
  //       form.setValues({
  //         url: `${parentUrl}page-${parentChildrenSize + 1}`,
  //       });
  //     }
  //   }
  // }, [form.values.parentId]);

  return (
    <Modal
      title={
        pageManageStore.pageOpen?.id === addingId ? '新增页面' : '修改页面'
      }
      visible={pageManageStore.pageOpen != null}
      onCancel={() => pageManageStore.closePage()}
      width={800}
      maskClosable={false}
      footer={
        <Observer>
          {() => (
            <>
              <Button
                type="primary"
                onClick={() => {
                  form
                    .triggerValidation()
                    .pipe(
                      mergeMap((isValid) => {
                        if (isValid) {
                          return pageManageStore.savePage(form.values);
                        }

                        return from(EMPTY);
                      }),
                    )
                    .subscribe();
                }}
                disabled={streamStore.pending.get('savePage')}
              >
                确定
              </Button>
            </>
          )}
        </Observer>
      }
    >
      <Form {...dialogFormItemLayout}>
        <Form.Item
          label="名称"
          required
          {...getItemErrorProps(form.errors.name)}
        >
          <Input {...form.bind('name', { required: true })} />
        </Form.Item>
        <Form.Item
          label="自定义URL"
          required
          {...getItemErrorProps(form.errors.url)}
        >
          <Input {...form.bind('url', { required: true })} />
        </Form.Item>
        <Form.Item label="父级页面">
          <Observer>
            {() => {
              const root: IdTreeNode = {
                id: '-1',
                children: pageManageStore.idTree,
              };

              const treeData = mapTreeNode([root], (n) => {
                const node = pageStore.pages[n.id] || {};

                return (
                  node && {
                    key: n.id,
                    value: n.id,
                    title: n.id === '-1' ? '页面' : node.name || '--',
                    children: [],
                  }
                );
              });

              return (
                <TreeSelect<string>
                  {...form.bind('parentId')}
                  treeData={treeData}
                />
              );
            }}
          </Observer>
        </Form.Item>
        <Form.Item label="平台">
          {form.values.id === addingId ? (
            <Radio.Group
              {...form.bind('platform')}
              defaultValue={PagePlatform.PC}
              options={[
                PagePlatform.PC,
                PagePlatform.MOBILE,
                PagePlatform.TARO,
              ].map((d) => ({
                label: language.pagePlatform[d],
                value: d,
              }))}
              buttonStyle="solid"
              optionType="button"
            />
          ) : (
            <div>
              {language.pagePlatform[form.values.platform || PagePlatform.PC]}
            </div>
          )}
        </Form.Item>
      </Form>
    </Modal>
  );
}

export default observer(PageDialog);
