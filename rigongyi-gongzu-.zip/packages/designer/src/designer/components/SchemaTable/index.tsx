export { default } from './SchemaTable';
