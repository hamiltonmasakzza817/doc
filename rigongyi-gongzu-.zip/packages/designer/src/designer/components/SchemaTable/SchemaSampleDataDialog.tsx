import Loading from '@gongzu/core/common/Loading';
import useFormMobx from '@gongzu/core/mobx-form/useFormMobx';
import { getItemErrorProps, validateJSON } from '@gongzu/core/mobx-form/utils';
import { parseJSON } from '@gongzu/core/utils/data';
import { Form, Modal } from 'antd';
import jsonPretty from 'json-stringify-pretty-compact';
import { Observer } from 'mobx-react';
import React from 'react';
import Loadable from 'react-loadable';

const CodeEditor = Loadable({
  loader: () => import('../../../components/CodeEditor'),
  loading: Loading,
});

export default function SchemaSampleDataDialog(props: {
  sampleData: Record<string, unknown> | null;
  onOk: (sampleData: Record<string, unknown>) => void;
  onCancel: () => void;
}) {
  const { sampleData, onOk, onCancel } = props;

  const form = useFormMobx<{
    data: string;
  }>({
    defaultValues: null,
  });

  React.useEffect(() => {
    if (sampleData) {
      form.reset({
        data: jsonPretty(sampleData, {
          maxLength: 0,
        }),
      });
    }
  }, [sampleData]);

  const visible = sampleData != null;

  return (
    <Modal
      visible={visible}
      width={800}
      title="填写JSON数据"
      onOk={() => {
        form.triggerValidation().subscribe((isValid) => {
          if (isValid) {
            onOk(parseJSON(form.values.data));
          }
        });
      }}
      onCancel={() => onCancel()}
    >
      <Form>
        <Observer>
          {() => (
            <>
              <Form.Item
                required
                {...getItemErrorProps(form.errors.data)}
              >
                {visible && (
                  <CodeEditor
                    language="json"
                    {...form.bind('data', {
                      required: true,
                      validate: validateJSON,
                    })}
                  />
                )}
              </Form.Item>
            </>
          )}
        </Observer>
      </Form>
    </Modal>
  );
}
