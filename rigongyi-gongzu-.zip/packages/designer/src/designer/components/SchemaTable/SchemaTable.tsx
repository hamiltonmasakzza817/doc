import {
  DeleteOutlined,
  EditOutlined,
  PlusCircleOutlined,
  SaveOutlined,
} from '@ant-design/icons';
import { gzdnBem } from '@gongzu/core/config/constants';
import language from '@gongzu/core/config/language';
import {
  BaseStoresContext,
  DesignerStoreContext,
} from '@gongzu/core/contexts/store-contexts';
import useFormMobx from '@gongzu/core/mobx-form/useFormMobx';
import { Schema, SchemaDataType } from '@gongzu/core/types/entities';
import {
  buildSchema,
  buildSchemaSampleData,
  buildSchemaTree,
  SchemaTreeNode,
} from '@gongzu/core/utils/schema';
import { Button, Input, Modal, Select, Table, Tooltip } from 'antd';
import { ColumnProps } from 'antd/es/table';
import classNames from 'classnames';
import assign from 'lodash-es/assign';
import compact from 'lodash-es/compact';
import concat from 'lodash-es/concat';
import get from 'lodash-es/get';
import set from 'lodash-es/set';
import size from 'lodash-es/size';
import uniq from 'lodash-es/uniq';
import unset from 'lodash-es/unset';
import { runInAction } from 'mobx';
import { Observer, observer, useLocalObservable } from 'mobx-react';
import React from 'react';
import { Observable, of } from 'rxjs';
import ClickableText from '../../../components/ClickableText';
import SchemaSampleDataDialog from './SchemaSampleDataDialog';

const schemaTableBem = gzdnBem('schema-table');

export default observer(
  (props: {
    schema?: Schema;
    editable?: boolean;
    deduce?: boolean;
    loading?: boolean;
    onSync?: () => Observable<unknown>;
    autoSync?: boolean;
    onChange?: (schema: Schema) => void;
  }) => {
    const {
      schema,
      loading = false,
      editable = false,
      deduce = false,
      onSync = () => of(),
      onChange = () => {},
    } = props;

    const { streamStore } = React.useContext(BaseStoresContext);

    const designerStore = React.useContext(DesignerStoreContext);

    const states = useLocalObservable<{
      expendedKeys: string[];
      sampleDataOpen: Record<string, unknown> | null;
    }>(() => ({
      expendedKeys: [],
      sampleDataOpen: null,
    }));

    const [editing, setEditing] = React.useState<SchemaTreeNode | null>(null);

    const schemaTree = schema
      ? compact([buildSchemaTree({ schema, pathname: 'root', key: '[0]' })])
      : undefined;

    const form = useFormMobx<SchemaTreeNode>({
      defaultValues: null,
    });

    React.useEffect(() => {
      if (editing) {
        form.reset(editing);
      }
    }, [editing]);

    React.useEffect(() => {
      if (schemaTree && size(states.expendedKeys) === 0) {
        runInAction(() => {
          states.expendedKeys = compact([schemaTree[0]?.pathname]);
        });
      }
    }, [schemaTree]);

    return (
      <>
        <div className={classNames('mb-1', schemaTableBem('header'))}>
          <Button
            size="small"
            onClick={() => {
              onSync().subscribe();
            }}
            disabled={loading}
          >
            {loading ? '同步中...' : '同步'}
          </Button>

          {deduce && (
            <Button
              className="ml-1"
              type="primary"
              size="small"
              onClick={() => {
                runInAction(() => {
                  states.sampleDataOpen = schema
                    ? buildSchemaSampleData(schema) ?? {}
                    : {};
                });
              }}
            >
              {streamStore.pending.get('analysisSchema')
                ? '推导中...'
                : '使用JSON推导'}
            </Button>
          )}

          {editable && size(schemaTree) === 0 && (
            <Button className="ml-1" type="primary" size="small">
              添加根节点
            </Button>
          )}
        </div>

        <Table<SchemaTreeNode>
          size="small"
          expandedRowKeys={states.expendedKeys}
          onExpandedRowsChange={(expendedKeys1) =>
            runInAction(() => {
              states.expendedKeys = expendedKeys1.map((k) => k.toString());
            })
          }
          columns={compact(
            concat<ColumnProps<SchemaTreeNode> | null>(
              [
                {
                  dataIndex: 'code',
                  title: '属性名',
                  width: 400,
                  render: (text, record) => {
                    if (editing?.pathname === record.pathname) {
                      return (
                        <Observer>
                          {() => (
                            <Input className="w-auto" {...form.bind('code')} />
                          )}
                        </Observer>
                      );
                    }

                    return text;
                  },
                },
                {
                  dataIndex: 'dataType',
                  title: '类型',
                  align: 'center',
                  width: 200,
                  render: (_text, record) => {
                    if (editing?.pathname === record.pathname) {
                      return (
                        <Observer>
                          {() => (
                            <Select {...form.bind('dataType')}>
                              {[
                                SchemaDataType.STRING,
                                SchemaDataType.BOOLEAN,
                                SchemaDataType.INTEGER,
                                SchemaDataType.JSON_OBJECT,
                              ].map((t) => (
                                <Select.Option key={t} value={t}>
                                  {language.schemaDataType[t]}
                                </Select.Option>
                              ))}
                            </Select>
                          )}
                        </Observer>
                      );
                    }

                    return (
                      <>
                        {language.schemaDataType[record.dataType]}
                        {record.multiple ? '（数组）' : ''}
                      </>
                    );
                  },
                },
              ],
              editable
                ? {
                    key: 'actions',
                    title: '操作',
                    align: 'center',
                    render: (_text, record) => (
                      <>
                        {record.dataType === SchemaDataType.JSON_OBJECT && (
                          <ClickableText
                            className="mr-1"
                            onClick={() => {
                              const length = size(record.children);

                              if (record.children) {
                                set(
                                  record,
                                  'children',
                                  concat<SchemaTreeNode>(record.children, {
                                    code: `prop${length + 1}`,
                                    dataType: SchemaDataType.STRING,
                                    multiple: false,
                                    pathname: '',
                                    key: `${record.key}.children[${length}]`,
                                  }),
                                );
                              }

                              const schema1 = buildSchema(
                                get(schemaTree, '[0]'),
                              );

                              if (schema1) {
                                onChange(schema1);
                              }

                              runInAction(() => {
                                states.expendedKeys = uniq(
                                  concat(states.expendedKeys, record.pathname),
                                );
                              });
                            }}
                          >
                            <Tooltip title="添加下级">
                              <PlusCircleOutlined />
                            </Tooltip>
                          </ClickableText>
                        )}

                        {editing?.pathname === record.pathname ? (
                          <ClickableText
                            className="mr-1"
                            onClick={() => {
                              if (
                                form.values.dataType !==
                                SchemaDataType.JSON_OBJECT
                              ) {
                                set(record, 'children', null);
                              }

                              assign(record, form.values);

                              const schema1 = buildSchema(
                                get(schemaTree, '[0]'),
                              );

                              if (schema1) {
                                onChange(schema1);
                              }

                              setEditing(null);
                            }}
                          >
                            <Tooltip title="保存">
                              <SaveOutlined />
                            </Tooltip>
                          </ClickableText>
                        ) : (
                          <ClickableText
                            className="mr-1 text-primary"
                            onClick={() => setEditing(record)}
                          >
                            <Tooltip title="编辑">
                              <EditOutlined />
                            </Tooltip>
                          </ClickableText>
                        )}

                        <ClickableText
                          className="text-error"
                          onClick={() => {
                            Modal.confirm({
                              title: '是否删除该节点？',
                              content: record.code,
                              onOk: () => {
                                unset(schemaTree, record.key);

                                const schema1 = buildSchema(
                                  get(schemaTree, '[0]'),
                                );

                                if (schema1) {
                                  onChange(schema1);
                                }
                              },
                            });
                          }}
                        >
                          <DeleteOutlined />
                        </ClickableText>
                      </>
                    ),
                  }
                : null,
            ),
          )}
          dataSource={schemaTree}
          loading={loading}
          pagination={false}
          rowKey="pathname"
        />

        <SchemaSampleDataDialog
          sampleData={states.sampleDataOpen}
          onOk={(sampleData) => {
            designerStore.analysisSchema(sampleData).subscribe((s) => {
              onChange(s);
              runInAction(() => {
                states.sampleDataOpen = null;
              });
            });
          }}
          onCancel={() =>
            runInAction(() => {
              states.sampleDataOpen = null;
            })
          }
        />
      </>
    );
  },
);
