import { PlusOutlined } from '@ant-design/icons';
import FileUploader from '@gongzu/core/components/FileUploader';
import api from '@gongzu/core/config/api';
import { gzdnBem } from '@gongzu/core/config/constants';
import { Image } from 'antd';
import classNames from 'classnames';
import first from 'lodash-es/first';
import React from 'react';

const imageUploaderBem = gzdnBem('image-uploader');

export default function ImageUploader(props: {
  onChange: (file: { url: string; name: string }) => void;
  url?: string;
  width?: number;
  height?: number;
}) {
  const { url, onChange, width = 104, height = 104 } = props;

  return (
    <FileUploader
      url={api.file.upload}
      onChange={(files) => {
        const file = first(files);
        if (file) {
          onChange(file);
        }
      }}
    >
      {url ? (
        <Image width={width} height={height} src={url} />
      ) : (
        <div
          style={{
            height,
            width,
          }}
          className={classNames(
            imageUploaderBem('placeholder'),
            'hover:text-primary',
          )}
        >
          <PlusOutlined />
          <div className="mt-1">上传</div>
        </div>
      )}
    </FileUploader>
  );
}
