export interface ExpressionRestrictProps {
  arrayOnly?: boolean;
  leafOnly?: boolean;
  nonLeafOnly?: boolean;
  asPathname?: boolean;
}
