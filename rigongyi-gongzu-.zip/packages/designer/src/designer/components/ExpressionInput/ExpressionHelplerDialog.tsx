import { gzdnBem } from '@gongzu/core/config/constants';
import { EngineStoresContext } from '@gongzu/core/contexts/store-contexts';
import { DataNode, SchemaDataType } from '@gongzu/core/types/entities';
import { buildSchemaTree, SchemaTreeNode } from '@gongzu/core/utils/schema';
import { findTreeNode, mapTreeNode } from '@gongzu/core/utils/tree';
import { Button, Input, Modal, Tree } from 'antd';
import { ModalProps } from 'antd/es/modal';
import compact from 'lodash-es/compact';
import { observer } from 'mobx-react';
import React from 'react';
import { ExpressionRestrictProps } from './type';

const expressionHelperDialogBem = gzdnBem('expression-helper-dialog');

enum ExpressionTransforms {
  SIZE = 'size',
  DATE = 'date',
  CEIL = 'ceil',
  FLOOR = 'floor',
}

const expressionTransformsLanguage = {
  [ExpressionTransforms.SIZE]: '获取长度',
  [ExpressionTransforms.DATE]: '格式化时间',
  [ExpressionTransforms.CEIL]: '上取整',
  [ExpressionTransforms.FLOOR]: '下取整',
};

export default observer(
  (
    props: ModalProps &
      ExpressionRestrictProps & {
        onSave: (expression: string | null) => void;
      },
  ) => {
    const {
      onSave,
      visible,
      asPathname = false,
      arrayOnly = false,
      leafOnly = false,
      nonLeafOnly = false,
      ...modalProps
    } = props;

    const [expression, setExpression] = React.useState<string | null>(null);
    const [selectedKey, setSelectedKey] = React.useState<React.Key | null>(
      null,
    );

    React.useEffect(() => {
      if (visible) {
        setExpression(null);
      }
    }, [visible]);

    const { engineModelStore } = React.useContext(EngineStoresContext);

    const schemaTree = compact(
      Object.values(engineModelStore.datas).map((data) =>
        buildSchemaTree({
          schema: data.schema || { dataType: SchemaDataType.STRING },
          pathname: data.code,
          key: '[0]',
        }),
      ),
    );

    const treeData = mapTreeNode<SchemaTreeNode, DataNode>(
      schemaTree,
      (node) => ({
        value: node.pathname,
        key: node.pathname,
        title: `${node.code}${node.multiple ? '（数组）' : ''}`,
        disabled:
          (arrayOnly && !node.multiple) ||
          (leafOnly &&
            (node.children == null ? false : node.children.length > 0)) ||
          (nonLeafOnly && node.children?.length === 0),
      }),
    );

    return (
      <Modal
        {...modalProps}
        visible={visible}
        title="表达式助手"
        width={800}
        onOk={() => onSave(expression)}
      >
        <>
          {!asPathname && (
            <div
              className="pb-3 mb-3 border-border"
              style={{
                borderBottom: '1px solid',
              }}
            >
              <Input
                value={expression ?? undefined}
                onChange={(e) => setExpression(e.target.value)}
              />
            </div>
          )}

          <div className={expressionHelperDialogBem('container')}>
            <div>
              <div className="mb-1">Schema：</div>
              <Tree
                treeData={treeData}
                selectedKeys={selectedKey ? [selectedKey] : undefined}
                onSelect={(selectedKeys) => {
                  if (selectedKeys[0]) {
                    const node = findTreeNode<SchemaTreeNode>(
                      schemaTree,
                      'pathname',
                      selectedKeys[0],
                    );
                    setSelectedKey(selectedKeys[0]);
                    setExpression(node?.pathname || null);
                  } else {
                    setSelectedKey(null);
                    setExpression(null);
                  }
                }}
              />
            </div>

            {!asPathname && (
              <div className="pl-3">
                <div className="mb-1">格式化工具：</div>

                <div className={expressionHelperDialogBem('container')}>
                  {[ExpressionTransforms.SIZE, ExpressionTransforms.DATE].map(
                    (ets) => (
                      <Button
                        key={ets}
                        size="small"
                        type="primary"
                        onClick={() => {
                          setExpression(`${expression}|${ets}`);
                        }}
                      >
                        {expressionTransformsLanguage[ets]}
                      </Button>
                    ),
                  )}
                </div>
              </div>
            )}
          </div>
        </>
      </Modal>
    );
  },
);
