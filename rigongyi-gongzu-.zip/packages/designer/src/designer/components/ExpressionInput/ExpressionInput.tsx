import { Input, Tooltip } from 'antd';
import { observer } from 'mobx-react';
import React from 'react';
import ClickableText from '../../../components/ClickableText';
import ExpressionHelperDialog from './ExpressionHelplerDialog';
import { ExpressionRestrictProps } from './type';

export default observer(
  (
    props: ExpressionRestrictProps & {
      value?: string;
      onChange?: (value: string) => void;
      onBlur?: () => void;
      onFocus?: () => void;
      rows?: number;
      defaultValue?: string;
    },
  ) => {
    const {
      value,
      onChange = () => {},
      onBlur,
      onFocus,
      asPathname = false,
      rows = 1,
      defaultValue,
      ...rest
    } = props;

    const [helperOpen, setHelperOpen] = React.useState<boolean>(false);

    return (
      <>
        <div className="flex item">
          <Tooltip title={value}>
            <Input.TextArea
              className="flex-1"
              defaultValue={defaultValue}
              rows={rows}
              value={value}
              onChange={(event) => onChange(event.target.value)}
              onBlur={onBlur}
              onFocus={onFocus}
              placeholder={
                asPathname ? '表达式（作为路径）' : '表达式（作为值）'
              }
            />
          </Tooltip>
          <ClickableText
            onClick={() => setHelperOpen(true)}
            style={{ lineHeight: '32px' }}
            className="text-primary ml-1"
          >
            选择
          </ClickableText>
        </div>

        <ExpressionHelperDialog
          {...rest}
          asPathname={asPathname}
          visible={helperOpen}
          onCancel={() => setHelperOpen(false)}
          onSave={(expression) => {
            if (asPathname) {
              onChange(`${value ?? ''}${expression}`);
            } else {
              onChange(`${value ?? ''}\${${expression}}`);
            }

            if (onBlur) {
              onBlur();
            }

            setHelperOpen(false);
          }}
        />
      </>
    );
  },
);
