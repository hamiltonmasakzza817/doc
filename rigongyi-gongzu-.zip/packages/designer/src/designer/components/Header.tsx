import { gzdnBem } from '@gongzu/core/config/constants';
import { BaseStoresContext } from '@gongzu/core/contexts/store-contexts';
import { Tooltip } from 'antd';
import classNames from 'classnames';
import { observer } from 'mobx-react';
import React from 'react';
import ClickableText from '../../components/ClickableText';
import logo from '../../favicon.svg';

const headerBem = gzdnBem('header');

export default observer(
  (props: { className?: string; children?: JSX.Element }) => {
    const { className, children } = props;

    const { sessionStore } = React.useContext(BaseStoresContext);

    return (
      <header className={classNames(className, 'px-3', headerBem('container'))}>
        <a href={`//${window.location.host}${window.location.pathname}`}>
          <Tooltip title="回到首页">
            <img src={logo} width={134} alt="logo" />
          </Tooltip>
        </a>

        <div className="flex-1">{children}</div>

        <div className="mx-1">
          {sessionStore.login?.name || sessionStore.login?.nickname}
        </div>

        <ClickableText
          className="text-error"
          onClick={() => {
            sessionStore.logout().subscribe();
          }}
        >
          登出
        </ClickableText>
      </header>
    );
  },
);
