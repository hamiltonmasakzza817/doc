import { EditOutlined } from '@ant-design/icons';
import Loading from '@gongzu/core/common/Loading';
import { gzdnBem } from '@gongzu/core/config/constants';
import useFormMobx from '@gongzu/core/mobx-form/useFormMobx';
import { getItemErrorProps, validateJSON } from '@gongzu/core/mobx-form/utils';
import { CodeEditorProps } from '@gongzu/core/types/comps-common';
import { Card, Form, Modal, Spin } from 'antd';
import { ModalProps } from 'antd/es/modal';
import jsonPretty from 'json-stringify-pretty-compact';
import omit from 'lodash-es/omit';
import { observer, Observer, useLocalObservable } from 'mobx-react';
import React from 'react';
import Loadable from 'react-loadable';
import ClickableText from '../../components/ClickableText';

const CodeEditor = Loadable({
  loader: () => import('../../components/CodeEditor'),
  loading: () => (
    <Loading>
      <Spin />
    </Loading>
  ),
});

const { Item } = Form;

let showCode = false;

function CodeEditorDialog(
  props: Pick<ModalProps, 'visible' | 'onCancel'> & {
    onSave: (value?: string) => void;
    defaultValue?: string;
  } & CodeEditorProps,
) {
  const {
    visible,
    language,
    value,
    onCancel,
    onSave,
    defaultValue,
    ...codeEditorProps
  } = props;

  const form = useFormMobx<{
    code?: string;
  }>({
    defaultValues: null,
  });

  React.useEffect(() => {
    if (visible) {
      let code;

      if (!value) {
        code = defaultValue;
      } else {
        try {
          code =
            (language === 'json'
              ? jsonPretty(props.value, {
                  maxLength: 0,
                })
              : props.value) ?? defaultValue;
        } catch (e) {
          code = '';
        }
      }

      form.reset({ code });
    }
  }, [visible, language, value]);

  return (
    <Modal
      title="代码编辑"
      onCancel={onCancel}
      visible={visible}
      width={800}
      maskClosable={false}
      onOk={() => {
        form.triggerValidation().subscribe((isValid) => {
          if (isValid) {
            let { code } = form.values;

            if (language === 'json') {
              try {
                code = JSON.parse(code || '');
              } catch (e) {
                code = '';
              }
            }

            onSave(code);
          }
        });
      }}
    >
      <Observer>
        {() => (
          <Form>
            <Item
              className="block"
              {...getItemErrorProps(form.errors.code)}
            >
              {visible && (
                <CodeEditor
                  {...omit(codeEditorProps, ['value', 'onChange', 'readOnly'])}
                  language={language}
                  height={300}
                  {...form.bind(
                    'code',
                    language === 'json'
                      ? {
                          validate: validateJSON,
                        }
                      : undefined,
                  )}
                />
              )}
            </Item>
          </Form>
        )}
      </Observer>
    </Modal>
  );
}

export default observer(
  (
    props: CodeEditorProps & {
      title: string;
      extra?: JSX.Element;
      defaultValue?: string;
    },
  ) => {
    const { onChange, title, extra, defaultValue, value, ...codeEditorProps } =
      props;

    const state = useLocalObservable(() => ({
      showCode,
      showDialog: false,
    }));

    React.useEffect(
      () => () => {
        showCode = state.showCode;
      },
      [],
    );

    const code =
      props.language === 'json'
        ? jsonPretty(value, {
            maxLength: 0,
          })
        : value;

    return (
      <>
        <Card
          type="inner"
          size="small"
          title={title ?? '--'}
          className={gzdnBem('code-card')}
          extra={
            <>
              <ClickableText
                className="mr-1 text-primary"
                onClick={() => {
                  state.showCode = !state.showCode;
                }}
              >
                {state.showCode ? '收起' : '展开'}
              </ClickableText>

              <ClickableText
                className="text-primary"
                onClick={() => {
                  state.showDialog = true;
                }}
              >
                <EditOutlined />
              </ClickableText>
              {extra}
            </>
          }
        >
          {state.showCode ? (
            <CodeEditor {...props} value={code} readOnly />
          ) : (
            <span className="break-all">{code || '无'}</span>
          )}
        </Card>

        <CodeEditorDialog
          {...codeEditorProps}
          value={value}
          defaultValue={defaultValue}
          visible={state.showDialog}
          onCancel={() => {
            state.showDialog = false;
          }}
          onSave={(value1) => {
            if (onChange) {
              onChange(value1);
            }
            state.showDialog = false;
          }}
        />
      </>
    );
  },
);
