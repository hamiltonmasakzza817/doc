import { MinusOutlined } from '@ant-design/icons';
import { gzdnBem } from '@gongzu/core/config/constants';
import language from '@gongzu/core/config/language';
import { ToolModule } from '@gongzu/core/stores/DesignerStore';
import classNames from 'classnames';
import React from 'react';
import ClickableText from '../../components/ClickableText';

export default function ToolWindow(props: {
  toolModule: ToolModule;
  active: boolean;
  onClose: () => void;
  children: JSX.Element;
  className?: string;
}) {
  const { toolModule, onClose, active, children, className } = props;

  if (active) {
    return (
      <div
        className={classNames(
          'flex flex-col relative h-full overflow-y-auto',
          className,
        )}
        style={{
          width: 350,
        }}
      >
        <div>
          <div
            className="px-2 border-border border-b flex justify-between items-center font-bold"
            style={{ height: 32 }}
          >
            <div>{language.toolModule[toolModule]}</div>

            <MinusOutlined
              onClick={onClose}
              className="p-0.5 transition-all rounded"
            />
          </div>
        </div>

        <div className="flex-1 overflow-auto">{children}</div>
      </div>
    );
  }

  return <></>;
}
