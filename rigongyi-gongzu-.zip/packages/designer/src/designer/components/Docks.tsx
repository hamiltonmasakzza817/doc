import { gzdnBem } from '@gongzu/core/config/constants';
import language from '@gongzu/core/config/language';
import { ToolModule } from '@gongzu/core/stores/DesignerStore';
import classNames from 'classnames';
import React from 'react';
import ClickableText from '../../components/ClickableText';

const docksBem = gzdnBem('docks');

export default function Docks(props: {
  toolModules: ToolModule[];
  activeToolModule?: ToolModule;
  onChange: (toolModule?: ToolModule) => void;
  className?: string;
}) {
  const { toolModules, activeToolModule, onChange, className } = props;

  return (
    <div className={classNames(className, docksBem('container'))}>
      {toolModules.map((toolModule) => {
        const active = activeToolModule === toolModule;

        return (
          <ClickableText
            key={`${toolModule}`}
            className={classNames(docksBem('menu', { active }), 'py-2', 'px-0.5')}
            onClick={() => {
              onChange(active ? undefined : toolModule)
            }}
          >
            {language.toolModule[toolModule]}
          </ClickableText>
        );
      })}
    </div>
  );
}
