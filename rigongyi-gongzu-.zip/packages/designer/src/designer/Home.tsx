import {
  DatabaseOutlined,
  DeleteOutlined,
  EditOutlined,
  EyeOutlined,
  PlusCircleOutlined,
} from '@ant-design/icons';
import { css } from '@emotion/css';
import FlexWrapper from '@gongzu/core/components/FlexWrapper';
import { getHistory } from '@gongzu/core/config/history';
import language from '@gongzu/core/config/language';
import { BaseStoresContext } from '@gongzu/core/contexts/store-contexts';
import { Page, PagePlatform, PageStatus } from '@gongzu/core/types/entities';
import { mapTreeNode } from '@gongzu/core/utils/tree';
import { Button, Card, Modal, Table, Tag, Tooltip } from 'antd';
import { PresetColorType, PresetStatusColorType } from 'antd/lib/_util/colors';
import { LiteralUnion } from 'antd/lib/_util/type';
import classNames from 'classnames';
import cloneDeep from 'lodash-es/cloneDeep';
import concat from 'lodash-es/concat';
import keys from 'lodash-es/keys';
import size from 'lodash-es/size';
import { observer, useLocalObservable } from 'mobx-react';
import qs from 'qs';
import React from 'react';
import ClickableText from '../components/ClickableText';
import { addingId } from '../config/constants';
import Header from './components/Header';
import PageDialog from './components/PageDialog';
import PageModelDialog from './components/PageModelDialog';
import { PageManageStoreContext } from './contexts';

export default observer(() => {
  const { pageStore, streamStore } = React.useContext(BaseStoresContext);

  const pageManageStore = React.useContext(PageManageStoreContext);

  React.useEffect(() => {
    pageManageStore.init().subscribe();
    document.title = '日拱壹Designer';
  }, []);

  const history = getHistory();

  const { idTree } = pageManageStore;

  const dataSource = mapTreeNode(idTree || [], ({ id }) =>
    cloneDeep(pageStore.pages[id]),
  );

  const localState = useLocalObservable<{
    selectedRowKeys: React.Key[];
  }>(() => ({
    selectedRowKeys: [],
  }));

  const publishing = streamStore.getPending('publishBatch', true);

  return (
    <>
      <Header>
        <div className={classNames('pl-3')}>享受简单开发的乐趣</div>
      </Header>

      <FlexWrapper>
        <div className="m-3 rounded-xl bg-white p-3">
          <div className="mb-2 flex justify-between items-center">
            <div className="flex gap-1">
              <Button
                type="primary"
                onClick={() =>
                  pageManageStore.openPage({
                    id: addingId,
                    name: `页面${size(pageStore.pages) + 1}`,
                    status: PageStatus.UNPUBLISHED,
                    parentId: '-1',
                    platform: PagePlatform.PC,
                  })
                }
              >
                新建
              </Button>

              <Button
                type="primary"
                ghost
                onClick={() => {
                  pageManageStore.fetchPageTree().subscribe();
                }}
              >
                刷新
              </Button>

              <Button
                danger
                type="primary"
                disabled={size(localState.selectedRowKeys) === 0 || publishing}
                onClick={() => {
                  Modal.confirm({
                    title: '发版提示',
                    content: '是否发布选中页面',
                    onOk: () => {
                      pageManageStore
                        .publishBatch(localState.selectedRowKeys as string[])
                        .subscribe();
                    },
                  });
                }}
              >
                {publishing ? '发版中' : '发版'}
              </Button>
            </div>

            <div className="flex gap-1">
              <ClickableText
                className="text-primary"
                onClick={() => {
                  pageManageStore.updateExpandedRowKeys(keys(pageStore.pages));
                }}
              >
                全部展开
              </ClickableText>

              <ClickableText
                className="text-primary"
                onClick={() => {
                  pageManageStore.updateExpandedRowKeys([]);
                }}
              >
                全部收起
              </ClickableText>
            </div>
          </div>

          <Table<Page>
            className={css`
              .ant-table-row-expand-icon {
                margin-top: 0;
              }
            `}
            size="small"
            expandable={{
              expandedRowKeys: pageManageStore.expandedRowKeys,
              onExpand: (expanded, record) => {
                const expandedRowKeys = pageManageStore.expandedRowKeys.slice();
                if (expanded) {
                  pageManageStore.updateExpandedRowKeys(
                    concat(expandedRowKeys, record.id),
                  );
                } else {
                  pageManageStore.updateExpandedRowKeys(
                    expandedRowKeys.filter((id) => id !== record.id),
                  );
                }
              },
            }}
            rowSelection={{
              selectedRowKeys: localState.selectedRowKeys,
              onChange: (selectedRowKeys) => {
                localState.selectedRowKeys = selectedRowKeys;
              },
            }}
            columns={[
              {
                dataIndex: 'name',
                title: '页面名称',
                render: (text, record) => (
                  <div className="inline-block">
                    <div className="flex items-center gap-0.5">
                      <a
                        className="text-primary"
                        href={`${history.location.pathname}?${qs.stringify({
                          pageId: record.id,
                        })}`}
                        target="_blank"
                        rel="noreferrer"
                      >
                        {text}
                      </a>

                      <ClickableText
                        className="text-content"
                        onClick={() => {
                          pageManageStore.openPage({
                            id: addingId,
                            name: `页面${size(pageStore.pages) + 1}`,
                            status: PageStatus.UNPUBLISHED,
                            parentId: record.id,
                            url: record.url
                              ? `${record.url}/page-${
                                  size(record.children) + 1
                                }`
                              : undefined,
                            platform: PagePlatform.PC,
                          });
                        }}
                      >
                        <Tooltip title="增加下级">
                          <PlusCircleOutlined />
                        </Tooltip>
                      </ClickableText>

                      <ClickableText
                        onClick={() =>
                          pageManageStore.openPage(record).subscribe()
                        }
                      >
                        <Tooltip title="修改基本信息">
                          <EditOutlined />
                        </Tooltip>
                      </ClickableText>

                      <ClickableText
                        onClick={() => {
                          Modal.confirm({
                            title: '是否删除页面？',
                            content: record.name,
                            onOk: () => {
                              pageManageStore.deletePage(record.id).subscribe();
                            },
                          });
                        }}
                        className="text-error"
                      >
                        <Tooltip title="删除">
                          <DeleteOutlined />
                        </Tooltip>
                      </ClickableText>
                    </div>
                  </div>
                ),
              },
              {
                dataIndex: 'url',
                title: 'URL',
                render: (value: string, record) => {
                  let valid = false;

                  const { parentId } = record;

                  if (parentId === '-1') {
                    valid = true;
                  } else {
                    const parent = pageStore.pages[parentId!];

                    if (
                      parent &&
                      parent.url != null &&
                      value != null &&
                      value.startsWith(parent.url)
                    ) {
                      valid = true;
                    }
                  }

                  return value ? (
                    <Tag color={valid ? undefined : 'error'}>{value}</Tag>
                  ) : (
                    <span className="text-error">未设置</span>
                  );
                },
              },
              {
                dataIndex: 'platform',
                title: '平台',
                align: 'center',
                width: 80,
                render: (value: keyof typeof language.pagePlatform) =>
                  language.pagePlatform[value],
              },
              {
                dataIndex: 'status',
                title: '发布状态',
                align: 'center',
                width: 160,
                render: (value: PageStatus, record) => {
                  const pageStatusText =
                    language.pageStatus[value ?? PageStatus.UNPUBLISHED];

                  return (
                    <div className="flex justify-center gap-1">
                      <Tag className="mr-0" style={{ width: 63 }}>
                        <code className="text-xs">
                          {record.publishedModelMd5 != null
                            ? record.publishedModelMd5?.slice(0, 7)
                            : '未知'}
                        </code>
                      </Tag>

                      {pageStatusText}

                      <Tooltip title="去发布页">
                        <a
                          href={`/web?pageId=${record.id}`}
                          target="_blank"
                          rel="noreferrer"
                          className={
                            [
                              PageStatus.PUBLISHED,
                              PageStatus.ROLLBACK,
                            ].includes(value)
                              ? undefined
                              : classNames(
                                  'text-disabled',
                                  css`
                                    pointer-events: none;
                                  `,
                                )
                          }
                        >
                          <EyeOutlined />
                        </a>
                      </Tooltip>
                    </div>
                  );
                },
              },
              {
                dataIndex: 'isDrafting',
                title: '草稿状态',
                align: 'center',
                width: 160,
                render: (isDrafting: boolean, record) => {
                  let tagColor: LiteralUnion<
                    PresetColorType | PresetStatusColorType,
                    string
                  > = 'default';

                  if (record.draftModelMd5 != null) {
                    if (record.draftModelMd5 === record.publishedModelMd5) {
                      tagColor = 'success';
                    } else {
                      tagColor = 'error';
                    }
                  }

                  return (
                    <div className="flex justify-center gap-1">
                      <Tag
                        color={tagColor}
                        className="mr-0"
                        style={{ width: 62 }}
                      >
                        <code className="text-xs">
                          {record.draftModelMd5 != null
                            ? record.draftModelMd5?.slice(0, 7)
                            : '未知'}
                        </code>
                      </Tag>

                      {isDrafting ? '编辑中' : '已发布'}

                      <Tooltip title="查看模型">
                        <ClickableText
                          className="text-primary"
                          onClick={() => {
                            pageManageStore.openPageModel(record).subscribe();
                          }}
                        >
                          <DatabaseOutlined
                            onClick={() => {
                              pageManageStore.openPageModel(record).subscribe();
                            }}
                          />
                        </ClickableText>
                      </Tooltip>
                    </div>
                  );
                },
              },
            ]}
            dataSource={dataSource}
            pagination={false}
            loading={pageManageStore.streamStore.getPending(
              'fetchPageTreePending',
            )}
            rowKey="id"
          />

          <PageDialog />

          <PageModelDialog
            pageModel={pageManageStore.pageModelOpen}
            onCancel={() => pageManageStore.closePageModel()}
            onSave={(model) => {
              pageStore
                .savePageModel(pageManageStore.pageModelOpen!.id, model)
                .subscribe(() => {
                  window.location.reload();
                });
            }}
          />
        </div>
      </FlexWrapper>
    </>
  );
});
