import Central from '@gongzu/core/common/Central';
import { BaseStoresContext } from '@gongzu/core/contexts/store-contexts';
import { Spin } from 'antd';
import { configure } from 'mobx';
import { observer } from 'mobx-react';
import qs from 'qs';
import React from 'react';
import { useLocation } from 'react-use';
import {
  loggerStore,
  messageStore,
  pageManageStore,
  pageStore,
  sessionStore,
  streamStore,
} from '../config/container';
import '../style.scss';
import Console from './Console';
import { PageManageStoreContext } from './contexts';
import Home from './Home';
import { useNotificationEffect } from './hooks';

configure({
  isolateGlobalState: true,
});

export default observer(() => {
  const location = useLocation();

  const { pageId } = React.useMemo<{ pageId?: string }>(
    () =>
      location.search
        ? qs.parse(location.search, { ignoreQueryPrefix: true })
        : { pageId: undefined },
    [location.search],
  );

  React.useEffect(() => {
    window.dispatchEvent(new Event('resize'));
    sessionStore.fetchLogin().subscribe();
  }, []);

  useNotificationEffect(loggerStore);

  if (sessionStore.login == null) {
    return (
      <Central>
        <Spin />
      </Central>
    );
  }

  return (
    <>
      <BaseStoresContext.Provider
        value={{
          streamStore,
          loggerStore,
          messageStore,
          sessionStore,
          pageStore,
        }}
      >
        <PageManageStoreContext.Provider value={pageManageStore}>
          {pageId ? <Console pageId={pageId} /> : <Home />}
        </PageManageStoreContext.Provider>
      </BaseStoresContext.Provider>
    </>
  );
});
