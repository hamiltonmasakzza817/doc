import { Router } from '@gongzu/core/types/engine';
import get from 'lodash-es/get';
import qs from 'qs';

const router: Router = {
  location: {
    href: window.location.href,
    pathname: window.location.pathname,
    origin: window.location.origin,
  },
  searchParams:
    qs.parse(get(window, 'location.search'), { ignoreQueryPrefix: true }) ?? {},
  navigateTo: (url, mode) => {},
};

export default router;
