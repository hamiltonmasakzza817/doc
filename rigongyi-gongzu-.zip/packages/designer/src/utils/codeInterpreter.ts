import { CodeInterpreter } from '@gongzu/core/types/engine';

const codeInterpreter: CodeInterpreter = (code, context) => {
  // eslint-disable-next-line @typescript-eslint/no-implied-eval
  const func = new Function(`{ return ${code} };`);
  return func().call(
    {},
    ...context.map(([, value]) => value),
  );
};

export default codeInterpreter;
