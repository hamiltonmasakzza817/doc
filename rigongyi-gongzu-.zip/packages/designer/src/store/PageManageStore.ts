import api from '@gongzu/core/config/api';
import { createService } from '@gongzu/core/config/service';
import LoggerStore from '@gongzu/core/stores/LoggerStore';
import PageStore from '@gongzu/core/stores/PageStore';
import StreamStore from '@gongzu/core/stores/StreamStore';
import { IdTreeNode, Page } from '@gongzu/core/types/entities';
import concat from 'lodash-es/concat';
import uniq from 'lodash-es/uniq';

import { action, makeObservable, observable, runInAction } from 'mobx';
import { from, of } from 'rxjs';
import { mergeMap, tap } from 'rxjs/operators';
import { addingId } from '../config/constants';

class PageManageStore {
  idTree: IdTreeNode[] = [];

  expandedRowKeys: string[] = [];

  pageOpen: Page | null = null;

  pageModelOpen: Page | null = null;

  constructor(
    readonly pageStore: PageStore,
    readonly loggerStore: LoggerStore,
    readonly streamStore: StreamStore,
  ) {
    makeObservable(this, {
      idTree: observable.ref,
      expandedRowKeys: observable.ref,
      pageOpen: observable.ref,
      pageModelOpen: observable.ref,
      updateExpandedRowKeys: action,
      init: action,
      fetchPageTree: action,
      openPage: action,
      closePage: action,
      openPageModel: action,
      closePageModel: action,
      savePage: action,
      deletePage: action,
    });
  }

  updateExpandedRowKeys(expandedRowKeys: string[]) {
    this.expandedRowKeys = expandedRowKeys;
  }

  init() {
    return this.streamStore.fromStream(this.fetchPageTree());
  }

  fetchPageTree() {
    return this.streamStore.fromStream(
      this.pageStore.fetchTree().pipe(
        tap((n) =>
          runInAction(() => {
            this.idTree = n.idTree;
          }),
        ),
      ),
      'fetchPageTreePending',
    );
  }

  openPage(page: Page) {
    if (page.id === addingId) {
      this.pageOpen = page;
      return of(page);
    }

    return this.streamStore.fromStream(
      this.pageStore.fetchPage({ id: page.id }, 'draft').pipe(
        tap((page1) => {
          runInAction(() => {
            this.pageOpen = page1;
          });
        }),
      ),
      'openPage',
    );
  }

  closePage() {
    this.pageOpen = null;
  }

  openPageModel(page: Page) {
    return this.streamStore.fromStream(
      this.pageStore.fetchPage({ id: page.id }, 'draft').pipe(
        tap((n) =>
          runInAction(() => {
            this.pageModelOpen = n;
          }),
        ),
      ),
    );
  }

  closePageModel() {
    this.pageModelOpen = null;
  }

  savePage(page: Page) {
    const id = page.id === addingId ? null : page.id;

    const params = {
      name: page.name,
      url: page.url,
      platform: page.platform,
      parentId: page.parentId,
    };

    const service = createService();

    return this.streamStore.fromStream(
      from(
        id == null
          ? service.post(api.page.save, params)
          : service.put(api.page.update(id), params),
      ).pipe(
        tap(() => {
          this.loggerStore.success('保存成功');
          if (page.parentId !== '-1') {
            this.updateExpandedRowKeys(
              uniq(concat(this.expandedRowKeys, page.parentId!)),
            );
          }
          this.closePage();
        }),
        mergeMap(() => this.fetchPageTree()),
      ),
      'savePage',
    );
  }

  deletePage(id: string) {
    return this.streamStore.fromStream(
      from(createService().delete(api.page.remove(id))).pipe(
        tap(() => {
          this.loggerStore.success('删除成功');
        }),
        mergeMap(() => this.fetchPageTree()),
      ),
    );
  }

  publishBatch(ids: string[]) {
    return this.streamStore.fromStream(
      from(createService().post(api.page.publishBatch, ids)).pipe(
        tap(() => {
          this.loggerStore.success('发版成功');
        }),
        mergeMap(() => this.fetchPageTree()),
      ),
      'publishBatch',
    );
  }
}

export default PageManageStore;
