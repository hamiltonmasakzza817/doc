import classNames from 'classnames';
import React from 'react';

export default function Dot(props: { className?: string; size?: number }) {
  const { size, className } = props;

  return (
    <div
      style={{
        width: size || 10,
        height: size || 10,
      }}
      className={classNames('inline-block rounded-full', className)}
    />
  );
}
