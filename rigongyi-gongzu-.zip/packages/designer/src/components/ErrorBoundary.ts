import { notification } from 'antd';
import React from 'react';

class ErrorBoundaryDesktop extends React.Component {
  componentDidCatch(error: Error) {
    notification.error({
      message: '错误',
      description: error.message,
    });
    this.forceUpdate();
  }

  render() {
    return this.props.children;
  }
}

export default ErrorBoundaryDesktop;
