import { CodeEditorProps } from '@gongzu/core/types/comps-common';
import { editor } from 'monaco-editor';
import React from 'react';
import MonacoEditor, { MonacoDiffEditor } from 'react-monaco-editor';

export default function CodeEditor(props: CodeEditorProps) {
  const {
    onChange,
    value,
    original,
    diff = false,
    language,
    height = 300,
    width,
    readOnly = false,
    editorDidMount,
  } = props;

  const editorProps = {
    height: `${height}`,
    width,
    theme: 'vs-dark',
    options: {
      lineNumbers: 'off' as editor.LineNumbersType,
      minimap: {
        enabled: false,
      },
      readOnly,
    },
    language,
    onChange,
    value: value?.toString() ?? '',
    editorDidMount,
  };

  if (diff) {
    return <MonacoDiffEditor {...editorProps} original={original} />;
  }

  return <MonacoEditor {...editorProps} />;
}
