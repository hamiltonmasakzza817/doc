import classNames from 'classnames';
import React from 'react';

export default function ClickableText(
  props: React.HTMLAttributes<HTMLDivElement>,
) {
  const { className, ...divProps } = props;

  return (
    <div
      {...divProps}
      className={classNames(
        'inline-block cursor-pointer whitespace-nowrap',
        className,
      )}
    >
      {props.children}
    </div>
  );
}
