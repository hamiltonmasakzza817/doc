const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const MiniCssExtractPlugin = require('mini-css-extract-plugin');
const CssMinimizerPlugin = require('css-minimizer-webpack-plugin');
const TerserPlugin = require('terser-webpack-plugin');
const MonacoWebpackPlugin = require('monaco-editor-webpack-plugin');
const _ = require('lodash');
const webpack = require('webpack');
const packageInfo = require('./package.json');
require('dotenv').config();

const entry = {
  index: './src/designer/index',
};

module.exports = (env) => {
  const output = path.resolve(__dirname, 'dist');

  const { development } = env;

  const { CDN_DOMAIN = 'https://static.gongzu.info', VERSION = packageInfo.version } = process.env;

  const publicPath = development
    ? '/designer/'
    : `${CDN_DOMAIN}/gongzu/${VERSION}/gongzu-designer/`;

  return {
    mode: development ? 'development' : 'production',
    entry,
    output: {
      filename: 'static/[name].[contenthash].js',
      path: output,
      publicPath,
      clean: true,
    },
    resolve: {
      extensions: ['.ts', '.tsx', '.js', '.jsx'],
      alias: {
        '@gongzu/core': path.resolve(__dirname, '..', 'core/src'),
      },
    },
    externals: {
      react: 'React',
      'react-dom': 'ReactDOM',
      mobx: 'mobx',
      'mobx-react': 'mobxReact',
    },
    module: {
      rules: [
        {
          test: /\.[j|t]sx?$/,
          loader: 'babel-loader',
          options: {
            rootMode: 'upward',
          },
          exclude: /node_modules/,
        },
        {
          test: /\.scss$/,
          use: [
            MiniCssExtractPlugin.loader,
            'css-loader',
            {
              loader: 'postcss-loader',
              options: {
                postcssOptions: {
                  plugins: ['autoprefixer'],
                },
              },
            },
            'sass-loader',
          ],
        },
        {
          test: /\.css$/,
          use: [
            MiniCssExtractPlugin.loader,
            'css-loader',
            {
              loader: 'postcss-loader',
              options: {
                postcssOptions: {
                  plugins: ['tailwindcss'],
                },
              },
            },
          ],
        },
        {
          test: /\.(png|jpe?g|gif|svg|ico)(\?.*)?$/,
          use: [
            {
              loader: 'file-loader',
              options: {
                limit: 100,
                name: 'static/[name].[hash:7].[ext]',
              },
            },
          ],
        },
      ],
    },

    devServer: {
      port: 1079,
      hot: false,
      liveReload: false,
      allowedHosts: ['dev.gongzu.info'],
      static: false
    },

    plugins: _.concat(
      new MonacoWebpackPlugin({
        languages: [
          'json',
          'java',
          'javascript',
          'typescript',
          'less',
          'scss',
          'sass',
          'css',
          'sql',
          'markdown',
        ],
        filename: 'static/[name].worker.[contenthash].js',
      }),

      _.keys(entry).map(
        (entryName) =>
          new HtmlWebpackPlugin({
            template: './src/index.html',
            chunks: [entryName],
            filename: `${entryName}.html`,
            templateParameters: {
              publicPath,
              cdnDomain: CDN_DOMAIN,
            },
          }),
      ),

      new MiniCssExtractPlugin({
        ignoreOrder: true,
        filename: 'static/[name].[contenthash].css',
      }),

      new webpack.DefinePlugin({
        NODE_ENV: JSON.stringify(process.env),
        VERSION: JSON.stringify(VERSION),
      }),
    ),

    devtool: development ? 'source-map' : false,

    optimization: {
      minimize: !development,
      chunkIds: development ? 'named' : 'deterministic',
      // chunkIds: 'named',
      minimizer: [
        new TerserPlugin({
          parallel: true,
          terserOptions: {
            // https://github.com/webpack-contrib/terser-webpack-plugin#terseroptions
          },
        }),
        new CssMinimizerPlugin(),
      ],
    },
  };
};
