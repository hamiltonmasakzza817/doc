/** @type {import("tailwindcss").Config} */
const colors = {
  white: '#fff',
  black: '#000',
  content: 'rgba(0,0,0,.85)',
  primary: '#1890ff',
  secondary: 'rgba(0,0,0,.45)',
  success: '#52c41a',
  error: '#ff4d4f',
  disabled: 'rgba(0,0,0,.25)',
  heading: 'rgba(0,0,0,.85)',
  warning: '#faad14',
  border: '#d9d9d9',
};

module.exports = {
  content: ['./src/**/*.{html,js,ts,tsx}', '../core/**/*.{js,ts,tsx}'],
  theme: {
    extend: {
      colors,
      backgroundColor: colors,
    },
    spacing: {
      0: '0',
      0.5: '4px',
      1: '8px',
      1.5: '12px',
      2: '16px',
      2.5: '20px',
      3: '24px',
      3.5: '28px',
      4: '32px',
      5: '40px',
      6: '48px',
      8: '64px',
    },
  },
  plugins: [],
};
