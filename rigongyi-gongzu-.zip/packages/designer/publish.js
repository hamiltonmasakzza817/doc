const publish = require('../../publish');
const path = require('path');
const packageInfo = require('./package.json');

publish('gongzu-designer', packageInfo.version, path.resolve(__dirname, 'dist'));
