import CompContext from '@gongzu/core/common/CompContext';
import CustomCompNav from '@gongzu/core/common/CustomCompNav';
import { EngineStoresContext } from '@gongzu/core/contexts/store-contexts';
import React from 'react';

export function useCustomElement(id?: string) {
  const { engineModelStore } = React.useContext(EngineStoresContext);

  const compContext = React.useContext(CompContext);

  if (id == null) {
    return null;
  }

  const comp = engineModelStore.customs[id];

  let el;

  if (comp) {
    if (compContext.inDesigner) {
      el = React.createElement(CustomCompNav, { config: comp });
    } else {
      el = React.createElement(compContext.factoryComp, {
        config: comp,
      });
    }
  } else {
    el = null;
  }

  return el;
}
