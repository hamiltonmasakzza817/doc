import { configService } from '@gongzu/core/config/service';
import Taro from '@tarojs/taro';
import { axios } from 'taro-axios';
import './style/style.scss';
import './style/weui/weui-taro.less';

configService({
  // @ts-ignore
  axios,
  getHeader: () => ({
    cookie: Taro.getStorageSync('taro-cookie'),
  }),
  tapResponse: (resp) => {
    const cookie = resp.headers['Set-Cookie'];

    if (cookie != null) {
      Taro.setStorageSync('taro-cookie', cookie);
    }
  },
});
