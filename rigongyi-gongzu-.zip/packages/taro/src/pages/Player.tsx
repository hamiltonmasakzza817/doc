import {
  BaseStoresContext,
  EngineStoresContext,
  PlayerStoreContext,
} from '@gongzu/core/contexts/store-contexts';
import EngineStore from '@gongzu/core/engine/EngineStore';
import PlayerStore from '@gongzu/core/stores/PlayerStore';
import Taro, { ENV_TYPE } from '@tarojs/taro';
import EventEmitter from 'eventemitter3';
import get from 'lodash-es/get';
import set from 'lodash-es/set';
import { configure } from 'mobx';
import { observer } from 'mobx-react';
import React, { useState } from 'react';
import Loading from '../components/Loading';
import TaroPortal from '../components/TaroPortal';
import {
  loggerStore,
  messageStore,
  pageStore,
  sessionStore,
  streamStore,
} from '../container';
import codeInterpreter from '../utils/codeInterpreter';
import { getRouter } from '../utils/router';

configure({
  isolateGlobalState: true,
});

const Player = observer((props: { playerStore: PlayerStore }) => {
  const { playerStore } = props;

  const { engineStore } = playerStore;

  const [loading, setLoading] = useState(true);

  React.useEffect(() => {
    playerStore.init().subscribe(() => {
      setLoading(false);
    });
  }, []);

  if (loading) {
    return <Loading>页面初始化...</Loading>;
  }

  return (
    <EngineStoresContext.Provider
      value={{
        engineStore,
        ...engineStore,
      }}
    >
      <PlayerStoreContext.Provider value={playerStore}>
        <TaroPortal />
      </PlayerStoreContext.Provider>
    </EngineStoresContext.Provider>
  );
});

export default observer((props: { pageUrls: Record<string, string> }) => {
  let pathname = Taro.getCurrentInstance().router?.path;

  if (pathname) {
    pathname = pathname.replace(/\?\S*$/, '');
  }

  const pageUrl = pathname ? get(props.pageUrls, pathname) : null;

  let pageId: string | undefined;

  if (Taro.getEnv() === ENV_TYPE.WEB) {
    pageId =
      new URLSearchParams(window.location.search).get('pageId') || undefined;
  }

  const [playerStore, setPlayerStore] = React.useState<PlayerStore>();

  React.useEffect(() => {
    let eventEmitter = get(Taro.getCurrentInstance().app, 'eventEmitter');
    if (eventEmitter == null) {
      eventEmitter = new EventEmitter();
      set(Taro.getCurrentInstance(), 'app.eventEmitter', eventEmitter);
    }

    if (pageId || pageUrl) {
      pageStore
        .fetchPage({ id: pageId, url: pageUrl || undefined }, 'publish')
        .subscribe((page) => {
          const pageEngineStore = new EngineStore(
            {
              page,
              params: {
                windowInfo: Taro.getWindowInfo ? Taro.getWindowInfo() : {},
              },
              portal: null,
              eventEmitter,
            },
            loggerStore,
            messageStore,
            codeInterpreter,
            getRouter(),
          );
          setPlayerStore(new PlayerStore(pageEngineStore, streamStore));
        });
    }
  }, []);

  if (playerStore == null) {
    return <Loading>获取模型..</Loading>;
  }

  return (
    <body>
      <BaseStoresContext.Provider
        value={{
          streamStore,
          loggerStore,
          messageStore,
          sessionStore,
          pageStore,
        }}
      >
        <Player playerStore={playerStore} key={pathname} />
      </BaseStoresContext.Provider>
    </body>
  );
});
