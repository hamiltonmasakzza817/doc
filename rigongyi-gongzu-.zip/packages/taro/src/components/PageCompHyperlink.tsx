import React from 'react';
import { useParseValue } from '@gongzu/core/common/hooks';
import { CompProps } from '@gongzu/core/common/types';
import { PageCompHyperlinkConfig } from '@gongzu/core/types/comps-page';
import { Text } from '@tarojs/components';
import Taro from '@tarojs/taro';
import classNames from 'classnames';
import { observer } from 'mobx-react';

export default observer((props: CompProps<PageCompHyperlinkConfig>) => {
  const { className, rawProps, innerRef, config, onClick, ...rest } = props;

  const parseValue = useParseValue();

  return (
    <Text
      className={classNames('text-primary', className)}
      onClick={(e) => {
        if (onClick) {
          onClick(e);
          return;
        }
        const url = parseValue(config.url);
        if (url != null) {
          Taro.navigateTo({ url });
        }
      }}
      ref={innerRef}
      {...rest}
      {...rawProps}
    >
      {parseValue(config.text)}
    </Text>
  );
});
