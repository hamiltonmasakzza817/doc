import PageCompCustom from '@gongzu/core/gongzu-components/PageCompCustom';
import PageCompDefault from '@gongzu/core/gongzu-components/PageCompDefault';
import PageCompPagePortal from '@gongzu/core/gongzu-components/PageCompPagePortal';
import PageCompRepeat from '@gongzu/core/gongzu-components/PageCompRepeat';
import { PageCompConfig, PageCompType } from '@gongzu/core/types/comps-page';
import { TaroCompConfig, TaroCompType } from '@gongzu/core/types/comps-taro';
import PageCompHyperlink from './PageCompHyperlink';
import PageCompPage from './PageCompPage';
import PageCompText from './PageCompText';
import TaroCompBooleanItem from './TaroCompBooleanItem';
import TaroCompBottomContainer from './TaroCompBottomContainer';
import TaroCompButton from './TaroCompButton';
import TaroCompCheckbox from './TaroCompCheckbox';
import TaroCompContainer from './TaroCompContainer';
import TaroCompDatePicker from './TaroCompDatePicker';
import TaroCompDatePickerItem from './TaroCompDatePickerItem';
import TaroCompForm from './TaroCompForm';
import TaroCompImage from './TaroCompImage';
import TaroCompInput from './TaroCompInput';
import TaroCompInputItem from './TaroCompInputItem';
import TaroCompList from './TaroCompList';
import TaroCompListItem from './TaroCompListItem';
import TaroCompModal from './TaroCompModal';
import TaroCompNavContainer from './TaroCompNavContainer';
import TaroCompRadio from './TaroCompRadio';
import TaroCompScrollView from './TaroCompScrollView';
import TaroCompSelect from './TaroCompSelect';
import TaroCompSelectItem from './TaroCompSelectItem';
import TaroCompSlider from './TaroCompSlider';
import TaroCompSwiper from './TaroCompSwiper';
import TaroCompSwitch from './TaroCompSwitch';
import TaroCompTextArea from './TaroCompTextArea';

export default (config: PageCompConfig | TaroCompConfig) => {
  switch (config.type) {
    case PageCompType.PAGE: {
      return PageCompPage;
    }

    case PageCompType.PAGE_PORTAL: {
      return PageCompPagePortal;
    }

    case PageCompType.REPEAT: {
      return PageCompRepeat;
    }

    case PageCompType.TEXT: {
      return PageCompText;
    }

    case PageCompType.HYPERLINK: {
      return PageCompHyperlink;
    }

    case TaroCompType.BUTTON: {
      return TaroCompButton;
    }

    case TaroCompType.CONTAINER: {
      return TaroCompContainer;
    }

    case TaroCompType.IMAGE: {
      return TaroCompImage;
    }

    case TaroCompType.INPUT: {
      return TaroCompInput;
    }

    case TaroCompType.SELECT: {
      return TaroCompSelect;
    }

    case TaroCompType.SELECT_ITEM: {
      return TaroCompSelectItem;
    }

    case TaroCompType.DATE_PICKER: {
      return TaroCompDatePicker;
    }

    case TaroCompType.DATE_PICKER_ITEM: {
      return TaroCompDatePickerItem;
    }

    case TaroCompType.RADIO: {
      return TaroCompRadio;
    }

    case TaroCompType.FORM: {
      return TaroCompForm;
    }

    case TaroCompType.SWITCH: {
      return TaroCompSwitch;
    }

    case TaroCompType.LIST_ITEM: {
      return TaroCompListItem;
    }

    case TaroCompType.LIST: {
      return TaroCompList;
    }

    case TaroCompType.TEXT_AREA: {
      return TaroCompTextArea;
    }

    case TaroCompType.CHECKBOX: {
      return TaroCompCheckbox;
    }

    case PageCompType.CUSTOM: {
      return PageCompCustom;
    }

    case TaroCompType.MODAL: {
      return TaroCompModal;
    }

    case TaroCompType.SLIDER: {
      return TaroCompSlider;
    }

    case TaroCompType.SWIPER: {
      return TaroCompSwiper;
    }

    case TaroCompType.SCROLL_VIEW: {
      return TaroCompScrollView;
    }

    case TaroCompType.INPUT_ITEM: {
      return TaroCompInputItem;
    }

    case TaroCompType.BOOLEAN_ITEM: {
      return TaroCompBooleanItem;
    }

    case TaroCompType.NAV_CONTAINER: {
      return TaroCompNavContainer;
    }

    case TaroCompType.BOTTOM_CONTAINER: {
      return TaroCompBottomContainer;
    }

    default:
      return PageCompDefault;
  }
};
