import { CompProps } from '@gongzu/core/common/types';
import { TaroCompBottomContainerConfig } from '@gongzu/core/types/comps-taro';
import { View } from '@tarojs/components';
import classNames from 'classnames';

import { observer } from 'mobx-react';
import React from 'react';
import { gongzuTaroBem } from './constants';

const bottomContainerBlock = gongzuTaroBem('bottom-container');

export default observer((props: CompProps<TaroCompBottomContainerConfig>) => {
  const { config, children, className, rawProps, innerRef, style, ...rest } = props;

  return (
    <View
      className={classNames(className, bottomContainerBlock())}
      ref={innerRef}
      style={style}
      {...rest}
    >
      <View>{children}</View>

      {(style == null || style.bottom == null) && (
        <View style={{ height: 'env(safe-area-inset-bottom)' }} />
      )}
    </View>
  );
});
