import { CompProps } from '@gongzu/core/common/types';
import {
  TaroCompInputItemConfig,
  TaroCompType,
} from '@gongzu/core/types/comps-taro';
import { View } from '@tarojs/components';
import { observer } from 'mobx-react';
import React from 'react';
import TaroCompInput from './TaroCompInput';
import TaroCompListItem from './TaroCompListItem';

export default observer((props: CompProps<TaroCompInputItemConfig>) => {
  const { config, innerRef, rawProps, ...rest } = props;

  return (
    <View ref={innerRef} {...rest}>
      <TaroCompListItem
        config={{
          ...config,
          useLabel: true,
          type: TaroCompType.LIST_ITEM,
        }}
        rawProps={{}}
      >
        <TaroCompInput
          config={{ ...config, type: TaroCompType.INPUT }}
          rawProps={rawProps}
        />
      </TaroCompListItem>
    </View>
  );
});
