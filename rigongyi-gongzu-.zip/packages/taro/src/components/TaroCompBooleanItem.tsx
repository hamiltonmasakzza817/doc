import { CompProps } from '@gongzu/core/common/types';
import useFormItem from '@gongzu/core/common/useFormItem';
import {
  TaroCompBooleanItemConfig,
  TaroCompType,
} from '@gongzu/core/types/comps-taro';
import { View } from '@tarojs/components';
import classNames from 'classnames';
import { observer } from 'mobx-react';
import React from 'react';
import TaroCompListItem from './TaroCompListItem';
import TaroCompSwitch from './TaroCompSwitch';

export default observer((props: CompProps<TaroCompBooleanItemConfig>) => {
  const { config, innerRef, rawProps, ...rest } = props;

  return (
    <View ref={innerRef} {...rest}>
      {
        useFormItem(config, ({ bind }) => {
          return (
            <TaroCompListItem
              config={{
                ...config,
                arrow: config.compType === 'check',
                type: TaroCompType.LIST_ITEM,
              }}
              rawProps={{}}
              onClick={() => {
                bind.onChange(!bind.value);
              }}
            >
              {config.compType === 'check' ? (
                <View
                  className={classNames('weui2-icon-check', {
                    hidden: !bind.value,
                  })}
                />
              ) : (
                <TaroCompSwitch
                  config={{
                    ...config,
                    color: config.switchColor,
                    type: TaroCompType.SWITCH,
                  }}
                  rawProps={{}}
                />
              )}
            </TaroCompListItem>
          );
        }).content
      }
    </View>
  );
});
