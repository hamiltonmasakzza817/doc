import { useParseValue } from '@gongzu/core/common/hooks';
import { CompProps } from '@gongzu/core/common/types';
import { TaroCompImageConfig } from '@gongzu/core/types/comps-taro';
import { Image } from '@tarojs/components';
import { observer } from 'mobx-react';
import React from 'react';
import defaultImage from '../resource/default-image.png';

export default observer((props: CompProps<TaroCompImageConfig>) => {
  const { config, innerRef, rawProps, ...rest } = props;

  const parseValue = useParseValue();

  return (
    <Image
      src={parseValue(config.src) || defaultImage}
      mode={config.mode || 'scaleToFill'}
      lazyLoad={config.lazyLoad}
      ref={innerRef}
      {...rest}
      {...rawProps}
    />
  );
});
