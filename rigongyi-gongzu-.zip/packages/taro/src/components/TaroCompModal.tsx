import CompContext from '@gongzu/core/common/CompContext';
import { useActionDispatcher, useParseValue } from '@gongzu/core/common/hooks';
import { CompProps } from '@gongzu/core/common/types';
import { EngineStoresContext } from '@gongzu/core/contexts/store-contexts';
import { TaroCompModalConfig } from '@gongzu/core/types/comps-taro';
import { View } from '@tarojs/components';
import get from 'lodash-es/get';
import { observer } from 'mobx-react';
import React from 'react';
import HalfScreenDialog from './HalfScreenDialog';
import Modal from './Modal';

export default observer((props: CompProps<TaroCompModalConfig>) => {
  const { config, innerRef, rawProps, children, className, style, ...rest } = props;

  const { engineStore } = React.useContext(EngineStoresContext);

  const compContext = React.useContext(CompContext);

  const dispatchCancel = useActionDispatcher(config.onCancel);

  const dispatchOk = useActionDispatcher(config.onOk);

  const parseValue = useParseValue();

  const visiblePathname = `_system.modalOpen.${config.id}`;

  const visible = Boolean(get(compContext.state, visiblePathname));

  if (compContext.inDesigner) {
    return (
      <View className={className} ref={innerRef} {...rest}>
        {children}
      </View>
    );
  }

  const modalProps = {
    visible,
    onOk: (event) => {
      event.preventDefault();
      event.stopPropagation();

      dispatchOk();
    },
    onCancel: (event) => {
      event.preventDefault();
      event.stopPropagation();
      dispatchCancel();
      engineStore.updateData(`${visiblePathname}`, false);
    },
    title: parseValue(config.title),
    noFooter: config.noFooter,
    cancelText: parseValue(config.cancelText),
    okText: parseValue(config.okText),
    maskClosable: config.maskClosable,
    style
  };

  if (config.modalType === 'half-screen') {
    return <HalfScreenDialog {...modalProps}>{children}</HalfScreenDialog>;
  }

  return <Modal {...modalProps}>{children}</Modal>;
});
