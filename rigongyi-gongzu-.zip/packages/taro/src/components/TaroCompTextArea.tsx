import { CompProps } from '@gongzu/core/common/types';
import useFormItem from '@gongzu/core/common/useFormItem';
import { TaroCompTextAreaConfig } from '@gongzu/core/types/comps-taro';
import { Textarea, View } from '@tarojs/components';
import classNames from 'classnames';
import size from 'lodash-es/size';
import { observer } from 'mobx-react';
import React from 'react';
import { gongzuTaroBem } from './constants';

const textareaBlock = gongzuTaroBem('textarea');

export default observer((props: CompProps<TaroCompTextAreaConfig>) => {
  const { config, className, innerRef, rawProps, ...rest } = props;

  const maxlength = config.maxlength || (rawProps.maxlength as number);

  return useFormItem(config, ({ bind, placeholder }) => {
    return (
      <View
        className={classNames(className, textareaBlock())}
        ref={innerRef}
        {...rest}
      >
        <Textarea
          placeholder={placeholder}
          maxlength={maxlength}
          value={bind.value}
          onInput={(e) => {
            bind.onChange(e.detail.value);
          }}
          ref={innerRef}
          {...rawProps}
        />
        {maxlength > -1 && (
          <View className={classNames(textareaBlock('counter'))}>
            {size(bind.value)}/{maxlength}
          </View>
        )}
      </View>
    );
  }).content;
});
