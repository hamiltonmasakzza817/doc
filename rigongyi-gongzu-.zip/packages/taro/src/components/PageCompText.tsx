import { useParseValue } from '@gongzu/core/common/hooks';
import { CompProps } from '@gongzu/core/common/types';
import { PageCompTextConfig } from '@gongzu/core/types/comps-page';
import { Text } from '@tarojs/components';
import classNames from 'classnames';
import { observer } from 'mobx-react';
import React from 'react';

export default observer((props: CompProps<PageCompTextConfig>) => {
  const { config, style, rawProps, className, innerRef, ...rest } = props;

  const parseValue = useParseValue();

  const text = parseValue(config.text);

  const disabled = parseValue(config.disabled);

  const { textType } = config;

  const content = text?.toString() || '--';

  let textTypeClassName: string | undefined;

  if (disabled) {
    textTypeClassName = 'text-disabled';
  } else if (textType) {
    textTypeClassName = `text-${textType === 'danger' ? 'error' : textType}`;
  }

  return (
    <Text
      className={classNames(className, textTypeClassName, 'gz-page-comp-text')}
      ref={innerRef}
      style={style}
      {...rest}
      {...rawProps}
    >
      {content}
    </Text>
  );
});
