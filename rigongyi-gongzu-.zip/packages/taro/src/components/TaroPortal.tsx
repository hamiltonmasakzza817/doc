import Central from '@gongzu/core/common/Central';
import CompContext from '@gongzu/core/common/CompContext';
import FactoryComp from '@gongzu/core/common/FactoryComp';
import useCompPortal from '@gongzu/core/common/useCompPortal';
import { EngineStoresContext } from '@gongzu/core/contexts/store-contexts';
import { View } from '@tarojs/components';
import Taro from '@tarojs/taro';
import compact from 'lodash-es/compact';
import { observer } from 'mobx-react';
import React from 'react';
import { useMessageEffects } from '../hooks/useMessageEffects';
import { useNotificationEffects } from '../hooks/useNotificationEffects';
import compFactory from './compFactory';
import Loading from './Loading';
import TaroCompProxy from './TaroCompProxy';

const SideEffects = observer(() => {
  useMessageEffects();
  useNotificationEffects();
  return <></>;
});

export default observer(() => {
  const { engineModelStore, engineStore } =
    React.useContext(EngineStoresContext);

  React.useEffect(() => {
    if (Taro.getEnv() === 'WEB') {
      engineStore.loadCssResources();
    }
  }, []);

  const compContext = useCompPortal(engineStore);

  const { elements, modals } = engineModelStore;

  return elements != null && elements.length > 0 ? (
    <CompContext.Provider
      value={{
        ...compContext,
        pageIds: compact([engineStore.page.id]),
        factory: compFactory,
        proxyComp: TaroCompProxy,
        factoryComp: FactoryComp,
        wrapperComp: View,
        viewportQuerySelector: `[data-viewport="${engineStore.page.id}"]`,
        state: engineStore.engineRuntimeStore.state,
        loading: <Loading />,
      }}
    >
      <>
        <View id="top-tips" />

        {elements[0] != null && <FactoryComp config={elements[0]} key="1" />}

        {modals.map((modal) => (
          <FactoryComp config={modal} key={modal.id} />
        ))}

        <SideEffects />
      </>
    </CompContext.Provider>
  ) : (
    <Central>
      <View>无权限或未加载到数据</View>
    </Central>
  );
});
