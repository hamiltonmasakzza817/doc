import { View } from '@tarojs/components';
import Taro from '@tarojs/taro';
import classNames from 'classnames';
import uniqueId from 'lodash-es/uniqueId';
import { observer, useLocalObservable } from 'mobx-react';
import React, { ReactNode } from 'react';
import ReactDOM from 'react-dom';
import { gongzuTaroBem, weuiBem } from './constants';

const topTipsBem = weuiBem('toptips');
const gztTopTipsBem = gongzuTaroBem('toptips');

const TopTips = observer(
  (props: { className?: string; content?: ReactNode; warn?: boolean }) => {
    const { content, warn, className } = props;

    const localState = useLocalObservable<{
      active: boolean;
      visible: boolean;
      content?: ReactNode;
    }>(() => ({
      active: false,
      visible: false,
    }));

    const timer = React.useRef<number | null>(null);

    React.useEffect(() => {
      let transitionTimer;

      if (localState.content) {
        localState.visible = true;

        Taro.nextTick(() => {
          localState.active = true;
        });
      } else {
        localState.active = false;

        transitionTimer = window.setTimeout(() => {
          localState.visible = false;
        }, 200);
      }

      return () => {
        if (transitionTimer) {
          clearTimeout(transitionTimer);
          transitionTimer = null;
        }
      };
    }, [localState.content]);

    React.useEffect(() => {
      localState.content = content;

      if (content) {
        timer.current = window.setTimeout(() => {
          localState.content = undefined;
        }, 3000);
      }
    }, [content]);

    React.useEffect(
      () => () => {
        if (timer.current) {
          clearTimeout(timer.current);
        }
      },
      [],
    );

    return (
      <View
        className={classNames(
          className,
          gztTopTipsBem({ active: localState.active }),
          topTipsBem({ warn }),
        )}
        style={{
          display: localState.visible ? 'block' : 'none',
          opacity: localState.active ? 1 : 0
        }}
      >
        {content}
      </View>
    );
  },
);

export default TopTips;

export function showTopTips(content: ReactNode, warn = false) {
  ReactDOM.render(
    <TopTips content={content} warn={warn} key={uniqueId()} />,
    document.getElementById('top-tips'),
  );
}
