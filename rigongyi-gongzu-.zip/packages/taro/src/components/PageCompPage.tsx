import { css, Global } from '@emotion/react';
import { useActionDispatcher, useParseValue } from '@gongzu/core/common/hooks';
import { CompProps } from '@gongzu/core/common/types';
import { EngineStoresContext } from '@gongzu/core/contexts/store-contexts';
import { PageCompPageConfig } from '@gongzu/core/types/comps-page';
import { View } from '@tarojs/components';
import Taro from '@tarojs/taro';
import { observer } from 'mobx-react';
import React, { useEffect } from 'react';
import Loading from './Loading';

export default observer((props: CompProps<PageCompPageConfig>) => {
  const { config, innerRef, children, rawProps, ...rest } = props;

  const { engineModelStore } = React.useContext(EngineStoresContext);

  const dispatchOnLoad = useActionDispatcher(config.onLoad);
  const dispatchDispose = useActionDispatcher(config.onDispose);

  const parseValue = useParseValue();

  useEffect(() => {
    dispatchOnLoad();
    return () => {
      dispatchDispose();
    };
  }, []);

  return (
    <View ref={innerRef} {...rest}>
      {Taro.getEnv() === 'WEB' && (
        <Global styles={css(engineModelStore.globalStyle)} />
      )}
      {children}
      {!!parseValue(config.loading) && <Loading />}
    </View>
  );
});
