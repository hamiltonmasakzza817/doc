import { ITouchEvent, Text, View } from '@tarojs/components';
import classNames from 'classnames';
import isEmpty from 'lodash-es/isEmpty';
import { runInAction } from 'mobx';
import { observer, useLocalObservable } from 'mobx-react';
import React, { ReactNode, useEffect } from 'react';
import { gongzuTaroBem, weuiBem } from './constants';

const weuiDialog = weuiBem('dialog');
const gongzuModal = gongzuTaroBem('modal');

export default observer(
  (props: {
    visible: boolean;
    className?: string;
    title: string;
    noFooter?: boolean;
    maskClosable?: boolean;

    okText?: string;
    cancelText?: string;

    onOk: (event: ITouchEvent) => void;
    onCancel: (event: ITouchEvent) => void;

    children?: ReactNode;
  }) => {
    const {
      visible,
      className,
      title,
      noFooter,
      okText,
      cancelText,
      onOk,
      onCancel,
      children,
      maskClosable,
    } = props;

    const localState = useLocalObservable(() => ({
      mount: false,
      active: false,
      visible: false,
    }));

    useEffect(() => {
      let timer;

      if (visible) {
        localState.visible = true;

        timer = setTimeout(() => {
          runInAction(() => {
            localState.mount = true;
            localState.active = true;
          });
        }, 50);
      } else {
        localState.active = false;

        timer = setTimeout(() => {
          runInAction(() => {
            localState.visible = false;
          });
        }, 200);
      }

      return () => {
        if (timer) {
          clearTimeout(timer);
          timer = null;
        }
      };
    }, [visible]);

    return (
      <View
        className={classNames(
          className,
          gongzuModal({ active: localState.active }),
        )}
        style={{ display: localState.visible ? 'block' : 'none' }}
      >
        {localState.mount && (
          <>
            <View
              className={classNames(weuiBem('mask')())}
              onClick={maskClosable ? onCancel : undefined}
            />

            <View className={classNames(weuiDialog())}>
              {title != null && (
                <View className={classNames(weuiDialog('hd'))}>
                  <Text className={classNames(weuiDialog('title'))}>
                    {title}
                  </Text>
                </View>
              )}

              <View className={classNames(weuiDialog('bd'))}>{children}</View>

              {!noFooter && (
                <View className={classNames(weuiDialog('ft'))}>
                  {!isEmpty(cancelText) && (
                    <Text
                      className={classNames(
                        weuiDialog('btn', { default: true }),
                      )}
                      onClick={onCancel}
                    >
                      {cancelText}
                    </Text>
                  )}

                  <Text
                    className={classNames(weuiDialog('btn', { primary: true }))}
                    onClick={onOk}
                  >
                    {okText || '确定'}
                  </Text>
                </View>
              )}
            </View>
          </>
        )}
      </View>
    );
  },
);
