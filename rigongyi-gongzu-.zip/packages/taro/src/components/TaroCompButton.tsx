import { useActionDispatcher, useParseValue } from '@gongzu/core/common/hooks';
import { CompProps } from '@gongzu/core/common/types';
import { TaroCompButtonConfig } from '@gongzu/core/types/comps-taro';
import { Button } from '@tarojs/components';
import classNames from 'classnames';
import { observer } from 'mobx-react';
import React from 'react';

export default observer((props: CompProps<TaroCompButtonConfig>) => {
  const { config, rawProps, className, innerRef, ...rest } = props;

  const parseValue = useParseValue();

  const dispatchOnGetPhoneNumber = useActionDispatcher(config.onGetPhoneNumber);

  return (
    <Button
      className={classNames(className, {
        'after-none': config.border === false,
      })}
      type={config.buttonType}
      size={config.size}
      plain={config.plain}
      disabled={parseValue(config.disabled)}
      loading={parseValue(config.loading)}
      onGetPhoneNumber={(e) => dispatchOnGetPhoneNumber(e.detail)}
      openType={config.openType}
      ref={innerRef}
      {...rest}
      {...rawProps}
    >
      {parseValue(config.text)}
    </Button>
  );
});
