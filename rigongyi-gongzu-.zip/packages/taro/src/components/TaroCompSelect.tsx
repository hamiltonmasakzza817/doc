import CompContext from '@gongzu/core/common/CompContext';
import { getOptions } from '@gongzu/core/common/form-helpers';
import { CompProps } from '@gongzu/core/common/types';
import useFormItem from '@gongzu/core/common/useFormItem';
import { TaroCompSelectConfig } from '@gongzu/core/types/comps-taro';
import { Picker } from '@tarojs/components';
import findIndex from 'lodash-es/findIndex';
import get from 'lodash-es/get';
import { observer } from 'mobx-react';
import React from 'react';

export default observer((props: CompProps<TaroCompSelectConfig>) => {
  const { config, children, innerRef, rawProps, ...rest } = props;

  const compContext = React.useContext(CompContext);

  const options = getOptions(config.options, compContext);

  return useFormItem(config, ({ bind, disabled, readOnly }) => {
    const currentIndex = findIndex(options, (opt) => opt.value === bind.value);

    return (
      <Picker
        mode="selector"
        range={options.map((opt) => opt.label || '')}
        value={currentIndex}
        onChange={(e) => {
          bind.onChange(get(options, `[${e.detail.value}].value`));
        }}
        ref={innerRef}
        disabled={compContext.inDesigner || disabled || readOnly}
        {...rest}
        {...rawProps}
      >
        {children}
      </Picker>
    );
  }).content;
});
