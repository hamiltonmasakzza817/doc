import CompContext from '@gongzu/core/common/CompContext';
import { CompProps } from '@gongzu/core/common/types';
import useFormItem from '@gongzu/core/common/useFormItem';
import { TaroCompDatePickerConfig } from '@gongzu/core/types/comps-taro';
import { Picker } from '@tarojs/components';
import { observer } from 'mobx-react';
import React, { useContext } from 'react';

export default observer((props: CompProps<TaroCompDatePickerConfig>) => {
  const { config, innerRef, rawProps, children, ...rest } = props;

  const compContext = useContext(CompContext);

  return useFormItem(config, ({ bind, disabled, readOnly }) => (
    <Picker
      onChange={(e) => {
        bind.onChange(e.detail.value);
      }}
      value={bind.value}
      mode={config.mode || 'date'}
      start={config.mode !== 'time' ? config.start : undefined}
      end={config.mode !== 'time' ? config.end : undefined}
      disabled={compContext.inDesigner || disabled || readOnly}
      ref={innerRef}
      {...rest}
      {...rawProps}
    >
      {children}
    </Picker>
  )).content;
});
