import CompContext from '@gongzu/core/common/CompContext';
import { useCustomElement, useParseValue } from '@gongzu/core/common/hooks';
import { CompProps } from '@gongzu/core/common/types';
import { TaroCompContainerConfig } from '@gongzu/core/types/comps-taro';
import { View } from '@tarojs/components';
import classNames from 'classnames';
import { observer } from 'mobx-react';
import React from 'react';
import Loading from './Loading';

export default observer((props: CompProps<TaroCompContainerConfig>) => {
  const { config, innerRef, className, id, rawProps, children, ...rest } =
    props;

  const parseValue = useParseValue();

  const loading = parseValue(config.loading);

  let customElement = useCustomElement(config.renderCompId);

  const compContext = React.useContext(CompContext);

  if (compContext.inDesigner && customElement) {
    customElement = (
      <div
        style={{
          height: 80,
          outline: '1px dashed',
          outlineOffset: -1,
        }}
        className={classNames('flex justify-center items-center', className)}
      >
        {customElement}
      </div>
    );
  }

  return (
    <View
      data-id={id}
      className={classNames(className, { relative: loading })}
      ref={innerRef}
      {...rest}
      {...rawProps}
    >
      {customElement || children}
      {loading && <Loading />}
    </View>
  );
});
