import Taro from '@tarojs/taro';
import { observer } from 'mobx-react';
import React from 'react';

export default observer((props: { children?: string }) => {
  React.useEffect(() => {
    Taro.showLoading({
      title: props.children || '加载中',
    });

    return () => Taro.hideLoading();
  }, []);

  return <></>;
});
