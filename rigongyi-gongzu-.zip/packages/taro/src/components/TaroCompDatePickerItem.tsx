import CompContext from '@gongzu/core/common/CompContext';
import { CompProps } from '@gongzu/core/common/types';
import { parseValueByPathname } from '@gongzu/core/common/utils';
import {
  TaroCompDatePickerItemConfig,
  TaroCompType,
} from '@gongzu/core/types/comps-taro';
import { View } from '@tarojs/components';
import { observer } from 'mobx-react';
import React, { useContext } from 'react';
import TaroCompDatePicker from './TaroCompDatePicker';
import TaroCompListItem from './TaroCompListItem';

export default observer((props: CompProps<TaroCompDatePickerItemConfig>) => {
  const { config, innerRef, rawProps, children, ...rest } = props;

  const compContext = useContext(CompContext);

  const value = parseValueByPathname({ expression: config.value, compContext });

  return (
    <View ref={innerRef} {...rest}>
      <TaroCompDatePicker
        config={{ ...config, type: TaroCompType.DATE_PICKER }}
        rawProps={rawProps}
      >
        <TaroCompListItem
          config={{
            ...config,
            contentText: (value as string) ?? '--',
            arrow: true,
            type: TaroCompType.LIST_ITEM,
          }}
          rawProps={{}}
        />
      </TaroCompDatePicker>
    </View>
  );
});
