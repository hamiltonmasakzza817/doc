import CompContext from '@gongzu/core/common/CompContext';
import { getOptions } from '@gongzu/core/common/form-helpers';
import { CompProps } from '@gongzu/core/common/types';
import useFormItem from '@gongzu/core/common/useFormItem';
import { gzdnBem } from '@gongzu/core/config/constants';
import { TaroCompCheckboxConfig } from '@gongzu/core/types/comps-taro';
import { Checkbox, CheckboxGroup, View } from '@tarojs/components';
import classNames from 'classnames';
import size from 'lodash-es/size';
import { observer } from 'mobx-react';
import React from 'react';

export default observer((props: CompProps<TaroCompCheckboxConfig>) => {
  const { config, className, rawProps, innerRef, ...rest } = props;

  const compContext = React.useContext(CompContext);

  const options = getOptions(config.options, compContext);

  const control = useFormItem(config, ({ bind, disabled }) => (
    <CheckboxGroup
      className={className}
      ref={innerRef}
      onChange={bind.onChange}
      {...rest}
      {...rawProps}
    >
      {options.map((option, index) => (
        <Checkbox
          key={index}
          value={option.value}
          checked={option.value === bind.value}
          disabled={disabled || option.disabled}
        >
          {option.label}
        </Checkbox>
      ))}
    </CheckboxGroup>
  )).content;

  if (compContext.inDesigner && size(options) === 0) {
    return (
      <View
        className={classNames(className, gzdnBem('empty-block')())}
        ref={innerRef}
        {...rest}
      >
        没有备选项
      </View>
    );
  }

  return control;
});
