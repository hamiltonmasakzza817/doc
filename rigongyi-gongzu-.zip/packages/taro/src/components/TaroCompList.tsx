import CompContext from '@gongzu/core/common/CompContext';
import { useParseValue } from '@gongzu/core/common/hooks';
import { CompProps } from '@gongzu/core/common/types';
import { TaroCompListConfig } from '@gongzu/core/types/comps-taro';
import { View } from '@tarojs/components';
import classNames from 'classnames';
import { cloneDeep } from 'lodash-es';
import isEmpty from 'lodash-es/isEmpty';
import set from 'lodash-es/set';
import { observer } from 'mobx-react';
import React, { useContext } from 'react';
import { gongzuTaroBem } from './constants';

const listBlock = gongzuTaroBem('list');

export default observer((props: CompProps<TaroCompListConfig>) => {
  const { config, className, children, innerRef, rawProps, ...rest } = props;

  const compContext = useContext(CompContext);

  const parseValue = useParseValue();

  const title = parseValue(config.title);

  const formLayout = cloneDeep(compContext.formLayout);

  if (config.headWidth != null) {
    set(formLayout, 'label.width', config.headWidth);
  }

  return (
    <View
      className={classNames(
        className,
        listBlock({
          card: config.card,
        }),
      )}
      ref={innerRef}
      {...rest}
      {...rawProps}
    >
      <CompContext.Provider
        value={{
          ...compContext,
          formLayout,
        }}
      >
        {!isEmpty(title) && (
          <View className={classNames(listBlock('title'))}>{title}</View>
        )}
        <View className={classNames(listBlock('body'))}>{children}</View>
      </CompContext.Provider>
    </View>
  );
});
