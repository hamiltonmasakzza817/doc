import { useActionDispatcher, useParseValue } from '@gongzu/core/common/hooks';
import { CompProps } from '@gongzu/core/common/types';
import { toPx } from '@gongzu/core/common/utils';
import { TaroCompScrollViewConfig } from '@gongzu/core/types/comps-taro';
import { ScrollView } from '@tarojs/components';
import Taro, { nextTick } from '@tarojs/taro';
import classNames from 'classnames';
import { runInAction } from 'mobx';
import { observer, useLocalObservable } from 'mobx-react';
import React, { useEffect } from 'react';
import Loading from './Loading';

export default observer((props: CompProps<TaroCompScrollViewConfig>) => {
  const {
    config,
    innerRef,
    className,
    id,
    rawProps,
    children,
    style,
    ...rest
  } = props;

  const parseValue = useParseValue();

  const loading = parseValue(config.loading);

  const scrollTop = parseValue(config.scrollTop);

  const flexGrowBottom = parseValue(config.flexGrowBottom);

  const dispatchOnScroll = useActionDispatcher(config.onScroll);

  const dispatchOnRefresherPulling = useActionDispatcher(
    config.onRefresherPulling,
  );

  const localState = useLocalObservable<{
    scrollTop: number;
    height: string | number;
  }>(() => ({
    scrollTop: 0,
    height: 0,
  }));

  useEffect(() => {
    if (flexGrowBottom != null) {
      nextTick(() => {
        Taro.createSelectorQuery()
          .select(`#scroll-view-${id}`)
          .boundingClientRect((rect) => {
            if (rect) {
              runInAction(() => {
                localState.height = `calc(100vh - ${rect.top}px - ${toPx(
                  flexGrowBottom,
                )})`;
                localState.scrollTop = scrollTop;
              });
            }
          })
          .exec();
      });
    } else {
      runInAction(() => {
        localState.scrollTop = scrollTop;
      });
    }
  }, [id, flexGrowBottom]);

  return (
    <ScrollView
      data-id={id}
      id={`scroll-view-${id}`}
      className={classNames(id, className, { relative: loading })}
      ref={innerRef}
      showScrollbar={config.hideScrollbar !== true}
      enhanced={config.hideScrollbar === true}
      scrollY={config.scrollY}
      scrollX={config.scrollX}
      scrollTop={localState.scrollTop}
      onScroll={(e) => {
        dispatchOnScroll(e.detail);
      }}
      {...rest}
      style={{
        ...style,
        height: flexGrowBottom != null ? localState.height : style?.height,
      }}
      refresherEnabled={config.refresherEnabled}
      onRefresherPulling={dispatchOnRefresherPulling}
      {...rawProps}
    >
      {children}
      {loading && <Loading />}
    </ScrollView>
  );
});
