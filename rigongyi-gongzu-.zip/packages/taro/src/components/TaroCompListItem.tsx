import CompContext from '@gongzu/core/common/CompContext';
import { useParseValue } from '@gongzu/core/common/hooks';
import { CompProps } from '@gongzu/core/common/types';
import useFormItem from '@gongzu/core/common/useFormItem';
import { TaroCompListItemConfig } from '@gongzu/core/types/comps-taro';
import { Label, Text, View } from '@tarojs/components';
import Taro from '@tarojs/taro';
import classNames from 'classnames';
import get from 'lodash-es/get';
import isEmpty from 'lodash-es/isEmpty';
import { observer } from 'mobx-react';
import React, { useContext } from 'react';
import { useCustomElement } from '../utils';
import { gongzuTaroBem } from './constants';

const listItemBlock = gongzuTaroBem('list-item');

export default observer((props: CompProps<TaroCompListItemConfig>) => {
  const { config, className, innerRef, rawProps, children, ...rest } = props;

  const compContext = useContext(CompContext);

  const headWidth =
    get(compContext, 'formLayout.label.width') ?? config.headWidth;

  const parseValue = useParseValue();

  const head = useCustomElement(config.head);

  const wrapper = config.useLabel && Taro.getEnv() === 'WEAPP' ? Label : View;

  return useFormItem(config, ({ required, error }) => {
    return React.createElement(
      wrapper,
      {
        className: classNames(
          className,
          listItemBlock({
            clickable: config.arrow,
            required,
            'has-error': !isEmpty(error),
          }),
        ),
        ref: innerRef,
        ...rest,
        ...rawProps,
      },
      <>
        <View
          className={classNames(listItemBlock('head'))}
          style={{
            width: headWidth ? `${headWidth}px` : undefined,
          }}
        >
          {head != null ? (
            head
          ) : (
            <Text>{parseValue(config.headText) ?? '--'}</Text>
          )}
        </View>

        <View
          className={classNames(
            listItemBlock('content', {
              'align-right': config.contentAlign === 'right',
              'align-center': config.contentAlign === 'center',
            }),
          )}
        >
          {children != null ? (
            children
          ) : (
            <Text className={classNames(listItemBlock('content-text'))}>
              {parseValue(config.contentText)}
            </Text>
          )}

          {config.arrow && (
            <View
              className={classNames(listItemBlock('arrow'), 'weui2-icon-arrow')}
            />
          )}
        </View>

        {!isEmpty(error) && (
          <View className={classNames(listItemBlock('error'))}>
            <Text>{error}</Text>
          </View>
        )}
      </>,
    );
  }).content;
});
