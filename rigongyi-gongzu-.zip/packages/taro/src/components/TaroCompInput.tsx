import { CompProps } from '@gongzu/core/common/types';
import useFormItem from '@gongzu/core/common/useFormItem';
import { TaroCompInputConfig } from '@gongzu/core/types/comps-taro';
import { Input } from '@tarojs/components';
import { observer } from 'mobx-react';
import React from 'react';

export default observer((props: CompProps<TaroCompInputConfig>) => {
  const { config, innerRef, rawProps, style, ...rest } = props;

  const inputStyle = { ...style };

  return useFormItem(config, ({ bind, pathname, placeholder, disabled }) => {
    return (
      <Input
        key={config.inputType || 'text'}
        name={pathname || ''}
        type={config.inputType}
        password={config.password}
        placeholder={placeholder}
        className="flex-1"
        value={bind.value}
        onInput={(e) => {
          bind.onChange(e.detail.value);
        }}
        disabled={disabled}
        style={inputStyle}
        ref={innerRef}
        {...rest}
        {...rawProps}
      />
    );
  }).content;
});
