import CompContext from '@gongzu/core/common/CompContext';
import { findOptionName, getOptions } from '@gongzu/core/common/form-helpers';
import { CompProps } from '@gongzu/core/common/types';
import { parseValueByPathname } from '@gongzu/core/common/utils';
import {
  TaroCompSelectItemConfig,
  TaroCompType,
} from '@gongzu/core/types/comps-taro';
import { View } from '@tarojs/components';
import { observer } from 'mobx-react';
import React from 'react';
import TaroCompListItem from './TaroCompListItem';
import TaroCompSelect from './TaroCompSelect';

export default observer((props: CompProps<TaroCompSelectItemConfig>) => {
  const { config, children, innerRef, rawProps, ...rest } = props;

  const compContext = React.useContext(CompContext);

  const options = getOptions(config.options, compContext);

  const value = parseValueByPathname({
    expression: config.value,
    compContext,
  }) as string;

  return (
    <View ref={innerRef} {...rest}>
      <TaroCompSelect
        config={{
          ...config,
          type: TaroCompType.SELECT,
        }}
        rawProps={rawProps}
      >
        <TaroCompListItem
          config={{
            ...config,
            arrow: true,
            type: TaroCompType.LIST_ITEM,
            contentText:
              (findOptionName(value, options, 'label') as string) ?? '--',
          }}
          rawProps={{}}
        />
      </TaroCompSelect>
    </View>
  );
});
