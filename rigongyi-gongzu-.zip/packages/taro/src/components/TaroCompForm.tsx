import CompContext from '@gongzu/core/common/CompContext';
import { CompProps } from '@gongzu/core/common/types';
import { parsePathname } from '@gongzu/core/common/utils';
import { TaroCompFormConfig } from '@gongzu/core/types/comps-taro';
import { View } from '@tarojs/components';
import classNames from 'classnames';
import compact from 'lodash-es/compact';
import concat from 'lodash-es/concat';
import { observer } from 'mobx-react';
import React from 'react';
import { weuiBem } from './constants';

const formBlock = weuiBem('form');

export default observer((props: CompProps<TaroCompFormConfig>) => {
  const { config, className, innerRef, rawProps, children, ...rest } = props;

  const compContext = React.useContext(CompContext);

  const { pathname } = parsePathname({
    expression: config.value,
    compContext,
  });

  return (
    <CompContext.Provider
      value={{
        ...compContext,
        dataBinding: {
          ...compContext.dataBinding,
          pathname,
          pathnames: compact(
            concat(pathname, compContext.dataBinding.pathnames),
          ),
        },
      }}
    >
      <View
        className={classNames(formBlock())}
        ref={innerRef}
        {...rest}
        {...rawProps}
      >
        {children}
      </View>
    </CompContext.Provider>
  );
});
