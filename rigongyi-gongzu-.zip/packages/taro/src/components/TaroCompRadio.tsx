import CompContext from '@gongzu/core/common/CompContext';
import { getOptions } from '@gongzu/core/common/form-helpers';
import { CompProps } from '@gongzu/core/common/types';
import useFormItem from '@gongzu/core/common/useFormItem';
import { gzdnBem } from '@gongzu/core/config/constants';
import { TaroCompRadioConfig } from '@gongzu/core/types/comps-taro';
import { Radio, RadioGroup, View } from '@tarojs/components';
import classNames from 'classnames';
import size from 'lodash-es/size';
import { observer } from 'mobx-react';
import React from 'react';

export default observer((props: CompProps<TaroCompRadioConfig>) => {
  const { config, innerRef, className, rawProps, ...rest } = props;

  const compContext = React.useContext(CompContext);

  const options = getOptions(config.options, compContext);

  const control = useFormItem(config, ({ bind, disabled }) => {
    return (
      <View ref={innerRef} {...rest}>
        <RadioGroup
          className={className}
          onChange={bind.onChange}
          {...rawProps}
        >
          {options.map((option, index) => (
            <Radio
              key={index}
              value={option.value}
              checked={option.value === bind.value}
              disabled={disabled || option.disabled}
            >
              {option.label}
            </Radio>
          ))}
        </RadioGroup>
      </View>
    );
  }).content;

  if (compContext.inDesigner && size(options) === 0) {
    return (
      <View
        className={classNames(className, gzdnBem('empty-block')())}
        ref={innerRef}
        {...rest}
      >
        没有备选项
      </View>
    );
  }

  return control;
});
