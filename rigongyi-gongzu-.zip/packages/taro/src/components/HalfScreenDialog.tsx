import { ITouchEvent, Text, View } from '@tarojs/components';
import classNames from 'classnames';
import isEmpty from 'lodash-es/isEmpty';
import { runInAction } from 'mobx';
import { observer, useLocalObservable } from 'mobx-react';
import React, { CSSProperties, ReactNode, useEffect } from 'react';
import { gongzuTaroBem, weuiBem } from './constants';

const weuiHalfScreenDialogBlock = weuiBem('half-screen-dialog');
const gztHalfScreenDialogBlock = gongzuTaroBem('half-screen-dialog');

export default observer(
  (props: {
    visible: boolean;
    className?: string;
    title: ReactNode | string;
    noFooter?: boolean;
    okText?: string;
    cancelText?: string;
    onOk: (event: ITouchEvent) => void;
    onCancel: (event: ITouchEvent) => void;
    children?: ReactNode;
    maskClosable?: boolean;
    style?: CSSProperties;
  }) => {
    const {
      visible,
      className,
      title,
      noFooter,
      okText,
      cancelText,
      onOk,
      onCancel,
      children,
      maskClosable,
    } = props;

    const style = props.style ?? {};

    const localState = useLocalObservable(() => ({
      mount: false,
      active: false,
      visible: false,
    }));

    useEffect(() => {
      let timer;

      if (visible) {
        localState.visible = true;

        timer = setTimeout(() => {
          runInAction(() => {
            localState.mount = true;
            localState.active = true;
          });
        }, 50);
      } else {
        localState.active = false;

        timer = setTimeout(() => {
          runInAction(() => {
            localState.visible = false;
          });
        }, 200);
      }

      return () => {
        if (timer) {
          clearTimeout(timer);
          timer = null;
        }
      };
    }, [visible]);

    return (
      <View
        className={classNames(
          className,
          gztHalfScreenDialogBlock({ active: localState.active }),
        )}
        style={{ display: localState.visible ? 'block' : 'none' }}
      >
        <View
          className={classNames(weuiBem('mask')())}
          onClick={maskClosable ? onCancel : undefined}
        />

        <View
          className={classNames(
            weuiHalfScreenDialogBlock({
              show: localState.active,
            }),
          )}
          style={{
            ...style,
            maxHeight: style.height != null ? 'none' : undefined,
          }}
        >
          {localState.mount && (
            <>
              {title != null && (
                <View className={classNames(weuiHalfScreenDialogBlock('hd'))}>
                  <View
                    className={classNames(
                      weuiHalfScreenDialogBlock('hd__side'),
                    )}
                  >
                    <View
                      className={classNames(weuiBem('btn_icon')())}
                      onClick={onCancel}
                    >
                      <View
                        className={classNames(weuiBem('icon-close-thin')())}
                      />
                    </View>
                  </View>

                  <View
                    className={classNames(
                      weuiHalfScreenDialogBlock('hd__main'),
                    )}
                  >
                    <Text
                      className={classNames(weuiHalfScreenDialogBlock('title'))}
                    >
                      {title}
                    </Text>
                  </View>
                </View>
              )}

              <View className={classNames(weuiHalfScreenDialogBlock('bd'))}>
                {children}
              </View>

              {!noFooter && (
                <View className={classNames(weuiHalfScreenDialogBlock('ft'))}>
                  <View
                    className={classNames(
                      weuiHalfScreenDialogBlock('btn-area'),
                    )}
                  >
                    {!isEmpty(cancelText) && (
                      <View
                        className={classNames(
                          weuiBem('btn')({ default: true }),
                        )}
                        onClick={onCancel}
                      >
                        {cancelText}
                      </View>
                    )}

                    <View
                      className={classNames(weuiBem('btn')({ primary: true }))}
                      onClick={onOk}
                    >
                      {okText || '确定'}
                    </View>
                  </View>
                </View>
              )}
            </>
          )}
        </View>
      </View>
    );
  },
);
