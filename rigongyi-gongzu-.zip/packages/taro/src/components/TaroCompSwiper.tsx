import CompContext, { ICompContext } from '@gongzu/core/common/CompContext';
import {
  useCustomElement,
  useParseValue,
  useParseValueWithContext,
} from '@gongzu/core/common/hooks';
import rawPropsTaro, {
  rawPropsTaroCommon,
} from '@gongzu/core/common/raw-props-taro';
import { CompProps } from '@gongzu/core/common/types';
import { parsePathname, parseValueDeep } from '@gongzu/core/common/utils';
import {
  TaroCompSwiperConfig,
  TaroCompType,
} from '@gongzu/core/types/comps-taro';
import { Image, Swiper, SwiperItem, View } from '@tarojs/components';
import classNames from 'classnames';
import concat from 'lodash-es/concat';
import get from 'lodash-es/get';
import map from 'lodash-es/map';
import pick from 'lodash-es/pick';
import { observer } from 'mobx-react';
import React from 'react';
import { gongzuTaroBem } from './constants';

const swiperBem = gongzuTaroBem('swiper');

export default observer((props: CompProps<TaroCompSwiperConfig>) => {
  const { config, className, innerRef, rawProps, style, ...rest } = props;

  const compContext = React.useContext(CompContext);

  const parseValue = useParseValue();

  const parseValueWithContext = useParseValueWithContext();

  const { pathname } = parsePathname({
    expression: config.dataSource,
    compContext,
  });

  const dataSource = ((pathname && get(compContext.state, pathname)) ||
    []) as any[];

  const imageRawProps = pick(
    parseValueDeep({
      source: config.imageRawProps,
      compContext,
    }),
    concat(rawPropsTaroCommon, rawPropsTaro[TaroCompType.IMAGE]),
  );

  return (
    <View className={classNames(className, swiperBem())} {...rest}>
      <Swiper
        autoplay={config.autoplay}
        current={parseValue(config.current)}
        style={style}
        {...rawProps}
      >
        {map(dataSource, (item, index) => {
          const imageUrl = parseValueWithContext({
            expression: config.imageUrl,
            context: item,
          });

          const url = parseValueWithContext({
            expression: config.url,
            context: item,
          });

          let content: JSX.Element | null;

          const customElement = useCustomElement(config.element);

          if (customElement != null) {
            const pathnameCurrent = `${pathname}[${index}]`;
            const context = {
              ...compContext,
              dataBinding: {
                pathname: pathnameCurrent,
                pathnames: concat(
                  pathnameCurrent,
                  pathname,
                  compContext.dataBinding.pathnames,
                ),
              },
            } as ICompContext;

            content = (
              <CompContext.Provider value={context}>
                {customElement}
              </CompContext.Provider>
            );
          } else {
            const image = (
              <Image
                src={imageUrl}
                mode="center"
                className={classNames(swiperBem('image'))}
                {...imageRawProps}
              />
            );

            content = url ? <a href={url}>{image}</a> : image;
          }

          return <SwiperItem key={index}>{content}</SwiperItem>;
        })}
      </Swiper>

      {compContext.inDesigner && (
        <View className={classNames(swiperBem('mask'))} ref={innerRef} />
      )}
    </View>
  );
});
