import CompContext from '@gongzu/core/common/CompContext';
import { CompProps } from '@gongzu/core/common/types';
import { parseValueDeep } from '@gongzu/core/common/utils';
import { CompConfig } from '@gongzu/core/types/comps-common';
import assign from 'lodash-es/assign';
import isNumber from 'lodash-es/isNumber';
import transform from 'lodash-es/transform';
import { observer } from 'mobx-react';
import React from 'react';

function taroStyleTransformer(
  result: Record<string, unknown>,
  value: unknown,
  key: string,
) {
  // result[key] = isnumber(value) ? taro.pxtransform(value) : value;
  // eslint-disable-next-line no-param-reassign
  result[key] = isNumber(value) ? `${value}px` : value;
}

export default observer(
  (
    props: CompProps<CompConfig> & {
      el:
        | React.FunctionComponent<any>
        | React.ComponentClass<any, any>
        | string;
    },
  ) => {
    const { style: computedStyle, children, el, config, ...rest } = props;

    const compContext = React.useContext(CompContext);

    let style;

    if (computedStyle) {
      style = transform(computedStyle, taroStyleTransformer, {});
    }

    if (config.style) {
      const customStyle = parseValueDeep({
        source: config.style,
        compContext,
      });

      style = assign(style, transform(customStyle, taroStyleTransformer, {}));
    }

    return React.createElement(el, { style, config, ...rest }, children);
  },
);
