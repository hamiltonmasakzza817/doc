import { useParseValue } from '@gongzu/core/common/hooks';
import { CompProps } from '@gongzu/core/common/types';
import { TaroCompNavContainerConfig } from '@gongzu/core/types/comps-taro';
import { Text, View } from '@tarojs/components';
import Taro from '@tarojs/taro';
import classNames from 'classnames';
import { observer } from 'mobx-react';
import React from 'react';
import { gongzuTaroBem } from './constants';

const navContainerBlock = gongzuTaroBem('nav-container');

export default observer((props: CompProps<TaroCompNavContainerConfig>) => {
  const { config, className, innerRef, rawProps, children, ...rest } = props;

  const parseValue = useParseValue();

  return (
    <View
      className={classNames(className, navContainerBlock())}
      ref={innerRef}
      {...rest}
    >
      <View style={{ height: Taro.getWindowInfo ? Taro.getWindowInfo().statusBarHeight ?? 0 : 0 }} />

      {children != null ? (
        children
      ) : (
        <View className={classNames(navContainerBlock('bar-title'))}>
          <Text>{parseValue(config.navigationBarTitleText)}</Text>
        </View>
      )}
    </View>
  );
});
