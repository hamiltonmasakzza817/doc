import { CompProps } from '@gongzu/core/common/types';
import useFormItem from '@gongzu/core/common/useFormItem';
import { TaroCompSliderConfig } from '@gongzu/core/types/comps-taro';
import { Slider } from '@tarojs/components';
import { observer } from 'mobx-react';
import React from 'react';
import ReactDOM from 'react-dom';

export default observer((props: CompProps<TaroCompSliderConfig>) => {
  const { config, className, innerRef, rawProps, ...rest } = props;

  return useFormItem(config, ({ bind, disabled }) => (
    <Slider
      min={config.min ?? 0}
      max={config.min ?? 100}
      step={config.step ?? 10}
      disabled={disabled}
      value={bind.value}
      showValue
      onChange={(event) => {
        bind.onChange(event.detail.value);
      }}
      ref={(el) => {
        if (innerRef) {
          innerRef.current = ReactDOM.findDOMNode(el);
        }
      }}
      {...rest}
      {...rawProps}
    />
  )).content;
});
