import { useParseValue } from '@gongzu/core/common/hooks';
import { CompProps } from '@gongzu/core/common/types';
import useFormItem from '@gongzu/core/common/useFormItem';
import { TaroCompSwitchConfig } from '@gongzu/core/types/comps-taro';
import { Switch } from '@tarojs/components';
import { observer } from 'mobx-react';
import React from 'react';

export default observer((props: CompProps<TaroCompSwitchConfig>) => {
  const { config, innerRef, rawProps, ...rest } = props;

  const parseValue = useParseValue();

  return useFormItem(config, ({ bind, disabled }) => {
    return (
      <Switch
        checked={bind.value}
        onChange={bind.onChange}
        disabled={disabled}
        ref={innerRef}
        color={parseValue(config.color)}
        {...rest}
        {...rawProps}
      />
    );
  }).content;
});
