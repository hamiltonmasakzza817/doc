import { CodeInterpreter } from '@gongzu/core/types/engine';
import Taro from '@tarojs/taro';
import { Interpreter } from 'eval5';

const codeInterpreter: CodeInterpreter = (code, context) => {
  // eslint-disable-next-line @typescript-eslint/no-implied-eval
  const func = new Function(`{ return ${code} };`);
  return func().call({}, ...context.map(([, value]) => value));
};

const eval5CodeInterpreter: CodeInterpreter = (code, context) => {
  const interpreter = new Interpreter(
    context.reduce((acc, [key, value]) => {
      acc[key] = value;
      return acc;
    }, {}),
    {
      rootContext: window,
    },
  );

  const matched = code.match(/function\s(\S*)\((.*)\)/);

  const [, funcName, params] = matched as string[];

  const func = code.replace(`${funcName}(${params})`, `${funcName}()`);

  interpreter.evaluate(func);

  return interpreter.evaluate(`${funcName}()`);
};

export default Taro.getEnv() === 'WEB' ? codeInterpreter : eval5CodeInterpreter;
