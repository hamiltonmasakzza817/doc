import { Router } from '@gongzu/core/types/engine';
import Taro from '@tarojs/taro';
import transform from "lodash-es/transform";

function getSearchParams() {
  const params = Taro.getCurrentInstance()?.router?.params;
  if (params == null) {
    return {};
  }
  return transform(params, (result, value, key) => {
    result[key] = decodeURIComponent(value!);
  }, {});
}

export function getRouter(): Router {
  return {
    location: {
      pathname: Taro.getCurrentInstance()?.router?.path ?? '',
      href: '',
      origin: '',
    },
    searchParams: getSearchParams(),
    navigateTo: (url, mode) => {
      if (mode === 'replace') {
        Taro.redirectTo({ url });
      } else {
        Taro.navigateTo({ url });
      }
    },
  };
}
