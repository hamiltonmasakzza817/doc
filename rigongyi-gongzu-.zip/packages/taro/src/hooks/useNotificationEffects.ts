import { BaseStoresContext } from '@gongzu/core/contexts/store-contexts';
import { LoggerLevel, LoggerType } from '@gongzu/core/types/entities';
import Taro from '@tarojs/taro';
import React from 'react';
import { showTopTips } from '../components/TopTips';

export function useNotificationEffects() {
  const { loggerStore } = React.useContext(BaseStoresContext);

  React.useEffect(() => {
    const { current } = loggerStore;

    if (current) {
      const { level, message: msg, type } = current;

      switch (`${type}-${level}`) {
        case `${LoggerType.CONSOLE}-${LoggerLevel.INFO}`: {
          // eslint-disable-next-line no-console
          console.info(msg);
          break;
        }

        case `${LoggerType.CONSOLE}-${LoggerLevel.ERROR}`: {
          // eslint-disable-next-line no-console
          console.error(msg);
          break;
        }

        case `${LoggerType.CONSOLE}-${LoggerLevel.SUCCESS}`: {
          // eslint-disable-next-line no-console
          console.info(msg);
          break;
        }

        case `${LoggerType.MESSAGE}-${LoggerLevel.INFO}`: {
          showTopTips(msg);
          break;
        }

        case `${LoggerType.MESSAGE}-${LoggerLevel.ERROR}`: {
          showTopTips(msg, true);
          break;
        }

        case `${LoggerType.MESSAGE}-${LoggerLevel.SUCCESS}`: {
          showTopTips(msg);
          break;
        }

        case `${LoggerType.NOTIFICATION}-${LoggerLevel.INFO}`: {
          Taro.showToast({
            title: msg,
            icon: 'none',
          });
          break;
        }

        case `${LoggerType.NOTIFICATION}-${LoggerLevel.ERROR}`: {
          Taro.showToast({
            title: msg,
            icon: 'none',
          });
          break;
        }

        case `${LoggerType.NOTIFICATION}-${LoggerLevel.SUCCESS}`: {
          Taro.showToast({
            title: msg,
            icon: 'success',
          });
          break;
        }

        default:
          break;
      }

      loggerStore.hide();
    }
  }, [loggerStore.current]);
}
