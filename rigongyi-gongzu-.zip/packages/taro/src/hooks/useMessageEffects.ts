import {
  BaseStoresContext,
  EngineStoresContext,
} from '@gongzu/core/contexts/store-contexts';
import {
  MessageActionSheet,
  MessageConfirm,
  MessageExecCode,
  MessageNavigate,
  MessageType,
} from '@gongzu/core/stores/MessageStore';
import Taro from '@tarojs/taro';
import assign from 'lodash-es/assign';
import React from 'react';

export function useMessageEffects() {
  const { messageStore } = React.useContext(BaseStoresContext);
  const {
    engineStore: { codeInterpreter },
  } = React.useContext(EngineStoresContext);

  React.useEffect(() => {
    const message = messageStore.current;

    if (message) {
      switch (message.type) {
        case MessageType.CONFIRM: {
          const { title, resolve, reject } = message as MessageConfirm;

          Taro.showModal({
            title: '请选择',
            content: title,
            success: (res) => {
              if (res.confirm) {
                resolve();
              } else if (res.cancel) {
                reject();
              }
            },
          });

          break;
        }

        case MessageType.ACTION_SHEET: {
          const { params, resolve, reject } = message as MessageActionSheet;

          Taro.showActionSheet({
            ...params,
            success: (res) => {
              resolve(res.tapIndex);
            },
            fail: () => {
              reject();
            },
          }).catch((e) => {
            // eslint-disable-next-line no-console
            console.log(e);
          });
          break;
        }

        case MessageType.EXEC_CODE: {
          const { code, resolve, reject, params } = message as MessageExecCode;

          try {
            /* eslint-disable @typescript-eslint/naming-convention */
            const [
              state,
              _params,
              _context,
              _index,
              _pathname,
              _pathnames,
              utils,
            ] = params;
            /* eslint-enable @typescript-eslint/naming-convention */

            // const interpreter = new Interpreter(
            //   {
            //     state,
            //     _params,
            //     _context,
            //     _index,
            //     _pathname,
            //     _pathnames,
            //     utils: assign(utils, {
            //       Taro,
            //     }),
            //   },
            //   {
            //     rootContext: window,
            //   },
            // );
            //
            // const func = code.replace(
            //   'execAction(state, _params, _context, _index, _pathname, _pathnames, utils)',
            //   'execAction()',
            // );
            //
            // interpreter.evaluate(func);
            //
            // resolve(interpreter.evaluate(`execAction()`));

            resolve(
              codeInterpreter(code, [
                ['state', state],
                ['_params', _params],
                ['_context', _context],
                ['_index', _index],
                ['_pathname', _pathname],
                ['_pathnames', _pathnames],
                [
                  'utils',
                  assign(utils, {
                    Taro,
                  }),
                ],
              ]),
            );
          } catch (e) {
            // eslint-disable-next-line
            console.log('eval error', JSON.stringify(e));
            reject();
          }
          break;
        }

        case MessageType.NAVIGATE: {
          const { url } = message as MessageNavigate;
          Taro.navigateTo({ url });
          break;
        }

        default:
          break;
      }

      messageStore.receive(messageStore.current);
    }
  }, [messageStore.current]);
}
