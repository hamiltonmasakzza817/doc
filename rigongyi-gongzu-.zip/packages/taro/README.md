# `@gongzu/taro`

> gongzu taro 公共库，包含组件、通用的生产入口。

## 发布方法
package.json 修改版本号
```
npm run package
cd dist
npm run publish
```
## 发布 beta 版本的方法
```shell
npm run build
cd dist
npm dist-tag add @gongzu/core@<version> beta
npm publish --tag beta
```

